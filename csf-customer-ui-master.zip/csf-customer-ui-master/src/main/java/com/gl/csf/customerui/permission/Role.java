package com.gl.csf.customerui.permission;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 19/08/2017.
 */
public class Role {
  public static final String CUSTOMER = "ROLE_CUSTOMER";
  public static final String STAFF = "ROLE_STAFF";
}
