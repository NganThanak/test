package com.gl.csf.customerui.adapter.service.parameter;

import com.gl.csf.common.util.jersey.GenericListType;
import com.gl.csf.common.util.jersey.JerseyClientUtils;
import com.gl.csf.customerui.model.parameter.District;
import com.gl.csf.customerui.model.parameter.Township;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 16/08/2017.
 */
@Service
public class TownshipService {

  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public TownshipService(@Value("${endpoints.rest.parameter.township}") String baseUrl, RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  // TODO: Improve the performance by introducing the pagination here
  public List<Township> getTownships(District district) {
    Objects.requireNonNull(district);
    return restTemplate.exchange(baseUrl + "?districtid=" + district.getId(), HttpMethod.GET, null,
            new ParameterizedTypeReference<List<Township>>(){}).getBody();
  }

  public Optional<Township> getTownship(UUID townshipId) {
    Objects.requireNonNull(townshipId);
    
    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/" + townshipId, HttpMethod.GET, null,
              new ParameterizedTypeReference<Township>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
