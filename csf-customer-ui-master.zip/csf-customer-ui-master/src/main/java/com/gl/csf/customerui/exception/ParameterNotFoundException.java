package com.gl.csf.customerui.exception;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 30/09/2017.
 */
public class ParameterNotFoundException extends RuntimeException {
  public ParameterNotFoundException(String message){
    super(message);
  }

  public ParameterNotFoundException(String message, Throwable throwable){
    super(message, throwable);
  }
}
