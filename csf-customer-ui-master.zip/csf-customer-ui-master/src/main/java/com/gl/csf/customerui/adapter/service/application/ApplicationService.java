package com.gl.csf.customerui.adapter.service.application;


import com.gl.csf.customerui.adapter.service.parameter.BankService;
import com.gl.csf.customerui.adapter.service.parameter.DistrictService;
import com.gl.csf.customerui.adapter.service.parameter.StateService;
import com.gl.csf.customerui.adapter.service.parameter.TownshipService;
import com.gl.csf.customerui.exception.ParameterNotFoundException;
import com.gl.csf.customerui.model.application.*;
import com.gl.csf.customerui.model.command.SaveApplicationCommand;
import com.gl.csf.customerui.model.command.SubmitApplicationCommand;
import com.gl.csf.customerui.model.parameter.Bank;
import com.gl.csf.customerui.model.parameter.District;
import com.gl.csf.customerui.model.parameter.State;
import com.gl.csf.customerui.model.parameter.Township;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.util.*;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 17/08/2017.
 */
@Service
public class ApplicationService {

  private static final String ID_REQUESTED_PARAMETER = "/{id}";
  private final String baseUrl;
  private final String permissionBaseUrl;

  @Inject
  private VaadinSecurity vaadinSecurity;
  @Inject
  private StateService stateService;
  @Inject
  private DistrictService districtService;
  @Inject
  private TownshipService townshipService;
  @Inject
  private BankService bankService;
  @Inject
  private RestTemplate restTemplate;

  @Inject
  public ApplicationService(@Value("${endpoints.rest.application}") String applicationBaseUrl,
                            @Value("${endpoints.rest.createapplicationpermission}") String permissionBaseUrl) {
    this.baseUrl = applicationBaseUrl;
    this.permissionBaseUrl = permissionBaseUrl;
  }

  public void saveApplication(String id, Application application) {
    Objects.requireNonNull(id);
    Objects.requireNonNull(application);
    application.getApplicant().setUsername(vaadinSecurity.getAuthentication().getName());

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(new MediaType("application", "x-command.SaveApplicationCommand+json"));
    headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

    HttpEntity<SaveApplicationCommand> entity = new HttpEntity<>(new SaveApplicationCommand(application), headers);
    restTemplate.exchange(baseUrl + ID_REQUESTED_PARAMETER, HttpMethod.PUT, entity, String.class, id).getBody();
  }

  public void submitApplication(String id, Application application) {
    Objects.requireNonNull(id);
    Objects.requireNonNull(application);
    application.getApplicant().setUsername(vaadinSecurity.getAuthentication().getName());

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(new MediaType("application", "x-command.SubmitApplicationCommand+json"));
    headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

    HttpEntity<SubmitApplicationCommand> entity = new HttpEntity<>(new SubmitApplicationCommand(application), headers);
    restTemplate.exchange(baseUrl + ID_REQUESTED_PARAMETER, HttpMethod.PUT, entity, String.class, id).getBody();
  }

  public List<com.gl.csf.customerui.model.applicationlist.Application> getApplications() {
    String customerUsername = vaadinSecurity.getAuthentication().getName();
    if (StringUtils.isEmpty(customerUsername))
      throw new IllegalArgumentException("customerUsername must not be null");

    return restTemplate.exchange(baseUrl + "?customerusername={customerName}", HttpMethod.GET, null,
            new ParameterizedTypeReference<List<com.gl.csf.customerui.model.applicationlist.Application>>() {}, customerUsername).getBody();
  }

  public Optional<LoanApplicationDTO> getById(String applicationId) {
    if (StringUtils.isEmpty(applicationId))
      throw new IllegalArgumentException("applicationId must not be empty");

    Optional<LoanApplicationDTO> optionalApplication = Optional.ofNullable(restTemplate.getForEntity(baseUrl + "/{id}", LoanApplicationDTO.class, applicationId).getBody());

    if(optionalApplication.isPresent()){
      initializeLoanApplication(optionalApplication.get());
      return optionalApplication;
    }

    return Optional.empty();
  }

  public CreateApplicationPermissionDTO getCreateApplicationPermission(String language) {
    HttpHeaders headers = new HttpHeaders();
    headers.set("Accept-Language", language);

    HttpEntity<String> restRequest = new HttpEntity<>(headers);

    String customerUsername = vaadinSecurity.getAuthentication().getName();
    return restTemplate.exchange(permissionBaseUrl + "?customerusername={customerName}",
            HttpMethod.GET, restRequest, CreateApplicationPermissionDTO.class, customerUsername).getBody();
  }

  private void initializeLoanApplication(LoanApplicationDTO loanApplicationDTO) {
    if (loanApplicationDTO.getApplication() == null)
      loanApplicationDTO.setApplication(new Application());

    Application application = loanApplicationDTO.getApplication();

    // Initialize the Loan Product if not exist
    if (application.getLoanProduct() == null)
      application.setLoanProduct(new LoanProduct());

    // Initialize Applicant if not exist
    if (application.getApplicant() == null)
      application.setApplicant(new Customer());

    // Initialize Address if not exist
    if (application.getApplicant().getAddress() == null)
      application.getApplicant().setAddress(new Address());
    else
      initializeAddress(application.getApplicant().getAddress());

    // Initialize Bank Account if not exist
    if (application.getApplicant().getBankAccount() == null)
      application.getApplicant().setBankAccount(new BankAccount());
    else
      initializeBankAccount(application.getApplicant().getBankAccount());
  }

  private void initializeBankAccount(BankAccount bankAccount) {
    // Get or Initialize Bank if not exist
    if (bankAccount.getBank() != null){
      UUID bankId = bankAccount.getBank().getId();
      Optional<Bank> optionalBank = bankService.getBankById(bankId);

      // Can't find bank. this case shouldn't happen.
      if (!optionalBank.isPresent())
        throw new ParameterNotFoundException("Can't find Bank with id: " + bankId);

      bankAccount.setBank(optionalBank.get());
    }
  }

  private void initializeAddress(Address address) {
    // Get State
    if(address.getState() != null){
      UUID stateId = address.getState().getId();
      Optional<State> optionalState = stateService.getStateById(stateId);

      // Can't find state. this case shouldn't happen because the id of parameter should always be valid.
      if(!optionalState.isPresent())
        throw new ParameterNotFoundException("Can't find state with id: " + stateId);

      address.setState(optionalState.get());
    }

    // Get District
    if (address.getDistrict() != null){
      UUID cityId = address.getDistrict().getId();
      Optional<District> optionalDistrict = districtService.getDistrictById(cityId);

      // Can't find district. this case shouldn't happen because the id of parameter should always be valid.
      if (!optionalDistrict.isPresent())
        throw new ParameterNotFoundException("Can't find district with id: " + cityId);

      address.setDistrict(optionalDistrict.get());
    }

    // Get Township
    if (address.getTownship() != null){
      UUID townshipId = address.getTownship().getId();
      Optional<Township> optionalTownship = townshipService.getTownship(townshipId);

      // Can't find township. this case shouldn't happen.
      if (!optionalTownship.isPresent())
        throw new ParameterNotFoundException("Can't find Township with id: " + townshipId);

      address.setTownship(optionalTownship.get());
    }
  }
}
