package com.gl.csf.customerui.ui.view;

import com.gl.csf.customerui.permission.Role;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Page;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Notification;

import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Created by jerome on 8/15/17.
 */
@SpringComponent
@UIScope
public class AccessDeniedView extends CustomComponent implements View {

  @Inject
  VaadinSecurity vaadinSecurity;

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    if (!vaadinSecurity.isAuthenticated()) {
      Page.getCurrent()
        .setLocation("/sso/login?viewName=" + event.getViewName());
    }else if(vaadinSecurity.hasAuthority(Role.STAFF)) {
      Page.getCurrent()
        .setLocation("/sso/login?viewName=" + UIScopeCustomerUIViews.STAFF_LOAN);
    }else Notification.show("Sorry, you don't have access to do that.",
      Notification.Type.ERROR_MESSAGE);
  }
}
