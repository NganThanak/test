package com.gl.csf.customerui.model.application;

import com.gl.csf.customerui.model.parameter.Interest;

import javax.money.MonetaryAmount;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 5, 2017.
 */
public class LoanProduct implements Serializable {

  @NotNull
  private ProductType productType;
  @NotNull
  private MonetaryAmount loanAmount;
  @NotNull
  private Integer term;
  
  private Interest interestRate;
  
  public Interest getInterestRate() {
    return interestRate;
  }
  
  public void setInterestRate(Interest interestRate) {
    this.interestRate = interestRate;
  }
  
  public ProductType getProductType() {
    return productType;
  }

  public void setProductType(ProductType productType) {
    this.productType = productType;
  }

  public MonetaryAmount getLoanAmount() {
    return loanAmount;
  }

  public void setLoanAmount(MonetaryAmount loanAmount) {
    this.loanAmount = loanAmount;
  }

  public Integer getTerm() {
    return term;
  }

  public void setTerm(Integer term) {
    this.term = term;
  }
}
