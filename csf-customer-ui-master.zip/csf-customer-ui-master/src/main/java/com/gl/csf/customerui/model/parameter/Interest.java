package com.gl.csf.customerui.model.parameter;

import javax.persistence.Column;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by p.ly on 2/5/2018.
 */

public class Interest implements Serializable {

  @NotNull
  @Column(name = "interest_rate")
  @Digits(integer = 2, fraction = 1)
  @Min(value = 1, message = "Interest rate must be greater than 1.")
  private BigDecimal interestRate;
  private boolean defaultValue;
  
  public boolean isDefaultValue() {
	return defaultValue;
  }

  public void setDefaultValue(boolean defaultValue) {
	this.defaultValue = defaultValue;
  }

  public BigDecimal getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(BigDecimal interestRate) {
    this.interestRate = interestRate;
  }
  
  @Override
  public String toString() {
    return interestRate.toString();
  }
  
  public static Interest create() {
    Interest interest = new Interest();
    interest.setInterestRate(BigDecimal.ZERO);
    interest.setDefaultValue(false);
    return interest;
  }
}
