package com.gl.csf.customerui.ui.viewdeclaration;

import com.gl.csf.common.util.ConfirmDialogUtil;
import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.adapter.service.application.ApplicationService;
import com.gl.csf.customerui.adapter.service.application.CreateApplicationPermissionDTO;
import com.gl.csf.customerui.model.application.ProductType;
import com.vaadin.spring.annotation.VaadinSessionScope;
import com.vaadin.ui.UI;
import org.springframework.stereotype.Service;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 30/09/2017.
 */
@Service
@VaadinSessionScope
public class NavigatorHelperService implements Serializable {

  private final VaadinSecurity vaadinSecurity;
  private final ApplicationService applicationService;
  private final I18nMessage localizer;
  private String businessId;

  @Inject
  public NavigatorHelperService(VaadinSecurity vaadinSecurity, ApplicationService applicationService, I18nMessage localizer){
    this.vaadinSecurity = vaadinSecurity;
    this.applicationService = applicationService;
    this.localizer = localizer;
  }

  public void navigateToApply(ProductType productType){
    if(vaadinSecurity.isAuthenticated()){
      CreateApplicationPermissionDTO createApplicationPermission = applicationService.getCreateApplicationPermission(localizer.getLocale().getLanguage());
      if(!createApplicationPermission.isAllowApply()) {
        UI.getCurrent().addWindow(ConfirmDialogUtil.createSaveMessage("<p>" + createApplicationPermission.getDescription() + "</p>"));
        return;
      }
    }

    UI.getCurrent().getNavigator().navigateTo(UIScopeCustomerUIViews.APPLICATION_FORM + "/productType=" + productType);
  }

  public void navigateToApply(){
    if(vaadinSecurity.isAuthenticated()){
      CreateApplicationPermissionDTO createApplicationPermission = applicationService.getCreateApplicationPermission(localizer.getLocale().getLanguage());
      if(!createApplicationPermission.isAllowApply()) {
        UI.getCurrent().addWindow(ConfirmDialogUtil.createSaveMessage("<p>" + createApplicationPermission.getDescription() + "</p>"));
        return;
      }
    }
    UI.getCurrent().getNavigator().navigateTo(UIScopeCustomerUIViews.APPLICATION_FORM);
  }

  public void navigateToFirstView(){
      UI.getCurrent().getNavigator().navigateTo("");
  }

  public String getBusinessId() {
    return businessId;
  }

  public void setBusinessId(String businessId) {
    this.businessId = businessId;
  }
}
