package com.gl.csf.customerui.ui.view.contract;

import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 7/29/2017.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeCustomerUIViews.CONTRACT)
public class ContractView extends ContractViewDesign implements View {
  @Inject
  public ContractView() {
    Window subWindow = new Window();
    buttonRequest.addClickListener(e -> {
      comfirmPopupLayout.setVisible(true);
      subWindow.setContent(comfirmPopupLayout);
      UI.getCurrent().addWindow(displayConfiguration(subWindow));
    });
    cancelRequestButton.addClickListener(e -> {
      subWindow.close();
    });
    confirmRequestButton.addClickListener(e -> {
      subWindow.close();
    });
  }

  private Window displayConfiguration(Window window) {
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth("60%");
    window.setHeight("-1px");
    return window;
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {

  }
}
