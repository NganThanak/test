package com.gl.csf.customerui.model.parameter;

import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 5, 2017.
 */
public class Township implements Serializable {

  @NotNull
  private UUID id;
  @NotEmpty
  private String name;
  @NotEmpty
  private String burmeseName;

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getBurmeseName() {
    return burmeseName;
  }

  public void setBurmeseName(String burmeseName) {
    this.burmeseName = burmeseName;
  }

  @Override
  public String toString() {
    return name;
  }
}
