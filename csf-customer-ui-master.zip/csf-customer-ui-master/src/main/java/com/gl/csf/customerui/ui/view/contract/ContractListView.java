package com.gl.csf.customerui.ui.view.contract;

import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;

import javax.inject.Inject;


@SpringComponent
@UIScope
@SpringView(name = UIScopeCustomerUIViews.CONTRACT_LIST)
public class ContractListView extends ContractListViewDesign implements View {
  @Override
  public void enter(ViewChangeEvent event) {

  }

  @Inject
  public ContractListView() {
    buttonSeeMoreDetail.addClickListener(e -> {
      getUI().getNavigator().navigateTo(UIScopeCustomerUIViews.CONTRACT);
    });
  }
}
