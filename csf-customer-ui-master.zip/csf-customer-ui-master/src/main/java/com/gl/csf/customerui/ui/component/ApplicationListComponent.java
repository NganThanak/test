package com.gl.csf.customerui.ui.component;

import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.model.applicationlist.Application;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 23/08/2017.
 */
public class ApplicationListComponent extends ApplicationListComponentDesign implements Localizable {

  private final I18nMessage localizer;
  private String applicationStatus;

  public ApplicationListComponent(I18nMessage localizer){
    this.localizer = localizer;
  }

  public void setApplication(Application application) {
    applicationStatus = application.getStatus();
    applicationReferenceLabel.setValue(application.getReferenceNumber());
    customerApplicationStatus.setValue(localizer.getMessage(applicationStatus));
    createdDate.setValue(application.getCreatedDate().toString());
    loanType.setValue(application.getLoanType() == null ? "-" : application.getLoanType());
    moreDetailButton.addClickListener(e -> getUI().getNavigator().navigateTo(UIScopeCustomerUIViews.APPLICATION_FORM + "/applicationid=" + application.getId()));
  }

  @Override
  public void attach() {
    super.attach();
    updateMessageStrings();
  }

  @Override
  public void updateMessageStrings() {
    createdDateLabel.setValue(localizer.getMessage("created.date"));
    loanTypeLabel.setValue(localizer.getMessage("loan.type"));
    moreDetailButton.setCaption(localizer.getMessage("more.detail"));
    customerApplicationStatus.setValue(localizer.getMessage(applicationStatus));
  }
}
