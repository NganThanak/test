package com.gl.csf.customerui.model.command;

import com.gl.csf.customerui.model.application.Application;

import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 18/08/2017.
 */
public class SaveApplicationCommand implements Serializable {

  private Application application;

  public SaveApplicationCommand(Application application){
    this.application = application;
  }

  public SaveApplicationCommand(){
  }

  public Application getApplication() {
    return application;
  }

  public void setApplication(Application application) {
    this.application = application;
  }
}
