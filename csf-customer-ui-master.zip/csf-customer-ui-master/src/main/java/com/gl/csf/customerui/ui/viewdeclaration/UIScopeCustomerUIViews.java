package com.gl.csf.customerui.ui.viewdeclaration;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/07/2017.
 */
public class UIScopeCustomerUIViews {
  private static final String RESOURCE = "customerui/";
  public static final String STANDARD_LOAN = RESOURCE + "standardloan";
  public static final String REVOLVING_LOAN = RESOURCE + "revolvingloan";
  public static final String STAFF_LOAN = RESOURCE + "staffloan";
  public static final String APPLICATION = RESOURCE + "application";
  public static final String APPLICATION_FORM = RESOURCE + "applicationform";
  public static final String APPLICATION_LIST = RESOURCE + "applicationlist";
  public static final String CONTRACT = RESOURCE + "contract";
  public static final String CONTRACT_LIST = RESOURCE + "contractlist";
}
