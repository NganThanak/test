package com.gl.csf.customerui.adapter.service.parameter;

import com.gl.csf.customerui.model.parameter.State;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/09/2017.
 */
@Service
public class StateService {

  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public StateService(@Value("${endpoints.rest.parameter.state}") String baseUrl, RestTemplate restTemplate){
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  public List<State> getAllStates(){
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
            new ParameterizedTypeReference<List<State>>(){}).getBody();
  }

  public Optional<State> getStateById(UUID stateId){
    Objects.requireNonNull(stateId);

    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/" + stateId, HttpMethod.GET, null,
              new ParameterizedTypeReference<State>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
