package com.gl.csf.customerui.ui.view.application;

import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.adapter.service.application.ApplicationService;
import com.gl.csf.customerui.model.applicationlist.Application;
import com.gl.csf.customerui.permission.Role;
import com.gl.csf.customerui.ui.component.ApplicationListComponent;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

import javax.inject.Inject;

@SpringComponent
@UIScope
@SpringView(name = UIScopeCustomerUIViews.APPLICATION_LIST)
@Secured(Role.CUSTOMER)
public class ApplicationListView extends ApplicationListViewDesign implements View, Localizable {

  private final I18nMessage localizer;
  private final ApplicationService applicationService;

  @Inject
  public ApplicationListView(ApplicationService applicationService, I18nMessage localizer) {
    this.applicationService = applicationService;
    this.localizer = localizer;
  }

  @Override
  public void enter(ViewChangeEvent event) {
    content.removeAllComponents();
    for(Application application : applicationService.getApplications())
      content.addComponent(createApplicationListComponent(application));
  }

  @Override
  public void attach() {
    super.attach();
    updateMessageStrings();
  }

  @Override
  public void updateMessageStrings() {
    applicationTitleLabel.setValue(localizer.getMessage("application.title"));
  }

  private ApplicationListComponent createApplicationListComponent(Application application) {
    ApplicationListComponent result = new ApplicationListComponent(localizer);
    result.setApplication(application);
    return result;
  }
}
