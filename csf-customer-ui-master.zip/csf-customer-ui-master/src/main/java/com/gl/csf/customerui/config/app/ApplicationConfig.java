package com.gl.csf.customerui.config.app;

import com.gl.csf.common.util.I18nMessage;
import com.vaadin.spring.annotation.VaadinSessionScope;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;

import java.util.Locale;

/**
 * @author Sereysopheak
 */
@Configuration
@PropertySource("classpath:rest-endpoints.properties")
public class ApplicationConfig {

  @Bean
  public MessageSource messageSource(){
    ResourceBundleMessageSource source = new ResourceBundleMessageSource();
    source.setBasenames("i18n/messages");
    source.setDefaultEncoding("UTF-8");
    return source;
  }

  @Bean
  @VaadinSessionScope
  public I18nMessage i18nMessage(MessageSource messageSource){
    return new I18nMessage(messageSource, new Locale("my"));
  }
}
