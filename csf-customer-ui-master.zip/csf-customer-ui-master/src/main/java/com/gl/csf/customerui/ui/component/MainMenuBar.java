package com.gl.csf.customerui.ui.component;

import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.permission.Role;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.viewdeclaration.NavigatorHelperService;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.server.Page;
import com.vaadin.server.ThemeResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.springframework.beans.factory.annotation.Value;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.util.Locale;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 20/07/2017.
 */
@SpringComponent
@UIScope
public class MainMenuBar extends MainMenuBarDesign implements Localizable {

  private static final Locale BURMESE_LOCALE = new Locale("my");
  private final VaadinSecurity vaadinSecurity;
  private final I18nMessage localizer;
  private final String keycloakAuthServerUrl;
  private final NavigatorHelperService navigatorHelperService;

  @Inject
  public MainMenuBar(VaadinSecurity vaadinSecurity, I18nMessage localizer, @Value("${keycloak.auth-server-url}") String keycloakAuthServerUrl, NavigatorHelperService navigatorHelperService) {
    this.localizer = localizer;
    this.vaadinSecurity = vaadinSecurity;
    this.keycloakAuthServerUrl = keycloakAuthServerUrl;
    this.navigatorHelperService = navigatorHelperService;
  }

  private MenuBar.Command createNavigationCommand(final String viewName) {
    return menuItem -> getUI().getNavigator().navigateTo(viewName);
  }

  @Override
  public void attach() {
    super.attach();
    updateMessageStrings();
  }

  @Override
  public void updateMessageStrings() {

    ThemeResource resource = new ThemeResource("image/logo.svg");
    logoSMEloan.setSource(resource);
    logoSMEloan.addClickListener(e-> navigatorHelperService.navigateToFirstView());

    productMenu.removeItems();
    applicationMenu.removeItems();
    contractMenu.removeItems();
    language.removeItems();
    login.removeItems();

    // Product
    MenuBar.MenuItem item = productMenu.addItem(localizer.getMessage("product"), null);

    // set permission if user as staff loan
    if(vaadinSecurity.hasAuthority(Role.STAFF))
      item.addItem(localizer.getMessage("staff.loan"), null, createNavigationCommand(UIScopeCustomerUIViews.STAFF_LOAN));

    else {
      item.addItem(localizer.getMessage("standard.loan"), null, createNavigationCommand(UIScopeCustomerUIViews.STANDARD_LOAN));
      // Application
      applicationMenu.addItem(localizer.getMessage("application"), createNavigationCommand(UIScopeCustomerUIViews.APPLICATION_LIST));
    }

    //Contract
    contractMenu.addItem(localizer.getMessage("contract"), createNavigationCommand(UIScopeCustomerUIViews.CONTRACT_LIST));

    // Language
    item = language.addItem(localizer.getMessage("language"), null);
    item.addItem(localizer.getMessage("english"), (MenuBar.Command) selectedItem -> {
      localizer.setLocale(Locale.ENGLISH);
      UI.getCurrent().setLocale(localizer.getLocale());

    });
    item.addItem(localizer.getMessage("burmese"), (MenuBar.Command) selectedItem -> {
      localizer.setLocale(BURMESE_LOCALE);
      UI.getCurrent().setLocale(localizer.getLocale());
    });

    // Login & Profile
    if (!vaadinSecurity.isAuthenticated()) {
      applicationMenu.removeItems();
      contractMenu.removeItems();
      login.addItem(localizer.getMessage("login"), loginItem -> Page.getCurrent().setLocation("/sso/login?viewName="));
    } else {
      login.addItem(localizer.getMessage("logout"), e -> {
        headerLogout.setValue(localizer.getMessage("logout"));
        questionLogout.setValue(localizer.getMessage("question.logout"));
        yesButton.setCaption(localizer.getMessage("yes"));
        noButton.setCaption(localizer.getMessage("no"));
        
        Window subWindow = new Window();
        assignTaskPopUpLayout.setVisible(true);
        subWindow.setContent(assignTaskPopUpLayout);
        UI.getCurrent().addWindow(displayConfiguration(subWindow));
        
        closeButton.addClickListener(btn-> subWindow.close());
        noButton.addClickListener(btn-> subWindow.close());
        yesButton.addClickListener(btn->{ vaadinSecurity.logout(); subWindow.close();});
      });
    }
  }
  private Window displayConfiguration(Window window) {
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth("443px");
    window.setHeight("240px");
    return window;
  }
}
