package com.gl.csf.customerui.ui.view.content.product;

import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.model.application.ProductType;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.viewdeclaration.NavigatorHelperService;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;

import javax.inject.Inject;

@SpringComponent
@UIScope
@SpringView(name = UIScopeCustomerUIViews.STANDARD_LOAN)
public class StandardLoanView extends StandardLoanViewDesign implements View, Localizable {

  private final I18nMessage localizer;

  @Inject
  public StandardLoanView(NavigatorHelperService navigatorHelperService, I18nMessage localizer) {
    this.localizer = localizer;
    buttonApplyStandardTop.addClickListener(e -> navigatorHelperService.navigateToApply(ProductType.STANDARD_LOAN));
    buttonApplyStandardBottom.addClickListener(e -> navigatorHelperService.navigateToApply(ProductType.STANDARD_LOAN));
  }

  @Override
  public void attach() {
    super.attach();
    updateMessageStrings();
  }

  @Override
  public void updateMessageStrings() {
    // Set Value For Label & Caption For Button
    titleLabel.setValue(localizer.getMessage("standard.loan"));
    descriptionLabel.setValue(localizer.getMessage("description.standard.loan"));
    guideLabel.setValue(localizer.getMessage("guide.standard.loan"));
    guide1Label.setValue(localizer.getMessage("guide1.standard.loan"));
    guide2Label.setValue(localizer.getMessage("guide2.standard.loan"));
    guide3Label.setValue(localizer.getMessage("guide3.standard.loan"));
    benefitLabel.setValue(localizer.getMessage("benefit.standard.loan"));
    benefitStandardLabel1.setValue(localizer.getMessage("benefit1.standard.loan"));
    benefitStandardLabel2.setValue(localizer.getMessage("benefit2.standard.loan"));
    benefitStandardLabel3.setValue(localizer.getMessage("benefit3.standard.loan"));
    benefitStandardLabel4.setValue(localizer.getMessage("benefit4.standard.loan"));
    buttonApplyStandardTop.setCaption(localizer.getMessage("apply.standard.loan"));
    buttonApplyStandardBottom.setCaption(localizer.getMessage("apply.standard.loan"));

    contractTermLabel.setValue(localizer.getMessage("contract.term"));
    contractMonths.setValue(localizer.getMessage("contract.months"));
    amountAvailableLabel.setValue(localizer.getMessage("amount.available"));
    amountValue.setValue(localizer.getMessage("amount.value"));
    interestLabel.setValue(localizer.getMessage("interest"));
    interestRate.setValue(localizer.getMessage("interest.rate"));
  }
}