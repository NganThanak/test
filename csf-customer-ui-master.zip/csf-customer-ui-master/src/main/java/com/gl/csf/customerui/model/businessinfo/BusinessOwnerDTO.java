package com.gl.csf.customerui.model.businessinfo;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 9/27/2017.
 */
public class BusinessOwnerDTO {
  private String businessName;
  private String businessId;
  private String email;
  private String phoneNumber;
  private AddressDTO address;
  private int numberOfBranches;
  
  public int getNumberOfBranches() {
    return numberOfBranches;
  }
  
  public void setNumberOfBranches(int numberOfBranches) {
    this.numberOfBranches = numberOfBranches;
  }
  
  public String getBusinessName() {
    return businessName;
  }
  
  public void setBusinessName(String businessName) {
    this.businessName = businessName;
  }

  public String getBusinessId() {
    return businessId;
  }

  public void setBusinessId(String businessId) {
    this.businessId = businessId;
  }

  public String getEmail() {
    return email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getPhoneNumber() {
    return phoneNumber;
  }
  
  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }
  
  public AddressDTO getAddress() {
    return address;
  }
  
  public void setAddress(AddressDTO address) {
    this.address = address;
  }
}
