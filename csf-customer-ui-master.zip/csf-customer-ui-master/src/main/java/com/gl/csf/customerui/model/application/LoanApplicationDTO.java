package com.gl.csf.customerui.model.application;

/**
 * Created by p.ly on 8/29/2017.
 */
public class LoanApplicationDTO {

    private Application application;
    private CustomerApplicationStatus customerApplicationStatus;

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    public CustomerApplicationStatus getCustomerApplicationStatus() {
        return customerApplicationStatus;
    }

    public void setCustomerApplicationStatus(CustomerApplicationStatus customerApplicationStatus) {
        this.customerApplicationStatus = customerApplicationStatus;
    }
}
