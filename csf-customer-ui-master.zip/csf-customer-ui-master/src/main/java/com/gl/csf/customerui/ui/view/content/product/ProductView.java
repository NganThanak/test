package com.gl.csf.customerui.ui.view.content.product;

import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.model.application.ProductType;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.viewdeclaration.NavigatorHelperService;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.UI;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/07/2017.
 */
@UIScope
@SpringView(name = "")
public class ProductView extends ProductViewDesign implements View, Localizable {

  private final NavigatorHelperService navigatorHelperService;
  private final I18nMessage localizer;

  @Inject
  public ProductView(NavigatorHelperService navigatorHelperService, I18nMessage localizer) {
    this.navigatorHelperService = navigatorHelperService;
    this.localizer = localizer;

    applyButton.addClickListener(e-> navigatorHelperService.navigateToApply());
    productStandardLoanButton.addClickListener(e-> UI.getCurrent().getNavigator().navigateTo(UIScopeCustomerUIViews.STANDARD_LOAN));
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    String businessId = event.getParameterMap().getOrDefault("businessId", null);
    if(businessId != null)
      navigatorHelperService.setBusinessId(businessId);
  }

  @Override
  public void attach() {
    super.attach();
    updateMessageStrings();
  }

  @Override
  public void updateMessageStrings() {
    productTitleLabel.setValue(localizer.getMessage("product.title"));
    productSubTitleLabel.setValue(localizer.getMessage("product.sub.title"));
    applyButton.setCaption(localizer.getMessage("product.apply.button"));
    productDescriptionLabel.setValue(localizer.getMessage("product.description"));
    productSubDescriptionLabel.setValue(localizer.getMessage("product.sub.description"));
    ourProductLabel.setValue(localizer.getMessage("product.our.product"));
    productStandardLoanTitleLabel.setValue(localizer.getMessage("product.standard.loan.title"));
    productStandardLoanSubTitleLabel.setValue(localizer.getMessage("product.standard.loan.sub.title"));
    productStandardLoanDescriptionLabel.setValue(localizer.getMessage("product.standard.loan.description"));
    productStandardLoanButton.setCaption(localizer.getMessage("product.standard.loan.button"));
    productRevolvingLoanTitleLabel.setValue(localizer.getMessage("product.revolving.loan.title"));
    productRevolvingLoanSubTitleLabel.setValue(localizer.getMessage("product.revolving.loan.sub.title"));
    productRevolvingLoanDescriptionLabel.setValue(localizer.getMessage("product.revolving.loan.description"));
    productRevolvingLoanButton.setCaption(localizer.getMessage("product.revolving.loan.button"));
  }
}