package com.gl.csf.customerui.config.app;

import org.springframework.security.core.Authentication;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by jerome on 8/16/17.
 */
public class AuthenticationSuccessNavigationHandler implements org.springframework.security.web.authentication.AuthenticationSuccessHandler {

  private static final String VIEW_NAME_PARAMETER = "viewName";

  @Override
  public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {
    String viewName = httpServletRequest.getParameter(VIEW_NAME_PARAMETER);
    if (viewName == null)
      return;
    httpServletResponse.sendRedirect("/#!" + viewName);

  }
}
