package com.gl.csf.common.util;

import com.vaadin.shared.ui.ContentMode;
import com.vaadin.ui.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 8/14/2017.
 */
public class ConfirmDialogUtil {
  public static Window createSaveMessage(String textMessage) {
    Window window = new Window();
    VerticalLayout components = new VerticalLayout();
    Label message = new Label(textMessage, ContentMode.HTML);
    components.addComponent(message);
    components.setComponentAlignment(message, Alignment.MIDDLE_CENTER);
    Button close = new Button("Ok", clickEvent -> window.close());
    components.addComponent(close);
    components.setComponentAlignment(close, Alignment.BOTTOM_CENTER);
    window.setContent(components);
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth("500px");
    window.setHeight("150px");
    return window;
  }
}
