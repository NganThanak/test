package com.gl.csf.customerui.model.application;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 5, 2017.
 */
public class Application implements Serializable {

  @NotNull
  private Customer applicant;
  @NotNull
  private LoanProduct loanProduct;

  public LoanProduct getLoanProduct() {
    return loanProduct;
  }

  public void setLoanProduct(LoanProduct loanProduct) {
    this.loanProduct = loanProduct;
  }

  public Customer getApplicant() {
    return applicant;
  }

  public void setApplicant(Customer applicant) {
    this.applicant = applicant;
  }
}
