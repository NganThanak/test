package com.gl.csf.customerui.ui.view.content.product;

import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.model.application.ProductType;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.viewdeclaration.NavigatorHelperService;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 9/12/2017.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeCustomerUIViews.REVOLVING_LOAN)
public class RevolvingLoanView extends RevolvingLoanViewDesign implements View, Localizable {

	private final I18nMessage localizer;

	@Inject
	public RevolvingLoanView(NavigatorHelperService navigatorHelperService, I18nMessage localizer) {
		this.localizer = localizer;
	}

	@Override
	public void attach() {
		super.attach();
		updateMessageStrings();
	}

	@Override
	public void updateMessageStrings() {
		titleLabel.setValue(localizer.getMessage("revolving.loan"));
		descriptionLabel.setValue(localizer.getMessage("description.revolving.loan"));
		whatIsRevolvingLoan.setValue(localizer.getMessage("whatIsRevolvingLoan"));
		guide1Label.setValue(localizer.getMessage("guide1.revolving.loan"));
		guide2Label.setValue(localizer.getMessage("guide2.revolving.loan"));
		benefitLabel.setValue(localizer.getMessage("benefit.revolving.loan"));
		benefitRevolvingLabel1.setValue(localizer.getMessage("benefit1.revolving.loan"));
		benefitRevolvingLabel2.setValue(localizer.getMessage("benefit2.revolving.loan"));
		benefitRevolvingLabel3.setValue(localizer.getMessage("benefit3.revolving.loan"));
		buttonApplyRevolvingTop.setCaption(localizer.getMessage("apply.revolving.loan"));
		buttonApplyRevolvingBottom.setCaption(localizer.getMessage("apply.revolving.loan"));

		contractTermLabel.setValue(localizer.getMessage("contract.term"));
		contractMonths.setValue(localizer.getMessage("contract.months"));
		amountAvailableLabel.setValue(localizer.getMessage("amount.available"));
		amountValue.setValue(localizer.getMessage("amount.value"));
		interestLabel.setValue(localizer.getMessage("interest"));
		interestRate.setValue(localizer.getMessage("interest.rate"));
	}
}
