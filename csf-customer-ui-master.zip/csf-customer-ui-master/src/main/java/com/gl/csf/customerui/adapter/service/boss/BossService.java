package com.gl.csf.customerui.adapter.service.boss;

import com.gl.csf.customerui.model.businessinfo.BusinessOwnerDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.Objects;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 9/27/2017.
 */
@Service
public class BossService {

  private final RestTemplate restTemplate;
  private final String endpoint;

  private final static Logger logger = LoggerFactory.getLogger(BossService.class);

  @Inject
  public BossService(BossConfigurationsProperties bossConfigurationsProperties) {
    this.restTemplate = new RestTemplateBuilder()
        .basicAuthorization(bossConfigurationsProperties.getCredentials().getUser(),
            bossConfigurationsProperties.getCredentials().getPassword()).build();
    this.endpoint = bossConfigurationsProperties.getEndpoint();
  }

  public Optional<BusinessOwnerDTO> getBusinessInformation(String businessId) {
    Objects.requireNonNull(businessId);
    try {
      return Optional.of(restTemplate.getForObject(endpoint + "/{businessId}", BusinessOwnerDTO.class, businessId));
    } catch (NotFoundException e) {
      logger.info("businessId: " + businessId + " can't be found in B.O.S.S", e);
      return Optional.empty();
    }
  }
}

