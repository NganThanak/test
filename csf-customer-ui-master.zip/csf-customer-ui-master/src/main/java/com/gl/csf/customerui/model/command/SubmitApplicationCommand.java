package com.gl.csf.customerui.model.command;

import com.gl.csf.customerui.model.application.Application;

import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 18/08/2017.
 */
public class SubmitApplicationCommand implements Serializable {
  private Application application;

  public SubmitApplicationCommand(Application application){
    this.application = application;
  }

  public SubmitApplicationCommand(){
  }

  public Application getApplication() {
    return application;
  }

  public void setApplication(Application application) {
    this.application = application;
  }
}
