package com.gl.csf.customerui.ui;

import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.view.AccessDeniedView;
import com.gl.csf.customerui.ui.viewdisplay.MainViewDisplay;
import com.vaadin.annotations.Theme;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.navigator.SpringViewProvider;
import com.vaadin.ui.Component;
import com.vaadin.ui.HasComponents;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.UI;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

/**
 * Created by jerome on 5/23/17.
 */
@SpringUI
@Theme("csf")
public class VaadinUI extends UI {

  private final static Logger logger = LoggerFactory.getLogger(VaadinUI.class);
  private MainViewDisplay mainViewDisplay;
  private SpringViewProvider springViewProvider;

  @Inject
  public VaadinUI(MainViewDisplay mainViewDisplay, SpringViewProvider viewProvider) {

    this.mainViewDisplay = mainViewDisplay;
    this.springViewProvider = viewProvider;
  }

  @Override
  protected void init(VaadinRequest vaadinRequest) {
    setupDefaultErrorHandler();
    springViewProvider.setAccessDeniedViewClass(AccessDeniedView.class);
    setContent(mainViewDisplay);
  }

  private void setupDefaultErrorHandler() {
    setErrorHandler(errorEvent -> {
      logger.error("An error occurred", errorEvent.getThrowable());
      Notification.show("An error occurred : please contact your support",
          Type.ERROR_MESSAGE);
    });
  }

  @Override
  public void setLocale(Locale locale) {
    super.setLocale(locale);
    updateMessageStrings(getContent());
  }

  private void updateMessageStrings(Component component){
    if(component instanceof Localizable)
      ((Localizable) component).updateMessageStrings();

    if(component instanceof HasComponents)
      ((HasComponents)component).iterator().forEachRemaining(this::updateMessageStrings);
  }
}
