package com.gl.csf.customerui.model.parameter;

import javax.money.MonetaryAmount;
import java.io.Serializable;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 16/08/2017.
 */
public class LoanProductTemplate implements Serializable {

  private MonetaryAmount maximumLoanAmount;
  private MonetaryAmount minimumLoanAmount;
  private MonetaryAmount loanAmountStep;

  private List<Term> terms;

  public MonetaryAmount getMaximumLoanAmount() {
    return maximumLoanAmount;
  }

  public void setMaximumLoanAmount(MonetaryAmount maximumLoanAmount) {
    this.maximumLoanAmount = maximumLoanAmount;
  }

  public MonetaryAmount getMinimumLoanAmount() {
    return minimumLoanAmount;
  }

  public void setMinimumLoanAmount(MonetaryAmount minimumLoanAmount) {
    this.minimumLoanAmount = minimumLoanAmount;
  }

  public MonetaryAmount getLoanAmountStep() {
    return loanAmountStep;
  }

  public void setLoanAmountStep(MonetaryAmount loanAmountStep) {
    this.loanAmountStep = loanAmountStep;
  }

  public List<Term> getTerms() {
    return terms;
  }

  public void setTerms(List<Term> terms) {
    this.terms = terms;
  }
}
