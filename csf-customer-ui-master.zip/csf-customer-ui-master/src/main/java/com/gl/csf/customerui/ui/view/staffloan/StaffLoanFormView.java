package com.gl.csf.customerui.ui.view.staffloan;

import com.gl.csf.customerui.permission.Role;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

/**
 * Created by p.ly on 1/18/2018.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeCustomerUIViews.STAFF_LOAN)
@Secured(Role.STAFF)
public class StaffLoanFormView extends StaffLoanFormViewDesign implements View{
}
