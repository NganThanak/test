package com.gl.csf.customerui.adapter.service.parameter;

import com.gl.csf.customerui.model.application.ProductType;
import com.gl.csf.customerui.model.parameter.LoanProductTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.Objects;
import java.util.Optional;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 16/08/2017.
 */
@Service
public class LoanProductTemplateService {

  private final String standardLoanBaseUrl;
  private final String revolvingLoanBaseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public LoanProductTemplateService(@Value("${endpoints.rest.parameter.standardloan}") String standardLoanBaseUrl,
                                    @Value("${endpoints.rest.parameter.revolvingloan}") String revolvingLoanBaseUrl,
                                    RestTemplate restTemplate) {
    this.standardLoanBaseUrl = standardLoanBaseUrl;
    this.revolvingLoanBaseUrl = revolvingLoanBaseUrl;
    this.restTemplate = restTemplate;
  }

  public Optional<LoanProductTemplate> getProductTemplate(ProductType productType) {
    Objects.requireNonNull(productType);

    String resourceUrl;
    switch (productType) {
      case STANDARD_LOAN:
        resourceUrl = standardLoanBaseUrl;
        break;
      default:
        throw new IllegalArgumentException("Not supported product type: " + productType);
    }

    try {
      return Optional.of(restTemplate.exchange(resourceUrl, HttpMethod.GET, null,
              new ParameterizedTypeReference<LoanProductTemplate>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
