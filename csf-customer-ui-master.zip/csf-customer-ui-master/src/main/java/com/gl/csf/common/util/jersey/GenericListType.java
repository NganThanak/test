package com.gl.csf.common.util.jersey;

import javax.ws.rs.core.GenericType;
import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/08/2017.
 */
public class GenericListType<T extends Serializable> extends GenericType<List<T>> {

  private static <T> ParameterizedType createParameterizedListType(final Class<T> resourceClass) {
    return new ParameterizedType() {
      @Override
      public Type[] getActualTypeArguments() {
        return new Type[]{resourceClass};
      }

      @Override
      public Type getRawType() {
        return List.class;
      }

      @Override
      public Type getOwnerType() {
        return List.class;
      }
    };
  }

  private GenericListType(Class<T> resourceClass) {
    super(createParameterizedListType(resourceClass));
  }

  public static <T extends Serializable> GenericListType<T> create(Class<T> resourceClass) {
    return new GenericListType<>(resourceClass);
  }
}
