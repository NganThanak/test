package com.gl.csf.customerui.model.parameter;

import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/09/2017.
 */
public class State implements Serializable {

  @NotNull
  private UUID id;
  @NotEmpty
  private String name;
  @NotEmpty
  private String burmeseName;

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getBurmeseName() {
    return burmeseName;
  }

  public void setBurmeseName(String burmeseName) {
    this.burmeseName = burmeseName;
  }

  @Override
  public String toString() {
    return name;
  }
}
