package com.gl.csf.customerui.ui.component;

import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import org.apache.commons.lang.StringEscapeUtils;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/16/2017.
 */
@SpringComponent
@UIScope
public class FooterComponent extends FooterComponentDesign implements Localizable {

	private final I18nMessage localizer;

	@Inject
	public FooterComponent(I18nMessage localizer) {
		this.localizer = localizer;
	}

	@Override
	public void attach() {
		super.attach();
		updateMessageStrings();
	}

	@Override
	public void updateMessageStrings() {
		copyrightLabel.setValue(StringEscapeUtils.unescapeHtml(localizer.getMessage("copyright")));
		contactLabel.setValue(localizer.getMessage("contact"));
		footerEmailLabel.setValue(localizer.getMessage("contact.email"));
		phoneNumberLabel.setValue(localizer.getMessage("contact.phone"));
	}
}
