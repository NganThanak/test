package com.gl.csf.common.util;

import org.springframework.context.MessageSource;

import java.util.Locale;
import java.util.Objects;

/**
 * @author Sereysopheak
 */
public class I18nMessage {

  private MessageSource messageSource;
  private Locale locale;

  public I18nMessage(MessageSource messageSource, Locale locale){
    this.messageSource = messageSource;
    this.locale = locale;
  }

  public I18nMessage(MessageSource messageSource){
    this(messageSource, Locale.ENGLISH);
  }

  public String getMessage(String i18nCode) {
    return getMessage(i18nCode, null);
  }

  public String getMessage(String i18nCode, Object... args) {
    return messageSource.getMessage(i18nCode, args, locale);
  }

  public Locale getLocale() {
    return locale;
  }

  public void setLocale(Locale locale) {
    Objects.requireNonNull(locale);
    this.locale = locale;
  }
}