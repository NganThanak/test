package com.gl.csf.customerui.model.application;

import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 5, 2017.
 */
public enum Gender implements Serializable {
  MALE("male"), FEMALE("female");
  private final String value;

  private Gender(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
