package com.gl.csf.customerui.model.application;

/**
 * Created by p.ly on 8/29/2017.
 */
public enum CustomerApplicationStatus {
    SAVED, APPLICATION_IN_PROGRESS, APPLICATION_DECLINED, APPLICATION_VALIDATED
}
