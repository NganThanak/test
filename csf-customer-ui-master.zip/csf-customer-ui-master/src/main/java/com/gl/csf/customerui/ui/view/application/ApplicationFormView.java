package com.gl.csf.customerui.ui.view.application;

import com.gl.csf.common.util.ConfirmDialogUtil;
import com.gl.csf.common.util.CurrencyUtil;
import com.gl.csf.common.util.I18nMessage;
import com.gl.csf.customerui.adapter.service.application.ApplicationService;
import com.gl.csf.customerui.adapter.service.application.CreateApplicationPermissionDTO;
import com.gl.csf.customerui.adapter.service.boss.BossService;
import com.gl.csf.customerui.model.businessinfo.BusinessOwnerDTO;
import com.gl.csf.customerui.adapter.service.parameter.*;
import com.gl.csf.customerui.model.application.*;
import com.gl.csf.customerui.model.parameter.*;
import com.gl.csf.customerui.permission.Role;
import com.gl.csf.customerui.ui.localization.Localizable;
import com.gl.csf.customerui.ui.viewdeclaration.NavigatorHelperService;
import com.gl.csf.customerui.ui.viewdeclaration.UIScopeCustomerUIViews;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.HasValue;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ItemCaptionGenerator;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.springframework.security.access.annotation.Secured;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.YEARS;

@SpringComponent
@UIScope
@SpringView(name = UIScopeCustomerUIViews.APPLICATION_FORM)
@Secured(Role.CUSTOMER)
public class ApplicationFormView extends ApplicationFormViewDesign implements View, Localizable {

  private final LoanProductTemplateService loanProductTemplateService;
  private final StateService stateService;
  private final BankService bankService;
  private final InterestRateService interestRateService;
  private final ApplicationService applicationService;
  private final BossService bossService;
  private final I18nMessage localizer;
  private final NavigatorHelperService navigatorHelperService;

  private final Binder<Application> applicationBinder = new BeanValidationBinder<>(Application.class);
  private final List<Integer> termParameters = new ArrayList<>();
  private final List<MonetaryAmount> loanAmounts = new ArrayList<>();

  private String productType;
  private String applicationId;
  private Application application;

  @Inject
  public ApplicationFormView(LoanProductTemplateService loanProductTemplateService, StateService stateService, DistrictService districtService, InterestRateService interestRateService, NavigatorHelperService navigatorHelperService, BossService bossService,
                             TownshipService townshipService, BankService bankService, ApplicationService applicationService, I18nMessage localizer) {
    this.loanProductTemplateService = loanProductTemplateService;
    this.stateService = stateService;
    this.interestRateService = interestRateService;
    this.bankService = bankService;
    this.applicationService = applicationService;
    this.bossService = bossService;
    this.localizer = localizer;
    this.navigatorHelperService = navigatorHelperService;

    loanAmount.setItemCaptionGenerator(CurrencyUtil.MONETARY_AMOUNT_FORMAT::format);
    gender.setDataProvider(new ListDataProvider<>(Arrays.asList(Gender.values())));
    loanType.setDataProvider(new ListDataProvider<ProductType>(Arrays.asList(ProductType.values())));

    initializeBinder(applicationBinder);

    addListeners(districtService, townshipService, applicationService);
    dateOfBirth.setRangeEnd(LocalDate.now().minusYears(18));
  }

  private void addListeners(DistrictService districtService, TownshipService townshipService, ApplicationService applicationService) {
    applicationBinder.addStatusChangeListener(e->buttonSubmit.setEnabled(e.getSource().isValid()));
    stateCombobox.addValueChangeListener(e->{
      districtCombobox.clear();
      ListDataProvider<District> districtListDataProvider = e.getSource().getOptionalValue().isPresent()
              ? new ListDataProvider<>(districtService.getDistrictsByState(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
      districtCombobox.setDataProvider(districtListDataProvider);
    });

    districtCombobox.addValueChangeListener(e->{
      townshipCombobox.clear();
      ListDataProvider<Township> townshipListDataProvider = e.getSource().getOptionalValue().isPresent()
              ? new ListDataProvider<>(townshipService.getTownships(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
      townshipCombobox.setDataProvider(townshipListDataProvider);
    });

    loanType.addValueChangeListener(this::onSelectedProductType);

    buttonSave.addClickListener(e->{
      applicationService.saveApplication(applicationId, application);
      UI.getCurrent().addWindow(ConfirmDialogUtil.createSaveMessage("<p>" + localizer.getMessage("save.success") + "</p>"));
    });

    buttonSubmit.addClickListener(e->{
      application.getLoanProduct().setInterestRate(interestRateComboBox.getSelectedItem().get());
      applicationService.submitApplication(applicationId, application);
      Window subWindow = ConfirmDialogUtil.createSaveMessage("<p>" + localizer.getMessage("submit.success") + "</p>");
      UI.getCurrent().addWindow(subWindow);
      subWindow.addCloseListener(new Window.CloseListener() {
        @Override
        public void windowClose(Window.CloseEvent e) {
          getUI().getNavigator().navigateTo(UIScopeCustomerUIViews.APPLICATION_LIST);
        }
      });
    });
  }

  @Override
  public void enter(ViewChangeEvent event) {
    // Initialize elements states
    buttonSubmit.setEnabled(false);
    loanTerm.setEnabled(false);
    loanAmount.setEnabled(false);

    CreateApplicationPermissionDTO createApplicationPermission = applicationService.getCreateApplicationPermission(localizer.getLocale().getLanguage());

    applicationId = event.getParameterMap().getOrDefault("applicationid", null);

    CustomerApplicationStatus customerApplicationStatus = null;

    if(applicationId != null){
      // Try to get application from application id
      Optional<LoanApplicationDTO> optionalLoanApplicationDTO = applicationService.getById(applicationId);
      if(optionalLoanApplicationDTO.isPresent()){
        // Found an exist application by id
        LoanApplicationDTO loanApplicationDTO = optionalLoanApplicationDTO.get();
        customerApplicationStatus = loanApplicationDTO.getCustomerApplicationStatus();
        application = loanApplicationDTO.getApplication();
      } else {
        Notification.show("App id can't be found: " + applicationId, Notification.Type.ERROR_MESSAGE);
        navigatorHelperService.navigateToFirstView();
        return;
      }
    } else {
      if(!applicationService.getCreateApplicationPermission(getLocale().getLanguage()).isAllowApply()) {
        Notification.show(createApplicationPermission.getDescription(), Notification.Type.WARNING_MESSAGE);
        navigatorHelperService.navigateToFirstView();
        return;
      }
      applicationId = UUID.randomUUID().toString();
      application = createApplication();

      updateBusinessOwnerInformation(application);
    }

    stateCombobox.setDataProvider(new ListDataProvider<State>(stateService.getAllStates()));
    bankCombobox.setDataProvider(new ListDataProvider<Bank>(bankService.getAllBanks()));
    interestRateComboBox.setDataProvider(new ListDataProvider<Interest>(interestRateService.getAllInterestRate()));
    interestRateComboBox.setSelectedItem(interestRateService.getDefaultInterestRate().get());
    loanTerm.setDataProvider(new ListDataProvider<Integer>(termParameters));
    loanAmount.setDataProvider(new ListDataProvider<MonetaryAmount>(loanAmounts));

    applicationBinder.setBean(application);

    if(customerApplicationStatus != null)
      setEnableFields(customerApplicationStatus.equals(CustomerApplicationStatus.SAVED));

    productType = event.getParameterMap().getOrDefault("productType", null);
    if (productType != null)
      loanType.setSelectedItem(ProductType.valueOf(productType));
  }

  private void updateBusinessOwnerInformation(Application application) {
    if(navigatorHelperService.getBusinessId() == null)
      return;

    Optional<BusinessOwnerDTO> optionalBusinessOwnerDTO = bossService.getBusinessInformation(navigatorHelperService.getBusinessId());

    if(!optionalBusinessOwnerDTO.isPresent())
      return;

    BusinessOwnerDTO businessOwnerDTO = optionalBusinessOwnerDTO.get();

    Customer customer = application.getApplicant();
    customer.setBusinessName(businessOwnerDTO.getBusinessName());
    customer.setBusinessId(businessOwnerDTO.getBusinessId());
    customer.setPhoneNumber(businessOwnerDTO.getPhoneNumber());
    customer.setEmail(businessOwnerDTO.getEmail());

    if(businessOwnerDTO.getAddress() != null)
      customer.getAddress().setText(businessOwnerDTO.getAddress().getAddressLine());
  }

  private Application createApplication() {
    Application result = new Application();
    Customer applicant = new Customer();
    applicant.setBankAccount(new BankAccount());
    applicant.setAddress(new Address());
    LoanProduct loanProduct = new LoanProduct();

    result.setApplicant(applicant);
    result.setLoanProduct(loanProduct);
    return result;
  }

  private void onSelectedProductType(HasValue.ValueChangeEvent<ProductType> productTypeValueChangeEvent) {

    boolean isProductTypePresent = productTypeValueChangeEvent.getSource().getOptionalValue().isPresent();

    if(productTypeValueChangeEvent.getOldValue() != null){
      loanTerm.clear();
      loanAmount.clear();
    }

    loanTerm.setEnabled(isProductTypePresent);
    loanAmount.setEnabled(isProductTypePresent);

    if (isProductTypePresent) {
      ProductType productType = productTypeValueChangeEvent.getValue();

      // Fetch loan product template
      Optional<LoanProductTemplate> optionalLoanProductTemplate = loanProductTemplateService.getProductTemplate(productType);
      if(!optionalLoanProductTemplate.isPresent())
        throw new RuntimeException("There are no product available. Please contact your support");

      LoanProductTemplate loanProductTemplate = optionalLoanProductTemplate.get();

      // Set available terms
      termParameters.clear();
      termParameters.addAll(loanProductTemplate.getTerms().stream().map(Term::getValue).collect(Collectors.toList()));
      loanTerm.getDataProvider().refreshAll();

      // Bind loan amount field with minimum loan and maximum loan amount validator
      MonetaryAmount minimumLoanAmount = loanProductTemplate.getMinimumLoanAmount();
      MonetaryAmount maximumLoanAmount = loanProductTemplate.getMaximumLoanAmount();

      loanAmounts.clear();
      for(MonetaryAmount loan = minimumLoanAmount ; loan.compareTo(maximumLoanAmount) <= 0 ; loan = loan.add(loanProductTemplate.getLoanAmountStep()))
        loanAmounts.add(loan);

      loanAmount.getDataProvider().refreshAll();
    }
  }

  private void initializeBinder(Binder<Application> applicationBinder) {
    Objects.requireNonNull(applicationBinder);
    applicationBinder.bind(businessName, "applicant.businessName");
    applicationBinder.bind(textFullName, "applicant.fullName");
    applicationBinder.bind(gender, "applicant.gender");
    applicationBinder.forField(dateOfBirth).withValidator(dob -> YEARS.between(dob, LocalDate.now()) >= 18, "Age must be greater than 18.")
            .asRequired("Age must be greater than 18.").bind("applicant.dateOfBirth");
    applicationBinder.bind(textPhoneNumber, "applicant.phoneNumber");
    // TODO investigate to use EmailValidator. It is disabled as it causes this field to be mandatory
    applicationBinder.bind(textEmail, "applicant.email");
    applicationBinder.bind(addressTextField, "applicant.address.text");
    applicationBinder.bind(stateCombobox, "applicant.address.state");
    applicationBinder.bind(districtCombobox, "applicant.address.district");
    applicationBinder.bind(townshipCombobox, "applicant.address.township");
    applicationBinder.bind(bankCombobox, "applicant.bankAccount.bank");
    applicationBinder.bind(bankAccountNameTextField, "applicant.bankAccount.accountName");
    applicationBinder.bind(bankAccountTextField, "applicant.bankAccount.accountNumber");
    applicationBinder.bind(loanType, "loanProduct.productType");
    applicationBinder.bind(loanTerm, "loanProduct.term");
    applicationBinder.forField(loanAmount).bind("loanProduct.loanAmount");
    if(applicationBinder.getBean() == null)
      interestRateComboBox.setSelectedItem(interestRateService.getDefaultInterestRate().get());
    else
      applicationBinder.bind(interestRateComboBox, "loanProduct.interestRate");
  }

  private void setEnableFields(boolean isEnable){
    businessName.setEnabled(isEnable);
    textFullName.setEnabled(isEnable);
    gender.setEnabled(isEnable);
    dateOfBirth.setEnabled(isEnable);
    textPhoneNumber.setEnabled(isEnable);
    textEmail.setEnabled(isEnable);
    addressTextField.setEnabled(isEnable);
    stateCombobox.setEnabled(isEnable);
    districtCombobox.setEnabled(isEnable);
    townshipCombobox.setEnabled(isEnable);
    bankCombobox.setEnabled(isEnable);
    bankAccountNameTextField.setEnabled(isEnable);
    bankAccountTextField.setEnabled(isEnable);
    loanType.setEnabled(isEnable);
    loanTerm.setEnabled(isEnable);
    buttonSave.setEnabled(isEnable);
    loanAmount.setEnabled(isEnable);
    // State of submit button depend on also the validation of the binder
    buttonSubmit.setEnabled(applicationBinder.isValid() && isEnable);
  }

  @Override
  public void attach() {
    super.attach();
    updateMessageStrings();
  }

  @Override
  public void updateMessageStrings() {
    // Set Caption For TextField & Button & Value For Label
    titleLabel.setValue(localizer.getMessage("application.form"));
    businessName.setCaption(localizer.getMessage("business.name"));
    textFullName.setCaption(localizer.getMessage("full.name"));
    gender.setCaption(localizer.getMessage("gender"));
    gender.setItemCaptionGenerator((ItemCaptionGenerator<Gender>) item -> localizer.getMessage(item.getValue()));
    dateOfBirth.setCaption(localizer.getMessage("date.of.birth"));
    textPhoneNumber.setCaption(localizer.getMessage("phone.number"));
    textEmail.setCaption(localizer.getMessage("email"));
    addressTextField.setCaption(localizer.getMessage("address"));
    stateCombobox.setCaption(localizer.getMessage("state"));
    districtCombobox.setCaption(localizer.getMessage("district"));
    townshipCombobox.setCaption(localizer.getMessage("township"));
    loanType.setCaption(localizer.getMessage("loan.type"));
    loanTerm.setCaption(localizer.getMessage("loan.term"));
    loanAmount.setCaption(localizer.getMessage("loan.amount"));
    bankAccountNameTextField.setCaption(localizer.getMessage("bank.account.name"));
    bankCombobox.setCaption(localizer.getMessage("bank"));
    bankAccountTextField.setCaption(localizer.getMessage("bank.account"));
    buttonSave.setCaption(localizer.getMessage("save"));
    buttonSubmit.setCaption(localizer.getMessage("submit"));
  }
}
