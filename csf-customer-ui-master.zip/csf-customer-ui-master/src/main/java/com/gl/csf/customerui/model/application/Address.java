package com.gl.csf.customerui.model.application;

import com.gl.csf.customerui.model.parameter.District;
import com.gl.csf.customerui.model.parameter.State;
import com.gl.csf.customerui.model.parameter.Township;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 5, 2017.
 */
public class Address implements Serializable {

  @NotEmpty
  private String text;
  @NotNull
  private State state;
  @NotNull
  private District district;
  @NotNull
  private Township township;

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public State getState() {
    return state;
  }

  public void setState(State state) {
    this.state = state;
  }

  public District getDistrict() {
    return district;
  }

  public void setDistrict(District district) {
    this.district = district;
  }

  public Township getTownship() {
    return township;
  }

  public void setTownship(Township township) {
    this.township = township;
  }
}
