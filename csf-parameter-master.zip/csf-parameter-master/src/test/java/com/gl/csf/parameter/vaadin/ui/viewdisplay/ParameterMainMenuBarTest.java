package com.gl.csf.parameter.vaadin.ui.viewdisplay;

import com.gl.csf.parameter.ParameterApplicationTests;
import com.vaadin.testbench.elements.MenuBarElement;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.Keys;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/4/2017.
 */
public class ParameterMainMenuBarTest extends ParameterApplicationTests {
  @Test
  public void testSelectProductConfiguration() {
    getDriver().get("http://localhost:8080/");
    MenuBarElement menu = $(MenuBarElement.class).get(0);
    menu.focus();
    menu.sendKeys(Keys.SPACE);
    menu.sendKeys(Keys.SPACE);
    Assert.assertTrue("Click on [Product Configuration] success", true);
  }
}
