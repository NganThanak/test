package com.gl.csf.parameter.vaadin.ui.product;

import com.gl.csf.parameter.ParameterApplicationTests;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/3/2017.
 */
public class LoanProductView extends ParameterApplicationTests{
}
