package com.gl.csf.parameter;

import com.vaadin.testbench.TestBenchTestCase;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ParameterApplicationTests extends TestBenchTestCase {

    @Before
    public void setUp() throws Exception {
        WebDriver driver = new ChromeDriver();
        setDriver(driver);
    }

    @After
    public void tearDown() throws Exception {
        getDriver().quit();
    }

}
