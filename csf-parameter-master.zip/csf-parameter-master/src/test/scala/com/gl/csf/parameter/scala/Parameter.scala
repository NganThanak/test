package com.gl.csf.parameter.scala

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._

/**
  * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
  * Author: Kuylim Tith (k.tith@gl-f.com) on 8/7/2017.
  */
class Parameter extends Simulation{

  val baseUrl = "http://localhost:8080"

  val httpProtocol = http
    .baseURL(baseUrl)
    .acceptHeader("*/*")
    .acceptEncodingHeader("gzip, deflate")
    .acceptLanguageHeader("en-US,en;q=0.5")
    .userAgentHeader("Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/3")

  val headers_0 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Upgrade-Insecure-Requests" -> "1")
  val headers_4 = Map("Accept" -> "text/css,*/*;q=0.1")
  val headers_6 = Map("Content-Type" -> "application/json; charset=UTF-8")
  val headers_7 = Map("Pragma" -> "no-cache")

  val initSyncAndClientIds = exec((session) => {
    session.setAll(
      "syncId" -> 0,
      "clientId" -> 0
    )
  })

  val syncIdExtract = regex("""syncId": ([0-9]*),""").saveAs("syncId")
  val clientIdExtract = regex("""clientId": ([0-9]*),""").saveAs("clientId")
  val xsrfTokenExtract = regex("""Vaadin-Security-Key\\":\\"([^\\]+)""").saveAs("seckey")

  val checkOrderStatusRegExp = regex("""caption":"Mark as Confirmed""")
  val checkProductListRegExp = regex("""com.vaadin.shared.data.DataCommunicatorClientRpc","setData""")

  val scn = scenario("BasicSimulation")
    .exec(http("request_1")
      .get("/"))
    .pause(5)

  setUp(scn.inject(rampUsers(200) over (250 seconds))).protocols(httpProtocol)
}
