package com.gl.csf.parameter.domain.dao.product;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.product.StandardLoanProduct;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
public interface StandardLoanProductRepository extends PagingAndSortingRepository<StandardLoanProduct, UUID> {
  Optional<StandardLoanProduct> findFirstByRecordStatus(ERecordStatus recordStatus);
}
