package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.product.StandardLoanProductRepository;
import com.gl.csf.parameter.domain.model.product.StandardLoanProduct;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Ron Rith (r.ron@gl-f.com) on 2017-07-24.
 */
@Scope("prototype")
@Component
public class StandardLoanProductDataProvider extends AbstractBackEndDataProvider<StandardLoanProduct, String> {
  //private final StandardLoanTermRepository repository;
  private final StandardLoanProductRepository repository;

  @Inject
  private StandardLoanProductDataProvider(StandardLoanProductRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  public void save(StandardLoanProduct bean) {
    repository.save(bean);
    refreshAll();
  }

  @Override
  protected Stream<StandardLoanProduct> fetchFromBackEnd(Query<StandardLoanProduct, String> query) {
    StreamSupport.stream(repository.findAll().spliterator(), true);
    return null;
  }

  @Override
  protected int sizeInBackEnd(Query<StandardLoanProduct, String> query) {
    return Math.toIntExact(repository.count());
  }
}
