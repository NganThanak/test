package com.gl.csf.parameter.vaadin.ui.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.productconfiguration.InterestRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.Interest;
import com.gl.csf.parameter.vaadin.dataprovider.InterestDataProvider;
import com.gl.csf.parameter.vaadin.ui.common.ConfirmationMessageComponent;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToBigDecimalConverter;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import io.swagger.models.auth.In;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.inject.Inject;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Created by p.ly on 2/5/2018.
 */
@UIScope
@SpringComponent
public class InterestComponent extends InterestComponentDesign{
  private final Logger logger = LoggerFactory.getLogger(InterestComponent.class);

  @Inject
  InterestComponent(InterestDataProvider dataProvider, InterestRepository repository) {

    interestGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    interestGrid.setDataProvider(dataProvider);

    Binder<Interest> interestBinder = new BeanValidationBinder<>(Interest.class);

    interestBinder.forField(interestTextField).withConverter(
      new StringToBigDecimalConverter("Interest rate must be number. Cannot be zero or negative number."))
      .bind("interestRate");

    interestBinder.setBean(Interest.create());
    interestBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    addButton.setEnabled(false);
    addButton.addClickListener(e -> {
      Optional<Interest> optionalInterest = repository.findByDefaultValue(true);
      if (optionalInterest.isPresent())
        interestBinder.getBean().setDefaultValue(false);
      else
        interestBinder.getBean().setDefaultValue(true);

      dataProvider.save(interestBinder.getBean());
      interestBinder.setBean(Interest.create());
    });

    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);

    initGridEditor(dataProvider, repository);
  }

  private void initGridEditor(InterestDataProvider dataProvider, InterestRepository repository){
    BeanValidationBinder<Interest> editorBinder = new BeanValidationBinder<>(Interest.class);
    interestGrid.getEditor().setBinder(editorBinder);
    
    interestGrid.addComponentColumn(record -> {
    	CheckBox checkbox = new CheckBox();
      // check which one is default value
    	if (!record.isDefaultValue()) {
        record.setDefaultValue(false);
        checkbox.setValue(record.isDefaultValue());
      } else {
        record.setDefaultValue(true);
        checkbox.setValue(record.isDefaultValue());
        checkbox.setEnabled(false);
      }
      checkbox.addValueChangeListener(event -> {
        Optional<Interest> interestOptional = repository.findByDefaultValue(true);
        // reset old value to false
        if (interestOptional.isPresent()) {
          Interest interest = interestOptional.get();
          interest.setDefaultValue(false);
          repository.save(interest);
        }
        // set the selected value to default value
        record.setDefaultValue(true);
        repository.save(record);
        interestGrid.getDataProvider().refreshAll();
      });
      return checkbox;
    }).setId("checkboxDefaultValue").setCaption("Default");
    
    // Set editor of purpose field
    TextField nameEditor = new TextField();
    Binder.Binding<Interest, BigDecimal> nameBinding = editorBinder.forField(nameEditor).withConverter(
      new StringToBigDecimalConverter("Interest rate must be number. Cannot be zero or negative number."))
      .bind("interestRate");
    interestGrid.getColumn("interestRate").setEditorBinding(nameBinding);

    // Set editor of record status field
    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
    Binder.Binding<Interest, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
    interestGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);
    
    

    //Deleted Purpose
    interestGrid.addComponentColumn(event->{
      Button deleteButton =new Button("");
      deleteButton.setStyleName("field_check-references-document-close-button borderless");
      deleteButton.setIcon(VaadinIcons.TRASH);
      // we could not delete default value
      if(event.isDefaultValue())
        deleteButton.setEnabled(false);

      deleteButton.addClickListener(e->{

        ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
        Window window = confirmationMessage.displayConfiguration();
        confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
          @Override
          public void onClosed() { window.close(); }
          @Override
          public void onNoButtonClicked() { window.close(); }
          @Override
          public void onYesButtonClicked() {
            try {
              repository.delete(event);
              interestGrid.getDataProvider().refreshAll();
            }catch (Exception ex){
              logger.error("Error while deleting interest", ex);
            }
            window.close();
          }
        });
        window.setContent(confirmationMessage);
        UI.getCurrent().addWindow(window);
      });
      return deleteButton;
    });
    interestGrid.getEditor().setEnabled(true);
    interestGrid.getEditor().addSaveListener(e-> dataProvider.save(e.getBean()));
  }
}
