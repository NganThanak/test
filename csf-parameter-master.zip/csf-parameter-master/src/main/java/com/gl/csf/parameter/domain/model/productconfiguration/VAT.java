package com.gl.csf.parameter.domain.model.productconfiguration;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.Range;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
@Entity
@Table(name = "vat")
public class VAT extends AbstractUUIDEntity {

  @NotNull
  @Column(name = "value", nullable = false)
  @Digits(integer = 1, fraction = 2)
  @Range(min = 0, max = 1, message = "VAT must be between [0, 1.0]")
  private BigDecimal value;

  @NotNull
  @Column(name = "effective_date", nullable = false)
  private LocalDate effectiveDate;

  public static VAT create() {
    VAT vat = new VAT();
    vat.setValue(BigDecimal.ZERO);
    vat.setEffectiveDate(LocalDate.now());
    return vat;
  }

  public BigDecimal getValue() {
    return value;
  }

  public void setValue(BigDecimal value) {
    this.value = value;
  }

  public LocalDate getEffectiveDate() {
    return effectiveDate;
  }

  public void setEffectiveDate(LocalDate effectiveDate) {
    this.effectiveDate = effectiveDate;
  }
}
