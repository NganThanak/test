package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.address.BusinessTypeRepository;
import com.gl.csf.parameter.domain.model.address.BusinessType;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@Component
public class BusinessTypeDataProvider extends AbstractBackEndDataProvider<BusinessType, String> {
    private final BusinessTypeRepository repository;
    @Inject
    public BusinessTypeDataProvider(BusinessTypeRepository repository){
        this.repository = repository;
    }
    @Override
    protected Stream<BusinessType> fetchFromBackEnd(Query<BusinessType, String> query) {
        return StreamSupport.stream(repository.findAll().spliterator(), true);
    }

    @Override
    protected int sizeInBackEnd(Query<BusinessType, String> query) {
        return Math.toIntExact(repository.count());
    }
    public void save(BusinessType bean) {
        repository.save(bean);
        refreshAll();
    }
}