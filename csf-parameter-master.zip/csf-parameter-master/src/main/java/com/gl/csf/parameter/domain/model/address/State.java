package com.gl.csf.parameter.domain.model.address;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.*;
import java.util.List;

/**
 * Created by p.ly on 9/15/2017.
 */
@Entity
@Table(name = "state")
public class State extends AbstractUUIDEntity {
  @NotEmpty
  @Column(name = "name")
  private String name;

  @NotEmpty
  @Column(name = "burmese_name")
  private String burmeseName;

  @JsonIgnore
  @OneToMany(mappedBy="state")
  private List<District> districts;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getBurmeseName() {
    return burmeseName;
  }

  public void setBurmeseName(String burmeseName) {
    this.burmeseName = burmeseName;
  }

  public List<District> getDistricts() {
    return districts;
  }

  public void setDistricts(List<District> districts) {
    this.districts = districts;
  }

  @Override
  public String toString() {
    return name;
  }
}
