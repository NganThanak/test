package com.gl.csf.parameter.common;

import javax.money.CurrencyUnit;
import javax.money.Monetary;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 26/07/2017.
 */
public class CurrencyUtil {
  public static final CurrencyUnit MMK_CURRENCY = Monetary.getCurrency("MMK");
}
