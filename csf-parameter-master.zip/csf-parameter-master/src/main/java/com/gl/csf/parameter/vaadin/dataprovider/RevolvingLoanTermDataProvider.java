package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.RevolvingLoanTermRepository;
import com.gl.csf.parameter.domain.model.product.RevolvingLoanTerm;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 7/25/2017.
 */
@Scope("prototype")
@Component
public class RevolvingLoanTermDataProvider extends AbstractBackEndDataProvider<RevolvingLoanTerm, String> {

  private final RevolvingLoanTermRepository repository;

  @Inject
  public RevolvingLoanTermDataProvider(RevolvingLoanTermRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  @Override
  protected Stream<RevolvingLoanTerm> fetchFromBackEnd(Query<RevolvingLoanTerm, String> query) {
    return StreamSupport.stream(repository.findByRecordStatus(ERecordStatus.ACTIVE).spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<RevolvingLoanTerm, String> query) {
    return Math.toIntExact(repository.countByRecordStatus(ERecordStatus.ACTIVE));
  }

  public void save(RevolvingLoanTerm bean) {
    repository.save(bean);
    refreshAll();
  }

  public void remove(RevolvingLoanTerm bean) {
    bean.setRecordStatus(ERecordStatus.INACTIVE);
    save(bean);
  }
}
