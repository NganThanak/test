package com.gl.csf.parameter.domain.dao.productconfiguration;

import com.gl.csf.parameter.domain.model.productconfiguration.PaymentFrequency;
import org.springframework.data.repository.CrudRepository;

import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
public interface PaymentFrequencyRepository extends CrudRepository<PaymentFrequency, UUID> {
}
