package com.gl.csf.parameter.resource.product;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.StandardLoanProductRepository;
import com.gl.csf.parameter.domain.model.product.StandardLoanProduct;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 7/26/2017.
 */
@Component
@Path("/standardloan")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Standard Loan", produces = "application/json")
public class StandardLoanResource {

  private final StandardLoanProductRepository standardLoanProductRepository;

  @Inject
  public StandardLoanResource(StandardLoanProductRepository standardLoanProductRepository) {
    this.standardLoanProductRepository = standardLoanProductRepository;
  }

  @GET
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Standard Loan resource found"),
          @ApiResponse(code = 404, message = "Standard loan not found")
  })
  public Response getActiveStandardLoanProduct() {
    Optional<StandardLoanProduct> optionalStandardLoanProduct = standardLoanProductRepository.findFirstByRecordStatus(ERecordStatus.ACTIVE);

    if (!optionalStandardLoanProduct.isPresent())
      throw new NotFoundException();

    return Response.ok(optionalStandardLoanProduct.get()).build();
  }
}