package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.productconfiguration.StaffLoanPurposeRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.StaffLoanPurpose;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 1/19/2018.
 */
@Component
public class StaffLoanPurposeDataProvider extends AbstractBackEndDataProvider<StaffLoanPurpose, String> {
  private final StaffLoanPurposeRepository repository;

  @Inject
  public StaffLoanPurposeDataProvider(StaffLoanPurposeRepository repository) {
    this.repository = repository;
  }
  @Override
  protected Stream<StaffLoanPurpose> fetchFromBackEnd(Query<StaffLoanPurpose, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<StaffLoanPurpose, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(StaffLoanPurpose bean) {
    repository.save(bean);
    refreshAll();
  }
}
