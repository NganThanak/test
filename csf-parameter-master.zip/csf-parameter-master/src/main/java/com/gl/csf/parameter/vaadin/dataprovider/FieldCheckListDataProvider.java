package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.otherconfiguration.FieldCheckListRepository;
import com.gl.csf.parameter.domain.model.underwriting.FieldCheckList;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/13/2017.
 */
@Scope("prototype")
@Component
public class FieldCheckListDataProvider extends AbstractBackEndDataProvider<FieldCheckList, String> {

	private FieldCheckListRepository repository;

	@Inject
	public FieldCheckListDataProvider(FieldCheckListRepository fieldCheckListRepository) {
		Objects.requireNonNull(fieldCheckListRepository);
		this.repository = fieldCheckListRepository;
	}

	@Override
	protected Stream<FieldCheckList> fetchFromBackEnd(Query<FieldCheckList, String> query) {
		return StreamSupport.stream(repository.findAll().spliterator(), true);
	}

	@Override
	protected int sizeInBackEnd(Query<FieldCheckList, String> query) {
		return Math.toIntExact(repository.count());
	}

	public void save(FieldCheckList bean) {
		repository.save(bean);
		refreshAll();
	}

}
