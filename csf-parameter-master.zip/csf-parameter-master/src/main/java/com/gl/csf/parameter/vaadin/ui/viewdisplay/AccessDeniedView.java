package com.gl.csf.parameter.vaadin.ui.viewdisplay;

import com.gl.csf.parameter.config.security.Role;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Page;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Created by jerome on 8/15/17.
 */
@SpringComponent
@UIScope
public class AccessDeniedView extends CustomComponent implements View {
	
  /**
  * 
  */
  private static final long serialVersionUID = 3965711851279708419L;

  private static final String UNKNOWN = "Unknown";
  private static final String CM_STAFF = "CM staff";
  private static final String UW_STAFF = "UW staff";
  private static final String CUSTOMER = "Customer";
  
  @Inject
  VaadinSecurity vaadinSecurity;
  
  String staff = UNKNOWN;

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    if (!vaadinSecurity.isAuthenticated()) {
      Page.getCurrent()
              .setLocation("/sso/login?viewName=" + event.getViewName());
    } else {
      final PermissionRoleComponent permissionRoleComponent = new PermissionRoleComponent();
      vaadinSecurity.getAuthentication().getAuthorities().forEach(e-> {
        if (Role.OPERATION_STAFF.equals(e.getAuthority())) {
          staff = CM_STAFF;
        } else if (Role.CUSTOMER.equals(e.getAuthority())) {
          staff = CUSTOMER;
        } else {
          staff = UW_STAFF;
        }
      });
      permissionRoleComponent.confirmationMessage.setValue("Sorry, you don't have access to module Parameter as '"+ staff +"'.Please logout and login with proper credential.");
      Window window = permissionRoleComponent.displayConfiguration();
      permissionRoleComponent.setListener(new PermissionRoleComponent.PermissionRoleComponentListener() {
        @Override
        public void onClosed() {window.close();}
        @Override
        public void onLogoutButtonClicked() {
          vaadinSecurity.logout();
        }
      });
      window.setContent(permissionRoleComponent);
      UI.getCurrent().addWindow(window);
    }
  }
}
