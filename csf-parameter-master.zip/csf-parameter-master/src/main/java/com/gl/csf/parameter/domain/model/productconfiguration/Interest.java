package com.gl.csf.parameter.domain.model.productconfiguration;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * Created by p.ly on 2/5/2018.
 */
@Entity
@Table(name = "interest")
public class Interest extends AbstractUUIDEntity {

  @NotNull
  @Column(name = "interest_rate")
  @Digits(integer = 2, fraction = 1)
  @Min(value = 1, message = "Interest rate must be greater than 1.")
  private BigDecimal interestRate;
  private boolean defaultValue;
  
  public boolean isDefaultValue() {
	return defaultValue;
  }

  public void setDefaultValue(boolean defaultValue) {
	this.defaultValue = defaultValue;
  }

  public BigDecimal getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(BigDecimal interestRate) {
    this.interestRate = interestRate;
  }

  public static Interest create() {
    Interest interest = new Interest();
    interest.setInterestRate(BigDecimal.ZERO);
    interest.setDefaultValue(false);
    return interest;
  }
}
