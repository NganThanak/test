package com.gl.csf.parameter.vaadin.ui.finance.payment;

import com.gl.csf.parameter.domain.model.paymentconfiguration.PenaltyCalculationPeriod;
import com.gl.csf.parameter.vaadin.dataprovider.PenaltyCalculationPeriodDataProvider;
import com.gl.csf.parameter.vaadin.util.BackDateError;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
@UIScope
@SpringComponent
public class PenaltyCalculationPeriodComponent extends PenaltyCalculationPeriodComponentDesign {
  @Inject
  public PenaltyCalculationPeriodComponent(PenaltyCalculationPeriodDataProvider calculationRateDataProvider){
    penaltyCalculationPeriodGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    penaltyCalculationPeriodGrid.setDataProvider(calculationRateDataProvider);
  
    Binder<PenaltyCalculationPeriod> penaltyRateBinder = new BeanValidationBinder<>(PenaltyCalculationPeriod.class);
    penaltyRateBinder.forField(penaltyCalculationPeriodTextField).withConverter(new StringToIntegerConverter("Days must enter a number")).bind("days");
    penaltyRateBinder.forField(effectiveDateTextField).bind("effectiveDate");
    penaltyRateBinder.setBean(new PenaltyCalculationPeriod());
    effectiveDateTextField.setValue(LocalDate.now());
    penaltyRateBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));
    
    addButton.setEnabled(false);
    addButton.addClickListener(e->{
      if(calculationRateDataProvider.checkBackDateBeforeSave(penaltyRateBinder.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        calculationRateDataProvider.save(penaltyRateBinder.getBean());
      
      penaltyRateBinder.setBean(new PenaltyCalculationPeriod());
      effectiveDateTextField.setValue(LocalDate.now());
    });
    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);
    initGridEditor(calculationRateDataProvider);
  }
  
  private void initGridEditor(PenaltyCalculationPeriodDataProvider calculationRateDataProvider){
    BeanValidationBinder<PenaltyCalculationPeriod> editorBinder = new BeanValidationBinder<>(PenaltyCalculationPeriod.class);
    penaltyCalculationPeriodGrid.getEditor().setBinder(editorBinder);
    
    TextField nameEditor = new TextField();
    Binder.Binding<PenaltyCalculationPeriod, Integer> nameBinding = editorBinder.forField(nameEditor).withConverter(new StringToIntegerConverter("Days must enter a number")).bind("days");
    penaltyCalculationPeriodGrid.getColumn("days").setEditorBinding(nameBinding);
  
    DateField editEffectiveDate = new DateField();
    Binder.Binding<PenaltyCalculationPeriod, LocalDate> effectiveDate = editorBinder.forField(editEffectiveDate).bind("effectiveDate");
    penaltyCalculationPeriodGrid.getColumn("effectiveDate").setEditorBinding(effectiveDate);
    
//    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
//    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
//    Binder.Binding<PenaltyCalculationPeriod, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
//    penaltyCalculationPeriodGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);
    penaltyCalculationPeriodGrid.getEditor().setEnabled(true);
    penaltyCalculationPeriodGrid.getEditor().addSaveListener(e-> {
      if(calculationRateDataProvider.checkBackDateBeforeSave(e.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        calculationRateDataProvider.save(e.getBean());
    });
  }
}
