package com.gl.csf.parameter.domain.model.bank;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * Created by p.ly on 9/27/2017.
 */
@Entity
@Table(name = "bank_account")
public class BankAccount extends AbstractUUIDEntity {
  @NotEmpty
  @Column(name = "account_number")
  private String accountNumber;

  @NotNull
  @JsonBackReference
  @ManyToOne
  @JoinColumn(name = "bank_id", nullable = false, referencedColumnName = "id")
  private Bank bank;

  public String getAccountNumber() {
    return accountNumber;
  }

  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  public Bank getBank() {
    return bank;
  }

  public void setBank(Bank bank) {
    this.bank = bank;
  }
}
