package com.gl.csf.parameter.resource.payment;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.payment.PenaltyThresholdRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.PenaltyThreshold;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/26/2018.
 */
@Component
@Path("/penaltythreshold")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Penalty Threshold", produces = "application/json")
public class PenaltyThresholdResource {

  private final PenaltyThresholdRepository penaltyThresholdRepository;

  @Inject
  public PenaltyThresholdResource(PenaltyThresholdRepository penaltyThresholdRepository) {
    this.penaltyThresholdRepository = penaltyThresholdRepository;
  }

  @GET
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Return list of Penalty Threshold")
  })
  public Response getAllPenaltyCalculationPeriods() {
    List<PenaltyThreshold> penaltyThresholds = penaltyThresholdRepository.findAllByRecordStatus(ERecordStatus.ACTIVE);
    return Response.ok().entity(penaltyThresholds).build();
  }
}
