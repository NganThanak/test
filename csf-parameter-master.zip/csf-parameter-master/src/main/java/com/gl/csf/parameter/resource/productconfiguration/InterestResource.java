package com.gl.csf.parameter.resource.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.productconfiguration.InterestRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.Interest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 2/5/2018.
 */
@Component
@Path("/interests")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Interest", produces = "application/json")
public class InterestResource {

  private final InterestRepository repository;

  @Inject
  InterestResource(InterestRepository repository) {
    this.repository = repository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return list of Interest")
  })
  public Response getAllInterests() {
    List<Interest> loanPurposes = repository.findAllByRecordStatus(ERecordStatus.ACTIVE);
    return Response.ok().entity(loanPurposes).build();
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return Default of Interest")
  })
  @Path("/defaultinterest")
  public Response getDefaultInterest() {
    Optional<Interest> interestOptional = repository.findByDefaultValue(true);
    return Response.ok().entity(interestOptional.get()).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return Interest by id"),
    @ApiResponse(code = 404, message = "Given Interest not found"
    )
  })
  public Response getInterest(@PathParam("id") UUID id){

    Interest interest = repository.findOne(id);
    if (interest == null) {
      throw new NotFoundException();
    }
    return Response.ok(interest).build();
  }
}
