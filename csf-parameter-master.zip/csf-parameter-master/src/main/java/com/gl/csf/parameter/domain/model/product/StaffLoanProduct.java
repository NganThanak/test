package com.gl.csf.parameter.domain.model.product;

import com.gl.csf.parameter.common.CurrencyUtil;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * Created by p.ly on 1/18/2018.
 */
@Entity
@Table(name = "staff_loan_product")
public class StaffLoanProduct extends AbstractLoanProduct {

  @ManyToMany(cascade = CascadeType.MERGE)
  @LazyCollection(LazyCollectionOption.FALSE)
  @JoinTable(name = "staff_loan_product_loan_term", joinColumns = {@JoinColumn(name = "staff_loan_id", referencedColumnName = "id")}, inverseJoinColumns = {@JoinColumn(name = "staff_term_id", referencedColumnName = "id")})
  private List<StaffLoanTerm> terms;

  @NotNull
  @Column(name = "interest_rate")
  @Digits(integer = 2, fraction = 1)
  @Min(value = 1, message = "Interest rate must be greater than 1.")
  private BigDecimal interestRate;

  public List<StaffLoanTerm> getTerms() {
    return terms;
  }

  public void setTerms(List<StaffLoanTerm> terms) {
    this.terms = terms;
  }

  public BigDecimal getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(BigDecimal interestRate) {
    this.interestRate = interestRate;
  }

  public static StaffLoanProduct create() {
    MonetaryAmount zero = Money.of(BigDecimal.ZERO, CurrencyUtil.MMK_CURRENCY);

    StaffLoanProduct staffLoanProduct = new StaffLoanProduct();

    staffLoanProduct.setInterestRate(BigDecimal.ZERO);
    staffLoanProduct.setMaximumLoanAmount(zero);
    staffLoanProduct.setMinimumLoanAmount(zero);
    staffLoanProduct.setLoanAmountStep(zero);

    return staffLoanProduct;
  }
}
