package com.gl.csf.parameter.domain.dao.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.productconfiguration.Company;
import org.springframework.data.repository.CrudRepository;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 1/20/2018.
 */
public interface CompanyRepository extends CrudRepository<Company, UUID> {
  List<Company> findAllByRecordStatus(ERecordStatus eRecordStatus);
}
