package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.bank.BankAccountRepository;
import com.gl.csf.parameter.domain.model.bank.BankAccount;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 9/27/2017.
 */
@Component
public class BankAccountDataProvider extends AbstractBackEndDataProvider<BankAccount, String> {
  private final BankAccountRepository repository;
  @Inject
  public BankAccountDataProvider(BankAccountRepository repository){
    this.repository = repository;
  }
  @Override
  protected Stream<BankAccount> fetchFromBackEnd(Query<BankAccount, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<BankAccount, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(BankAccount bean) {
    repository.save(bean);
    refreshAll();
  }
}
