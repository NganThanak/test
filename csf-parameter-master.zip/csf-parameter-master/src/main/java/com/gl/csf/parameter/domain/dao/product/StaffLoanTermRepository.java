package com.gl.csf.parameter.domain.dao.product;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.product.StaffLoanTerm;
import org.springframework.data.repository.CrudRepository;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 1/18/2018.
 */
public interface StaffLoanTermRepository extends CrudRepository<StaffLoanTerm, UUID> {
  List<StaffLoanTerm> findByRecordStatus(ERecordStatus recordStatus);

  long countByRecordStatus(ERecordStatus recordStatus);
}
