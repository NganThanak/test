package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.productconfiguration.LoanPurposeRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.LoanPurpose;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 12/12/2017.
 */
@Component
public class LoanPurposeDataProvider extends AbstractBackEndDataProvider<LoanPurpose, String> {

  private final LoanPurposeRepository repository;

  @Inject
  LoanPurposeDataProvider(LoanPurposeRepository repository){
    this.repository = repository;
  }

  @Override
  protected Stream<LoanPurpose> fetchFromBackEnd(Query<LoanPurpose, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<LoanPurpose, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(LoanPurpose bean) {
    repository.save(bean);
    refreshAll();
  }
}
