package com.gl.csf.parameter.domain.dao.productconfiguration;

import com.gl.csf.parameter.domain.model.productconfiguration.VAT;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
public interface VATRepository extends CrudRepository<VAT, UUID> {
  Optional<VAT> findTopByEffectiveDateIsLessThanEqualOrderByEffectiveDateDesc(LocalDate baseComparingDate);
  boolean existsByEffectiveDate(LocalDate baseComparingDate);
}
