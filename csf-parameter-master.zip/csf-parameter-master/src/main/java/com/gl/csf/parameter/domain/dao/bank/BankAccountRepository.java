package com.gl.csf.parameter.domain.dao.bank;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.bank.BankAccount;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 9/27/2017.
 */
@Repository
public interface BankAccountRepository extends CrudRepository<BankAccount, UUID> {
  List<BankAccount> findAllByRecordStatus(ERecordStatus eRecordStatus);
}
