package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.productconfiguration.PaymentFrequencyRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.PaymentFrequency;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/07/2017.
 */
@Scope("prototype")
@Component
public class PaymentFrequencyDataProvider extends AbstractBackEndDataProvider<PaymentFrequency, String> {

  private final PaymentFrequencyRepository repository;

  @Inject
  private PaymentFrequencyDataProvider(PaymentFrequencyRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  @Override
  protected Stream<PaymentFrequency> fetchFromBackEnd(Query<PaymentFrequency, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<PaymentFrequency, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(PaymentFrequency bean) {
    repository.save(bean);
    refreshAll();
  }
}
