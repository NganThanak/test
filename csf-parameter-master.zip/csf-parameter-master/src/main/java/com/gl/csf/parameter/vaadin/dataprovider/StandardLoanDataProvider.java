package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.StandardLoanProductRepository;
import com.gl.csf.parameter.domain.model.product.StandardLoanProduct;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 7/25/2017.
 */
@Scope("prototype")
@Component
public class StandardLoanDataProvider extends AbstractBackEndDataProvider<StandardLoanProduct, String> {

  private final StandardLoanProductRepository repository;

  @Inject
  public StandardLoanDataProvider(StandardLoanProductRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  @Override
  protected Stream<StandardLoanProduct> fetchFromBackEnd(Query<StandardLoanProduct, String> query) {
    return StreamSupport.stream(repository.findAll(new Sort(Sort.Direction.ASC, "recordStatus")).spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<StandardLoanProduct, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(StandardLoanProduct bean) {
    Optional<StandardLoanProduct> standardLoanProduct = repository.findFirstByRecordStatus(ERecordStatus.ACTIVE);

    if (standardLoanProduct.isPresent()) {
      standardLoanProduct.get().setRecordStatus(ERecordStatus.INACTIVE);
      repository.save(standardLoanProduct.get());
    }

    repository.save(bean);
    refreshAll();
  }
}
