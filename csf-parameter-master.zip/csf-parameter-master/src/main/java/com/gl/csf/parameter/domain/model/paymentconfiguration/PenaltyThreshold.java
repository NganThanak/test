package com.gl.csf.parameter.domain.model.paymentconfiguration;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/26/2018.
 */
@Entity
@Table(name = "penalty_threshold")
public class PenaltyThreshold extends AbstractUUIDEntity {
  @NotNull
  @Column(name = "threshold")
  private double threshold;

  @NotNull
  @Column(name = "effective_date")
  private LocalDate effectiveDate;

  public double getThreshold() {
    return threshold;
  }

  public void setThreshold(double threshold) {
    this.threshold = threshold;
  }

  public LocalDate getEffectiveDate() {
    return effectiveDate;
  }

  public void setEffectiveDate(LocalDate effectiveDate) {
    this.effectiveDate = effectiveDate;
  }

  @Override
  public String toString() {
    return String.valueOf(threshold);
  }
}
