package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.payment.DailyPenaltyRateRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.DailyPenaltyRate;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
@Component
public class DailyPenaltyRateDataProvider extends AbstractBackEndDataProvider<DailyPenaltyRate, String> {
  private final DailyPenaltyRateRepository repository;
  
  @Inject
  public DailyPenaltyRateDataProvider(DailyPenaltyRateRepository repository) {
    this.repository = repository;
  }
  
  public void save(DailyPenaltyRate bean) {
    repository.save(bean);
    refreshAll();
  }
  
  public boolean checkBackDateBeforeSave(LocalDate date) {
    //DailyPenaltyRate penaltyRate = repository.findFirstByOrderByEffectiveDate();
    return LocalDate.now().compareTo(date) > 0; //penaltyRate != null ? (penaltyRate.getEffectiveDate().compareTo(date) > 0 &&  LocalDate.now().compareTo(date) > 0) :  LocalDate.now().compareTo(date) > 0;
  }
  
//  public void update(DailyPenaltyRate bean){
//    if ((bean.getRecordStatus() == ERecordStatus.ACTIVE)) {
//      updateStatusToInactive();
//      DailyPenaltyRate penaltyRate = repository.findOne(bean.getId());
//      penaltyRate.setRate(bean.getRate());
//      penaltyRate.setRecordStatus(ERecordStatus.ACTIVE);
//      repository.save(penaltyRate);
//    } else if(bean.getRecordStatus() == ERecordStatus.INACTIVE) {
//      DailyPenaltyRate penaltyRate = repository.findOne(bean.getId());
//      penaltyRate.setRate(bean.getRate());
//      repository.save(penaltyRate);
//    }
//    refreshAll();
//  }
//
//  public void updateStatusToInactive() {
//    List<DailyPenaltyRate> dailyPenaltyRates = (List<DailyPenaltyRate>) repository.findAll();
//    dailyPenaltyRates.forEach(rate -> {
//      rate.setRecordStatus(ERecordStatus.INACTIVE);
//      repository.save(rate);
//    });
//  }
//
  @Override
  protected Stream<DailyPenaltyRate> fetchFromBackEnd(Query<DailyPenaltyRate, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }
  
  @Override
  protected int sizeInBackEnd(Query<DailyPenaltyRate, String> query) {
    return Math.toIntExact(repository.count());
  }
}
