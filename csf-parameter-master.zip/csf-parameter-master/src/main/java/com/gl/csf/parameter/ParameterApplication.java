package com.gl.csf.parameter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.gl.csf"})
public class ParameterApplication {

  public static void main(String[] args) {
    SpringApplication.run(ParameterApplication.class, args);
  }
}
