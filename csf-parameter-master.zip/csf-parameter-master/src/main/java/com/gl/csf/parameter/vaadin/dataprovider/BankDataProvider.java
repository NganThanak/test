package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.bank.BankRepository;
import com.gl.csf.parameter.domain.model.bank.Bank;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 9/14/2017.
 */
@Component
public class BankDataProvider extends AbstractBackEndDataProvider<Bank, String> {
  private final BankRepository repository;

  @Inject
  public BankDataProvider(BankRepository repository) {
    this.repository = repository;
  }
  @Override
  protected Stream<Bank> fetchFromBackEnd(Query<Bank, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<Bank, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(Bank bean) {
    repository.save(bean);
    refreshAll();
  }
}
