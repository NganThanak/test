package com.gl.csf.parameter.vaadin.ui.finance.payment;

import com.gl.csf.parameter.domain.model.paymentconfiguration.PenaltyThreshold;
import com.gl.csf.parameter.vaadin.dataprovider.PenaltyThresholdDataProvider;
import com.gl.csf.parameter.vaadin.util.BackDateError;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToDoubleConverter;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/26/2018.
 */
@UIScope
@SpringComponent
public class PenaltyThresholdComponent extends PenaltyThresholdComponentDesign {
  @Inject
  public PenaltyThresholdComponent(PenaltyThresholdDataProvider penaltyThresholdDataProvider){

    penaltyThresholdGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    penaltyThresholdGrid.setDataProvider(penaltyThresholdDataProvider);

    Binder<PenaltyThreshold> penaltyThresholdBinder = new BeanValidationBinder<>(PenaltyThreshold.class);
    penaltyThresholdBinder.forField(thresholdTextField).withConverter(new StringToDoubleConverter("Threshold must enter a number")).bind("threshold");
    penaltyThresholdBinder.forField(effectiveDateTextField).bind("effectiveDate");
    penaltyThresholdBinder.setBean(new PenaltyThreshold());
    effectiveDateTextField.setValue(LocalDate.now());
    penaltyThresholdBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    addButton.setEnabled(false);
    addButton.addClickListener(e->{
      if(penaltyThresholdDataProvider.checkBackDateBeforeSave(penaltyThresholdBinder.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        penaltyThresholdDataProvider.save(penaltyThresholdBinder.getBean());

      penaltyThresholdBinder.setBean(new PenaltyThreshold());
      effectiveDateTextField.setValue(LocalDate.now());
    });
    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);
    initGridEditor(penaltyThresholdDataProvider);
  }

  private void initGridEditor(PenaltyThresholdDataProvider penaltyThresholdDataProvider){
    BeanValidationBinder<PenaltyThreshold> editorBinder = new BeanValidationBinder<>(PenaltyThreshold.class);
    penaltyThresholdGrid.getEditor().setBinder(editorBinder);

    TextField nameEditor = new TextField();
    Binder.Binding<PenaltyThreshold, Double> nameBinding = editorBinder.forField(nameEditor).withConverter(new StringToDoubleConverter("Threshold must enter a number")).bind("threshold");
    penaltyThresholdGrid.getColumn("threshold").setEditorBinding(nameBinding);

    DateField editEffectiveDate = new DateField();
    Binder.Binding<PenaltyThreshold, LocalDate> effectiveDate = editorBinder.forField(editEffectiveDate).bind("effectiveDate");
    penaltyThresholdGrid.getColumn("effectiveDate").setEditorBinding(effectiveDate);

    penaltyThresholdGrid.getEditor().setEnabled(true);
    penaltyThresholdGrid.getEditor().addSaveListener(e-> {
      if(penaltyThresholdDataProvider.checkBackDateBeforeSave(e.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        penaltyThresholdDataProvider.save(e.getBean());
    });
  }
}
