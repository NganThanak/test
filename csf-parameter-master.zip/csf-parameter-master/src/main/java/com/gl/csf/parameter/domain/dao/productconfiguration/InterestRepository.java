package com.gl.csf.parameter.domain.dao.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.productconfiguration.Interest;
import org.springframework.data.repository.CrudRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 2/5/2018.
 */
public interface InterestRepository extends CrudRepository<Interest, UUID> {
  List<Interest> findAllByRecordStatus(ERecordStatus eRecordStatus);
  Optional<Interest> findByDefaultValue(boolean defaultValue);
}
