package com.gl.csf.parameter.resource.payment;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.payment.DailyPenaltyRateRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.DailyPenaltyRate;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 1/16/2018.
 */
@Component
@Path("/dailypenaltyrates")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Daily Penalty Rate", produces = "application/json")
public class DailyPenaltyRateResource {

  private final DailyPenaltyRateRepository repository;

  @Inject
  DailyPenaltyRateResource(DailyPenaltyRateRepository repository) {
    this.repository = repository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return list of Daily Penalty Rates")
  })
  public Response getAllDailyPenaltyRates() {
    List<DailyPenaltyRate> loanPurposes = repository.findAllByRecordStatus(ERecordStatus.ACTIVE);
    return Response.ok().entity(loanPurposes).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return Daily Penalty Rate by id"),
    @ApiResponse(code = 404, message = "Given Daily Penalty Rate not found"
    )
  })
  public Response getDailyPenaltyRate(@PathParam("id") UUID id){

    DailyPenaltyRate gracePeriod = repository.findOne(id);
    if (gracePeriod == null) {
      throw new NotFoundException();
    }
    return Response.ok(gracePeriod).build();
  }

}
