package com.gl.csf.parameter.domain.dao.payment;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.paymentconfiguration.DueDateCalculationPeriod;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 2/1/2018.
 */
public interface DueDateCalculationPeriodRepository extends CrudRepository<DueDateCalculationPeriod, UUID> {
  List<DueDateCalculationPeriod> findAllByRecordStatus(ERecordStatus eRecordStatus);
  DueDateCalculationPeriod findFirstByOrderByEffectiveDate();
}

