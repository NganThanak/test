package com.gl.csf.parameter.domain.dao.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.productconfiguration.StaffLoanPurpose;
import org.springframework.data.repository.CrudRepository;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 1/19/2018.
 */
public interface StaffLoanPurposeRepository extends CrudRepository<StaffLoanPurpose, UUID> {
  List<StaffLoanPurpose> findAllByRecordStatus(ERecordStatus eRecordStatus);
}
