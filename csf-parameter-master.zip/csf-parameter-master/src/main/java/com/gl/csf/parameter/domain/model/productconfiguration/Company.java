package com.gl.csf.parameter.domain.model.productconfiguration;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by p.ly on 1/20/2018.
 */
@Entity
@Table(name = "company")
public class Company extends AbstractUUIDEntity {
  @NotEmpty
  @Column(name = "company")
  private String company;

  public String getCompany() {
    return company;
  }

  public void setCompany(String company) {
    this.company = company;
  }

  @Override
  public String toString() {
    return company;
  }
}