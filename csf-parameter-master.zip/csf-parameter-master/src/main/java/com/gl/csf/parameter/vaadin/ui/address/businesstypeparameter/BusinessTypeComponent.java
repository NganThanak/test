package com.gl.csf.parameter.vaadin.ui.address.businesstypeparameter;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.BusinessType;
import com.gl.csf.parameter.vaadin.dataprovider.BusinessTypeDataProvider;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import java.util.Arrays;

@UIScope
@SpringComponent
public class BusinessTypeComponent extends BusinessTypeComponentDesign{

    @Inject
    public BusinessTypeComponent(BusinessTypeDataProvider dataProvider){

        businessTypeGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
        businessTypeGrid.setDataProvider(dataProvider);

        Binder<BusinessType> businessTypeBinder = new BeanValidationBinder<>(BusinessType.class);
        businessTypeBinder.bind(businessTypeTextField,"name");
        businessTypeBinder.setBean(new BusinessType());
        businessTypeBinder.addStatusChangeListener(e -> addBusinessButton.setEnabled(e.getBinder().isValid()));

        addBusinessButton.setEnabled(false);
        addBusinessButton.addClickListener(e->{
            dataProvider.save(businessTypeBinder.getBean());
            businessTypeBinder.setBean(new BusinessType());
        });
        addBusinessButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);

        initGridEditor(dataProvider);
    }

    private void initGridEditor(BusinessTypeDataProvider dataProvider) {
        BeanValidationBinder<BusinessType> editorBinder = new BeanValidationBinder<>(BusinessType.class);
        businessTypeGrid.getEditor().setBinder(editorBinder);

        TextField nameEditor = new TextField();
        Binder.Binding<BusinessType, String> nameBinding = editorBinder.bind(nameEditor, "name");
        businessTypeGrid.getColumn("name").setEditorBinding(nameBinding);

        ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
        recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
        Binder.Binding<BusinessType, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
        businessTypeGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);

        businessTypeGrid.getEditor().setEnabled(true);
        businessTypeGrid.getEditor().addSaveListener(e-> dataProvider.save(e.getBean()));
    }
}
