package com.gl.csf.parameter.vaadin.ui.product;

import com.gl.csf.parameter.common.CurrencyUtil;
import com.gl.csf.parameter.config.security.Role;
import com.gl.csf.parameter.domain.model.product.StandardLoanProduct;
import com.gl.csf.parameter.domain.model.product.StandardLoanTerm;
import com.gl.csf.parameter.domain.model.productconfiguration.PaymentFrequency;
import com.gl.csf.parameter.vaadin.dataprovider.PaymentFrequencyDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.StandardLoanDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.StandardLoanProductDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.StandardLoanTermDataProvider;
import com.gl.csf.parameter.vaadin.ui.UIScopeParameterUIViews;
import com.gl.csf.parameter.vaadin.util.MonetaryAmountRenderer;
import com.gl.csf.parameter.vaadin.util.StringToMonetaryConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Sizeable;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import com.vaadin.ui.renderers.ButtonRenderer;
import org.springframework.security.access.annotation.Secured;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/07/2017.
 */
@UIScope
@SpringView(name = UIScopeParameterUIViews.STANDARD_LOAN)
@Secured(Role.ADMINISTRATOR)
public class StandardLoanProductView extends LoanProductView implements View {

  private final PaymentFrequencyDataProvider paymentFrequencyDataProvider;
  private final StandardLoanTermDataProvider standardLoanTermDataProvider;
  private final StandardLoanDataProvider standardLoanDataProvider;
  protected Button saveButton = new Button("Save");

  @Inject
  public StandardLoanProductView(StandardLoanProductDataProvider standardLoanProductDataProvider, PaymentFrequencyDataProvider paymentFrequencyDataProvider,
                                 StandardLoanTermDataProvider standardLoanTermDataProvider, StandardLoanDataProvider standardLoanDataProvider) {
    Objects.requireNonNull(standardLoanProductDataProvider);
    this.paymentFrequencyDataProvider = paymentFrequencyDataProvider;
    this.standardLoanTermDataProvider = standardLoanTermDataProvider;
    this.standardLoanDataProvider = standardLoanDataProvider;
    saveButton.setWidth(-1, Unit.PIXELS);
    saveButton.setStyleName("standard-loan-save-button borderless");
    initializeUI();
  }

  private void initializeUI() {
    VerticalLayout content = new VerticalLayout();
    content.setWidth(80, Unit.PERCENTAGE);
    content.setStyleName("general-layout");
    BeanValidationBinder<StandardLoanProduct> standardLoanProductBinder = new BeanValidationBinder<>(StandardLoanProduct.class);
    BeanValidationBinder<StandardLoanTerm> standardLoanTermBeanValidationBinder = new BeanValidationBinder<>(StandardLoanTerm.class);
    standardLoanProductBinder.setBean(StandardLoanProduct.create());
    Grid<StandardLoanTerm> grid = new Grid<>();
    Grid<PaymentFrequency> paymentGrid = new Grid<>();

    saveButton.setEnabled(false);
    saveButton.addClickListener(e -> {
      if (standardLoanProductBinder.getBean().getPaymentFrequencies() == null
              || standardLoanProductBinder.getBean().getPaymentFrequencies().isEmpty()
              || standardLoanProductBinder.getBean().getTerms() == null
              || standardLoanProductBinder.getBean().getTerms().isEmpty()) {
        UI.getCurrent().addWindow(createSaveProductMessage("<p style='color: red;'>Please select term and payment frequency.</p>"));
      } else {
        standardLoanDataProvider.save(standardLoanProductBinder.getBean());
        standardLoanProductBinder.setBean(StandardLoanProduct.create());
        saveButton.setEnabled(false);
        grid.deselectAll();
        paymentGrid.deselectAll();
        UI.getCurrent().addWindow(createSaveProductMessage("<p style='color: green;'>Create new product successfully</p>"));
      }
    });

    standardLoanProductBinder.addStatusChangeListener(e -> saveButton.setEnabled(e.getBinder().isValid()));

    content.addComponent(createTitleDescription());
    content.addComponent(createTermSection(standardLoanTermBeanValidationBinder, standardLoanProductBinder, grid));
    content.addComponent(createPaymentSection(standardLoanProductBinder, paymentGrid));
    content.addComponent(createStandardGridComponent());
    addComponent(content);
    addComponent(new CssLayout());
  }

  private CssLayout createTitleDescription() {
    CssLayout result = new CssLayout();
    Label productName = new Label("Standard Loan");
    productName.setStyleName("general-configuratio-label");
    result.addComponent(productName);
    return result;
  }

  private CssLayout createTermSection(Binder<StandardLoanTerm> standardLoanTermBinder, Binder<StandardLoanProduct> standardLoanProductBeanBinder, Grid<StandardLoanTerm> grid){
    CssLayout termSection = new CssLayout();
    termSection.setWidth(100, Unit.PERCENTAGE);
    termSection.setStyleName("bank-configuration-sub-layout");

    VerticalLayout components = new VerticalLayout();
    components.setMargin(false);
    components.addComponent(createTermTitleLayout());
    components.addComponent(createTermComponent(standardLoanTermBinder, standardLoanProductBeanBinder, grid));
    components.addComponent(new CssLayout());
    termSection.addComponent(components);
    return termSection;
  }

  private CssLayout createTermTitleLayout() {
    CssLayout termSection = new CssLayout();
    termSection.setWidth(100, Unit.PERCENTAGE);
    termSection.setStyleName("bank-configuration-sub-title-layout");

    Label termLabel = new Label("1. Term");
    termLabel.setStyleName("bank-configuration-sub-title");
    termSection.addComponent(termLabel);
    return termSection;
  }

  private Component createTermComponent(Binder<StandardLoanTerm> standardLoanTermBinder, Binder<StandardLoanProduct> standardLoanProductBeanBinder, Grid<StandardLoanTerm> grid) {
    HorizontalLayout result = new HorizontalLayout();
    result.setWidth(100, Unit.PERCENTAGE);
    result.setMargin(true);
    VerticalLayout controlPanel = new VerticalLayout();
    controlPanel.setWidth(100, Unit.PERCENTAGE);

    TextField term = new TextField("Month");
    standardLoanTermBinder.forField(term).withConverter(new StringToIntegerConverter("Term must be number. Cannot be zero or negative number."))
            .bind("value");
    term.setWidth(100, Unit.PERCENTAGE);
    standardLoanTermBinder.setBean(StandardLoanTerm.create());

    Button addButton = new Button("Add");
    addButton.setWidth(-1, Unit.PIXELS);
    addButton.setStyleName("district-button borderless");
    addButton.setEnabled(false);
    addButton.addClickListener(e -> {
      standardLoanTermDataProvider.save(standardLoanTermBinder.getBean());
      standardLoanTermBinder.setBean(StandardLoanTerm.create());
      addButton.setEnabled(false);
    });

    standardLoanTermBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    controlPanel.addComponents(term, addButton);
    controlPanel.setComponentAlignment(addButton, Alignment.BOTTOM_LEFT);

    grid.setWidth(100, Unit.PERCENTAGE);
    grid.setHeight(240, Unit.PIXELS);
    grid.setStyleName("csf-bank-grid");
    grid.addColumn(StandardLoanTerm::getValue).setCaption("Term (month)");
    grid.setDataProvider(standardLoanTermDataProvider);
    grid.addColumn(RevolvingLoanTerm ->
            "Remove", new ButtonRenderer(clickEvent ->
            UI.getCurrent().addWindow(createConfirmationRemoveTerm(new Button("Yes", remove ->
                    standardLoanTermDataProvider.remove((StandardLoanTerm) clickEvent.getItem())))))).setCaption("Action");

    grid.setSelectionMode(Grid.SelectionMode.MULTI);
    grid.addSelectionListener(e -> {
      StandardLoanProduct standardLoanProduct = standardLoanProductBeanBinder.getBean();
      standardLoanProduct.setTerms(new ArrayList<>(e.getAllSelectedItems()));
      standardLoanProductBeanBinder.setBean(standardLoanProduct);
    });

    result.addComponents(controlPanel, grid);
    return result;
  }

  private Component createPaymentSection(Binder<StandardLoanProduct> standardLoanProductBinder, Grid<PaymentFrequency> paymentGrid) {
    VerticalLayout paymentSection = new VerticalLayout();
    paymentSection.setMargin(false);
    paymentSection.setWidth(100, Sizeable.Unit.PERCENTAGE);
    paymentSection.setStyleName("bank-configuration-sub-layout");

    CssLayout paymentTitleLayout = new CssLayout();
    paymentTitleLayout.setWidth(100, Sizeable.Unit.PERCENTAGE);
    paymentTitleLayout.setStyleName("bank-configuration-sub-title-layout");

    Label termLabel = new Label("2. Payment");
    termLabel.setStyleName("bank-configuration-sub-title");
    paymentTitleLayout.addComponent(termLabel);

    HorizontalLayout buttonLayout = new HorizontalLayout();
    buttonLayout.setMargin(true);
    buttonLayout.setStyleName("pull-right");
    buttonLayout.addComponent(saveButton);

    HorizontalLayout subContent = new HorizontalLayout();
    subContent.setSizeFull();

    subContent.addComponent(createPaymentFrequencyComponent(standardLoanProductBinder, paymentGrid));
    subContent.addComponent(createMaximumAndMinimumComponent(standardLoanProductBinder));
    paymentSection.addComponent(paymentTitleLayout);
    paymentSection.addComponent(subContent);
    paymentSection.addComponent(buttonLayout);
    return paymentSection;
  }

  private Component createPaymentFrequencyComponent(Binder<StandardLoanProduct> standardLoanProductBeanBinder, Grid<PaymentFrequency> paymentGrid) {
    VerticalLayout result = new VerticalLayout();
    result.setSizeFull();
    result.setMargin(true);

    paymentGrid.setWidth(100, Unit.PERCENTAGE);
    paymentGrid.addColumn(PaymentFrequency::getDescription).setCaption("Frequency");
    paymentGrid.setSelectionMode(Grid.SelectionMode.MULTI);
    paymentGrid.setStyleName("csf-bank-grid");
    paymentGrid.setHeight(240, Unit.PIXELS);
    paymentGrid.setDataProvider(paymentFrequencyDataProvider);

    paymentGrid.addSelectionListener(e -> {
      StandardLoanProduct standardLoanProduct = standardLoanProductBeanBinder.getBean();
      standardLoanProduct.setPaymentFrequencies(new ArrayList<>(e.getAllSelectedItems()));
      standardLoanProductBeanBinder.setBean(standardLoanProduct);
    });

    result.addComponent(new Label("Payment Frequency"));
    result.addComponent(paymentGrid);
    result.addComponent(new CssLayout());
    return result;
  }

  private Component createMaximumAndMinimumComponent(Binder<StandardLoanProduct> standardLoanProductBinder) {
    VerticalLayout result = new VerticalLayout();
    result.setMargin(true);

    TextField minimumFinanceAmount = new TextField("Minimum financial amount");
    minimumFinanceAmount.setWidth(100, Unit.PERCENTAGE);
    standardLoanProductBinder.forField(minimumFinanceAmount).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("minimumLoanAmount");
    TextField maximumFinanceAmount = new TextField("Maximum financial amount");
    maximumFinanceAmount.setWidth(100, Unit.PERCENTAGE);
    standardLoanProductBinder.forField(maximumFinanceAmount).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("maximumLoanAmount");
    TextField loanAmountStep = new TextField("Financial amount step");
    loanAmountStep.setWidth(100, Unit.PERCENTAGE);
    standardLoanProductBinder.forField(loanAmountStep).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("loanAmountStep");

    result.addComponent(minimumFinanceAmount);
    result.addComponent(maximumFinanceAmount);
    result.addComponent(loanAmountStep);

    return result;
  }

  private Component createStandardGridComponent(){
    CssLayout components = new CssLayout();
    components.setWidth(100, Unit.PERCENTAGE);

    CssLayout paymentTitleLayout = new CssLayout();
    paymentTitleLayout.setWidth(100, Sizeable.Unit.PERCENTAGE);
    paymentTitleLayout.setStyleName("bank-configuration-sub-title-layout");

    Label termLabel = new Label("3. Standard loan history");
    termLabel.setStyleName("bank-configuration-sub-title");
    paymentTitleLayout.addComponent(termLabel);

    components.addComponent(paymentTitleLayout);
    components.addComponent(createStandardLoanGrid());
    components.addComponent(new CssLayout());
    return components;
  }

  private Component createStandardLoanGrid() {
    VerticalLayout result = new VerticalLayout();
    result.setStyleName("bank-configuration-sub-layout");

    Grid<StandardLoanProduct> grid = new Grid<>();
    grid.setSizeFull();
    grid.setStyleName("csf-bank-grid");
    grid.addColumn(StandardLoanProduct::getMaximumLoanAmount)
        .setRenderer(new MonetaryAmountRenderer()).setCaption("Maximum loan amount");
    grid.addColumn(StandardLoanProduct::getMinimumLoanAmount)
        .setRenderer(new MonetaryAmountRenderer()).setCaption("Minimum loan amount");
    grid.addColumn(StandardLoanProduct::getLoanAmountStep)
      .setRenderer(new MonetaryAmountRenderer()).setCaption("Financial amount step");
    grid.addColumn(StandardLoanProduct::getPaymentFrequencies).setCaption("Payment frequency");
    grid.addColumn(StandardLoanProduct::getTerms).setCaption("Loan Term");
    grid.addColumn(StandardLoanProduct::getCreatedBy).setCaption("Create By");
    grid.addColumn(StandardLoanProduct::getCreatedDate).setCaption("Create Date");
    grid.addColumn(StandardLoanProduct::getInactivatedBy).setCaption("Inactivated By");
    grid.addColumn(StandardLoanProduct::getModifiedDate).setCaption("Modified Date");
    grid.addColumn(StandardLoanProduct::getRecordStatus).setCaption("Status");

    grid.setDataProvider(standardLoanDataProvider);
    result.addComponent(new CssLayout());
    result.addComponent(grid);
    result.addComponent(new CssLayout());
    return result;
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {

  }
}
