package com.gl.csf.parameter.vaadin.ui.finance.payment;

import com.gl.csf.parameter.domain.model.paymentconfiguration.GracePeriod;
import com.gl.csf.parameter.vaadin.dataprovider.GracePeriodDataProvider;
import com.gl.csf.parameter.vaadin.util.BackDateError;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
@UIScope
@SpringComponent
public class GracePeriodComponent extends GracePeriodComponentDesign {
  @Inject
  public GracePeriodComponent(GracePeriodDataProvider gracePeriodDataProvider) {
    gracePeriodGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    gracePeriodGrid.setDataProvider(gracePeriodDataProvider);
  
    Binder<GracePeriod> gracePeriodBinder = new BeanValidationBinder<>(GracePeriod.class);
    
    gracePeriodBinder.forField(gracePeriodTextField).withConverter(new StringToIntegerConverter("Days must enter a number")).bind("days");
    gracePeriodBinder.forField(effectiveDateTextField).bind("effectiveDate");
    gracePeriodBinder.setBean(new GracePeriod());
    effectiveDateTextField.setValue(LocalDate.now());
    gracePeriodBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));
    
    addButton.setEnabled(false);
    addButton.addClickListener(e -> {
      if(gracePeriodDataProvider.checkBackDateBeforeSave(gracePeriodBinder.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        gracePeriodDataProvider.save(gracePeriodBinder.getBean());
      
      gracePeriodBinder.setBean(new GracePeriod());
      effectiveDateTextField.setValue(LocalDate.now());
    });
    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);
    initGridEditor(gracePeriodDataProvider);
  }
  
  private void initGridEditor(GracePeriodDataProvider gracePeriodDataProvider) {
    BeanValidationBinder<GracePeriod> editorBinder = new BeanValidationBinder<>(GracePeriod.class);
    gracePeriodGrid.getEditor().setBinder(editorBinder);
    
    TextField nameEditor = new TextField();
    Binder.Binding<GracePeriod, Integer> nameBinding = editorBinder.forField(nameEditor).withConverter(new StringToIntegerConverter("Days must enter a number")).bind("days");
    gracePeriodGrid.getColumn("days").setEditorBinding(nameBinding);
  
    DateField editEffectiveDate = new DateField();
    Binder.Binding<GracePeriod, LocalDate> effectiveDate = editorBinder.forField(editEffectiveDate).bind("effectiveDate");
    gracePeriodGrid.getColumn("effectiveDate").setEditorBinding(effectiveDate);
    
//    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
//    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
//    Binder.Binding<GracePeriod, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
//    gracePeriodGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);
    gracePeriodGrid.getEditor().setEnabled(true);
    gracePeriodGrid.getEditor().addSaveListener(e -> {
      if(gracePeriodDataProvider.checkBackDateBeforeSave(e.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        gracePeriodDataProvider.save(e.getBean());
    });
  }
}
