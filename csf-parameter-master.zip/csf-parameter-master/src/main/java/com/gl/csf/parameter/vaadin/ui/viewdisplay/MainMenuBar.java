package com.gl.csf.parameter.vaadin.ui.viewdisplay;

import com.gl.csf.parameter.common.I18nMessage;
import com.gl.csf.parameter.vaadin.ui.UIScopeParameterUIViews;
import com.vaadin.server.ThemeResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.UI;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/07/2017.
 */
@SpringComponent
@UIScope
public class MainMenuBar extends MainMenuBarDesign {

  private final static String SPACE = "";

  @Inject
  public MainMenuBar(VaadinSecurity vaadinSecurity, I18nMessage localizer) {
    //set picture logo
    ThemeResource resource = new ThemeResource("images/logo.svg");
    logo.setSource(resource);
    logo.addClickListener(e -> UI.getCurrent().getNavigator().navigateTo(SPACE));

    // Loan Product
    MenuBar.MenuItem loanProduct = loanProductMenuBar.addItem("Loan Product Parameter",null);
    loanProduct.addItem("Product Configuration",createNavigationCommand(UIScopeParameterUIViews.PRODUCT_CONFIGURATION));
    loanProduct.addItem("Standard Loan",createNavigationCommand(UIScopeParameterUIViews.STANDARD_LOAN));
    loanProduct.addItem("Revolving Loan",createNavigationCommand(UIScopeParameterUIViews.REVOLVING_LOAN));
    loanProduct.addItem("Staff Loan",createNavigationCommand(UIScopeParameterUIViews.STAFF_LOAN));

    // General
    MenuBar.MenuItem generalParameter = generalMenuBar.addItem("General Parameter", null);
    generalParameter.addItem("Address", createNavigationCommand(UIScopeParameterUIViews.ADDRESS));

    // Finance
    MenuBar.MenuItem finance = financeMenuBar.addItem("Finance Parameter",  null);
    finance.addItem("Financial Configuration", createNavigationCommand(UIScopeParameterUIViews.FINANCIAL_PARAMETER));

    // Underwriting
    MenuBar.MenuItem underwriting = underwritingMenuBar.addItem("Underwriting Parameter", createNavigationCommand(UIScopeParameterUIViews.FIELD_CHECK_LIST));
    MenuBar.MenuItem userName = userNameMenuBar.addItem("Aaron Garza",null);
    
    if(vaadinSecurity.isAuthenticated())
      userName.addItem(localizer.getMessage("logout"), e -> vaadinSecurity.logout()).setStyleName("pull-right");
  }

  private MenuBar.Command createNavigationCommand(final String viewName) {
    return menuItem -> getUI().getNavigator().navigateTo(viewName);
  }
}
