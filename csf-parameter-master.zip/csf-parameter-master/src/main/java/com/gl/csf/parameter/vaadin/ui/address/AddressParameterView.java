package com.gl.csf.parameter.vaadin.ui.address;

import com.gl.csf.parameter.config.security.Role;
import com.gl.csf.parameter.vaadin.ui.UIScopeParameterUIViews;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

/**
 * Created by p.ly on 9/15/2017.
 */
@UIScope
@SpringComponent
@SpringView(name = UIScopeParameterUIViews.ADDRESS)
@Secured(Role.ADMINISTRATOR)
public class AddressParameterView extends AddressParameterViewDesign implements View {
}
