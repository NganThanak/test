package com.gl.csf.parameter.vaadin.ui.product;

import com.vaadin.shared.ui.ContentMode;
import com.vaadin.ui.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 31/07/2017.
 */
public abstract class LoanProductView extends VerticalLayout {

  Window createSaveProductMessage(String textMessage) {
    Window subWindow = new Window();
    VerticalLayout components = new VerticalLayout();

    Label message = new Label(textMessage, ContentMode.HTML);
    components.addComponent(message);
    components.setComponentAlignment(message, Alignment.MIDDLE_CENTER);

    Button close = new Button("Close", clickEvent -> subWindow.close());
    components.addComponent(close);
    components.setComponentAlignment(close, Alignment.BOTTOM_CENTER);

    subWindow.setContent(components);
    return displayConfiguration(subWindow);
  }

  Window createConfirmationRemoveTerm(Button delete) {
    Window subWindow = new Window();
    VerticalLayout components = new VerticalLayout();

    Label message = new Label("<p style='color: blue;'>Are you sure to remove this term?</p>", ContentMode.HTML);
    components.addComponent(message);
    components.setComponentAlignment(message, Alignment.MIDDLE_CENTER);

    HorizontalLayout wrapButton = new HorizontalLayout();

    Button cancel = new Button("No", clickEvent -> subWindow.close());
    delete.addClickListener(e -> {
      subWindow.close();
    });
    wrapButton.addComponent(delete);
    wrapButton.addComponent(cancel);
    components.addComponent(wrapButton);
    components.setComponentAlignment(wrapButton, Alignment.BOTTOM_CENTER);

    subWindow.setContent(components);
    return displayConfiguration(subWindow);
  }

  private Window displayConfiguration(Window window) {
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth("500px");
    window.setHeight("130px");

    return window;
  }
}
