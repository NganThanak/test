package com.gl.csf.parameter.vaadin.ui.address.districtparameter;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.District;
import com.gl.csf.parameter.domain.model.address.State;
import com.gl.csf.parameter.vaadin.dataprovider.DistrictDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.StateDataProvider;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;
import javax.inject.Inject;
import java.util.Arrays;

/**
 * Created by p.ly on 9/15/2017.
 */
@UIScope
@SpringComponent
public class DistrictParameterComponent extends DistrictParameterComponentDesign{

  @Inject
  public DistrictParameterComponent(DistrictDataProvider districtDataProvider, StateDataProvider stateDataProvider){
    districtGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    districtGrid.setDataProvider(districtDataProvider);
    stateComboBox.setDataProvider(stateDataProvider);

    Binder<District> districtBinder = new BeanValidationBinder<>(District.class);
    districtBinder.bind(districtNameTextField,"name");
    districtBinder.bind(districtBurmeseNameTextField,"burmeseName");
    districtBinder.bind(stateComboBox,"state");
    districtBinder.setBean(new District());

    districtBinder.addStatusChangeListener(e -> addDistricButton.setEnabled(e.getBinder().isValid()));

    addDistricButton.setEnabled(false);
    addDistricButton.addClickListener(e->{
      districtDataProvider.save(districtBinder.getBean());
      districtBinder.setBean(new District());
    });

    addDistricButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);
    initGridEditor(districtDataProvider,stateDataProvider);
  }

  private void initGridEditor(DistrictDataProvider districtDataProvider,StateDataProvider stateDataProvider) {
    BeanValidationBinder<District> editorBinder = new BeanValidationBinder<>(District.class);
    districtGrid.getEditor().setBinder(editorBinder);

    // Set editor of state field
    ComboBox<State> stateEditor = new ComboBox<>();
    stateEditor.setDataProvider(stateDataProvider);
    Binder.Binding<District, State> stateBinding = editorBinder.bind(stateEditor, "state");
    districtGrid.getColumn("state").setEditorBinding(stateBinding).setCaption("State");

    // Set editor of name field
    TextField nameEditor = new TextField();
    Binder.Binding<District, String> nameBinding = editorBinder.bind(nameEditor, "name");
    districtGrid.getColumn("name").setEditorBinding(nameBinding).setCaption("District");

    // Set editor of burmeseName field
    TextField burmeseNameEditor = new TextField();
    Binder.Binding<District, String> burmeseNameBinding = editorBinder.bind(burmeseNameEditor, "burmeseName");
    districtGrid.getColumn("burmeseName").setEditorBinding(burmeseNameBinding).setCaption("");

    // Set editor of record status field
    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
    Binder.Binding<District, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
    districtGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding).setCaption("");

    districtGrid.getEditor().setEnabled(true);
    districtGrid.getEditor().addSaveListener(e-> districtDataProvider.save(e.getBean()));
  }
}
