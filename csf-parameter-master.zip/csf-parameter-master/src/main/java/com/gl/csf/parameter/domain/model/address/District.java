package com.gl.csf.parameter.domain.model.address;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.List;
/**
 * Created by p.ly on 9/18/2017.
 */
@Entity
@Table(name = "district")
public class District  extends AbstractUUIDEntity {
  @NotEmpty
  @Column(name = "name")
  private String name;

  @NotEmpty
  @Column(name = "burmese_name")
  private String burmeseName;

  @NotNull
  @JsonBackReference
  @ManyToOne
  @JoinColumn(name = "state_id", nullable = false, referencedColumnName = "id")
  private State state;

  @JsonIgnore
  @OneToMany(mappedBy="district")
  private List<Township> townships;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getBurmeseName() {
    return burmeseName;
  }

  public void setBurmeseName(String burmeseName) {
    this.burmeseName = burmeseName;
  }

  public State getState() {
    return state;
  }

  public void setState(State state) {
    this.state = state;
  }

  public List<Township> getTownships() {
    return townships;
  }

  public void setTownships(List<Township> townships) {
    this.townships = townships;
  }

  @Override
  public String toString() {
    return name;
  }
}
