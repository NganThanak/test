package com.gl.csf.parameter.domain.model.address;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 7/28/2017.
 */
@Entity
@Table(name = "township")
public class Township extends AbstractUUIDEntity {
  @NotEmpty
  @Column(name = "name")
  private String name;

  @NotEmpty
  @Column(name = "burmese_name")
  private String burmeseName;

  @NotNull
  @JsonBackReference
  @ManyToOne
  @JoinColumn(name = "district_id", nullable = false, referencedColumnName = "id")
  private District district;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getBurmeseName() {
    return burmeseName;
  }

  public void setBurmeseName(String burmeseName) {
    this.burmeseName = burmeseName;
  }

  public District getDistrict() {
    return district;
  }

  public void setDistrict(District district) {
    this.district = district;
  }

  @Override
  public String toString() {
    return name;
  }
}
