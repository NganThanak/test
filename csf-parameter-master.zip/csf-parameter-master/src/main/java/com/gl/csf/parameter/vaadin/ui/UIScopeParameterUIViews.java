package com.gl.csf.parameter.vaadin.ui;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/09/2017.
 */
public class UIScopeParameterUIViews {

  // Finance
  public static final String FINANCIAL_PARAMETER = "finance/";

  // Product
  private static final String PRODUCT_PARAMETER = "product/";
  public static final String PRODUCT_CONFIGURATION = "";
  public static final String STANDARD_LOAN = PRODUCT_PARAMETER + "standardloan";
  public static final String REVOLVING_LOAN = PRODUCT_PARAMETER + "revolvingloan";
  public static final String STAFF_LOAN = PRODUCT_PARAMETER + "staffloan";

  // General
  public static final String ADDRESS ="address/";

  // Underwriting
  private static final String UNDERWRITER_PARAMETER = "underwriter/";
  public static final String FIELD_CHECK_LIST = UNDERWRITER_PARAMETER + "fieldchecklist";
}
