package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.StaffLoanTermRepository;
import com.gl.csf.parameter.domain.model.product.StaffLoanTerm;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import org.springframework.context.annotation.Scope;

import javax.inject.Inject;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 1/18/2018.
 */
@Scope("prototype")
@SpringComponent
public class StaffLoanTermDataProvider extends AbstractBackEndDataProvider<StaffLoanTerm, String> {

  private final StaffLoanTermRepository repository;

  @Inject
  public StaffLoanTermDataProvider(StaffLoanTermRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

    @Override
    protected Stream<StaffLoanTerm> fetchFromBackEnd(Query<StaffLoanTerm, String> query) {
    return StreamSupport.stream(repository.findByRecordStatus(ERecordStatus.ACTIVE).spliterator(), true);
  }

    @Override
    protected int sizeInBackEnd(Query<StaffLoanTerm, String> query) {
    return Math.toIntExact(repository.countByRecordStatus(ERecordStatus.ACTIVE));
  }

  public void save(StaffLoanTerm bean) {
    repository.save(bean);
    refreshAll();
  }

  public void remove(StaffLoanTerm bean) {
    bean.setRecordStatus(ERecordStatus.INACTIVE);
    save(bean);
  }
}
