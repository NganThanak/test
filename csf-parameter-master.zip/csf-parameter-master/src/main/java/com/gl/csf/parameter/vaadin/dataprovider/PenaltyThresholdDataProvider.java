package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.payment.PenaltyThresholdRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.PenaltyThreshold;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/26/2018.
 */
@Component
public class PenaltyThresholdDataProvider extends AbstractBackEndDataProvider<PenaltyThreshold, String> {

  private final PenaltyThresholdRepository penaltyThresholdRepository;

  public PenaltyThresholdDataProvider(PenaltyThresholdRepository penaltyThresholdRepository) {
    this.penaltyThresholdRepository = penaltyThresholdRepository;
  }

  public void save(PenaltyThreshold bean) {
    penaltyThresholdRepository.save(bean);
    refreshAll();
  }

  public boolean checkBackDateBeforeSave(LocalDate date) {
    PenaltyThreshold gracePeriod = penaltyThresholdRepository.findFirstByOrderByEffectiveDate();
    return gracePeriod != null ? (gracePeriod.getEffectiveDate().compareTo(date) > 0 &&  LocalDate.now().compareTo(date) > 0) :  LocalDate.now().compareTo(date) > 0;
  }

  @Override
  protected Stream<PenaltyThreshold> fetchFromBackEnd(Query<PenaltyThreshold, String> query) {
    return StreamSupport.stream(penaltyThresholdRepository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<PenaltyThreshold, String> query) {
    return Math.toIntExact(penaltyThresholdRepository.count());
  }
}
