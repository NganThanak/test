package com.gl.csf.parameter.domain.dao.bank;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.bank.Bank;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 16/08/2017.
 */
@Repository
public interface BankRepository extends CrudRepository<Bank, UUID> {
  List<Bank> findAllByRecordStatus(ERecordStatus eRecordStatus);
}
