package com.gl.csf.parameter.vaadin.ui.finance.payment;

import com.gl.csf.parameter.domain.model.paymentconfiguration.DueDateCalculationPeriod;
import com.gl.csf.parameter.vaadin.dataprovider.DueDateCalculationPeriodDataProvider;
import com.gl.csf.parameter.vaadin.util.BackDateError;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import java.time.LocalDate;

/**
 * Created by p.ly on 2/1/2018.
 */
@UIScope
@SpringComponent
public class DueDateCalculationPeriodComponent extends DueDateCalculationPeriodComponentDesign {
  @Inject
  public DueDateCalculationPeriodComponent(DueDateCalculationPeriodDataProvider gracePeriodDataProvider) {
    dueDateGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    dueDateGrid.setDataProvider(gracePeriodDataProvider);

    Binder<DueDateCalculationPeriod> gracePeriodBinder = new BeanValidationBinder<>(DueDateCalculationPeriod.class);

    gracePeriodBinder.forField(daysTextField).withConverter(new StringToIntegerConverter("Days must enter a number")).bind("days");
    gracePeriodBinder.forField(effectiveDateTextField).bind("effectiveDate");
    gracePeriodBinder.setBean(new DueDateCalculationPeriod());
    effectiveDateTextField.setValue(LocalDate.now());
    gracePeriodBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    addButton.setEnabled(false);
    addButton.addClickListener(e -> {
      if (gracePeriodDataProvider.checkBackDateBeforeSave(gracePeriodBinder.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        gracePeriodDataProvider.save(gracePeriodBinder.getBean());

      gracePeriodBinder.setBean(new DueDateCalculationPeriod());
      effectiveDateTextField.setValue(LocalDate.now());
    });
    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);
    initGridEditor(gracePeriodDataProvider);
  }

  private void initGridEditor(DueDateCalculationPeriodDataProvider gracePeriodDataProvider) {
    BeanValidationBinder<DueDateCalculationPeriod> editorBinder = new BeanValidationBinder<>(DueDateCalculationPeriod.class);
    dueDateGrid.getEditor().setBinder(editorBinder);

    TextField nameEditor = new TextField();
    Binder.Binding<DueDateCalculationPeriod, Integer> nameBinding = editorBinder.forField(nameEditor).withConverter(new StringToIntegerConverter("Days must enter a number")).bind("days");
    dueDateGrid.getColumn("days").setEditorBinding(nameBinding);

    DateField editEffectiveDate = new DateField();
    Binder.Binding<DueDateCalculationPeriod, LocalDate> effectiveDate = editorBinder.forField(editEffectiveDate).bind("effectiveDate");
    dueDateGrid.getColumn("effectiveDate").setEditorBinding(effectiveDate);

    dueDateGrid.getEditor().setEnabled(true);
    dueDateGrid.getEditor().addSaveListener(e -> {
      if (gracePeriodDataProvider.checkBackDateBeforeSave(e.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        gracePeriodDataProvider.save(e.getBean());
    });
  }
}