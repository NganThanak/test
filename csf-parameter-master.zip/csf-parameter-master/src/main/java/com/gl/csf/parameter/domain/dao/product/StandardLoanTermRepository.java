package com.gl.csf.parameter.domain.dao.product;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.product.StandardLoanTerm;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */

public interface StandardLoanTermRepository extends CrudRepository<StandardLoanTerm, UUID> {
  List<StandardLoanTerm> findByRecordStatus(ERecordStatus recordStatus);

  long countByRecordStatus(ERecordStatus recordStatus);
}
