package com.gl.csf.parameter.config.security;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 10/6/2017.
 */
public class Role {
  public static final String ADMINISTRATOR = "ROLE_ADMINISTRATOR";
  public static final String OPERATION_STAFF = "ROLE_OPERATION_STAFF";
  public static final String CUSTOMER = "ROLE_CUSTOMER";
}
