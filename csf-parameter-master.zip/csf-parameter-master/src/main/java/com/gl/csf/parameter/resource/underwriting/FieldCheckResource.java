package com.gl.csf.parameter.resource.underwriting;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.otherconfiguration.FieldCheckListRepository;
import com.gl.csf.parameter.domain.model.underwriting.FieldCheckList;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/09/2017.
 */
@Component
@Path("/fieldchecklist")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Field Checklist", produces = "application/json")
public class FieldCheckResource {

  private final FieldCheckListRepository repository;

  @Inject
  public FieldCheckResource(FieldCheckListRepository repository){
    this.repository = repository;
  }

  @GET
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Return Field Checklist")
  })
  public Response getAll(){
    return Response.ok().entity(repository.findAllByRecordStatus(ERecordStatus.ACTIVE)).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Return Field Check list by id"),
          @ApiResponse(code = 404, message = "Given Field Check list not found"
          )
  })
  public Response getBankById(@PathParam("id") UUID id){
    FieldCheckList fieldCheckList = repository.findOne(id);
    if (fieldCheckList == null)
      throw new NotFoundException();

    return Response.ok(fieldCheckList).build();
  }
}
