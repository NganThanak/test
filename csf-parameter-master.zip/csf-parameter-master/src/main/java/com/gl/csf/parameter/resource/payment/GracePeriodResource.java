package com.gl.csf.parameter.resource.payment;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.payment.GracePeriodRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.GracePeriod;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 1/16/2018.
 */
@Component
@Path("/graceperiods")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Grace Period", produces = "application/json")
public class GracePeriodResource {

  private final GracePeriodRepository repository;

  @Inject
  GracePeriodResource(GracePeriodRepository repository) {
    this.repository = repository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return list of Grace Periods")
  })
  public Response getAllGracePeriods() {
    List<GracePeriod> loanPurposes = repository.findAllByRecordStatus(ERecordStatus.ACTIVE);
    return Response.ok().entity(loanPurposes).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return Grace Period by id"),
    @ApiResponse(code = 404, message = "Given Grace Period not found"
    )
  })
  public Response getGracePeriod(@PathParam("id") UUID id){

    GracePeriod gracePeriod = repository.findOne(id);
    if (gracePeriod == null) {
      throw new NotFoundException();
    }
    return Response.ok(gracePeriod).build();
  }

}
