package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.address.RelationshipRepository;
import com.gl.csf.parameter.domain.model.address.Relationship;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/26/2017.
 */
@Component
public class RelationshipDataProvider extends AbstractBackEndDataProvider<Relationship, String> {
	private final RelationshipRepository repository;
	@Inject
	public RelationshipDataProvider(RelationshipRepository repository){
		this.repository = repository;
	}
	@Override
	protected Stream<Relationship> fetchFromBackEnd(Query<Relationship, String> query) {
		return StreamSupport.stream(repository.findAll().spliterator(), true);
	}

	@Override
	protected int sizeInBackEnd(Query<Relationship, String> query) {
		return Math.toIntExact(repository.count());
	}
	public void save(Relationship bean) {
		repository.save(bean);
		refreshAll();
	}
}
