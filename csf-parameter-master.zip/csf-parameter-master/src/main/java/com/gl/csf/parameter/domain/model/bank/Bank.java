package com.gl.csf.parameter.domain.model.bank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 16/08/2017.
 */
@Entity
@Table(name = "bank")
public class Bank extends AbstractUUIDEntity {

  @NotEmpty
  @Column(name = "name")
  private String name;

  @JsonIgnore
  @OneToMany(mappedBy="bank")
  private List<BankAccount> bankAccounts;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<BankAccount> getBankAccounts() {
    return bankAccounts;
  }

  public void setBankAccounts(List<BankAccount> bankAccounts) {
    this.bankAccounts = bankAccounts;
  }

  @Override
  public String toString(){
    return name;
  }
}
