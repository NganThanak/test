package com.gl.csf.parameter.vaadin.ui.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.productconfiguration.CompanyRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.Company;
import com.gl.csf.parameter.vaadin.dataprovider.CompanyDataProvider;
import com.gl.csf.parameter.vaadin.ui.common.ConfirmationMessageComponent;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.inject.Inject;
import java.util.Arrays;

/**
 * Created by p.ly on 1/20/2018.
 */
@SpringComponent
@UIScope
public class CompanyComponent extends CompanyComponentDesign{
  private final Logger logger = LoggerFactory.getLogger(CompanyComponent.class);

  @Inject
  CompanyComponent (CompanyDataProvider dataProvider, CompanyRepository repository){
    companyGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    companyGrid.setDataProvider(dataProvider);

    Binder<Company> companyBinder = new BeanValidationBinder<>(Company.class);
    companyBinder.bind(bankNameTextField, "company");
    companyBinder.setBean(new Company());
    companyBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    addButton.setEnabled(false);
    addButton.addClickListener(e -> {
      dataProvider.save(companyBinder.getBean());
      companyBinder.setBean(new Company());
    });

    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);

    initGridEditor(dataProvider, repository);
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  private void initGridEditor(CompanyDataProvider dataProvider, CompanyRepository repository){
    BeanValidationBinder<Company> editorBinder = new BeanValidationBinder<>(Company.class);
    companyGrid.getEditor().setBinder(editorBinder);

    // Set editor of company field
    TextField nameEditor = new TextField();
    Binder.Binding<Company, String> nameBinding = editorBinder.bind(nameEditor, "company");
    companyGrid.getColumn("company").setEditorBinding(nameBinding);

    // Set editor of record status field
    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
    Binder.Binding<Company, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
    companyGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);

    //Deleted Company
    companyGrid.addComponentColumn(event->{
      Button deleteButton =new Button("");
      deleteButton.setIcon(VaadinIcons.TRASH);
      deleteButton.setStyleName("field_check-references-document-close-button borderless");
      deleteButton.addClickListener(e->{

        ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
        Window window = confirmationMessage.displayConfiguration();
        confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
          @Override
          public void onClosed() { window.close(); }
          @Override
          public void onNoButtonClicked() { window.close(); }
          @Override
          public void onYesButtonClicked() {
            try {
              repository.delete(event);
              companyGrid.getDataProvider().refreshAll();
            }catch (Exception ex){
              logger.error("Error while deleting loan purpose", ex);
            }
            window.close();
          }
        });
        window.setContent(confirmationMessage);
        UI.getCurrent().addWindow(window);
      });
      return deleteButton;
    });
    companyGrid.getEditor().setEnabled(true);
    companyGrid.getEditor().addSaveListener(e-> dataProvider.save(e.getBean()));
  }
}
