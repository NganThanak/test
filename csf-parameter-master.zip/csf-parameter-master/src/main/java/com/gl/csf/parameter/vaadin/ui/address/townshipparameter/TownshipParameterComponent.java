package com.gl.csf.parameter.vaadin.ui.address.townshipparameter;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.District;
import com.gl.csf.parameter.domain.model.address.Township;
import com.gl.csf.parameter.vaadin.dataprovider.DistrictDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.TownshipDataProvider;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;
import javax.inject.Inject;
import java.util.Arrays;

/**
 * Created by p.ly on 9/18/2017.
 */
@UIScope
@SpringComponent
public class TownshipParameterComponent extends TownshipParameterComponentDesign{

  @Inject
  public TownshipParameterComponent(DistrictDataProvider districtDataProvider, TownshipDataProvider townshipDataProvider){
    townshipGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    townshipGrid.setDataProvider(townshipDataProvider);
    districtComboBox.setDataProvider(districtDataProvider);

    Binder<Township> townshipBinder = new BeanValidationBinder<>(Township.class);
    townshipBinder.bind(townshipNameTextField,"name");
    townshipBinder.bind(townshipBurmeseNameTextField,"burmeseName");
    townshipBinder.bind(districtComboBox,"district");
    townshipBinder.setBean(new Township());

    townshipBinder.addStatusChangeListener(e -> addTownshipButton.setEnabled(e.getBinder().isValid()));

    addTownshipButton.setEnabled(false);
    addTownshipButton.addClickListener(e->{
      townshipDataProvider.save(townshipBinder.getBean());
      townshipBinder.setBean(new Township());
    });

    addTownshipButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);
    initGridEditor(districtDataProvider,townshipDataProvider);
  }

    private void initGridEditor(DistrictDataProvider districtDataProvider, TownshipDataProvider townshipDataProvider) {
      BeanValidationBinder<Township> editorBinder = new BeanValidationBinder<>(Township.class);
      townshipGrid.getEditor().setBinder(editorBinder);

      // Set editor of district field
      ComboBox<District> stateEditor = new ComboBox<>();
      stateEditor.setDataProvider(districtDataProvider);
      Binder.Binding<Township, District> stateBinding = editorBinder.bind(stateEditor, "district");
      townshipGrid.getColumn("district").setEditorBinding(stateBinding).setCaption("District");

      // Set editor of name field
      TextField nameEditor = new TextField();
      Binder.Binding<Township, String> nameBinding = editorBinder.bind(nameEditor, "name");
      townshipGrid.getColumn("name").setEditorBinding(nameBinding).setCaption("Township");

      // Set editor of burmeseName field
      TextField burmeseNameEditor = new TextField();
      Binder.Binding<Township, String> burmeseNameBinding = editorBinder.bind(burmeseNameEditor, "burmeseName");
      townshipGrid.getColumn("burmeseName").setEditorBinding(burmeseNameBinding).setCaption("");

      // Set editor of record status field
      ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
      recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
      Binder.Binding<Township, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
      townshipGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding).setCaption("");

      townshipGrid.getEditor().setEnabled(true);
      townshipGrid.getEditor().addSaveListener(e-> townshipDataProvider.save(e.getBean()));
    }
}
