package com.gl.csf.parameter.domain.model.product;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * Created by p.ly on 1/18/2018.
 */
@Entity
@Table(name = "staff_loan_term")
public class StaffLoanTerm extends AbstractUUIDEntity {

  @NotNull
  @Column(name = "value")
  @Min(value = 1, message = "Term must be greater than 1.")
  private int value;

  public StaffLoanTerm(int value) {
    this.value = value;
  }

  public StaffLoanTerm() {
    value = 1;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public static StaffLoanTerm create() {
    StaffLoanTerm staffLoanTerm = new StaffLoanTerm();
    staffLoanTerm.setValue(0);
    return staffLoanTerm;
  }

  public String toString() {
    return value + " (Months)";
  }
}
