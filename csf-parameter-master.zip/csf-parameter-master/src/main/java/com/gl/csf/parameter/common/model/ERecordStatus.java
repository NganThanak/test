package com.gl.csf.parameter.common.model;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 18/07/2017.
 */
public enum ERecordStatus {
  ACTIVE, INACTIVE
}
