package com.gl.csf.parameter.domain.model.productconfiguration;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
/**
 * Created by p.ly on 12/12/2017.
 */
@Entity
@Table(name = "loan_purpose")
public class LoanPurpose  extends AbstractUUIDEntity {
  @NotEmpty
  @Column(name = "purpose")
  private String purpose;

  public String getPurpose() {
    return purpose;
  }

  public void setPurpose(String purpose) {
    this.purpose = purpose;
  }

  @Override
  public String toString() {
    return purpose;
  }
}