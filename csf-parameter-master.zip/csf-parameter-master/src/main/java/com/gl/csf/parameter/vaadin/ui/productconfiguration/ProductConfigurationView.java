package com.gl.csf.parameter.vaadin.ui.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.config.security.Role;
import com.gl.csf.parameter.domain.dao.productconfiguration.CompanyRepository;
import com.gl.csf.parameter.domain.dao.productconfiguration.InterestRepository;
import com.gl.csf.parameter.domain.dao.productconfiguration.LoanPurposeRepository;
import com.gl.csf.parameter.domain.dao.productconfiguration.StaffLoanPurposeRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.PaymentFrequency;
import com.gl.csf.parameter.domain.model.productconfiguration.VAT;
import com.gl.csf.parameter.vaadin.dataprovider.*;
import com.gl.csf.parameter.vaadin.ui.UIScopeParameterUIViews;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.ValidationResult;
import com.vaadin.data.converter.StringToBigDecimalConverter;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.navigator.View;
import com.vaadin.shared.ui.ContentMode;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import com.vaadin.ui.themes.ValoTheme;
import org.springframework.security.access.annotation.Secured;
import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/07/2017.
 */
@UIScope
@SpringView(name = UIScopeParameterUIViews.PRODUCT_CONFIGURATION)
@Secured(Role.ADMINISTRATOR)
public class ProductConfigurationView extends VerticalLayout implements View {

  private final PaymentFrequencyDataProvider paymentFrequencyDataProvider;
  private final VATDataProvider vatDataProvider;
  private final LoanPurposeDataProvider loanPurposeDataProvider;
  private final LoanPurposeRepository loanPurposeRepository;
  private final StaffLoanPurposeDataProvider staffLoanPurposeDataProvider;
  private final StaffLoanPurposeRepository staffLoanPurposeRepository;
  private final CompanyDataProvider companyDataProvider;
  private final CompanyRepository companyRepository;
  private final InterestDataProvider interestDataProvider;
  private final InterestRepository interestRepository;

  @Inject
  public ProductConfigurationView(PaymentFrequencyDataProvider paymentFrequencyDataProvider,
                                  VATDataProvider vatDataProvider, LoanPurposeDataProvider loanPurposeDataProvider,
                                  LoanPurposeRepository loanPurposeRepository, StaffLoanPurposeDataProvider staffLoanPurposeDataProvider,
                                  StaffLoanPurposeRepository staffLoanPurposeRepository, CompanyDataProvider companyDataProvider,
                                  CompanyRepository companyRepository, InterestDataProvider interestDataProvider, InterestRepository interestRepository) {

    Objects.requireNonNull(paymentFrequencyDataProvider);
    Objects.requireNonNull(vatDataProvider);
    Objects.requireNonNull(loanPurposeDataProvider);
    Objects.requireNonNull(staffLoanPurposeDataProvider);
    Objects.requireNonNull(companyDataProvider);

    this.loanPurposeRepository = loanPurposeRepository;
    this.loanPurposeDataProvider = loanPurposeDataProvider;
    this.paymentFrequencyDataProvider = paymentFrequencyDataProvider;
    this.vatDataProvider = vatDataProvider;
    this.staffLoanPurposeRepository = staffLoanPurposeRepository;
    this.staffLoanPurposeDataProvider = staffLoanPurposeDataProvider;
    this.companyDataProvider = companyDataProvider;
    this.companyRepository = companyRepository;
    this.interestDataProvider = interestDataProvider;
    this.interestRepository = interestRepository;

    initializeUI();
  }

  private void initializeUI() {
    CssLayout components = new CssLayout();
    components.setWidth(85, Unit.PERCENTAGE);
    components.setStyleName("product-configure-layout");
    VerticalLayout content = new VerticalLayout();
    content.setMargin(true);
    content.setSizeFull();
    content.addComponent(createTitleDescription());
    content.addComponent(createPaymentFrequencySection());
    content.addComponent(createVatSection());
    content.addComponent(new LoanPurposeComponent(loanPurposeDataProvider, loanPurposeRepository));
    content.addComponent(new StaffLoanPurposeComponent(staffLoanPurposeDataProvider, staffLoanPurposeRepository));
    content.addComponent(new CompanyComponent(companyDataProvider, companyRepository));
    content.addComponent(new InterestComponent(interestDataProvider, interestRepository));
    components.addComponent(content);
    addComponent(components);
  }

  private VerticalLayout createTitleDescription() {
    VerticalLayout result = new VerticalLayout();
    Label productName = new Label("<h2>Product configuration</h2>", ContentMode.HTML);
    result.addComponent(productName);
    return result;
  }

  private VerticalLayout createPaymentFrequencySection() {
    VerticalLayout paymentSection = new VerticalLayout();

    paymentSection.setSizeFull();
    paymentSection.setStyleName("bank-configuration-sub-title-layout");

    Label paymentLabel = new Label("1. Payment Frequency");
    paymentLabel.setStyleName("product-configuration-sub-title");
    paymentSection.addComponent(paymentLabel);

    HorizontalLayout subContent = new HorizontalLayout();
    paymentSection.addComponent(subContent);

    subContent.setSizeFull();
    subContent.addComponent(createPaymentFrequencyComponent());
    subContent.addComponent(createPaymentFrequencyDataComponent());
    return paymentSection;
  }

  private Component createPaymentFrequencyComponent() {
    VerticalLayout result = new VerticalLayout();
    result.setSizeFull();
    result.setMargin(false);

    HorizontalLayout paymentTextField = new HorizontalLayout();
    paymentTextField.setWidth(100, Unit.PERCENTAGE);

    BeanValidationBinder<PaymentFrequency> paymentFrequencyBinder = new BeanValidationBinder<>(PaymentFrequency.class);

    TextField textFieldFrequency = new TextField("Frequency");
    paymentFrequencyBinder.bind(textFieldFrequency, "description");
    textFieldFrequency.setWidth(100, Unit.PERCENTAGE);

    TextField textFieldMonth = new TextField("Month");
    paymentFrequencyBinder.forField(textFieldMonth).withConverter(new StringToIntegerConverter("Month must be number. Cannot be zero or negative number"))
            .bind("value");
    textFieldMonth.setWidth(100, Unit.PERCENTAGE);

    paymentFrequencyBinder.setBean(PaymentFrequency.create());
    paymentTextField.addComponents(textFieldFrequency, textFieldMonth);

    result.addComponent(paymentTextField);
    result.addComponent(new CssLayout());

    Button buttonAddFrequency = new Button("Add");
    buttonAddFrequency.setStyleName(ValoTheme.BUTTON_PRIMARY);
    buttonAddFrequency.setWidth(-1, Unit.PERCENTAGE);
    buttonAddFrequency.setEnabled(false);

    buttonAddFrequency.addClickListener(e -> {
      paymentFrequencyDataProvider.save(paymentFrequencyBinder.getBean());
      paymentFrequencyBinder.setBean(PaymentFrequency.create());
    });

    paymentFrequencyBinder.addStatusChangeListener(e -> buttonAddFrequency.setEnabled(e.getBinder().isValid()));
    result.addComponent(buttonAddFrequency);

    return result;
  }

  private Component createPaymentFrequencyDataComponent() {
    Grid<PaymentFrequency> grid = new Grid<>();
    grid.setSizeFull();
    grid.setStyleName("csf-purpos-grid");
    grid.setHeight(264,Unit.PIXELS);

    Grid.Column<PaymentFrequency, ?> descriptionColumn = grid.addColumn(PaymentFrequency::getDescription).setCaption("Frequency");
    Grid.Column<PaymentFrequency, ?> valueColumn = grid.addColumn(PaymentFrequency::getValue).setCaption("Month");
    Grid.Column<PaymentFrequency, ?> recordStatusColumn = grid.addColumn(PaymentFrequency::getRecordStatus).setCaption("Status");

    grid.setDataProvider(paymentFrequencyDataProvider);

    VerticalLayout result = new VerticalLayout();
    result.addComponent(grid);
    result.addComponent(new CssLayout());

    // Init in-line grid editor
    BeanValidationBinder<PaymentFrequency> editorBinder = new BeanValidationBinder<>(PaymentFrequency.class);
    grid.getEditor().setBinder(editorBinder);

    // Set editor for value field
    TextField valueEditor = new TextField();
    Binder.Binding<PaymentFrequency, Integer> valueBinding = editorBinder.forField(valueEditor)
            .withConverter(new StringToIntegerConverter("Month must be number. Cannot be zero or negative number"))
            .bind("value");
    valueColumn.setEditorBinding(valueBinding);

    // Set editor for description field
    TextField descriptionEditor = new TextField();
    Binder.Binding<PaymentFrequency, String> descriptionBinding = editorBinder.forField(descriptionEditor)
            .bind("description");
    descriptionColumn.setEditorBinding(descriptionBinding);

    // Set editor of record status field
    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
    Binder.Binding<PaymentFrequency, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
    recordStatusColumn.setEditorBinding(recordStatusBinding);

    grid.getEditor().setEnabled(true);
    grid.getEditor().addSaveListener(e->paymentFrequencyDataProvider.save(e.getBean()));

    return result;
  }

  private VerticalLayout createVatSection() {
    VerticalLayout vatSection = new VerticalLayout();
    vatSection.setSizeFull();
    vatSection.setMargin(true);
    vatSection.setStyleName("bank-configuration-sub-title-layout");

    Label titleLabel = new Label("2. VAT");
    titleLabel.setStyleName("product-configuration-sub-title");
    vatSection.addComponent(titleLabel);

    HorizontalLayout subContent = new HorizontalLayout();
    subContent.setSizeFull();
    subContent.addComponent(createVatComponent());
    subContent.addComponent(createVatDataComponent());

    vatSection.addComponent(subContent);
    return vatSection;
  }

  private Component createVatComponent() {
    VerticalLayout result = new VerticalLayout();
    result.setSizeFull();
    result.setMargin(false);

    HorizontalLayout vatTextField = new HorizontalLayout();
    vatTextField.setWidth(100, Unit.PERCENTAGE);

    BeanValidationBinder<VAT> vatDataBinder = new BeanValidationBinder<>(VAT.class);

    // Value
    TextField textFieldVAT = new TextField("VAT");
    textFieldVAT.setWidth(100, Unit.PERCENTAGE);
    vatDataBinder.forField(textFieldVAT)
            .withConverter(new StringToBigDecimalConverter("VAT must be number. Cannot be zero or negative number."))
            .bind("value");

    // Effective Date
    DateField dateFieldEffectiveDate = new DateField("Effective Date");
    dateFieldEffectiveDate.setWidth(100, Unit.PERCENTAGE);
    vatDataBinder.forField(dateFieldEffectiveDate).bind("effectiveDate");

    vatTextField.addComponents(textFieldVAT, dateFieldEffectiveDate);
    result.addComponent(vatTextField);

    Button buttonAddVAT = new Button("Add");
    buttonAddVAT.setStyleName(ValoTheme.BUTTON_PRIMARY);
    buttonAddVAT.setWidth(-1, Unit.PERCENTAGE);
    buttonAddVAT.setEnabled(false);

    buttonAddVAT.addClickListener(e -> {
      VAT vatBean = vatDataBinder.getBean();

      ValidationResult validationResult = validateVAT(vatBean);

      if(validationResult.isError()){
        Notification.show(validationResult.getErrorMessage(), Notification.Type.WARNING_MESSAGE);
      } else {
        vatDataProvider.save(vatBean);
        vatDataBinder.setBean(VAT.create());
      }
    });
    vatDataBinder.addStatusChangeListener(e -> buttonAddVAT.setEnabled(e.getBinder().isValid()));
    vatDataBinder.setBean(VAT.create());

    result.addComponent(buttonAddVAT);

    return result;
  }

  private Component createVatDataComponent() {
    Grid<VAT> grid = new Grid<>();
    grid.setSizeFull();
    grid.setStyleName("csf-purpos-grid");
    grid.setHeight(264,Unit.PIXELS);

    Grid.Column<VAT, ?> valueColumn = grid.addColumn(VAT::getValue).setCaption("VAT");
    Grid.Column<VAT, ?> effectiveDateColumn = grid.addColumn(VAT::getEffectiveDate).setCaption("Effective Date");
    grid.setDataProvider(vatDataProvider);

    VerticalLayout result = new VerticalLayout();
    result.addComponent(grid);
    result.addComponent(new CssLayout());

    // Init in-line grid editor
    BeanValidationBinder<VAT> editorBinder = new BeanValidationBinder<>(VAT.class);
    grid.getEditor().setBinder(editorBinder);

    // Set editor for value field
    TextField valueEditor = new TextField();
    Binder.Binding<VAT, BigDecimal> valueBinding = editorBinder.forField(valueEditor)
            .withConverter(new StringToBigDecimalConverter("Must be number"))
            .bind("value");
    valueColumn.setEditorBinding(valueBinding);

    // Set editor for effective date field
    DateField effectiveDateEditor = new DateField();
    Binder.Binding<VAT, LocalDate> effectiveDateBinding = editorBinder.forField(effectiveDateEditor)
            .bind("effectiveDate");
    effectiveDateColumn.setEditorBinding(effectiveDateBinding);

    grid.getEditor().setEnabled(true);
    grid.getEditor().addSaveListener(e->{
      Optional<VAT> activeVat = vatDataProvider.getActiveVat(LocalDate.now());

      if(activeVat.isPresent() && e.getBean().getId() != null && activeVat.get().getId() != null && e.getBean().getId().equals(activeVat.get().getId())){
        Notification.show("Can't edit the current active vat", Notification.Type.WARNING_MESSAGE);
        vatDataProvider.refreshAll();
        return;
      }

      VAT vatBean = e.getBean();
      ValidationResult validationResult = validateVAT(vatBean);

      if(validationResult.isError())
        Notification.show(validationResult.getErrorMessage(), Notification.Type.WARNING_MESSAGE);
      else
        vatDataProvider.save(e.getBean());
    });

    return result;
  }

  private ValidationResult validateVAT(VAT vat){
    LocalDate today = LocalDate.now();

    if(vat.getEffectiveDate().compareTo(today) < 0)
      return ValidationResult.error("The date must not be backdated");

    if(vatDataProvider.existsByEffectiveDate(vat.getEffectiveDate()))
      return ValidationResult.error("The date must not be the same as the current existing effective date: " + vat.getEffectiveDate());

    Optional<VAT> optionalVat = vatDataProvider.getActiveVat(today);

    if(optionalVat.isPresent()){
      VAT activeVat = optionalVat.get();
      if(vat.getEffectiveDate().compareTo(activeVat.getEffectiveDate()) <= 0){
        return ValidationResult.error("Effective date must be greater than the current active one which is: " + activeVat.getEffectiveDate());
      }
    }

    return ValidationResult.ok();
  }
}
