package com.gl.csf.parameter.domain.model.address;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "business_type")
public class BusinessType extends AbstractUUIDEntity {
    @NotEmpty
    @Column(name = "name")
    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
