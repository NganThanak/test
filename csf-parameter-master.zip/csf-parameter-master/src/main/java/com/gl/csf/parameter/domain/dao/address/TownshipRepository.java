package com.gl.csf.parameter.domain.dao.address;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.District;
import com.gl.csf.parameter.domain.model.address.Township;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 7/28/2017.
 */
@Repository
public interface TownshipRepository extends CrudRepository<Township, UUID>{
  List<Township> findAllByDistrictAndRecordStatus(District district, ERecordStatus eRecordStatus);
  List<Township> findAllByRecordStatus(ERecordStatus eRecordStatus);
  Optional<Township> findById(UUID id);
}
