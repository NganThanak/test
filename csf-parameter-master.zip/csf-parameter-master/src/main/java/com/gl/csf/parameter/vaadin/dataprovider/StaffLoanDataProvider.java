package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.StaffLoanProductRepository;
import com.gl.csf.parameter.domain.model.product.StaffLoanProduct;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import javax.inject.Inject;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 1/18/2018.
 */
@Scope("prototype")
@SpringComponent
public class StaffLoanDataProvider extends AbstractBackEndDataProvider<StaffLoanProduct, String> {

  private final StaffLoanProductRepository repository;

  @Inject
  public StaffLoanDataProvider(StaffLoanProductRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  @Override
  protected Stream<StaffLoanProduct> fetchFromBackEnd(Query<StaffLoanProduct, String> query) {
    return StreamSupport.stream(repository.findAll(new Sort(Sort.Direction.ASC, "recordStatus")).spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<StaffLoanProduct, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(StaffLoanProduct bean) {
    Optional<StaffLoanProduct> standardLoanProduct = repository.findFirstByRecordStatus(ERecordStatus.ACTIVE);

    if (standardLoanProduct.isPresent()) {
      standardLoanProduct.get().setRecordStatus(ERecordStatus.INACTIVE);
      repository.save(standardLoanProduct.get());
    }

    repository.save(bean);
    refreshAll();
  }
}
