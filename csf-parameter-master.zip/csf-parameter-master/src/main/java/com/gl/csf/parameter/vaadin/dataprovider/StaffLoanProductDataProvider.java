package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.StaffLoanProductRepository;
import com.gl.csf.parameter.domain.model.product.StaffLoanProduct;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import org.springframework.context.annotation.Scope;

import javax.inject.Inject;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 1/18/2018.
 */
@Scope("prototype")
@SpringComponent
public class StaffLoanProductDataProvider extends AbstractBackEndDataProvider<StaffLoanProduct, String> {

  private final StaffLoanProductRepository repository;

  @Inject
  public StaffLoanProductDataProvider(StaffLoanProductRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  @Override
  protected Stream<StaffLoanProduct> fetchFromBackEnd(Query<StaffLoanProduct, String> query) {
    StreamSupport.stream(repository.findAll().spliterator(), true);
    return null;
  }

  @Override
  protected int sizeInBackEnd(Query<StaffLoanProduct, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(StaffLoanProduct bean) {
    repository.save(bean);
    refreshAll();
  }

  public void remove(StaffLoanProduct bean) {
    bean.setRecordStatus(ERecordStatus.INACTIVE);
    save(bean);
  }
}
