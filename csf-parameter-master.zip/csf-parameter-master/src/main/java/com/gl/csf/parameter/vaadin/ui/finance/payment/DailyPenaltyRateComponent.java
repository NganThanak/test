package com.gl.csf.parameter.vaadin.ui.finance.payment;

import com.gl.csf.parameter.common.CurrencyUtil;
import com.gl.csf.parameter.common.StringToMonetaryAmountConverter;
import com.gl.csf.parameter.domain.model.paymentconfiguration.DailyPenaltyRate;
import com.gl.csf.parameter.vaadin.dataprovider.DailyPenaltyRateDataProvider;
import com.gl.csf.parameter.vaadin.util.BackDateError;
import com.gl.csf.parameter.vaadin.util.MonetaryAmountRenderer;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
@UIScope
@SpringComponent
public class DailyPenaltyRateComponent extends DailyPenaltyRateComponentDesign {
  @Inject
  public DailyPenaltyRateComponent(DailyPenaltyRateDataProvider penaltyRateDataProvider){
    dailyPenaltyRateGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    dailyPenaltyRateGrid.setDataProvider(penaltyRateDataProvider);
  
    Binder<DailyPenaltyRate> penaltyRateBinder = new BeanValidationBinder<>(DailyPenaltyRate.class);
    penaltyRateBinder.forField(dailyPenaltyRateTextField).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("rate");
    penaltyRateBinder.forField(effectiveDateTextField).bind("effectiveDate");
    penaltyRateBinder.setBean(new DailyPenaltyRate());
    effectiveDateTextField.setValue(LocalDate.now());
    penaltyRateBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));
    
    addButton.setEnabled(false);
    addButton.addClickListener(e->{
      if(penaltyRateDataProvider.checkBackDateBeforeSave(penaltyRateBinder.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR, "", Notification.Type.ERROR_MESSAGE);
      else
        penaltyRateDataProvider.save(penaltyRateBinder.getBean());
      
      penaltyRateBinder.setBean(new DailyPenaltyRate());
      effectiveDateTextField.setValue(LocalDate.now());
    });
    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);
    initGridEditor(penaltyRateDataProvider);
  }
  
  private void initGridEditor(DailyPenaltyRateDataProvider penaltyRateDataProvider){
    BeanValidationBinder<DailyPenaltyRate> editorBinder = new BeanValidationBinder<>(DailyPenaltyRate.class);
    dailyPenaltyRateGrid.getEditor().setBinder(editorBinder);
    
    TextField nameEditor = new TextField();
    Binder.Binding<DailyPenaltyRate, MonetaryAmount> nameBinding = editorBinder.forField(nameEditor).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("rate");
    dailyPenaltyRateGrid.getColumn("rate").setEditorBinding(nameBinding);
    dailyPenaltyRateGrid.getColumn("rate").setRenderer(new MonetaryAmountRenderer());
  
    DateField editEffectiveDate = new DateField();
    Binder.Binding<DailyPenaltyRate, LocalDate> effectiveDate = editorBinder.forField(editEffectiveDate).bind("effectiveDate");
    dailyPenaltyRateGrid.getColumn("effectiveDate").setEditorBinding(effectiveDate);
    
//    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
//    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
//    Binder.Binding<DailyPenaltyRate, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
//    dailyPenaltyRateGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);
    
    dailyPenaltyRateGrid.getEditor().setEnabled(true);
    dailyPenaltyRateGrid.getEditor().addSaveListener(e-> {
      if(penaltyRateDataProvider.checkBackDateBeforeSave(e.getBean().getEffectiveDate()))
        Notification.show(BackDateError.BACKDATE_ERROR , Notification.Type.ERROR_MESSAGE);
      else
        penaltyRateDataProvider.save(e.getBean());
    });
  }
}
