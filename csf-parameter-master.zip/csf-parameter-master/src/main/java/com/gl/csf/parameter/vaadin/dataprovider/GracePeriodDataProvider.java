package com.gl.csf.parameter.vaadin.dataprovider;


import com.gl.csf.parameter.domain.dao.payment.GracePeriodRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.GracePeriod;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
@Component
public class GracePeriodDataProvider extends AbstractBackEndDataProvider<GracePeriod, String> {
  private final GracePeriodRepository repository;
  
  @Inject
  public GracePeriodDataProvider(GracePeriodRepository repository) {
    this.repository = repository;
  }
  
  public void save(GracePeriod bean) {
    //updateStatusToInactive();
    repository.save(bean);
    refreshAll();
  }
  
  public boolean checkBackDateBeforeSave(LocalDate date) {
    //GracePeriod gracePeriod = repository.findFirstByOrderByEffectiveDate();
    return LocalDate.now().compareTo(date) > 0; //gracePeriod != null ? (gracePeriod.getEffectiveDate().compareTo(date) > 0 &&  LocalDate.now().compareTo(date) > 0) :  LocalDate.now().compareTo(date) > 0;
  }
  
//  public void update(GracePeriod bean){
//    if ((bean.getRecordStatus() == ERecordStatus.ACTIVE)) {
//      updateStatusToInactive();
//      GracePeriod gracePeriod = repository.findOne(bean.getId());
//      gracePeriod.setDays(bean.getDays());
//      gracePeriod.setRecordStatus(ERecordStatus.ACTIVE);
//      repository.save(gracePeriod);
//    } else if(bean.getRecordStatus() == ERecordStatus.INACTIVE) {
//      GracePeriod gracePeriod = repository.findOne(bean.getId());
//      gracePeriod.setDays(bean.getDays());
//      repository.save(gracePeriod);
//    }
//    refreshAll();
//  }
//
//  public void updateStatusToInactive() {
//    List<GracePeriod> gracePeriodList = (List<GracePeriod>) repository.findAll();
//    gracePeriodList.forEach(gracePeriod -> {
//      gracePeriod.setRecordStatus(ERecordStatus.INACTIVE);
//      repository.save(gracePeriod);
//    });
//  }
  
  
  @Override
  protected Stream<GracePeriod> fetchFromBackEnd(Query<GracePeriod, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }
  
  @Override
  protected int sizeInBackEnd(Query<GracePeriod, String> query) {
    return Math.toIntExact(repository.count());
  }
}
