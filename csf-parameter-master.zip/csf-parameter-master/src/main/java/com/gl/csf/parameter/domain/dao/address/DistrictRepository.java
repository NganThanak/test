package com.gl.csf.parameter.domain.dao.address;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.District;
import com.gl.csf.parameter.domain.model.address.State;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 9/18/2017.
 */
@Repository
public interface DistrictRepository extends CrudRepository<District, UUID> {
  List<District> findAllByRecordStatus(ERecordStatus eRecordStatus);
  Optional<District> findById(UUID id);
  List<District> findAllByStateAndRecordStatus(State one, ERecordStatus recordStatus);
}
