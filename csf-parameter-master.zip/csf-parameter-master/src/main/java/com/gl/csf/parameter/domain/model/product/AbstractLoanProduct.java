package com.gl.csf.parameter.domain.model.product;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import com.gl.csf.parameter.domain.model.productconfiguration.PaymentFrequency;
import org.hibernate.annotations.*;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public abstract class AbstractLoanProduct extends AbstractUUIDEntity {

  @NotNull
  @Type(type = "Money")
  @Positive(message = "Maximum loan amount cannot be zero or negative number.")
  @Columns(columns = {@Column(name = "maximum_loan_currency"), @Column(name = "maximum_loan_amount")})
  private MonetaryAmount maximumLoanAmount;

  @NotNull
  @Type(type = "Money")
  @Positive(message = "Maximum loan amount cannot be zero or negative number.")
  @Columns(columns = {@Column(name = "minimum_loan_currency"), @Column(name = "minimum_loan_amount")})
  private MonetaryAmount minimumLoanAmount;

  @NotNull
  @Type(type = "Money")
  @Positive(message = "Financial amount step cannot be zero or negative number.")
  @Columns(columns = {@Column(name = "loan_amount_step_currency"), @Column(name = "loan_amount_step")})
  private MonetaryAmount loanAmountStep;

  @ManyToMany(cascade = CascadeType.MERGE)
  @LazyCollection(LazyCollectionOption.FALSE)
  @JoinTable(name = "payment_frequency_product_loan", joinColumns = {@JoinColumn(name = "loan_id", referencedColumnName = "id")}, inverseJoinColumns = {@JoinColumn(name = "payment_frequency_id", referencedColumnName = "id")})
  private List<PaymentFrequency> paymentFrequencies;

  @Column(name = "description")
  private String description;

  @Column(name = "burmese_description")
  private String burmeseDescription;

  public MonetaryAmount getMaximumLoanAmount() {
    return maximumLoanAmount;
  }

  public void setMaximumLoanAmount(MonetaryAmount maximumLoanAmount) {
    this.maximumLoanAmount = maximumLoanAmount;
  }

  public MonetaryAmount getMinimumLoanAmount() {
    return minimumLoanAmount;
  }

  public void setMinimumLoanAmount(MonetaryAmount minimumLoanAmount) {
    this.minimumLoanAmount = minimumLoanAmount;
  }

  public MonetaryAmount getLoanAmountStep() {
    return loanAmountStep;
  }

  public void setLoanAmountStep(MonetaryAmount loanAmountStep) {
    this.loanAmountStep = loanAmountStep;
  }

  public List<PaymentFrequency> getPaymentFrequencies() {
    return paymentFrequencies;
  }

  public void setPaymentFrequencies(List<PaymentFrequency> paymentFrequencies) {
    this.paymentFrequencies = paymentFrequencies;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getBurmeseDescription() {
    return burmeseDescription;
  }

  public void setBurmeseDescription(String burmeseDescription) {
    this.burmeseDescription = burmeseDescription;
  }
}

