package com.gl.csf.parameter.vaadin.ui.underwriter;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.config.security.Role;
import com.gl.csf.parameter.domain.model.underwriting.FieldCheckList;
import com.gl.csf.parameter.vaadin.dataprovider.FieldCheckListDataProvider;
import com.gl.csf.parameter.vaadin.ui.UIScopeParameterUIViews;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.TextField;
import org.springframework.security.access.annotation.Secured;

import javax.inject.Inject;
import java.util.Arrays;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/13/2017.
 */
@UIScope
@SpringView(name = UIScopeParameterUIViews.FIELD_CHECK_LIST)
@Secured(Role.ADMINISTRATOR)
public class FieldCheckListView extends FieldCheckListViewDesign implements View {

	@Inject
	public FieldCheckListView(FieldCheckListDataProvider fieldCheckListDataProvider) {
		addButton.setEnabled(false);
		mandatoryButtonGroup.setDataProvider(new ListDataProvider<>(Arrays.asList(true, false)));
		textRequiredRadioButton.setDataProvider(new ListDataProvider<>(Arrays.asList(true, false)));
		documentRequiredRadioButton.setDataProvider(new ListDataProvider<>(Arrays.asList(true, false)));
		// Bind data
		Binder<FieldCheckList> binder = new BeanValidationBinder<>(FieldCheckList.class);
		binder.bind(nameTextField, "name");
		binder.bind(descriptionTextArea, "description");
		binder.bind(mandatoryButtonGroup, "isMandatory");
		binder.bind(textRequiredRadioButton, "isTextRequired");
		binder.bind(documentRequiredRadioButton, "isDocumentRequired");
		binder.setBean(new FieldCheckList());

		grid.setDataProvider(fieldCheckListDataProvider);

		binder.addStatusChangeListener(e->addButton.setEnabled(e.getSource().isValid()));
		addButton.addClickListener(e->{
			fieldCheckListDataProvider.save(binder.getBean());
			binder.setBean(new FieldCheckList());
		});

		initGridEditor(fieldCheckListDataProvider);
	}

	private void initGridEditor(FieldCheckListDataProvider fieldCheckListDataProvider){
		BeanValidationBinder<FieldCheckList> editorBinder = new BeanValidationBinder<>(FieldCheckList.class);
		grid.getEditor().setBinder(editorBinder);

		// Set editor for name field
		TextField nameEditor = new TextField();
		Binder.Binding<FieldCheckList, String> nameBinding = editorBinder.bind(nameEditor, "name");
		grid.getColumn("name").setEditorBinding(nameBinding);

		// Set editor for description field
		TextField descriptionEditor = new TextField();
		Binder.Binding<FieldCheckList, String> descriptionBinding = editorBinder.bind(descriptionEditor, "description");
		grid.getColumn("description").setEditorBinding(descriptionBinding);

		// Set editor for is mandatory field
		ComboBox<Boolean> isMandatoryEditor = new ComboBox<>();
		isMandatoryEditor.setDataProvider(new ListDataProvider<Boolean>(Arrays.asList(true, false)));
		Binder.Binding<FieldCheckList, Boolean> isMandatoryBinding = editorBinder.bind(isMandatoryEditor, "isMandatory");
		grid.getColumn("isMandatory").setEditorBinding(isMandatoryBinding);

		// Set editor for is text required field
		ComboBox<Boolean> isTextRequireEditor = new ComboBox<>();
		isTextRequireEditor.setDataProvider(new ListDataProvider<Boolean>(Arrays.asList(true, false)));
		Binder.Binding<FieldCheckList, Boolean> isTextRequiredBinding = editorBinder.bind(isTextRequireEditor, "isTextRequired");
		grid.getColumn("isTextRequired").setEditorBinding(isTextRequiredBinding).setEditorComponent(isTextRequireEditor);

		// Set editor for is document required field
		ComboBox<Boolean> isDocumentRequireEditor = new ComboBox<>();
		isDocumentRequireEditor.setDataProvider(new ListDataProvider<Boolean>(Arrays.asList(true, false)));
		Binder.Binding<FieldCheckList, Boolean> isDocumentRequiredBinding = editorBinder.bind(isDocumentRequireEditor, "isDocumentRequired");
		grid.getColumn("isDocumentRequired").setEditorBinding(isDocumentRequiredBinding);

		// Set editor of record status field
		ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
		recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
		Binder.Binding<FieldCheckList, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
		grid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);

		grid.getEditor().setEnabled(true);
		grid.getEditor().addSaveListener(e-> fieldCheckListDataProvider.save(e.getBean()));
	}
}
