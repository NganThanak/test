package com.gl.csf.parameter.domain.model.product;

import com.gl.csf.parameter.common.CurrencyUtil;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
@Entity
@Table(name = "standard_loan_product")
public class StandardLoanProduct extends AbstractLoanProduct {

  @ManyToMany(cascade = CascadeType.MERGE)
  @LazyCollection(LazyCollectionOption.FALSE)
  @JoinTable(name = "standard_loan_product_loan_term", joinColumns = {@JoinColumn(name = "standard_loan_id", referencedColumnName = "id")}, inverseJoinColumns = {@JoinColumn(name = "standard_term_id", referencedColumnName = "id")})
  private List<StandardLoanTerm> terms;

  public List<StandardLoanTerm> getTerms() {
    return terms;
  }

  public void setTerms(List<StandardLoanTerm> terms) {
    this.terms = terms;
  }

  public static StandardLoanProduct create() {
    MonetaryAmount zero = Money.of(BigDecimal.ZERO, CurrencyUtil.MMK_CURRENCY);

    StandardLoanProduct standardLoanProduct = new StandardLoanProduct();

    standardLoanProduct.setMaximumLoanAmount(zero);
    standardLoanProduct.setMinimumLoanAmount(zero);
    standardLoanProduct.setLoanAmountStep(zero);

    return standardLoanProduct;
  }
}
