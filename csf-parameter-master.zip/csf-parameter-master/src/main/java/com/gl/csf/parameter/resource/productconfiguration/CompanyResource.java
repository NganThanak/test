package com.gl.csf.parameter.resource.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.productconfiguration.CompanyRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.Company;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 1/20/2018.
 */
@Component
@Path("/companies")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Company", produces = "application/json")
public class CompanyResource {

  private final CompanyRepository repository;

  @Inject
  CompanyResource(CompanyRepository repository) {
    this.repository = repository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return list of Companies")
  })
  public Response getAllCompanies() {
    List<Company> companies = repository.findAllByRecordStatus(ERecordStatus.ACTIVE);
    return Response.ok().entity(companies).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return Company by id"),
    @ApiResponse(code = 404, message = "Given Company not found"
    )
  })
  public Response getCompany(@PathParam("id") UUID id){

    Company company = repository.findOne(id);
    if (company == null) {
      throw new NotFoundException();
    }
    return Response.ok(company).build();
  }
}
