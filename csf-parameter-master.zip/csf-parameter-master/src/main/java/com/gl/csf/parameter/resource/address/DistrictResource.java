package com.gl.csf.parameter.resource.address;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.address.DistrictRepository;
import com.gl.csf.parameter.domain.dao.address.StateRepository;
import com.gl.csf.parameter.domain.model.address.District;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 9/18/2017.
 */
@Component
@Path("/districts")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "district", produces = "application/json")
public class DistrictResource {

  private final DistrictRepository districtRepository;
  private final StateRepository stateRepository;

  @Inject
  public DistrictResource(DistrictRepository districtRepository, StateRepository stateRepository){
    this.districtRepository = districtRepository;
    this.stateRepository = stateRepository;
  }

  @GET
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Return List of Districts"),
          @ApiResponse(code = 404, message = "Given State not found"
          )
  })
  public Response getDistrictsByState(@QueryParam("stateid") UUID stateId) {
    if(stateId == null)
      return Response.status(Response.Status.ACCEPTED).entity(districtRepository.findAllByRecordStatus(ERecordStatus.ACTIVE)).build();

    if (!stateRepository.exists(stateId))
      return Response.status(Response.Status.NOT_FOUND).build();

    List<District> townships = districtRepository.findAllByStateAndRecordStatus(stateRepository.findOne(stateId), ERecordStatus.ACTIVE);

    return Response.ok().entity(townships).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return State by id"),
    @ApiResponse(code = 404, message = "Given District not found"
    )
  })
  public Response getDistrict(@PathParam("id") UUID id){

    Optional<District> district = districtRepository.findById(id);
    if (!district.isPresent())
      throw new NotFoundException();

    return Response.ok(district.get()).build();
  }
}
