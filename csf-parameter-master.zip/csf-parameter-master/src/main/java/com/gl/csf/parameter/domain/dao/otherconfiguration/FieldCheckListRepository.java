package com.gl.csf.parameter.domain.dao.otherconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.underwriting.FieldCheckList;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/13/2017.
 */
public interface FieldCheckListRepository extends CrudRepository<FieldCheckList, UUID> {
  List<FieldCheckList> findAllByRecordStatus(ERecordStatus active);
}
