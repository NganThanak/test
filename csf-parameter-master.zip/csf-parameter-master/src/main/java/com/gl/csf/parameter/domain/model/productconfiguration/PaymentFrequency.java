package com.gl.csf.parameter.domain.model.productconfiguration;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
@Entity
@Table(name = "payment_frequency")
public class PaymentFrequency extends AbstractUUIDEntity {

  @NotNull
  @Min(value = 1)
  @Column(name = "value", unique = true)
  private int value;

  @NotNull
  @NotBlank
  @Column(name = "description")
  private String description;

  public PaymentFrequency(){
  }

  public static PaymentFrequency create() {
    PaymentFrequency paymentFrequency = new PaymentFrequency();
    paymentFrequency.setValue(0);
    return paymentFrequency;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public PaymentFrequency(int value, String description) {
    this.value = value;
    this.description = description;
  }

  public String toString() {
    return description + " : " + value;
  }
}
