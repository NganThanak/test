package com.gl.csf.parameter.resource.address;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.address.StateRepository;
import com.gl.csf.parameter.domain.model.address.State;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 9/15/2017.
 */
@Component
@Path("/states")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "state", produces = "application/json")
public class StateResource {
  private final StateRepository stateRepository;

  @Inject
  public StateResource(StateRepository stateRepository){
    this.stateRepository=stateRepository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return List of States")
  })
  public Response getAllStates() {
    List<State> states = stateRepository.findAllByRecordStatus(ERecordStatus.ACTIVE);
    return Response.ok().entity(states).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return State by id"),
    @ApiResponse(code = 404, message = "Given State not found"
    )
  })
  public Response getState(@PathParam("id") UUID id){

    Optional<State> state = stateRepository.findById(id);
    if (!state.isPresent())
      throw new NotFoundException();

    return Response.ok(state.get()).build();
  }
}
