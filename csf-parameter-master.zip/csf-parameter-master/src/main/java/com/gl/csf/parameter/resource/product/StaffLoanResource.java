package com.gl.csf.parameter.resource.product;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.StaffLoanProductRepository;
import com.gl.csf.parameter.domain.model.product.StaffLoanProduct;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Optional;

/**
 * Created by p.ly on 1/18/2018.
 */
@Component
@Path("/staffloan")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Staff Loan", produces = "application/json")
public class StaffLoanResource {

  private final StaffLoanProductRepository repository;

  @Inject
  public StaffLoanResource(StaffLoanProductRepository repository) {
    this.repository = repository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Staff Loan resource found"),
    @ApiResponse(code = 404, message = "Staff loan not found")
  })
  public Response getActiveStaffLoanProduct() {
    Optional<StaffLoanProduct> staffLoanProductOptional = repository.findFirstByRecordStatus(ERecordStatus.ACTIVE);

    if (!staffLoanProductOptional.isPresent())
      throw new NotFoundException();

    return Response.ok(staffLoanProductOptional.get()).build();
  }
}
