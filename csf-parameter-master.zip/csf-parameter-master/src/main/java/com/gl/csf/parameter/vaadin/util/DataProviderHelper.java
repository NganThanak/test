package com.gl.csf.parameter.vaadin.util;

import com.gl.csf.parameter.common.OffsetPageRequest;
import com.vaadin.data.provider.Query;
import com.vaadin.shared.data.sort.SortDirection;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/07/2017.
 */
public class DataProviderHelper {

  public static Pageable createPageable(Query<?, ?> query) {
    List<Sort.Order> sortOrders = query.getSortOrders().stream().map(querySortOrder ->
      new Sort.Order(querySortOrder.getDirection() == SortDirection.ASCENDING
        ? Sort.Direction.ASC : Sort.Direction.DESC, querySortOrder.getSorted())).collect(Collectors.toList());

    return new OffsetPageRequest(query.getOffset(), query.getLimit(),
      sortOrders.isEmpty() ? null : new Sort(sortOrders));
  }
}