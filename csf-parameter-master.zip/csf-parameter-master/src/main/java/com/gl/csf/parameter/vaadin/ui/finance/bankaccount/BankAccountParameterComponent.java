package com.gl.csf.parameter.vaadin.ui.finance.bankaccount;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.bank.Bank;
import com.gl.csf.parameter.domain.model.bank.BankAccount;
import com.gl.csf.parameter.vaadin.dataprovider.BankAccountDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.BankDataProvider;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;
import javax.inject.Inject;
import java.util.Arrays;

/**
 * Created by p.ly on 9/27/2017.
 */
@UIScope
@SpringComponent
public class BankAccountParameterComponent extends BankAccountParameterComponentDesign{
  @Inject
  public BankAccountParameterComponent(BankAccountDataProvider bankAccountDataProvider , BankDataProvider bankDataProvider){
    bankAccountGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    bankAccountGrid.setDataProvider(bankAccountDataProvider);
    bankNameComboBox.setDataProvider(bankDataProvider);

    Binder<BankAccount> bankBinder = new BeanValidationBinder<>(BankAccount.class);
    bankBinder.bind(bankAccountNumberTextField,"accountNumber");
    bankBinder.bind(bankNameComboBox,"bank");
    bankBinder.setBean(new BankAccount());
    bankBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    addButton.setEnabled(false);
    addButton.addClickListener(e->{
      bankAccountDataProvider.save(bankBinder.getBean());
      bankBinder.setBean(new BankAccount());
    });

    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);

    initGridEditor(bankAccountDataProvider , bankDataProvider);
  }
  private void initGridEditor(BankAccountDataProvider bankAccountDataProvider , BankDataProvider bankDataProvider){
    BeanValidationBinder<BankAccount> editorBinder = new BeanValidationBinder<>(BankAccount.class);
    bankAccountGrid.getEditor().setBinder(editorBinder);

    // Set editor of bank combobox
    ComboBox<Bank> bankEditor = new ComboBox<>();
    bankEditor.setDataProvider(bankDataProvider);
    Binder.Binding<BankAccount, Bank> bankBinding = editorBinder.bind(bankEditor, "bank");
    bankAccountGrid.getColumn("bank").setEditorBinding(bankBinding);

    // Set editor of account number
    TextField bankAccountNumberEditor = new TextField();
    Binder.Binding<BankAccount, String> accountNumberBinding = editorBinder.bind(bankAccountNumberEditor, "accountNumber");
    bankAccountGrid.getColumn("accountNumber").setEditorBinding(accountNumberBinding);

    // Set editor of record status field
    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
    Binder.Binding<BankAccount, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
    bankAccountGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);

    bankAccountGrid.getEditor().setEnabled(true);
    bankAccountGrid.getEditor().addSaveListener(e-> bankAccountDataProvider.save(e.getBean()));
  }
}
