package com.gl.csf.parameter.resource.productconfiguration;

import com.gl.csf.parameter.domain.dao.productconfiguration.VATRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.VAT;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 7/26/2017.
 */
@Component
@Path("/vat")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "VAT", produces = "application/json")
public class VATResource {

  private final VATRepository vatRepository;

  @Inject
  public VATResource(VATRepository vatRepository) {
    this.vatRepository = vatRepository;
  }

  @GET
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Found Active VAT"),
          @ApiResponse(code = 404, message = "Active VAT Not found")
  })
  public Response getActiveVAT() {
    Optional<VAT> optionalActiveVat = vatRepository.findTopByEffectiveDateIsLessThanEqualOrderByEffectiveDateDesc(LocalDate.now());

    if(!optionalActiveVat.isPresent())
      throw new NotFoundException("Active VAT can't be found");

    return Response.ok().entity(optionalActiveVat.get()).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Return VAT by id"),
          @ApiResponse(code = 404, message = "Given VAT not found")
  })
  public Response getVATById(@PathParam("id") UUID id){
    VAT vat = vatRepository.findOne(id);

    if (vat == null)
      throw new NotFoundException();

    return Response.ok(vat).build();
  }
}