package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.productconfiguration.VATRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.VAT;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/07/2017.
 */
@Scope("prototype")
@Component
public class VATDataProvider extends AbstractBackEndDataProvider<VAT, String> {

  private final VATRepository repository;

  @Inject
  public VATDataProvider(VATRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  @Override
  protected Stream<VAT> fetchFromBackEnd(Query<VAT, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<VAT, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(VAT bean) {
    repository.save(bean);
    refreshAll();
  }

  public Optional<VAT> getActiveVat(LocalDate baseComparingDate){
    return repository.findTopByEffectiveDateIsLessThanEqualOrderByEffectiveDateDesc(baseComparingDate);
  }

  public boolean existsByEffectiveDate(LocalDate baseComparingDate){
    return repository.existsByEffectiveDate(baseComparingDate);
  }
}
