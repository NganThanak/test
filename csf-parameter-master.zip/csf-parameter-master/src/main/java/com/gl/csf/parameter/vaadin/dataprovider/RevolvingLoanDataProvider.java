package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.product.RevolvingLoanProductRepository;
import com.gl.csf.parameter.domain.model.product.RevolvingLoanProduct;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 7/24/2017.
 */
@Scope("prototype")
@Component
public class RevolvingLoanDataProvider extends AbstractBackEndDataProvider<RevolvingLoanProduct, String> {

  private final RevolvingLoanProductRepository repository;

  @Inject
  public RevolvingLoanDataProvider(RevolvingLoanProductRepository repository) {
    Objects.requireNonNull(repository);
    this.repository = repository;
  }

  @Override
  protected Stream<RevolvingLoanProduct> fetchFromBackEnd(Query<RevolvingLoanProduct, String> query) {
    return StreamSupport.stream(repository.findAll(new Sort(Sort.Direction.ASC, "recordStatus")).spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<RevolvingLoanProduct, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(RevolvingLoanProduct bean) {
    Optional<RevolvingLoanProduct> activeRevolvingLoanProduct = repository.findFirstByRecordStatus(ERecordStatus.ACTIVE);

    if (activeRevolvingLoanProduct.isPresent()) {
      activeRevolvingLoanProduct.get().setRecordStatus(ERecordStatus.INACTIVE);
      repository.save(activeRevolvingLoanProduct.get());
    }

    repository.save(bean);
    refreshAll();
  }
}
