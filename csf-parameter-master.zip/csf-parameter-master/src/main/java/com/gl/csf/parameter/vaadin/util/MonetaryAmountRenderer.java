package com.gl.csf.parameter.vaadin.util;

import com.vaadin.ui.renderers.TextRenderer;
import elemental.json.JsonValue;
import java.util.Locale;
import javax.money.MonetaryAmount;
import javax.money.format.AmountFormatQueryBuilder;
import javax.money.format.MonetaryAmountFormat;
import javax.money.format.MonetaryFormats;

/**
 * Created by jerome on 8/19/17.
 */
public class MonetaryAmountRenderer extends TextRenderer {


  public static final String PATTERN_KEY = "pattern";
  //¤ is a placeholder for the currency symbol
  public static final String DEFAULT_PATTERN = "¤ #,##0.00";
  private final MonetaryAmountFormat monetaryAmountFormatter = MonetaryFormats.getAmountFormat(
      AmountFormatQueryBuilder.of(Locale.getDefault()).set(PATTERN_KEY, DEFAULT_PATTERN)
          .build());


  @Override
  public JsonValue encode(Object value) {
    return super.encode(value == null ? null :
        monetaryAmountFormatter
            .format((MonetaryAmount) value));

  }
}
