package com.gl.csf.parameter.vaadin.ui.product;

import com.gl.csf.parameter.common.CurrencyUtil;
import com.gl.csf.parameter.config.security.Role;
import com.gl.csf.parameter.domain.model.product.RevolvingLoanProduct;
import com.gl.csf.parameter.domain.model.product.RevolvingLoanTerm;
import com.gl.csf.parameter.domain.model.productconfiguration.PaymentFrequency;
import com.gl.csf.parameter.vaadin.dataprovider.PaymentFrequencyDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.RevolvingLoanDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.RevolvingLoanTermDataProvider;
import com.gl.csf.parameter.vaadin.ui.UIScopeParameterUIViews;
import com.gl.csf.parameter.vaadin.util.MonetaryAmountRenderer;
import com.gl.csf.parameter.vaadin.util.StringToMonetaryConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToBigDecimalConverter;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Sizeable;
import com.vaadin.shared.ui.ContentMode;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import com.vaadin.ui.renderers.ButtonRenderer;
import com.vaadin.ui.themes.ValoTheme;
import org.springframework.security.access.annotation.Secured;

import javax.inject.Inject;
import java.util.ArrayList;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 20/07/2017.
 */

@UIScope
@SpringView(name = UIScopeParameterUIViews.REVOLVING_LOAN)
@Secured(Role.ADMINISTRATOR)
public class RevolvingLoanProductView extends LoanProductView implements View {

  private final RevolvingLoanDataProvider revolvingLoanDataProvider;
  private final PaymentFrequencyDataProvider paymentFrequencyDataProvider;
  private final RevolvingLoanTermDataProvider revolvingLoanTermDataProvider;

  @Inject
  public RevolvingLoanProductView(RevolvingLoanDataProvider revolvingLoanDataProvider,
      PaymentFrequencyDataProvider paymentFrequencyDataProvider,
      RevolvingLoanTermDataProvider revolvingLoanTermDataProvider) {

    this.revolvingLoanDataProvider = revolvingLoanDataProvider;
    this.paymentFrequencyDataProvider = paymentFrequencyDataProvider;
    this.revolvingLoanTermDataProvider = revolvingLoanTermDataProvider;

    initializeUI();
  }

  private void initializeUI() {
    BeanValidationBinder<RevolvingLoanProduct> revolvingLoanProductBinder = new BeanValidationBinder<>(
        RevolvingLoanProduct.class);
    BeanValidationBinder<RevolvingLoanTerm> revolvingLoanTermBeanValidationBinder = new BeanValidationBinder<>(
        RevolvingLoanTerm.class);
    Grid<RevolvingLoanTerm> grid = new Grid<>();
    Grid<PaymentFrequency> gridPayment = new Grid<>("Payment frequency");
    addComponent(createTitleDescription());

    VerticalLayout content = new VerticalLayout();

    content.addComponent(
        createTermSection(revolvingLoanProductBinder, revolvingLoanTermBeanValidationBinder, grid));

    content.addComponent(createPaymentSection(revolvingLoanProductBinder, gridPayment));

    Button saveButton = new Button("Save");
    saveButton.setWidth(20, Unit.PERCENTAGE);
    saveButton.setStyleName(ValoTheme.BUTTON_PRIMARY);
    revolvingLoanProductBinder.setBean(RevolvingLoanProduct.create());
    saveButton.setEnabled(false);
    saveButton.addClickListener(e -> {
      if (revolvingLoanProductBinder.getBean().getPaymentFrequencies() == null
          || revolvingLoanProductBinder.getBean().getPaymentFrequencies().isEmpty()
          || revolvingLoanProductBinder.getBean().getTerms() == null
          || revolvingLoanProductBinder.getBean().getTerms().isEmpty()) {
        UI.getCurrent().addWindow(createSaveProductMessage(
            "<p style='color: red;'>Please select term and payment frequency.</p>"));
      } else {
        revolvingLoanDataProvider.save(revolvingLoanProductBinder.getBean());
        revolvingLoanProductBinder.setBean(RevolvingLoanProduct.create());
        saveButton.setEnabled(false);
        grid.deselectAll();
        gridPayment.deselectAll();
        UI.getCurrent().addWindow(createSaveProductMessage(
            "<p style='color: green;'>Create new product successfully</p>"));
      }
    });

    revolvingLoanProductBinder
        .addStatusChangeListener(e -> saveButton.setEnabled(e.getBinder().isValid()));

    content.addComponent(saveButton);
    content.setComponentAlignment(saveButton, Alignment.MIDDLE_CENTER);
    content.addComponent(createRevolvingLoanDataComponent());
    addComponent(content);
  }

  private VerticalLayout createTitleDescription() {
    VerticalLayout result = new VerticalLayout();
    Label productName = new Label("Revolving Loan");
    productName.setStyleName(ValoTheme.LABEL_H2);

    Label description = new Label(
        "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>"
            +
            "<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>",
        ContentMode.HTML);
    result.addComponent(productName);
    result.addComponent(description);
    return result;
  }

  private VerticalLayout createTermSection(
      Binder<RevolvingLoanProduct> revolvingLoanProductBeanBinder,
      Binder<RevolvingLoanTerm> revolvingLoanTermBeanValidationBinder,
      Grid<RevolvingLoanTerm> grid) {

    VerticalLayout result = new VerticalLayout();
    result.addComponent(new Label("<h3>1. Term</h3>", ContentMode.HTML));

    HorizontalLayout contentLayout = new HorizontalLayout();
    contentLayout.setSizeFull();
    result.addComponent(contentLayout);

    contentLayout.addComponent(
        createTermComponent(revolvingLoanTermBeanValidationBinder, revolvingLoanProductBeanBinder,
            grid));

    VerticalLayout childComponent = new VerticalLayout();
    childComponent.setSizeFull();

    TextField interestRate = new TextField("Interest rate (%)");
    revolvingLoanProductBeanBinder.forField(interestRate).withConverter(
        new StringToBigDecimalConverter(
            "Interest rate must be number. Cannot zero or negative number."))
        .bind("interestRate");
    interestRate.setWidth(50, Unit.PERCENTAGE);
    childComponent.addComponent(interestRate);

    TextField minimumWithdrawal = new TextField("Minimum withdrawal");
    revolvingLoanProductBeanBinder.forField(minimumWithdrawal)
        .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
        .bind("minimumWithdrawalAmount");
    minimumWithdrawal.setWidth(50, Unit.PERCENTAGE);
    childComponent.addComponent(minimumWithdrawal);

    contentLayout.addComponent(childComponent);

    return result;
  }

  private Component createTermComponent(Binder<RevolvingLoanTerm> revolvingLoanTermBinder,
      Binder<RevolvingLoanProduct> revolvingLoanProductBinder, Grid<RevolvingLoanTerm> grid) {

    VerticalLayout result = new VerticalLayout();
    result.setMargin(false);

    result.setWidth(100, Unit.PERCENTAGE);

    HorizontalLayout controlPanel = new HorizontalLayout();
    controlPanel.setWidth(100, Unit.PERCENTAGE);

    TextField term = new TextField("Month");
    revolvingLoanTermBinder.forField(term).withConverter(
        new StringToIntegerConverter("Term must be number. Cannot be zero or negative number."))
        .bind("value");
    term.setWidth(100, Unit.PERCENTAGE);

    TextField nonWithdrawalPeriod = new TextField("Non withdrawal period");
    revolvingLoanTermBinder.forField(nonWithdrawalPeriod).withConverter(
        new StringToIntegerConverter(
            "Non withdrawal period must be number. Cannot be zero or negative number."))
        .bind("nonWithdrawalPeriod");
    nonWithdrawalPeriod.setWidth(100, Unit.PERCENTAGE);
    revolvingLoanTermBinder.setBean(RevolvingLoanTerm.create());

    Button addButton = new Button("Add");
    addButton.setWidth(100, Unit.PERCENTAGE);
    addButton.setStyleName(ValoTheme.BUTTON_PRIMARY);

    addButton.setEnabled(false);

    addButton.addClickListener(e -> {
      revolvingLoanTermDataProvider.save(revolvingLoanTermBinder.getBean());
      revolvingLoanTermBinder.setBean(RevolvingLoanTerm.create());
      addButton.setEnabled(false);
    });

    revolvingLoanTermBinder
        .addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    controlPanel.addComponents(term, nonWithdrawalPeriod);

    grid.setWidth(100, Unit.PERCENTAGE);
    grid.addColumn(RevolvingLoanTerm::getValue).setCaption("Term (month)");
    grid.addColumn(RevolvingLoanTerm::getNonWithdrawalPeriod).setCaption("Non withdrawal period");
    grid.addColumn(RevolvingLoanTerm ->
        "Remove", new ButtonRenderer(clickEvent ->
        UI.getCurrent().addWindow(createConfirmationRemoveTerm(new Button("Yes", remove ->
            revolvingLoanTermDataProvider.remove((RevolvingLoanTerm) clickEvent.getItem()))))))
        .setCaption("Action");

    grid.setSelectionMode(Grid.SelectionMode.MULTI);

    grid.setDataProvider(revolvingLoanTermDataProvider);
    grid.addSelectionListener(e -> {
      RevolvingLoanProduct revolvingLoanProduct = revolvingLoanProductBinder.getBean();
      revolvingLoanProduct.setTerms(new ArrayList<>(e.getAllSelectedItems()));
      revolvingLoanProductBinder.setBean(revolvingLoanProduct);
    });

    result.addComponents(controlPanel, addButton, grid);

    return result;
  }

  private Component createPaymentSection(
      Binder<RevolvingLoanProduct> revolvingLoanProductBeanBinder,
      Grid<PaymentFrequency> gridPayment) {
    VerticalLayout result = new VerticalLayout();
    result.setWidth(100, Sizeable.Unit.PERCENTAGE);
    result.addComponent(new Label("<h3>2. Payment</h3>", ContentMode.HTML));

    HorizontalLayout content = new HorizontalLayout();
    content.setWidth(100, Sizeable.Unit.PERCENTAGE);
    result.addComponent(content);

    gridPayment.setWidth(100, Sizeable.Unit.PERCENTAGE);

    gridPayment.addColumn(PaymentFrequency::getDescription).setCaption("Frequency");
    gridPayment.setSelectionMode(Grid.SelectionMode.MULTI);

    gridPayment.setDataProvider(paymentFrequencyDataProvider);

    gridPayment.addSelectionListener(e -> {
      RevolvingLoanProduct revolvingLoanProduct = revolvingLoanProductBeanBinder.getBean();
      revolvingLoanProduct.setPaymentFrequencies(new ArrayList<>(e.getAllSelectedItems()));
      revolvingLoanProductBeanBinder.setBean(revolvingLoanProduct);
    });
    content.addComponent(gridPayment);

    VerticalLayout financeAmountControlLayout = new VerticalLayout();
    TextField minimumFinanceAmount = new TextField("Minimum financial amount");
    minimumFinanceAmount.setWidth(50, Unit.PERCENTAGE);
    revolvingLoanProductBeanBinder.forField(minimumFinanceAmount)
        .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
        .bind("minimumLoanAmount");

    TextField maximumFinanceAmount = new TextField("Maximum financial amount");
    maximumFinanceAmount.setWidth(50, Unit.PERCENTAGE);
    revolvingLoanProductBeanBinder.forField(maximumFinanceAmount)
        .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
        .bind("maximumLoanAmount");

    TextField loanAmountStep = new TextField("Financial amount step");
    loanAmountStep.setWidth(50, Unit.PERCENTAGE);
    revolvingLoanProductBeanBinder.forField(loanAmountStep).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("loanAmountStep");

    financeAmountControlLayout.addComponents(minimumFinanceAmount, maximumFinanceAmount, loanAmountStep);
    content.addComponent(financeAmountControlLayout);

    return result;
  }

  private Component createRevolvingLoanDataComponent() {
    Grid<RevolvingLoanProduct> grid = new Grid<>();
    grid.setSizeFull();

    grid.setCaption("Revolving loan history");

    grid.addColumn(RevolvingLoanProduct::getMaximumLoanAmount)
        .setRenderer(new MonetaryAmountRenderer()).setCaption("Maximum loan amount");
    grid.addColumn(RevolvingLoanProduct::getMinimumLoanAmount)
        .setRenderer(new MonetaryAmountRenderer()).setCaption("Minimum loan amount");
    grid.addColumn(RevolvingLoanProduct::getLoanAmountStep)
      .setRenderer(new MonetaryAmountRenderer()).setCaption("Financial amount step");
    grid.addColumn(RevolvingLoanProduct::getInterestRate).setCaption("Interest rate");
    grid.addColumn(RevolvingLoanProduct::getMinimumWithdrawalAmount)
        .setRenderer(new MonetaryAmountRenderer())
        .setCaption("Minimum withdrawal amount");
    grid.addColumn(RevolvingLoanProduct::getPaymentFrequencies).setCaption("Payment frequency");
    grid.addColumn(RevolvingLoanProduct::getTerms).setCaption("Loan Term");
    grid.addColumn(RevolvingLoanProduct::getCreatedBy).setCaption("Create By");
    grid.addColumn(RevolvingLoanProduct::getCreatedDate).setCaption("Create Date");
    grid.addColumn(RevolvingLoanProduct::getInactivatedBy).setCaption("Inactivated By");
    grid.addColumn(RevolvingLoanProduct::getModifiedDate).setCaption("Modified Date");
    grid.addColumn(RevolvingLoanProduct::getRecordStatus).setCaption("Status");

    grid.setDataProvider(revolvingLoanDataProvider);

    VerticalLayout result = new VerticalLayout();
    result.addComponent(grid);

    return result;
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {
  }
}
