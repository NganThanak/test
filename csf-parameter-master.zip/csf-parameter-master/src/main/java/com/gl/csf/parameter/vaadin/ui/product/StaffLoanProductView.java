package com.gl.csf.parameter.vaadin.ui.product;

import com.gl.csf.parameter.common.CurrencyUtil;
import com.gl.csf.parameter.config.security.Role;
import com.gl.csf.parameter.domain.model.product.StaffLoanProduct;
import com.gl.csf.parameter.domain.model.product.StaffLoanTerm;
import com.gl.csf.parameter.domain.model.productconfiguration.PaymentFrequency;
import com.gl.csf.parameter.vaadin.dataprovider.PaymentFrequencyDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.StaffLoanDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.StaffLoanProductDataProvider;
import com.gl.csf.parameter.vaadin.dataprovider.StaffLoanTermDataProvider;
import com.gl.csf.parameter.vaadin.ui.UIScopeParameterUIViews;
import com.gl.csf.parameter.vaadin.util.MonetaryAmountRenderer;
import com.gl.csf.parameter.vaadin.util.StringToMonetaryConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToBigDecimalConverter;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Sizeable;
import com.vaadin.shared.ui.ContentMode;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import com.vaadin.ui.renderers.ButtonRenderer;
import com.vaadin.ui.themes.ValoTheme;
import org.springframework.security.access.annotation.Secured;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Created by p.ly on 1/18/2018.
 */
@UIScope
@SpringView(name = UIScopeParameterUIViews.STAFF_LOAN)
@Secured(Role.ADMINISTRATOR)
public class StaffLoanProductView extends LoanProductView implements View {

  private final PaymentFrequencyDataProvider paymentFrequencyDataProvider;
  private final StaffLoanTermDataProvider staffLoanTermDataProvider;
  private final StaffLoanDataProvider staffLoanDataProvider;

  @Inject
  public StaffLoanProductView(StaffLoanProductDataProvider staffLoanProductDataProvider, PaymentFrequencyDataProvider paymentFrequencyDataProvider,
                              StaffLoanTermDataProvider staffLoanTermDataProvider, StaffLoanDataProvider staffLoanDataProvider) {
    Objects.requireNonNull(staffLoanProductDataProvider);
    this.paymentFrequencyDataProvider = paymentFrequencyDataProvider;
    this.staffLoanDataProvider = staffLoanDataProvider;
    this.staffLoanTermDataProvider = staffLoanTermDataProvider;
    initializeUI();
  }

  private void initializeUI() {
    VerticalLayout content = new VerticalLayout();
    BeanValidationBinder<StaffLoanProduct> staffLoanProductBinder = new BeanValidationBinder<>(StaffLoanProduct.class);
    BeanValidationBinder<StaffLoanTerm> staffLoanTermBeanValidationBinder = new BeanValidationBinder<>(StaffLoanTerm.class);
    staffLoanProductBinder.setBean(StaffLoanProduct.create());
    Grid<StaffLoanTerm> grid = new Grid<>();
    Grid<PaymentFrequency> paymentGrid = new Grid<>();
    addComponent(createTitleDescription());

    Button saveButton = new Button("Save");
    saveButton.setWidth(20, Unit.PERCENTAGE);
    saveButton.setStyleName(ValoTheme.BUTTON_PRIMARY);
    saveButton.setEnabled(false);
    saveButton.addClickListener(e -> {
      if (staffLoanProductBinder.getBean().getPaymentFrequencies() == null
        || staffLoanProductBinder.getBean().getPaymentFrequencies().isEmpty()
        || staffLoanProductBinder.getBean().getTerms() == null
        || staffLoanProductBinder.getBean().getTerms().isEmpty()) {
        UI.getCurrent().addWindow(createSaveProductMessage("<p style='color: red;'>Please select term and payment frequency.</p>"));
      } else {
        staffLoanDataProvider.save(staffLoanProductBinder.getBean());
        staffLoanProductBinder.setBean(StaffLoanProduct.create());
        saveButton.setEnabled(false);
        grid.deselectAll();
        paymentGrid.deselectAll();
        UI.getCurrent().addWindow(createSaveProductMessage("<p style='color: green;'>Create new product successfully</p>"));
      }
    });

    staffLoanProductBinder.addStatusChangeListener(e -> saveButton.setEnabled(e.getBinder().isValid()));

    content.addComponent(createTermSection(staffLoanTermBeanValidationBinder, staffLoanProductBinder, grid));
    content.addComponent(createPaymentSection(staffLoanProductBinder, paymentGrid));
    content.addComponent(saveButton);
    content.setComponentAlignment(saveButton, Alignment.MIDDLE_CENTER);
    content.addComponent(createStandardLoanGrid());
    addComponent(content);
  }

  private VerticalLayout createTitleDescription() {
    VerticalLayout result = new VerticalLayout();
    Label productName = new Label("Staff Loan");
    productName.setStyleName(ValoTheme.LABEL_H2);

    result.addComponent(productName);
    return result;
  }

  private VerticalLayout createTermSection(Binder<StaffLoanTerm> standardLoanTermBinder, Binder<StaffLoanProduct> standardLoanProductBeanBinder, Grid<StaffLoanTerm> grid) {
    VerticalLayout termSection = new VerticalLayout();
    termSection.addComponent(new Label("<h3>1. Term</h3>", ContentMode.HTML));
    HorizontalLayout subContent = new HorizontalLayout();
    termSection.addComponent(subContent);

    subContent.setWidth(100, Unit.PERCENTAGE);
    subContent.addComponent(createTermComponent(standardLoanTermBinder, standardLoanProductBeanBinder, grid));
    subContent.addComponent(createInterestRateComponent(standardLoanProductBeanBinder));

    return termSection;
  }

  private Component createTermComponent(Binder<StaffLoanTerm> staffLoanTermBinder, Binder<StaffLoanProduct> staffLoanProductBinder, Grid<StaffLoanTerm> grid) {
    VerticalLayout result = new VerticalLayout();
    result.setMargin(false);
    result.setWidth(100, Unit.PERCENTAGE);

    HorizontalLayout controlPanel = new HorizontalLayout();
    controlPanel.setWidth(100, Unit.PERCENTAGE);

    TextField term = new TextField("Month");
    staffLoanTermBinder.forField(term).withConverter(new StringToIntegerConverter("Term must be number. Cannot be zero or negative number."))
      .bind("value");
    term.setWidth(100, Unit.PERCENTAGE);
    staffLoanTermBinder.setBean(StaffLoanTerm.create());

    Button addButton = new Button("Add");
    addButton.setWidth(100, Unit.PERCENTAGE);
    addButton.setStyleName(ValoTheme.BUTTON_PRIMARY);
    addButton.setEnabled(false);
    addButton.addClickListener(e -> {
      staffLoanTermDataProvider.save(staffLoanTermBinder.getBean());
      staffLoanTermBinder.setBean(StaffLoanTerm.create());
      addButton.setEnabled(false);
    });

    staffLoanTermBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    controlPanel.addComponents(term, addButton);
    controlPanel.setComponentAlignment(addButton, Alignment.BOTTOM_LEFT);

    grid.setWidth(100, Unit.PERCENTAGE);
    grid.addColumn(StaffLoanTerm::getValue).setCaption("Term (month)");
    grid.setDataProvider(staffLoanTermDataProvider);
    grid.addColumn(RevolvingLoanTerm ->
      "Remove", new ButtonRenderer(clickEvent ->
      UI.getCurrent().addWindow(createConfirmationRemoveTerm(new Button("Yes", remove ->
        staffLoanTermDataProvider.remove((StaffLoanTerm) clickEvent.getItem())))))).setCaption("Action");

    grid.setSelectionMode(Grid.SelectionMode.MULTI);
    grid.addSelectionListener(e -> {
      StaffLoanProduct staffLoanProduct = staffLoanProductBinder.getBean();
      staffLoanProduct.setTerms(new ArrayList<>(e.getAllSelectedItems()));
      staffLoanProductBinder.setBean(staffLoanProduct);
    });

    result.addComponents(controlPanel, grid);

    return result;
  }

  private Component createInterestRateComponent(Binder<StaffLoanProduct> staffLoanProductBinder) {
    VerticalLayout result = new VerticalLayout();
    result.setSizeFull();

    TextField interestRate = new TextField("Interest rate (%)");
    staffLoanProductBinder.forField(interestRate).withConverter(new StringToBigDecimalConverter("Interest rate must be number. Cannot be zero or negative number."))
      .bind("interestRate");

    interestRate.setWidth(50, Unit.PERCENTAGE);
    result.setSpacing(false);

    result.addComponent(interestRate);

    return result;
  }

  private Component createPaymentSection(Binder<StaffLoanProduct> staffLoanProductBinder, Grid<PaymentFrequency> paymentGrid) {
    VerticalLayout paymentSection = new VerticalLayout();
    paymentSection.setWidth(100, Sizeable.Unit.PERCENTAGE);
    paymentSection.addComponent(new Label("<h3>2. Payment</h3>", ContentMode.HTML));

    HorizontalLayout subContent = new HorizontalLayout();
    subContent.setSizeFull();

    subContent.addComponent(createPaymentFrequencyComponent(staffLoanProductBinder, paymentGrid));
    subContent.addComponent(createMaximumAndMinimumComponent(staffLoanProductBinder));

    paymentSection.addComponent(subContent);
    return paymentSection;
  }

  private Component createPaymentFrequencyComponent(Binder<StaffLoanProduct> staffLoanProductBinder, Grid<PaymentFrequency> paymentGrid) {
    VerticalLayout result = new VerticalLayout();
    result.setSizeFull();
    result.setMargin(false);

    paymentGrid.setWidth(100, Unit.PERCENTAGE);
    paymentGrid.addColumn(PaymentFrequency::getDescription).setCaption("Frequency");
    paymentGrid.setSelectionMode(Grid.SelectionMode.MULTI);

    paymentGrid.setDataProvider(paymentFrequencyDataProvider);

    paymentGrid.addSelectionListener(e -> {
      StaffLoanProduct staffLoanProduct = staffLoanProductBinder.getBean();
      staffLoanProduct.setPaymentFrequencies(new ArrayList<>(e.getAllSelectedItems()));
      staffLoanProductBinder.setBean(staffLoanProduct);
    });

    result.addComponent(new Label("Payment Frequency"));
    result.addComponent(paymentGrid);

    return result;
  }

  private Component createMaximumAndMinimumComponent(Binder<StaffLoanProduct> staffLoanProductBinder) {
    VerticalLayout result = new VerticalLayout();

    TextField maximumFinanceAmount = new TextField("Maximum financial amount");
    maximumFinanceAmount.setWidth(50, Unit.PERCENTAGE);
    staffLoanProductBinder.forField(maximumFinanceAmount).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("maximumLoanAmount");

    TextField minimumFinanceAmount = new TextField("Minimum financial amount");
    minimumFinanceAmount.setWidth(50, Unit.PERCENTAGE);
    staffLoanProductBinder.forField(minimumFinanceAmount).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("minimumLoanAmount");

    TextField loanAmountStep = new TextField("Financial amount step");
    loanAmountStep.setWidth(50, Unit.PERCENTAGE);
    staffLoanProductBinder.forField(loanAmountStep).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("loanAmountStep");

    result.addComponent(loanAmountStep);
    result.addComponent(maximumFinanceAmount);
    result.addComponent(minimumFinanceAmount);


    return result;
  }

  private Component createStandardLoanGrid() {
    VerticalLayout result = new VerticalLayout();
    Grid<StaffLoanProduct> grid = new Grid<>();
    grid.setSizeFull();
    grid.setCaption("Staff loan history");

    grid.addColumn(StaffLoanProduct::getMaximumLoanAmount)
      .setRenderer(new MonetaryAmountRenderer()).setCaption("Maximum loan amount");
    grid.addColumn(StaffLoanProduct::getMinimumLoanAmount)
      .setRenderer(new MonetaryAmountRenderer()).setCaption("Minimum loan amount");
    grid.addColumn(StaffLoanProduct::getLoanAmountStep)
      .setRenderer(new MonetaryAmountRenderer()).setCaption("Financial amount step");
    grid.addColumn(StaffLoanProduct::getInterestRate).setCaption("Interest rate");
    grid.addColumn(StaffLoanProduct::getPaymentFrequencies).setCaption("Payment frequency");
    grid.addColumn(StaffLoanProduct::getTerms).setCaption("Loan Term");
    grid.addColumn(StaffLoanProduct::getCreatedBy).setCaption("Create By");
    grid.addColumn(StaffLoanProduct::getCreatedDate).setCaption("Create Date");
    grid.addColumn(StaffLoanProduct::getInactivatedBy).setCaption("Inactivated By");
    grid.addColumn(StaffLoanProduct::getModifiedDate).setCaption("Modified Date");
    grid.addColumn(StaffLoanProduct::getRecordStatus).setCaption("Status");

    grid.setDataProvider(staffLoanDataProvider);
    result.addComponent(grid);
    return result;
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {

  }
}
