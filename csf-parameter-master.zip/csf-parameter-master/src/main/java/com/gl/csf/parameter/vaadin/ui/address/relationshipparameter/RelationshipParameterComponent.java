package com.gl.csf.parameter.vaadin.ui.address.relationshipparameter;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.Relationship;
import com.gl.csf.parameter.vaadin.dataprovider.RelationshipDataProvider;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import java.util.Arrays;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/26/2017.
 */
@UIScope
@SpringComponent
public class RelationshipParameterComponent extends RelationshipParameterComponentDesign {

	@Inject
	public RelationshipParameterComponent(RelationshipDataProvider relationshipDataProvider){

		relationshipGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
		relationshipGrid.setDataProvider(relationshipDataProvider);

		Binder<Relationship> relationshipBinder = new BeanValidationBinder<Relationship>(Relationship.class);
		relationshipBinder.bind(relationshipNameTextField,"name");
		relationshipBinder.bind(relationshipDescriptionTextArea,"description");
		relationshipBinder.setBean(new Relationship());
		relationshipBinder.addStatusChangeListener(e -> addRelationshipButton.setEnabled(e.getBinder().isValid()));

		addRelationshipButton.setEnabled(false);
		addRelationshipButton.addClickListener(e->{
			relationshipDataProvider.save(relationshipBinder.getBean());
			relationshipBinder.setBean(new Relationship());
		});
		addRelationshipButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);

		initGridEditor(relationshipDataProvider);
	}

	private void initGridEditor(RelationshipDataProvider relationshipDataProvider) {
		BeanValidationBinder<Relationship> editorBinder = new BeanValidationBinder<>(Relationship.class);
		relationshipGrid.getEditor().setBinder(editorBinder);

		TextField nameEditor = new TextField();
		Binder.Binding<Relationship, String> nameBinding = editorBinder.bind(nameEditor, "name");
		relationshipGrid.getColumn("name").setEditorBinding(nameBinding);

		TextField descriptionEditor = new TextField();
		Binder.Binding<Relationship, String> descriptionBinding = editorBinder.bind(descriptionEditor, "description");
		relationshipGrid.getColumn("description").setEditorBinding(descriptionBinding);

		ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
		recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
		Binder.Binding<Relationship, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
		relationshipGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);

		relationshipGrid.getEditor().setEnabled(true);
		relationshipGrid.getEditor().addSaveListener(e-> relationshipDataProvider.save(e.getBean()));
	}
}
