package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.address.TownshipRepository;
import com.gl.csf.parameter.domain.model.address.Township;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 9/18/2017.
 */
@Component
public class TownshipDataProvider extends AbstractBackEndDataProvider<Township, String> {
  private final TownshipRepository repository;

  @Inject
  public TownshipDataProvider(TownshipRepository repository){
    this.repository = repository;
  }

  @Override
  protected Stream<Township> fetchFromBackEnd(Query<Township, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<Township, String> query) {
    return Math.toIntExact(repository.count());
  }
  public void save(Township bean){
    repository.save(bean);
    refreshAll();
  }
}