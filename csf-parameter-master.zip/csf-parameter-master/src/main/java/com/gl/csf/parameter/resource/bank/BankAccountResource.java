package com.gl.csf.parameter.resource.bank;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.bank.BankAccountRepository;
import com.gl.csf.parameter.domain.model.bank.BankAccount;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * Created by p.ly on 9/27/2017.
 */
@Component
@Path("/bankaccounts")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "BankAccount", produces = "application/json")
public class BankAccountResource {
  private final BankAccountRepository bankAccountRepository;

  @Inject
  public BankAccountResource(BankAccountRepository bankAccountRepository){
    this.bankAccountRepository = bankAccountRepository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return List of Bank Accounts")
  })
  public Response getAllBankAccounts(){
    return Response.ok().entity(bankAccountRepository.findAllByRecordStatus(ERecordStatus.ACTIVE)).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return Bank Account by id"),
    @ApiResponse(code = 404, message = "Given Bank Account not found"
    )
  })
  public Response getBankById(@PathParam("id") UUID id){
    BankAccount bankAccount = bankAccountRepository.findOne(id);

    if (bankAccount == null)
      throw new NotFoundException();

    return Response.ok(bankAccount).build();
  }
}
