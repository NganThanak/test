package com.gl.csf.parameter.domain.model.product;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
@Entity
@Table(name = "standard_loan_term")
public class StandardLoanTerm extends AbstractUUIDEntity {

  @NotNull
  @Column(name = "value")
  @Min(value = 1, message = "Term must be greater than 1.")
  private int value;

  public StandardLoanTerm(int value) {
    this.value = value;
  }

  public StandardLoanTerm() {
    value = 1;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public static StandardLoanTerm create() {
    StandardLoanTerm standardLoanTerm = new StandardLoanTerm();
    standardLoanTerm.setValue(0);
    return standardLoanTerm;
  }

  public String toString() {
    return value + " (Months)";
  }
}
