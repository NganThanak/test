package com.gl.csf.parameter.resource.address;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.address.DistrictRepository;
import com.gl.csf.parameter.domain.dao.address.TownshipRepository;
import com.gl.csf.parameter.domain.model.address.Township;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 7/28/2017.
 */

@Component
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "Township", produces = "application/json")
@Path("/townships")
public class TownshipResource {

  private final DistrictRepository districtRepository;
  private final TownshipRepository townshipRepository;

  @Inject
  public TownshipResource(DistrictRepository districtRepository, TownshipRepository townshipRepository) {
    this.districtRepository = districtRepository;
    this.townshipRepository = townshipRepository;
  }

  @GET
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Return List of Townships"),
          @ApiResponse(code = 404, message = "Given District not found"
          )
  })
  public Response getTownshipsByDistrict(@QueryParam("districtid") UUID districtId) {
    if(districtId == null)
      return Response.status(Response.Status.ACCEPTED).entity(townshipRepository.findAllByRecordStatus(ERecordStatus.ACTIVE)).build();

    if (!districtRepository.exists(districtId))
      return Response.status(Response.Status.NOT_FOUND).build();

    List<Township> townships = townshipRepository.findAllByDistrictAndRecordStatus(districtRepository.findOne(districtId), ERecordStatus.ACTIVE);

    return Response.ok().entity(townships).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
          @ApiResponse(code = 200, message = "Return Township by id"),
          @ApiResponse(code = 404, message = "Given Township not found"
          )
  })
  public Response getTownshipById(@PathParam("id") UUID id){

    Optional<Township> township = townshipRepository.findById(id);
    if (!township.isPresent())
      throw new NotFoundException();

    return Response.ok(township.get()).build();
  }

}