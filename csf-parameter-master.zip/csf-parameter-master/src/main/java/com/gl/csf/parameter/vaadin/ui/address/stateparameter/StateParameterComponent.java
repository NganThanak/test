package com.gl.csf.parameter.vaadin.ui.address.stateparameter;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.State;
import com.gl.csf.parameter.vaadin.dataprovider.StateDataProvider;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import javax.inject.Inject;
import java.util.Arrays;
/**
 * Created by p.ly on 9/15/2017.
 */
@UIScope
@SpringComponent
public class StateParameterComponent extends StateParameterComponentDesign {

  @Inject
  public StateParameterComponent(StateDataProvider stateDataProvider){

    stateGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    stateGrid.setDataProvider(stateDataProvider);

    Binder<State> stateBinder = new BeanValidationBinder<State>(State.class);
    stateBinder.bind(stateNameTextField,"name");
    stateBinder.bind(stateBurmeseNameTextField,"burmeseName");
    stateBinder.setBean(new State());
    stateBinder.addStatusChangeListener(e -> addStateButton.setEnabled(e.getBinder().isValid()));

    addStateButton.setEnabled(false);
    addStateButton.addClickListener(e->{
      stateDataProvider.save(stateBinder.getBean());
      stateBinder.setBean(new State());
    });

    addStateButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);

    initGridEditor(stateDataProvider);
  }

  private void initGridEditor(StateDataProvider stateDataProvider) {
    BeanValidationBinder<State> editorBinder = new BeanValidationBinder<>(State.class);
    stateGrid.getEditor().setBinder(editorBinder);

    // Set editor of name field
    TextField nameEditor = new TextField();
    Binder.Binding<State, String> nameBinding = editorBinder.bind(nameEditor, "name");
    stateGrid.getColumn("name").setEditorBinding(nameBinding).setCaption("State");

    // Set editor of burmeseName field
    TextField burmeseNameEditor = new TextField();
    Binder.Binding<State, String> burmeseNameBinding = editorBinder.bind(burmeseNameEditor, "burmeseName");
    stateGrid.getColumn("burmeseName").setEditorBinding(burmeseNameBinding).setCaption("");

    // Set editor of record status field
    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
    Binder.Binding<State, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
    stateGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding).setCaption("");

    stateGrid.getEditor().setEnabled(true);
    stateGrid.getEditor().addSaveListener(e-> stateDataProvider.save(e.getBean()));
  }
}
