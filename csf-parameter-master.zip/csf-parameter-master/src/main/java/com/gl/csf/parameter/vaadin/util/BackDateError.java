package com.gl.csf.parameter.vaadin.util;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/31/2018.
 */
public class BackDateError {
  public static final String BACKDATE_ERROR = "The date must not be backdated";
}
