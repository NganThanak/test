package com.gl.csf.parameter.domain.dao.address;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.Relationship;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/26/2017.
 */
@Repository
public interface RelationshipRepository extends CrudRepository<Relationship, UUID> {
	List<Relationship> findAllByRecordStatus(ERecordStatus eRecordStatus);
}
