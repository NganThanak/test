package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.productconfiguration.CompanyRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.Company;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 1/20/2018.
 */
@Component
public class CompanyDataProvider extends AbstractBackEndDataProvider<Company, String> {
  private final CompanyRepository repository;

  @Inject
  public CompanyDataProvider(CompanyRepository repository) {
    this.repository = repository;
  }
  @Override
  protected Stream<Company> fetchFromBackEnd(Query<Company, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<Company, String> query) {
    return Math.toIntExact(repository.count());
  }

  public void save(Company bean) {
    repository.save(bean);
    refreshAll();
  }
}
