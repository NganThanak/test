package com.gl.csf.parameter.domain.dao.payment;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.paymentconfiguration.DailyPenaltyRate;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
public interface DailyPenaltyRateRepository extends CrudRepository<DailyPenaltyRate, UUID> {
  List<DailyPenaltyRate> findAllByRecordStatus(ERecordStatus eRecordStatus);
  DailyPenaltyRate findAllByRecordStatusIsLike(ERecordStatus eRecordStatus);
  DailyPenaltyRate findFirstByOrderByEffectiveDate();
}
