package com.gl.csf.parameter.common;

import org.springframework.data.domain.AuditorAware;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/07/2017.
 */
public class AuditorAwareImpl implements AuditorAware<String> {

  @Inject
  VaadinSecurity vaadinSecurity;

  @Override
  public String getCurrentAuditor() {
    return vaadinSecurity.isAuthenticated() ? vaadinSecurity.getAuthentication().getName() : "Anonymous";
  }
}
