package com.gl.csf.parameter.domain.model.product;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
@Entity
@Table(name = "revolving_loan_term")
public class RevolvingLoanTerm extends AbstractUUIDEntity {

  @NotNull
  @Column(name = "value")
  @Min(value = 1, message = "Term must be greater than 1.")
  private int value;

  @NotNull
  @Column(name = "non_withdrawal_period")
  @Min(value = 1, message = "Non withdrawal period must be greater than 1.")
  private int nonWithdrawalPeriod;

  public static RevolvingLoanTerm create() {
    RevolvingLoanTerm revolvingLoanTerm = new RevolvingLoanTerm();
    revolvingLoanTerm.setValue(0);
    revolvingLoanTerm.setNonWithdrawalPeriod(0);
    return revolvingLoanTerm;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public int getNonWithdrawalPeriod() {
    return nonWithdrawalPeriod;
  }

  public void setNonWithdrawalPeriod(int nonWithdrawalPeriod) {
    this.nonWithdrawalPeriod = nonWithdrawalPeriod;
  }

  public String toString() {
    return value + " (Months)";
  }
}
