package com.gl.csf.parameter.vaadin.ui.finance.bankname;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.bank.Bank;
import com.gl.csf.parameter.vaadin.dataprovider.BankDataProvider;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.event.ShortcutAction;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;

import javax.inject.Inject;
import java.util.Arrays;

@UIScope
@SpringComponent
public class BankParameterComponent extends BankParameterComponentDesign{

  @Inject
  public BankParameterComponent(BankDataProvider bankDataProvider){
    bankGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
    bankGrid.setDataProvider(bankDataProvider);

    Binder<Bank> bankBinder = new BeanValidationBinder<>(Bank.class);
    bankBinder.bind(bankNameTextField,"name");
    bankBinder.setBean(new Bank());
    bankBinder.addStatusChangeListener(e -> addButton.setEnabled(e.getBinder().isValid()));

    addButton.setEnabled(false);
    addButton.addClickListener(e->{
      bankDataProvider.save(bankBinder.getBean());
      bankBinder.setBean(new Bank());
    });

    addButton.setClickShortcut(ShortcutAction.KeyCode.ENTER);

    initGridEditor(bankDataProvider);
  }

  private void initGridEditor(BankDataProvider bankDataProvider){
    BeanValidationBinder<Bank> editorBinder = new BeanValidationBinder<>(Bank.class);
    bankGrid.getEditor().setBinder(editorBinder);

    // Set editor of name field
    TextField nameEditor = new TextField();
    Binder.Binding<Bank, String> nameBinding = editorBinder.bind(nameEditor, "name");
    bankGrid.getColumn("name").setEditorBinding(nameBinding);

    // Set editor of record status field
    ComboBox<ERecordStatus> recordStatusEditor = new ComboBox<>();
    recordStatusEditor.setDataProvider(new ListDataProvider<ERecordStatus>(Arrays.asList(ERecordStatus.values())));
    Binder.Binding<Bank, ERecordStatus> recordStatusBinding = editorBinder.bind(recordStatusEditor, "recordStatus");
    bankGrid.getColumn("recordStatus").setEditorBinding(recordStatusBinding);

    bankGrid.getEditor().setEnabled(true);
    bankGrid.getEditor().addSaveListener(e-> bankDataProvider.save(e.getBean()));
  }
}
