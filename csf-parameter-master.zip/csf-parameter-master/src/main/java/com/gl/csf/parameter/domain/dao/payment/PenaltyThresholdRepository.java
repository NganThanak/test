package com.gl.csf.parameter.domain.dao.payment;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.paymentconfiguration.PenaltyThreshold;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/26/2018.
 */
public interface PenaltyThresholdRepository extends CrudRepository<PenaltyThreshold, UUID> {
  List<PenaltyThreshold> findAllByRecordStatus(ERecordStatus eRecordStatus);
  PenaltyThreshold findFirstByOrderByEffectiveDate();
}
