package com.gl.csf.parameter.domain.dao.address;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.address.State;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 9/15/2017.
 */
@Repository
public interface StateRepository extends CrudRepository<State, UUID> {
  List<State> findAllByRecordStatus(ERecordStatus eRecordStatus);
  Optional<State> findById(UUID uuid);
}
