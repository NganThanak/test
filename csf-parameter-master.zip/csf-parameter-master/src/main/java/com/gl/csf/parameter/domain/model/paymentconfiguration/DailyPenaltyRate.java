package com.gl.csf.parameter.domain.model.paymentconfiguration;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
@Entity
@Table(name = "daily_penalty_rate")
public class DailyPenaltyRate extends AbstractUUIDEntity {
  @NotNull
  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "rate_currency"), @Column(name = "rate_amount")})
  private MonetaryAmount rate;
  
  @NotNull
  @Column(name = "effective_date")
  private LocalDate effectiveDate;
  
  public LocalDate getEffectiveDate() {
    return effectiveDate;
  }
  
  public void setEffectiveDate(LocalDate effectiveDate) {
    this.effectiveDate = effectiveDate;
  }
  
  public MonetaryAmount getRate() {
    return rate;
  }
  
  public void setRate(MonetaryAmount rate) {
    this.rate = rate;
  }
  
  @Override
  public String toString() {
    return rate.getNumber().toString();
  }
}
