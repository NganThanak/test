package com.gl.csf.parameter.domain.dao.product;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.product.StaffLoanProduct;
import org.springframework.data.repository.PagingAndSortingRepository;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 1/18/2018.
 */
public interface StaffLoanProductRepository extends PagingAndSortingRepository<StaffLoanProduct, UUID> {
  Optional<StaffLoanProduct> findFirstByRecordStatus(ERecordStatus recordStatus);
}
