package com.gl.csf.parameter.domain.model.underwriting;

import com.gl.csf.parameter.common.model.AbstractUUIDEntity;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/13/2017.
 */
@Entity
@Table(name = "field_check_list")
public class FieldCheckList extends AbstractUUIDEntity {

	@NotEmpty
	@Column(name = "name", unique = true)
	private String name;

	@NotEmpty
	@Column(name = "description")
	private String description;

	@NotNull
	@Column(name = "is_mandatory")
	private Boolean isMandatory;

	@NotNull
	@Column(name = "is_text_required")
	private Boolean isTextRequired;

	@NotNull
	@Column(name = "is_document_required")
	private Boolean isDocumentRequired;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(Boolean mandatory) {
		isMandatory = mandatory;
	}

	public Boolean getIsTextRequired() {
		return isTextRequired;
	}

	public void setIsTextRequired(Boolean textRequired) {
		isTextRequired = textRequired;
	}

	public Boolean getIsDocumentRequired() {
		return isDocumentRequired;
	}

	public void setIsDocumentRequired(Boolean documentRequired) {
		isDocumentRequired = documentRequired;
	}
}
