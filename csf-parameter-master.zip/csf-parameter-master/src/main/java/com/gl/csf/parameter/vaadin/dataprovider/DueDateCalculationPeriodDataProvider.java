package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.payment.DueDateCalculationPeriodRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.DueDateCalculationPeriod;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 2/1/2018.
 */
@Component
public class DueDateCalculationPeriodDataProvider extends AbstractBackEndDataProvider<DueDateCalculationPeriod, String> {
  private final DueDateCalculationPeriodRepository repository;

  @Inject
  public DueDateCalculationPeriodDataProvider(DueDateCalculationPeriodRepository repository) {
    this.repository = repository;
  }

  public void save(DueDateCalculationPeriod bean) {
    //updateStatusToInactive();
    repository.save(bean);
    refreshAll();
  }

  public boolean checkBackDateBeforeSave(LocalDate date) {
    DueDateCalculationPeriod gracePeriod = repository.findFirstByOrderByEffectiveDate();
    return gracePeriod != null ? (gracePeriod.getEffectiveDate().compareTo(date) > 0 &&  LocalDate.now().compareTo(date) > 0) :  LocalDate.now().compareTo(date) > 0;
  }

  @Override
  protected Stream<DueDateCalculationPeriod> fetchFromBackEnd(Query<DueDateCalculationPeriod, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<DueDateCalculationPeriod, String> query) {
    return Math.toIntExact(repository.count());
  }
}
