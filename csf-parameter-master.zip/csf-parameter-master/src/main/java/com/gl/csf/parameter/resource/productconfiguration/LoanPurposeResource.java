package com.gl.csf.parameter.resource.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.dao.productconfiguration.LoanPurposeRepository;
import com.gl.csf.parameter.domain.model.productconfiguration.LoanPurpose;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 12/12/2017.
 */
@Component
@Path("/loanpurposes")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "loan_purpose", produces = "application/json")
public class LoanPurposeResource {

  private final LoanPurposeRepository repository;

  @Inject
  LoanPurposeResource(LoanPurposeRepository repository) {
    this.repository = repository;
  }

  @GET
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return list of LoanPurpose")
  })
  public Response getAllLoanPurposes() {
    List<LoanPurpose> loanPurposes = repository.findAllByRecordStatus(ERecordStatus.ACTIVE);
    return Response.ok().entity(loanPurposes).build();
  }

  @GET
  @Path("/{id}")
  @ApiResponses(value = {
    @ApiResponse(code = 200, message = "Return LoanPurpose by id"),
    @ApiResponse(code = 404, message = "Given LoanPurpose not found"
    )
  })
  public Response getLoanPurpose(@PathParam("id") UUID id){

    LoanPurpose loanPurpose = repository.findOne(id);
    if (loanPurpose == null) {
      throw new NotFoundException();
    }
    return Response.ok(loanPurpose).build();
  }
}
