package com.gl.csf.parameter.domain.dao.productconfiguration;

import com.gl.csf.parameter.common.model.ERecordStatus;
import com.gl.csf.parameter.domain.model.productconfiguration.LoanPurpose;
import org.springframework.data.repository.CrudRepository;
import java.util.List;
import java.util.UUID;

/**
 * Created by p.ly on 12/12/2017.
 */
public interface LoanPurposeRepository extends CrudRepository<LoanPurpose, UUID> {
  List<LoanPurpose> findAllByRecordStatus(ERecordStatus eRecordStatus);
}
