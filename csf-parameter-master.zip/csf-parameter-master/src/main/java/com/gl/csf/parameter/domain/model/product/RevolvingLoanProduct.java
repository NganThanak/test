package com.gl.csf.parameter.domain.model.product;

import com.gl.csf.parameter.common.CurrencyUtil;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.annotations.Type;
import org.javamoney.moneta.Money;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 20/07/2017.
 */
@Entity
@Table(name = "revolving_loan_product")
public class RevolvingLoanProduct extends AbstractLoanProduct {

  @ManyToMany(cascade = CascadeType.MERGE)
  @LazyCollection(LazyCollectionOption.FALSE)
  @JoinTable(name = "revolving_loan_product_loan_term", joinColumns = {@JoinColumn(name = "revolving_loan_id", referencedColumnName = "id")}, inverseJoinColumns = {@JoinColumn(name = "revolving_loan_term_id", referencedColumnName = "id")})
  private List<RevolvingLoanTerm> terms;

  @NotNull
  @Type(type = "Money")
  @Positive(message = "Minimum withdrawal amount must be greater than 1.")
  @Columns(columns = {@Column(name = "withdrawal_currency"), @Column(name = "minimum_withdrawal_amount")})
  private MonetaryAmount minimumWithdrawalAmount;

  @NotNull
  @Column(name = "interest_rate")
  @Digits(integer = 2, fraction = 1)
  @Min(value = 1, message = "Interest rate must be greater than 1.")
  private BigDecimal interestRate;

  public BigDecimal getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(BigDecimal interestRate) {
    this.interestRate = interestRate;
  }

  public static RevolvingLoanProduct create() {
    MonetaryAmount zero = Money.of(BigDecimal.ZERO, CurrencyUtil.MMK_CURRENCY);

    RevolvingLoanProduct revolvingLoanProduct = new RevolvingLoanProduct();
    revolvingLoanProduct.setInterestRate(BigDecimal.ZERO);
    revolvingLoanProduct.setMinimumWithdrawalAmount(zero);
    revolvingLoanProduct.setMinimumLoanAmount(zero);
    revolvingLoanProduct.setMaximumLoanAmount(zero);
    revolvingLoanProduct.setLoanAmountStep(zero);

    return revolvingLoanProduct;
  }

  public List<RevolvingLoanTerm> getTerms() {
    return terms;
  }

  public void setTerms(List<RevolvingLoanTerm> terms) {
    this.terms = terms;
  }

  public MonetaryAmount getMinimumWithdrawalAmount() {
    return minimumWithdrawalAmount;
  }

  public void setMinimumWithdrawalAmount(MonetaryAmount minimumWithdrawalAmount) {
    this.minimumWithdrawalAmount = minimumWithdrawalAmount;
  }
}
