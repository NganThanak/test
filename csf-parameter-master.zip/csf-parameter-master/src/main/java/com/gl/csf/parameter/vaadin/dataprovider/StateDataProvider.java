package com.gl.csf.parameter.vaadin.dataprovider;

import com.gl.csf.parameter.domain.dao.address.StateRepository;
import com.gl.csf.parameter.domain.model.address.State;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 9/15/2017.
 */
@Component
public class StateDataProvider extends AbstractBackEndDataProvider<State, String> {
  private final StateRepository repository;
  @Inject
  public StateDataProvider(StateRepository repository){
    this.repository = repository;
  }
  @Override
  protected Stream<State> fetchFromBackEnd(Query<State, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<State, String> query) {
    return Math.toIntExact(repository.count());
  }
  public void save(State bean) {
    repository.save(bean);
    refreshAll();
  }
}
