package com.gl.csf.parameter.vaadin.ui;

import com.gl.csf.parameter.vaadin.ui.viewdisplay.AccessDeniedView;
import com.gl.csf.parameter.vaadin.ui.viewdisplay.MainViewDisplay;
import com.vaadin.annotations.Theme;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.navigator.SpringViewProvider;
import com.vaadin.ui.UI;

import javax.inject.Inject;

/**
 * Created by jerome on 5/23/17.
 */
@SpringUI
@Theme("csf")
public class VaadinUI extends UI {

  private MainViewDisplay mainViewDisplay;
  private SpringViewProvider springViewProvider;

  @Inject
  public VaadinUI(MainViewDisplay mainViewDisplay, SpringViewProvider viewProvider) {
    this.mainViewDisplay = mainViewDisplay;
    this.springViewProvider = viewProvider;
  }

  @Override
  protected void init(VaadinRequest vaadinRequest) {
    springViewProvider.setAccessDeniedViewClass(AccessDeniedView.class);
    setContent(mainViewDisplay);
  }
}
