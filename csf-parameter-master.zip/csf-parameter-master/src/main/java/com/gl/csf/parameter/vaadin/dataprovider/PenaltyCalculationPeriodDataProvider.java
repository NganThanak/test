package com.gl.csf.parameter.vaadin.dataprovider;


import com.gl.csf.parameter.domain.dao.payment.PenaltyCalculationRateRepository;
import com.gl.csf.parameter.domain.model.paymentconfiguration.DailyPenaltyRate;
import com.gl.csf.parameter.domain.model.paymentconfiguration.PenaltyCalculationPeriod;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/10/2018.
 */
@Component
public class PenaltyCalculationPeriodDataProvider extends AbstractBackEndDataProvider<PenaltyCalculationPeriod, String> {
  private final PenaltyCalculationRateRepository repository;
  
  @Inject
  public PenaltyCalculationPeriodDataProvider(PenaltyCalculationRateRepository repository) {
    this.repository = repository;
  }
  
  public void save(PenaltyCalculationPeriod bean) {
    //updateStatusToInactive();
    repository.save(bean);
    refreshAll();
  }
  
  public boolean checkBackDateBeforeSave(LocalDate date) {
    //PenaltyCalculationPeriod calculationPeriod = repository.findFirstByOrderByEffectiveDate();
    return LocalDate.now().compareTo(date) > 0; //calculationPeriod != null ? (calculationPeriod.getEffectiveDate().compareTo(date) > 0 &&  LocalDate.now().compareTo(date) > 0) :  LocalDate.now().compareTo(date) > 0;
  }
  
//  public void update(PenaltyCalculationPeriod bean){
//    if (ERecordStatus.ACTIVE.equals(bean.getRecordStatus())) {
//      updateStatusToInactive();
//      PenaltyCalculationPeriod calculationPeriod = repository.findOne(bean.getId());
//      calculationPeriod.setDays(bean.getDays());
//      calculationPeriod.setRecordStatus(ERecordStatus.ACTIVE);
//      repository.save(calculationPeriod);
//    } else if(ERecordStatus.INACTIVE.equals(bean.getRecordStatus())) {
//      PenaltyCalculationPeriod gracePeriod = repository.findOne(bean.getId());
//      gracePeriod.setDays(bean.getDays());
//      repository.save(gracePeriod);
//    }
//    refreshAll();
//  }
//
//  public void updateStatusToInactive() {
//    List<PenaltyCalculationPeriod> calculationPeriods = (List<PenaltyCalculationPeriod>) repository.findAll();
//    calculationPeriods.forEach(gracePeriod -> {
//      gracePeriod.setRecordStatus(ERecordStatus.INACTIVE);
//      repository.save(gracePeriod);
//    });
//  }
  
  @Override
  protected Stream<PenaltyCalculationPeriod> fetchFromBackEnd(Query<PenaltyCalculationPeriod, String> query) {
    return StreamSupport.stream(repository.findAll().spliterator(), true);
  }
  
  @Override
  protected int sizeInBackEnd(Query<PenaltyCalculationPeriod, String> query) {
    return Math.toIntExact(repository.count());
  }
}
