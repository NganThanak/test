# Parameter module


Spring-boot based application with the following configuration :

- Vaadin 8.0.5
- Hibernate 5.2.104
- Jackson object mapper configuration
- Spring cloud stream RabbitMQ
- Jersey 2.25.1
- Actuator endpoints
- Docker and gitflow configurations


