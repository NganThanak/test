package com.gl.csf.underwriting.ui.component.task;

import com.gl.csf.underwriting.common.model.customer.Gender;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 8/22/2017.
 */
class MockApplication {

	private List<MockApplication> subMockApplications = new ArrayList<>();
	private String id;
	private String applicationDate;
	private String customerName;
	private Enum<Gender> gender;
	private String phoneNumber;
	private String businessName;
	private String address;
	private String city;
	private String township;

	public MockApplication(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(String applicationDate) {
		this.applicationDate = applicationDate;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Enum<Gender> getGender() {
		return gender;
	}

	public void setGender(Enum<Gender> gender) {
		this.gender = gender;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getTownship() {
		return township;
	}

	public void setTownship(String township) {
		this.township = township;
	}

	public List<MockApplication> getSubMockApplications() {
		return subMockApplications;
	}

	public void setSubMockApplications(List<MockApplication> subMockApplications) {
		this.subMockApplications = subMockApplications;
	}

	public void addSubProject(MockApplication subProject) {
		subMockApplications.add(subProject);
	}

}


class LeafProject extends MockApplication {

	private String id;
	private String applicationDate;
	private String customerName;
	private Enum<Gender> gender;
	private String phoneNumber;
	private String businessName;
	private String address;
	private String city;
	private String township;


	public LeafProject(String id, String applicationDate, String customerName, Enum<Gender> gender, String phoneNumber, String businessName, String address, String city, String township) {
		super(id);
		this.applicationDate = applicationDate;
		this.customerName = customerName;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.businessName = businessName;
		this.address = address;
		this.city = city;
		this.township = township;
	}

	@Override
	public String getApplicationDate() {
		return applicationDate;
	}

	@Override
	public String getCustomerName() {
		return customerName;
	}

	@Override
	public Enum<Gender> getGender() {
		return gender;
	}

	@Override
	public String getPhoneNumber() {
		return phoneNumber;
	}

	@Override
	public String getBusinessName() {
		return businessName;
	}

	@Override
	public String getAddress() {
		return address;
	}

	@Override
	public String getCity() {
		return city;
	}

	@Override
	public String getTownship() {
		return township;
	}

}