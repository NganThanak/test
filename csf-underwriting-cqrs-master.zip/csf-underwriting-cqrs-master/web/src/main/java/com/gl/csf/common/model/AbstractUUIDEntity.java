package com.gl.csf.common.model;

import java.time.LocalDateTime;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 18/07/2017.
 */
@MappedSuperclass
public abstract class AbstractUUIDEntity extends AbstractAuditedEntity {

  @Id
  @GeneratedValue
  private UUID id;

  @NotNull(message = "{fieldValidation.notNull}")
  @Column(name = "record_status", length = 10)
  @Enumerated(EnumType.STRING)
  private ERecordStatus recordStatus;

  @Column(name = "inactivated_date")
  private LocalDateTime inactivatedDate;

  @Column(name = "inactivated_by", length = 30)
  private String inactivatedBy;

  @Version
  @Column
  private Integer version;

  @PrePersist
  void prePersist() {
    if (recordStatus == null)
      recordStatus = ERecordStatus.ACTIVE;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public Integer getVersion() {
    return version;
  }

  public void setVersion(Integer version) {
    this.version = version;
  }

  public ERecordStatus getRecordStatus() {
    return recordStatus;
  }

  public void setRecordStatus(ERecordStatus recordStatus) {
    this.recordStatus = recordStatus;
  }

  public LocalDateTime getInactivatedDate() {
    return inactivatedDate;
  }

  public void setInactivatedDate(LocalDateTime inactivatedDate) {
    this.inactivatedDate = inactivatedDate;
  }

  public String getInactivatedBy() {
    return inactivatedBy;
  }

  public void setInactivatedBy(String inactivatedBy) {
    this.inactivatedBy = inactivatedBy;
  }
}