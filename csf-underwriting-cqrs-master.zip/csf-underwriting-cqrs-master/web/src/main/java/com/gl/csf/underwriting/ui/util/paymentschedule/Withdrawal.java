package com.gl.csf.underwriting.ui.util.paymentschedule;

import javax.money.MonetaryAmount;
import java.util.Date;

/**
 * Created by Calvin Phibol on 8/31/2017.
 */
public class Withdrawal {
  private MonetaryAmount amount;
  private Date withdrawalDate;

  public Withdrawal() {

  }

  public Withdrawal(MonetaryAmount amt, Date withdrawalDate) {
    this.amount = amt;
    this.withdrawalDate = withdrawalDate;
  }

  public MonetaryAmount getAmount() {
    return amount;
  }

  public Date getWithdrawalDate() {
    return withdrawalDate;
  }
}
