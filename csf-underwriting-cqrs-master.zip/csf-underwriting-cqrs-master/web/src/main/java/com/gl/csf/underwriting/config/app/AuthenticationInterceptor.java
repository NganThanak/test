package com.gl.csf.underwriting.config.app;

import java.util.Collections;
import java.util.List;
import java.util.function.BiFunction;
import org.axonframework.commandhandling.CommandMessage;
import org.axonframework.messaging.MessageDispatchInterceptor;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * Created by jerome on 9/5/17.
 */
public class AuthenticationInterceptor implements MessageDispatchInterceptor<CommandMessage<?>> {


  @Override
  public BiFunction<Integer, CommandMessage<?>, CommandMessage<?>> handle(
      List<CommandMessage<?>> messages) {

    return (index, message) -> SecurityContextHolder.getContext().getAuthentication() == null
        ? message : message
        .andMetaData(Collections.singletonMap("username",
            SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString()));
  }
}
