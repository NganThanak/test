package com.gl.csf.underwriting.ui.component.underwriting;

import com.gl.csf.underwriting.common.model.address.District;
import com.gl.csf.underwriting.common.model.address.State;
import com.gl.csf.underwriting.common.model.address.Township;
import com.gl.csf.underwriting.common.model.bank.Bank;
import com.gl.csf.underwriting.common.model.customer.Gender;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.PersonalInfoRepository;
import com.gl.csf.underwriting.service.BankService;
import com.gl.csf.underwriting.service.DistrictService;
import com.gl.csf.underwriting.service.StateService;
import com.gl.csf.underwriting.service.TownshipService;
import com.gl.csf.underwriting.ui.permission.Role;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.TextField;

import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
public class PersonalInfoComponent extends PersonalInfoComponentDesign {
    private final PersonalInfoRepository repository;
    private final TownshipService townshipService;
    private final DistrictService districtService;
    private final StateService stateService;
    private final BankService bankService;
    private final VaadinSecurity vaadinSecurity;
    @Inject
    public PersonalInfoComponent(PersonalInfoRepository repository, TownshipService townshipService, DistrictService districtService,
                                 StateService stateService, BankService bankService, VaadinSecurity vaadinSecurity) {
        this.repository = repository;
        this.townshipService = townshipService;
        this.districtService = districtService;
        this.stateService = stateService;
        this.bankService = bankService;
        this.vaadinSecurity = vaadinSecurity;
        enableAndDisablePersonalComponent(false);

        buttonEdit.addClickListener(e->{
            if(buttonEdit.getCaption().equalsIgnoreCase("Edit")){
                buttonSave.setVisible(true);
                buttonEdit.setCaption("Cancel");
                enableAndDisablePersonalComponent(true);
            }else if(buttonEdit.getCaption().equalsIgnoreCase("Cancel")) {
                buttonEdit.setCaption("Edit");
                buttonSave.setVisible(false);
                enableAndDisablePersonalComponent(false);
            }
        });
        buttonSave.addClickListener(event ->{
            buttonEdit.setCaption("Edit");
            buttonSave.setVisible(false);
            enableAndDisablePersonalComponent(false);
        });

        buttonSaveBankInfo.setVisible(false);
        enableAndDisableBankInfoComponent(false);

        buttonEditBankInfo.addClickListener(event->{
            if (buttonEditBankInfo.getCaption().equalsIgnoreCase("Edit")){
                buttonSaveBankInfo.setVisible(true);
                buttonEditBankInfo.setCaption("Cancel");
                enableAndDisableBankInfoComponent(true);
            }else if(buttonEditBankInfo.getCaption().equalsIgnoreCase("Cancel")){
                buttonEditBankInfo.setCaption("Edit");
                buttonSaveBankInfo.setVisible(false);
                enableAndDisableBankInfoComponent(false);
            }
        });

        buttonSaveBankInfo.addClickListener(event->{
            buttonEditBankInfo.setCaption("Edit");
            buttonSaveBankInfo.setVisible(false);
            enableAndDisableBankInfoComponent(false);
        });
        comboBoxGender.setDataProvider(new ListDataProvider<Gender>(Arrays.asList(Gender.values())));

        ListDataProvider<State> stateListDataProvider = new ListDataProvider<>(stateService.getAllStates());
        comboBoxState.setDataProvider(stateListDataProvider);
        addListeners(districtService, townshipService);

        ListDataProvider<Bank> bankListDataProvider = new ListDataProvider<>(bankService.getAllBanks());
        comboBoxBankName.setDataProvider(bankListDataProvider);

        //set permission for field checker
        if(vaadinSecurity.hasAuthority(Role.FIELDCHECKER)){
            buttonEditBankInfo.setVisible(false);
            buttonEdit.setVisible(false);
        }
        dateFieldDOB.setRangeEnd(LocalDate.now().minusYears(18));
        
    }
    
    public TextField getTextFieldNRCID() {
    	return textFieldNRCID;
    } 
    
    public TextField getBankAccountNumber() {
    	return textFieldBankNumber;
    }

    private void addListeners(DistrictService districtService, TownshipService townshipService) {
        comboBoxState.addValueChangeListener(e->{
            comboBoxDistrict.clear();
            ListDataProvider<District> districtListDataProvider = e.getSource().getOptionalValue().isPresent()
                    ? new ListDataProvider<>(districtService.getDistrictsByState(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
            comboBoxDistrict.setDataProvider(districtListDataProvider);
        });

        comboBoxDistrict.addValueChangeListener(e->{
            comboBoxTownship.clear();
            ListDataProvider<Township> townshipListDataProvider = e.getSource().getOptionalValue().isPresent()
                    ? new ListDataProvider<>(townshipService.getTownships(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
            comboBoxTownship.setDataProvider(townshipListDataProvider);
        });
    }

    public void enableAndDisablePersonalComponent(boolean value){
        textFieldFullName.setEnabled(value);
        comboBoxGender.setEnabled(value);
        dateFieldDOB.setEnabled(value);
        textFieldPhoneNumber.setEnabled(value);
        textFieldEmail.setEnabled(value);
        textFieldOwnerAddress.setEnabled(value);
        comboBoxDistrict.setEnabled(value);
        comboBoxTownship.setEnabled(value);
        textFieldFatherName.setEnabled(value);
        comboBoxState.setEnabled(value);
        textFieldNRCID.setEnabled(value);
        additionalPhoneNumberTextField1.setEnabled(value);
        additionalPhoneNumberTextField2.setEnabled(value);
    }

    public void enableAndDisableBankInfoComponent(boolean value){
        textFieldBankHolderName.setEnabled(value);
        comboBoxBankName.setEnabled(value);
        textFieldDescription.setEnabled(value);
        radioButtonBankAccountType.setEnabled(value);
        textFieldBankNumber.setEnabled(value);
    }
}