package com.gl.csf.underwriting.ui.dataprovider;

import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialdocument.FinancialDocumentRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;

import javax.inject.Inject;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/27/2017.
 */
@SpringComponent
public class FinancialDocumentDataProvider extends AbstractBackEndDataProvider<FinancialDocumentDTO, String> {
  private final FinancialDocumentRepository repository;

  @Inject
  public FinancialDocumentDataProvider(FinancialDocumentRepository repository) {
    this.repository = repository;
  }

  @Override
  protected Stream<FinancialDocumentDTO> fetchFromBackEnd(Query<FinancialDocumentDTO, String> query) {
    return repository.findAll().parallelStream();
  }

  @Override
  protected int sizeInBackEnd(Query<FinancialDocumentDTO, String> query) {
    return Math.toIntExact(repository.findAll().size());
  }

  public void save(FinancialDocumentDTO bean) {
    repository.save(bean);
    refreshAll();
  }

  public void remove(FinancialDocumentDTO bean) {
    repository.delete(bean);
    refreshAll();
  }
}
