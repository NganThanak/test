package com.gl.csf.underwriting.service;

import com.gl.csf.underwriting.common.model.customer.CustomerApplicationStatus;
import com.gl.csf.underwriting.dto.CreateApplicationPermissionDTO;
import com.gl.csf.underwriting.query.application.customer.loanapplication.LoanApplicationDTO;
import com.gl.csf.underwriting.query.application.customer.loanapplication.LoanApplicationRepository;
import com.gl.csf.underwriting.query.application.customer.loanapplicationsummary.LoanApplicationSummaryDTO;
import com.gl.csf.underwriting.query.application.customer.loanapplicationsummary.LoanApplicationSummaryRepository;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.DAYS;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Service
public class ApplicationQueryService {
  private final LoanApplicationRepository loanApplicationRepository;
  private final LoanApplicationSummaryRepository loanApplicationSummaryRepository;
  private final MessageSource messageSource;

  @Inject
  public ApplicationQueryService(LoanApplicationRepository loanApplicationRepository, LoanApplicationSummaryRepository loanApplicationSummaryRepository, MessageSource messageSource) {
    this.loanApplicationRepository = loanApplicationRepository;
    this.loanApplicationSummaryRepository = loanApplicationSummaryRepository;
    this.messageSource = messageSource;
  }

  public Optional<LoanApplicationDTO> getApplicationById(String id) {
    return loanApplicationRepository.findById(id);
  }

  public List<LoanApplicationDTO> getApplicationsByCustomer(String username) {
    return loanApplicationRepository.findByApplication_Applicant_Username(username);
  }

  public List<LoanApplicationSummaryDTO> getApplicationListByCustomer(String username){
    return loanApplicationSummaryRepository.findAllByUsername(username);
  }

  public CreateApplicationPermissionDTO getCreateApplicationPermission(String username, Locale language) {

    CreateApplicationPermissionDTO createApplicationPermissionDTO = new CreateApplicationPermissionDTO();
    List<LoanApplicationDTO> loanApplications = loanApplicationRepository.findByApplication_Applicant_Username(username);

    Map<CustomerApplicationStatus, List<LoanApplicationDTO>> loanApplicationByStatus = loanApplications.stream().collect(Collectors.groupingBy(LoanApplicationDTO::getCustomerApplicationStatus));

    if (loanApplicationByStatus.containsKey(CustomerApplicationStatus.SAVED)) {
      createApplicationPermissionDTO.setAllowApply(false);
      createApplicationPermissionDTO.setDescription(messageSource.getMessage("permission.desc.draft", null, language));
      return createApplicationPermissionDTO;
    }

    if (loanApplicationByStatus.containsKey(CustomerApplicationStatus.APPLICATION_IN_PROGRESS)) {
      createApplicationPermissionDTO.setAllowApply(false);
      createApplicationPermissionDTO.setDescription(messageSource.getMessage("permission.desc.pending", null, language));
      return createApplicationPermissionDTO;
    }

    if (loanApplicationByStatus.containsKey(CustomerApplicationStatus.APPLICATION_VALIDATED)) {
      createApplicationPermissionDTO.setAllowApply(false);
      createApplicationPermissionDTO.setDescription(messageSource.getMessage("permission.desc.validated", null, language));
      return createApplicationPermissionDTO;
    }

    if (loanApplicationByStatus.containsKey(CustomerApplicationStatus.APPLICATION_DECLINED)) {
      Optional<LoanApplicationDTO> latestRejectedApplication = loanApplicationByStatus.get(CustomerApplicationStatus.APPLICATION_DECLINED).stream()
              .max(Comparator.comparing(LoanApplicationDTO::getRejectedDate));

      if(latestRejectedApplication.isPresent()) {
        Long rejectedDays = DAYS.between(latestRejectedApplication.get().getRejectedDate(), LocalDate.now());
        if (rejectedDays <= 7L) {
          createApplicationPermissionDTO.setAllowApply(false);
          createApplicationPermissionDTO.setDescription(messageSource.getMessage("permission.desc.reject", null, language));
          return createApplicationPermissionDTO;
        }
      }
    }

    createApplicationPermissionDTO.setAllowApply(true);
    createApplicationPermissionDTO.setDescription(messageSource.getMessage("permission.desc.allow", null, language));

    return  createApplicationPermissionDTO;
  }
}
