package com.gl.csf.underwriting.ui.component.common;

import com.gl.csf.underwriting.ui.viewdeclaration.UIScopeUnderwritingViews;
import com.vaadin.annotations.Theme;
import com.vaadin.server.ThemeResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.UI;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 8/15/2017.
 */
@SpringComponent
@UIScope
@SpringUI
@Theme("csf")
public class MainMenuBar extends MainMenuBarDesign {
  private final static String SPACE = "";
  private VaadinSecurity vaadinSecurity;
  @Inject
  public MainMenuBar(VaadinSecurity vaadinSecurity) {
    //set picture logo
    ThemeResource resource = new ThemeResource("images/logo.svg");
    logo.setSource(resource);
    logo.addClickListener(e -> UI.getCurrent().getNavigator().navigateTo(SPACE));

    applicationMenu.addItem("Application", createNavigationCommand(UIScopeUnderwritingViews.APPLICATION_LIST));
    MenuBar.MenuItem item = profileLoggedInMenu.addItem("Welcome, "+vaadinSecurity.getAuthentication().getName().toUpperCase(), null);
    item.addItem("Log out", menuItem -> vaadinSecurity.logout());
  }

  private MenuBar.Command createNavigationCommand(final String viewName) {
    return menuItem -> getUI().getNavigator().navigateTo(viewName);
  }
}
