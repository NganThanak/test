package com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields;

import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceRepository;
import com.gl.csf.underwriting.service.DocumentService;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Label;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Created by p.ly on 10/13/2017.
 */
@SpringComponent
@UIScope
public class UnderwritingFieldReferencesComponent extends UnderwritingFieldReferencesComponentDesign {
  
  private final FieldCheckReferenceRepository fieldCheckReferenceRepository;
  private final FieldCheckReferenceDocumentRepository documentRepository;
  private final DocumentService documentService;
  private String applicationId;
  
  @Inject
  public UnderwritingFieldReferencesComponent(FieldCheckReferenceRepository fieldCheckReferenceRepository, FieldCheckReferenceDocumentRepository documentRepository, DocumentService documentService) {
    this.fieldCheckReferenceRepository = fieldCheckReferenceRepository;
    this.documentService = documentService;
    this.documentRepository = documentRepository;
  }
  
  public void setApplicationId( String applicationId){
    this.applicationId = applicationId;
    fetchData();
  }

  private void fetchData() {
    Map<LocalDateTime, List<FieldCheckReferenceDTO>> tempFieldCheckReferenceGroupByFieldCheckId = fieldCheckReferenceRepository.findByApplicationIdOrderBySubmittedDateDesc(applicationId)
            .stream().collect(Collectors.groupingBy(FieldCheckReferenceDTO::getSubmittedDate));
    content.removeAllComponents();

    Map<LocalDateTime, List<FieldCheckReferenceDTO>> fieldCheckReferenceGroupByFieldCheckId = new TreeMap<>(Collections.reverseOrder());
    fieldCheckReferenceGroupByFieldCheckId.putAll(tempFieldCheckReferenceGroupByFieldCheckId);

    if (fieldCheckReferenceGroupByFieldCheckId.isEmpty()) {
      Label noHistory = new Label("There is no history references submitted to underwriters yet.");
      noHistory.addStyleName("no-history");
      content.addComponent(noHistory);
    }

    fieldCheckReferenceGroupByFieldCheckId.values().forEach(fieldCheckReferenceList -> {
      content.addComponent(new UnderwritingFieldReferenceComponent(documentRepository, fieldCheckReferenceList, documentService));
    });

  }
}
