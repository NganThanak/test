package com.gl.csf.underwriting.ui.component.underwriting.businessinfo;

import com.gl.csf.underwriting.api.application.businessinfo.branch.command.DeleteBranchCommand;
import com.gl.csf.underwriting.api.application.businessinfo.branch.command.MarkBranchAsActiveCommand;
import com.gl.csf.underwriting.api.application.businessinfo.branch.command.MarkBranchAsInactiveCommand;
import com.gl.csf.underwriting.api.application.businessinfo.branch.command.UpdateBranchCommand;
import com.gl.csf.underwriting.common.model.address.BusinessType;
import com.gl.csf.underwriting.common.model.address.District;
import com.gl.csf.underwriting.common.model.address.State;
import com.gl.csf.underwriting.common.model.address.Township;
import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import com.gl.csf.underwriting.common.model.businessinfo.BranchStatus;
import com.gl.csf.underwriting.common.model.businessinfo.Business;
import com.gl.csf.underwriting.common.model.businessinfo.LocationOwner;
import com.gl.csf.underwriting.message.BranchDetailDeletedEvent;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.branch.BranchRepository;
import com.gl.csf.underwriting.query.application.util.CurrencyUtil;
import com.gl.csf.underwriting.service.BusinessTypeService;
import com.gl.csf.underwriting.service.adapter.boss.BossService;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.gl.csf.underwriting.ui.dataprovider.SalesDataProvider;
import com.gl.csf.underwriting.ui.permission.Role;
import com.gl.csf.underwriting.ui.util.NumeralFieldFormatterUtils;
import com.gl.csf.underwriting.ui.util.StringToMonetaryAmountConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.javamoney.moneta.Money;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.vaadin.spring.security.VaadinSecurity;

import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/11/2017.
 */
class BranchDetailComponent extends BranchDetailComponentDesign {

  private final static org.slf4j.Logger logger = LoggerFactory.getLogger(BossService.class);
  private final Consumer<BranchDetailDeletedEvent> deleteBranchDetailEventConsumer;
  private final String OTHER = "Other";
  private Binder<Branch> branchBinder = new BeanValidationBinder<>(Branch.class);
  private Branch originalBranch;

  BranchDetailComponent(BusinessTypeService businessTypeService, Supplier<List<State>> getStates, Function<State, List<District>> getDistrictByState,
                        Function<District, List<Township>> getTownshipByDistrict,
                        CommandGateway commandGateway, BranchRepository branchRepository,
                        BranchDetailComponentListener branchDetailComponentListener, VaadinSecurity vaadinSecurity,
                        SalesDataProvider salesDataProvider, Business business,
                        Consumer<BranchDetailDeletedEvent> deleteBranchDetailEventConsumer) {
    
    Objects.requireNonNull(getStates);
    Objects.requireNonNull(getDistrictByState);
    Objects.requireNonNull(getTownshipByDistrict);
    Objects.requireNonNull(commandGateway);
    Objects.requireNonNull(branchDetailComponentListener);
    Objects.requireNonNull(branchRepository);
    Objects.requireNonNull(vaadinSecurity);
    Objects.requireNonNull(deleteBranchDetailEventConsumer);
  
    this.deleteBranchDetailEventConsumer = deleteBranchDetailEventConsumer;
    
    stateComboBox.setDataProvider(new ListDataProvider<State>(getStates.get()));
    statusComboBox.setDataProvider(new ListDataProvider<BranchStatus>(Arrays.asList(BranchStatus.values())));
    locationOwnerCombobox.setDataProvider(new ListDataProvider<LocationOwner>(Arrays.asList(LocationOwner.values())));
    businessTypeComboBox.setEnabled(false);

    businessTypeComboBox.setDataProvider(new ListDataProvider<BusinessType>(sortBusinessTypes(businessTypeService.getAllBusinessType())));

    businessTypeComboBox.addValueChangeListener(event -> {
      if (businessTypeComboBox.getSelectedItem().isPresent() && OTHER.equalsIgnoreCase(businessTypeComboBox.getSelectedItem().get().getName())) {
        otherBusinessTypeTextArea.setVisible(true);
        otherBusinessTypeTextArea.clear();
      } else
        otherBusinessTypeTextArea.setVisible(false);
    });

    NumeralFieldFormatterUtils.formatNumeralTextField(rentAmountTextField, revenueTextField, expenseTextField, marginTextField,
            staffExpenseTextField, netProfitTextField, otherExpenseTextField);
    
    Window subWindow = new Window();

    saveButton.setEnabled(false);

    branchBinder.addValueChangeListener(e -> {
      calculateMargin();
      calculateNetProfit();
    });

    locationOwnerCombobox.addValueChangeListener(e -> {
      if (e.getSource().getOptionalValue().isPresent())
        if (e.getValue().equals(LocationOwner.OWNER)) {
          rentAmountTextField.setValue("0");
          rentAmountTextField.setEnabled(false);
        } else if (e.getValue().equals(LocationOwner.RENT) && branchBinder.getBean().getRentAmount() == null
          || rentAmountTextField.getValue().equals("0")) {
          rentAmountTextField.setValue("0");
          rentAmountTextField.setEnabled(true);
        }
    });

    stateComboBox.addValueChangeListener(e -> {
      districtComboBox.clear();
      try {
        ListDataProvider<District> districtListDataProvider = e.getSource().getOptionalValue().isPresent()
                ? new ListDataProvider<>(getDistrictByState.apply(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
        districtComboBox.setDataProvider(districtListDataProvider);
      }catch (Exception ex){
        logger.info("this state not found because select nothing :", ex);
      }
    });

    districtComboBox.addValueChangeListener(e -> {
      townshipComboBox.clear();
      try {
        ListDataProvider<Township> townshipListDataProvider = e.getSource().getOptionalValue().isPresent()
                ? new ListDataProvider<>(getTownshipByDistrict.apply(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
        townshipComboBox.setDataProvider(townshipListDataProvider);
      }catch (Exception ex){
        logger.info("this district not found because select nothing :", ex);
      }
    });

    editButton.addClickListener(e -> {
      int branchNumber = branchRepository.findAllByApplicationId(branchBinder.getBean().getApplicationId()).size();
      if (editButton.getCaption().equalsIgnoreCase("Edit")) {
        saveButton.setVisible(true);
        deleteBranchButton.setVisible(branchNumber > 1);
        editButton.setCaption("Cancel");
        enableAndDisableBranchDetailComponent(true);
      } else if (editButton.getCaption().equalsIgnoreCase("Cancel")) {
        reset();
        editButton.setCaption("Edit");
        saveButton.setVisible(false);
        deleteBranchButton.setVisible(false);

        enableAndDisableBranchDetailComponent(false);
      }
    });

    saveButton.addClickListener(e -> {
      editButton.setCaption("Edit");
      saveButton.setVisible(false);
      deleteBranchButton.setVisible(false);
      BeanUtils.copyProperties(branchBinder.getBean(), originalBranch);
      Branch branch = branchRepository.findOne(branchBinder.getBean().getId());
      if (!branch.getBranchStatus().equals(branchBinder.getBean().getBranchStatus())) {
        if (branchBinder.getBean().getBranchStatus().equals(BranchStatus.ACTIVE)) {
          commandGateway.send(new MarkBranchAsActiveCommand(branchBinder.getBean().getApplicationId(),
            branchBinder.getBean().getId(), BranchStatus.ACTIVE));
          branchDetailComponentListener.updateBranch(branchBinder.getBean());
        } else {
          commandGateway.send(new MarkBranchAsInactiveCommand(branchBinder.getBean().getApplicationId(),
            branchBinder.getBean().getId(), BranchStatus.INACTIVE));
          branchDetailComponentListener.updateBranch(branchBinder.getBean());
        }
      }
      if (!branch.equals(branchBinder.getBean()) && branch.getBranchStatus().equals(branchBinder.getBean().getBranchStatus())) {
        commandGateway.send(new UpdateBranchCommand(this.branchBinder.getBean().getApplicationId(), branch, this.branchBinder.getBean()));
        branchDetailComponentListener.updateBranch(branchBinder.getBean());
      }
      enableAndDisableBranchDetailComponent(false);
    });
  
    deleteBranchButton.addClickListener(event -> {
      ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
      Window window = confirmationMessage.displayConfiguration();
      confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
        @Override
        public void onClosed() {
          window.close();
        }
    
        @Override
        public void onNoButtonClicked() {
          window.close();
        }
    
        @Override
        public void onYesButtonClicked() {
          try {
            commandGateway.sendAndWait(new DeleteBranchCommand(branchBinder.getBean().getApplicationId(),branchBinder.getBean().getId()));
            deleteBranchDetailEventConsumer.accept(new BranchDetailDeletedEvent(branchBinder.getBean()));
          } catch (Exception e) {
            logger.error("Error when deleting a branch", e);
          }
          window.close();
        }
      });
      window.setContent(confirmationMessage);
      UI.getCurrent().addWindow(window);
    });

    saleHistory.addClickListener(e ->{

      LocalDate endDate = LocalDate.now();
      LocalDate startDate = endDate.minusMonths(2);

      if(business.getIsBoss() && branchBinder.getBean().getIsBoss()){
        subWindow.setContent(new SalesHistoryComponent(subWindow, salesDataProvider, business.getBusinessId()
                , branchBinder.getBean().getBranchName(), branchBinder.getBean().getBranchId(),
                startDate.toString(), endDate.toString()));
        UI.getCurrent().addWindow(displaySaleHistory(subWindow));
      }
    });

    branchBinder.addStatusChangeListener(e -> saveButton.setEnabled(e.getBinder().isValid()));

    //set permission for field checker
    if (vaadinSecurity.hasAuthority(Role.FIELDCHECKER))
      editButton.setVisible(false);
  }

  void bind(Branch branch) {
    originalBranch = branch;
    Branch clone = new Branch();
    BeanUtils.copyProperties(originalBranch, clone);
    branchBinder.setBean(clone);
    initializeBinder(branchBinder);
    if (clone.getBusinessType() != null)
      otherBusinessTypeTextArea.setVisible(clone.getBusinessType().getName().equalsIgnoreCase(OTHER));
  }

  private void reset() {
    Branch clone = new Branch();
    BeanUtils.copyProperties(originalBranch, clone);
    branchBinder.setBean(clone);
    initializeBinder(branchBinder);
  }

  //sort loan Purpose
  private List<BusinessType> sortBusinessTypes(List<BusinessType> businessTypes) {
    businessTypes.sort((x, y) -> y.getName().equalsIgnoreCase(OTHER) ? -1 : 0);
    return businessTypes;
  }

  private void calculateMargin() {
    Branch branch = branchBinder.getBean();
    if (branch.getRevenue() == null)
      branch.setRevenue(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    if (branch.getExpense() == null)
      branch.setExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    MonetaryAmount newMargin = branch.getRevenue().subtract(branch.getExpense());
    marginTextField.setValue(String.format("%,.2f", newMargin.getNumber().doubleValueExact()));
  }

  private void calculateNetProfit() {
    Branch branch = branchBinder.getBean();
    if (branch.getStaffExpense() == null)
      branch.setStaffExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    if (branch.getOtherExpense() == null)
      branch.setOtherExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    if (branch.getMargin() == null)
      branch.setMargin(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    if (branch.getRentAmount() == null)
      branch.setRentAmount(Money.of(0, CurrencyUtil.MMK_CURRENCY));

    MonetaryAmount newNetProfit = branch.getMargin().subtract(branch.getRentAmount()).subtract(branch.getStaffExpense())
      .subtract(branch.getOtherExpense());
    netProfitTextField.setValue(String.format("%,.2f", newNetProfit.getNumber().doubleValueExact()));
  }

  private void enableAndDisableBranchDetailComponent(boolean value) {
    addressTextField.setEnabled(value);
    businessTypeComboBox.setEnabled(value);
    emailTextField.setEnabled(value);
    branchNameTextField.setEnabled(value);
    locationOwnerCombobox.setEnabled(value);
    openSinceDateField.setEnabled(value);
    phoneNumberTextField.setEnabled(value);
    stateComboBox.setEnabled(value);
    districtComboBox.setEnabled(value);
    townshipComboBox.setEnabled(value);
    revenueTextField.setEnabled(value);
    expenseTextField.setEnabled(value);
    otherExpenseTextField.setEnabled(value);
    numberOfStaffTextField.setEnabled(value);
    staffExpenseTextField.setEnabled(value);
    statusComboBox.setEnabled(value);
    townshipComboBox.setEnabled(value);
    rentAmountTextField.setEnabled(value);
    otherBusinessTypeTextArea.setEnabled(value);
  }

  private void initializeBinder(Binder<Branch> branchBinder) {
    Objects.requireNonNull(branchBinder);

    openSinceDateField.setDateFormat("yyyy");

    branchBinder.bind(branchIdTextField, "branchId");
    branchBinder.bind(branchNameTextField, "branchName");
    branchBinder.forField(businessTypeComboBox).asRequired("Business type may not empty").bind("businessType");
    branchBinder.forField(otherBusinessTypeTextArea).bind("businessTypeDescription");
    branchBinder.bind(emailTextField, "email");
    branchBinder.forField(rentAmountTextField)
      .asRequired("Rent amount cannot empty!")
      .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("rentAmount");
    branchBinder.bind(phoneNumberTextField, "phoneNumber");
    branchBinder.bind(addressTextField, "address");
    branchBinder.bind(stateComboBox, "state");
    branchBinder.bind(districtComboBox, "district");
    branchBinder.bind(townshipComboBox, "township");
    branchBinder.bind(locationOwnerCombobox, "locationOwner");
    branchBinder.bind(openSinceDateField, "openSince");

    branchBinder.bind(statusComboBox, "branchStatus");
    branchBinder.forField(revenueTextField)
      .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("revenue");
    branchBinder.forField(expenseTextField)
      .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("expense");
    branchBinder.forField(marginTextField)
      .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("margin");
    branchBinder.forField(numberOfStaffTextField)
      .withConverter(new StringToIntegerConverter("")).bind("numberOfStaff");
    branchBinder.forField(staffExpenseTextField)
      .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("staffExpense");
    branchBinder.forField(otherExpenseTextField)
      .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("otherExpense");
    branchBinder.forField(netProfitTextField)
      .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
      .bind("netProfit");
  }
  
  private Window displaySaleHistory(Window window) {
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth(1280, Unit.PIXELS);
    window.setHeight(600, Unit.PIXELS);

    return window;
  }

  interface BranchDetailComponentListener {
    void updateBranch(Branch branch);
  }
  
}
