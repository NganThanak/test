package com.gl.csf.underwriting.ui.dataprovider;

import com.gl.csf.underwriting.common.model.businessinfo.Business;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.business.BusinessRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/11/2017.
 */
@Scope("prototype")
@Component
public class BusinessInfoDataProvider extends AbstractBackEndDataProvider<Business, String> {

  private final BusinessRepository businessRepository;

  @Inject
  public BusinessInfoDataProvider(BusinessRepository businessRepository) {
    this.businessRepository = businessRepository;
  }

  @Override
  protected Stream<Business> fetchFromBackEnd(Query<Business, String> query) {
    return StreamSupport.stream(businessRepository.findAll().spliterator(), true);
  }

  @Override
  protected int sizeInBackEnd(Query<Business, String> query) {
    return Math.toIntExact(businessRepository.count());
  }
}
