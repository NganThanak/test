package com.gl.csf.underwriting.resource.application;

import com.gl.csf.underwriting.api.application.command.DeleteApplicationDraftCommand;
import com.gl.csf.underwriting.api.application.command.SaveApplicationCommand;
import com.gl.csf.underwriting.api.application.command.SubmitApplicationCommand;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.stereotype.Component;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Component
@Path("")
public class ApplicationResource {

  private CommandGateway commandGateway;

  @Inject
  public ApplicationResource(CommandGateway commandGateway) {
    this.commandGateway = commandGateway;
  }

  @PUT
  @Path("/applications/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes("application/x-command.SaveApplicationCommand+json")
  public Response saveApplication(@PathParam("id") String id, SaveApplicationCommand saveApplicationCommand){
    saveApplicationCommand.setId(id);
    commandGateway.sendAndWait(saveApplicationCommand);
    return Response.noContent().build();
  }

  @DELETE
  @Path("/applications/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes("application/x-command.DeleteApplicationCommand+json")
  public Response deleteApplication(@PathParam("id") String id){
    DeleteApplicationDraftCommand deleteApplicationCommand = new DeleteApplicationDraftCommand();
    deleteApplicationCommand.setId(id);
    commandGateway.sendAndWait(deleteApplicationCommand);
    return Response.noContent().build();
  }

  @PUT
  @Path("/applications/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes("application/x-command.SubmitApplicationCommand+json")
  public Response submitApplication(@PathParam("id") String id, SubmitApplicationCommand submitApplicationCommand){
    submitApplicationCommand.setId(id);
    commandGateway.sendAndWait(submitApplicationCommand);
    return Response.noContent().build();
  }
}
