package com.gl.csf.underwriting.ui.dataprovider;

import lombok.Value;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 09/10/2017.
 */
@Value
public class ApplicationFilter {
  String username;
  String role;
}
