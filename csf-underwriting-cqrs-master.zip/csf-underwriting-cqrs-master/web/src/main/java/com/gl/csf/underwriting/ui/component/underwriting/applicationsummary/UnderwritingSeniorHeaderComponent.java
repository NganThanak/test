package com.gl.csf.underwriting.ui.component.underwriting.applicationsummary;

import com.gl.csf.underwriting.api.application.command.ApproveApplicationCommand;
import com.gl.csf.underwriting.api.application.command.DeclineApplicationCommand;
import com.gl.csf.underwriting.api.application.command.RecommendApplicationApprovalCommand;
import com.gl.csf.underwriting.api.application.command.RejectApplicationCommand;
import com.gl.csf.underwriting.config.jersey.CurrencyUtil;
import com.gl.csf.underwriting.message.*;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationheader.LoanApplicationHeaderDTO;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationheader.LoanApplicationHeaderRepository;
import com.gl.csf.underwriting.ui.component.common.ConfirmationComponent;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import net.engio.mbassy.listener.Enveloped;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;
import net.engio.mbassy.subscription.MessageEnvelope;
import org.axonframework.commandhandling.gateway.CommandGateway;

/**
 * Created by p.ly on 10/24/2017.
 */
@Listener
@SpringComponent
@UIScope
public class UnderwritingSeniorHeaderComponent extends UnderwritingSeniorHeaderComponentDesign {

  private final LoanApplicationHeaderRepository repository;
  private String applicationId;
  private SessionScopeBus bus;

  UnderwritingSeniorHeaderComponent(LoanApplicationHeaderRepository repository, SessionScopeBus bus, CommandGateway commandGateway) {
    this.repository = repository;
    this.bus = bus;

    buttonDecline.addClickListener(e -> {
      Window window = confirmationDecline();

      final ConfirmationComponent confirmationComponent = new ConfirmationComponent();
      confirmationComponent.setListener(new ConfirmationComponent.ConfirmationComponentListener() {
        @Override
        public void onClosed() {
          window.close();
        }

        @Override
        public void onNoButtonClicked() {
          window.close();
        }

        @Override
        public void onYesButtonClicked() {
          try {
            commandGateway.sendAndWait(new DeclineApplicationCommand(applicationId, confirmationComponent.getDeclineReason()));
            window.close();
          } catch (IllegalStateException e1) {
            Notification.show("Error can't decline an application", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
          }
        }
      });

      window.setContent(confirmationComponent);
      UI.getCurrent().addWindow(window);
    });

    buttonApprove.addClickListener(e->{
      ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
      confirmationMessage.confirmationTitle.setValue("Application Approval");
      confirmationMessage.messageLabel.setValue("Do you want to approve application?");
      Window window = confirmationMessage.displayConfiguration();
      confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {

        @Override
        public void onClosed() {
          window.close();
        }

        @Override
        public void onNoButtonClicked() {
          window.close();
        }

        @Override
        public void onYesButtonClicked() {
          try {
            commandGateway.sendAndWait(new ApproveApplicationCommand(applicationId));
            window.close();
            Notification.show("Application approve successful", Notification.Type.HUMANIZED_MESSAGE);
            getUI().getNavigator().navigateTo("");
          }catch (IllegalStateException e1) {
            window.close();
            Notification.show(e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
          }
        }
      });
      window.setContent(confirmationMessage);
      UI.getCurrent().addWindow(window);
    });
    
    buttonReject.addClickListener(e->{
      ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
      confirmationMessage.confirmationTitle.setValue("Rejection");
      confirmationMessage.messageLabel.setValue("Do you want to reject?");
      Window window = confirmationMessage.displayConfiguration();
      confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {

        @Override
        public void onClosed() {
          window.close();
        }

        @Override
        public void onNoButtonClicked() {
          window.close();
        }

        @Override
        public void onYesButtonClicked() {
          try {
            commandGateway.sendAndWait(new RejectApplicationCommand(applicationId));
            window.close();
            Notification.show("The Application has been rejected successfully.", Notification.Type.HUMANIZED_MESSAGE);
            getUI().getNavigator().navigateTo("");
          }catch (IllegalStateException e1) {
            window.close();
            Notification.show(e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
          }
        }
      });
      window.setContent(confirmationMessage);
      UI.getCurrent().addWindow(window);
    });
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
    updateData();
  }

  private void updateData() {
    LoanApplicationHeaderDTO loanApplicationHeaderDTO = repository.findByApplicationId(applicationId);
    labelCustomerName.setValue(loanApplicationHeaderDTO.getCustomerName());
    labelApplicationId.setValue(loanApplicationHeaderDTO.getReferenceId());
    labelBusinessName.setValue(loanApplicationHeaderDTO.getBusinessName());
    labelTerm.setValue(loanApplicationHeaderDTO.getTerm() + " months");
    labelStatus.setValue(loanApplicationHeaderDTO.getStatus().toString());
    labelProductName.setValue(loanApplicationHeaderDTO.getProductName().toString());
    labelCreditScore.setValue(loanApplicationHeaderDTO.getCreditScore());
    labelUnderwritingDecision.setValue(loanApplicationHeaderDTO.getUnderwritingDecision());
    labelRequestAmount.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(loanApplicationHeaderDTO.getRequestAmount()));
  }

  private Window confirmationDecline() {
    Window window = new Window();
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth(600, Unit.PIXELS);
    return window;
  }

  @Handler
  @Enveloped(messages = {CreditScoreUpdatedEvent.class, ProductInformationUpdatedEvent.class, BusinessInfoUpdatedEvent.class, CustomerInfoUpdatedEvent.class})
  public void handle(MessageEnvelope envelope) {
    updateData();
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }
}
