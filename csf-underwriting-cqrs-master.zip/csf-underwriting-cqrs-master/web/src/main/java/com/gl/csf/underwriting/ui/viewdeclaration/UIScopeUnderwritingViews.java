package com.gl.csf.underwriting.ui.viewdeclaration;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/07/2017.
 */
public class UIScopeUnderwritingViews {
  public static final String APPLICATION_LIST = "";
  public static final String APPLICATION = "application";
}
