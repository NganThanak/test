package com.gl.csf.underwriting.ui.util.paymentschedule;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.util.Date;

public class Installment {
    private Date dueDate;
    private int installmentNumber;
    private double interestRatePerPeriod; // given value.
    private MonetaryAmount beginBalance; // amount before payment
    private MonetaryAmount endBalance; // endBalance = beginBalance - principal, i.e. amount after payment
    private MonetaryAmount interest;  // interest = beginBalance x ratePerPeriod
    private MonetaryAmount principal;  // principal = amount - interest
    private MonetaryAmount amount; // amount = interest + principal; // given value

    public Installment(){

    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public int getInstallmentNumber() {
        return installmentNumber;
    }

    public void setInstallmentNumber(int installmentNumber) {
        this.installmentNumber = installmentNumber;
    }

    public double getInterestRatePerPeriod() {
        return interestRatePerPeriod;
    }

    public void setInterestRatePerPeriod(double interestRatePerPeriod) {
        this.interestRatePerPeriod = interestRatePerPeriod;
    }

    public MonetaryAmount getBeginBalance() {
        return beginBalance;
    }

    public void setBeginBalance(MonetaryAmount beginBalance) {
        this.beginBalance = beginBalance;
    }

    public MonetaryAmount getEndBalance() {
        return endBalance;
    }

    public void setEndBalance(MonetaryAmount endBalance) {
        this.endBalance = endBalance;
    }

    public MonetaryAmount getInterest() {
        return interest;
    }

    public void setInterest(MonetaryAmount interest) {
        this.interest = interest;
    }

    public MonetaryAmount getPrincipal() {
        return principal;
    }

    public void setPrincipal(MonetaryAmount principal) {
        this.principal = principal;
    }

    public MonetaryAmount getAmount() {
        return amount;
    }

    public void setAmount(MonetaryAmount amount) {
        this.amount = amount;
    }

    public MonetaryAmount round(MonetaryAmount val, int precision){
        /*
        // double looses precision, so supplying double as String to BigDecimal
        String valString = String.valueOf(val);
        //BigDecimal bd = BigDecimal.valueOf(val);
        BigDecimal bd = new BigDecimal(valString);
        bd = bd.setScale(precision, BigDecimal.ROUND_HALF_UP);

        return bd.doubleValue();
        */
        return val;
    }
}
