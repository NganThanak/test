package com.gl.csf.underwriting.ui.component.underwriting.fieldcheck;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.api.application.command.AttachDocumentToFieldCheckingFieldCommand;
import com.gl.csf.underwriting.api.application.command.DeleteDocumentFromFieldCheckingFieldCommand;
import com.gl.csf.underwriting.api.application.command.EditFieldCheckingFieldCommand;
import com.gl.csf.underwriting.api.application.command.EditFieldCheckingFieldCommentCommand;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.FieldCheckItemDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.FieldCheckItemDocumentDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.FieldCheckItemDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDTO;
import com.gl.csf.underwriting.service.DocumentService;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.gl.csf.underwriting.ui.component.common.FileUploadResult;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.ui.*;
import com.vaadin.ui.themes.ValoTheme;
import org.apache.http.entity.ContentType;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.util.stream.Stream;
/**
 * Created by p.ly on 10/7/2017.
 */
class FieldCheckItemComponent extends FieldCheckItemComponentDesign {
  private final static Logger logger = LoggerFactory.getLogger(FieldCheckItemComponent.class);
  private final Binder<FieldCheckReferenceDTO> fieldCheckReferenceDTOBinder;
  private String field;
  private String comment;


  @Inject
  public FieldCheckItemComponent(DocumentService documentService, CommandGateway commandGateway, FieldCheckItemDTO fieldCheckItem, FieldCheckItemDocumentRepository fieldCheckItemDocumentRepository, VaadinSecurity vaadinSecurity) {
    this.labelName.setValue(fieldCheckItem.getName());
    this.descriptionLabel.setValue(fieldCheckItem.getDescription());

    comment = (fieldCheckItem.getCommentValue()== null? "":fieldCheckItem.getCommentValue());
    field = (fieldCheckItem.getFieldValue()==null ?"": fieldCheckItem.getFieldValue());

    fieldCheckReferenceDTOBinder = createFieldCheckReferenceBinder(fieldCheckItem);
    setDocumentDataProvider(fieldCheckItemDocumentRepository, fieldCheckItem);
    textFieldField.setValue(field);
    textAreaComment.setValue(comment);

    textFieldField.setEnabled(false);
    textAreaComment.setEnabled(false);

    //format local date time
    Grid.Column commentDate = fieldCheckItemDocumentGrid.getColumn("dateModified");
    commentDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());

    buttonEditField.addClickListener(event -> {
      if(buttonEditField.getCaption().equals("Save")){
        buttonEditField.setCaption("Edit");
        buttonCancelField.setVisible(false);
        textFieldField.setEnabled(false);
        commandGateway.sendAndWait(new EditFieldCheckingFieldCommand(fieldCheckItem.getApplicationId(), fieldCheckItem.getUnderwritingFieldId(), textFieldField.getValue()));
        field = textFieldField.getValue();

      } else {
        buttonCancelField.setVisible(true);
        buttonEditField.setCaption("Save");
        textFieldField.setEnabled(true);
        buttonEditField.setEnabled(false);
      }
    });

    textFieldField.addValueChangeListener(e -> {
      if (buttonEditField.getCaption().equals("Save"))
        buttonEditField.setEnabled(!textFieldField.isEmpty() && !textFieldField.getValue().equals(field));
    });

    buttonCancelField.addClickListener(event -> {
      textFieldField.setEnabled(false);
      buttonCancelField.setVisible(false);
      buttonEditField.setCaption("Edit");
      textFieldField.setValue(field);
      buttonEditField.setEnabled(true);
    });

    buttonEditComment.addClickListener(event -> {
      if(buttonEditComment.getCaption().equals("Save")){
        buttonEditComment.setCaption("Edit");
        buttonCancelComment.setVisible(false);
        textAreaComment.setEnabled(false);
        commandGateway.sendAndWait(new EditFieldCheckingFieldCommentCommand(fieldCheckItem.getApplicationId(), fieldCheckItem.getUnderwritingFieldId(), textAreaComment.getValue()));
        comment = textAreaComment.getValue();
      }else{
        buttonCancelComment.setVisible(true);
        buttonEditComment.setCaption("Save");
        buttonEditComment.setEnabled(!textAreaComment.isEmpty());
        textAreaComment.setEnabled(true);
      }
    });

    textAreaComment.addValueChangeListener(event -> {
      if(buttonEditComment.getCaption().equals("Save"))
        buttonEditComment.setEnabled(!textAreaComment.isEmpty() && !textAreaComment.getValue().equals(comment));
    });

    buttonCancelComment.addClickListener(event -> {
      buttonEditComment.setCaption("Edit");
      buttonCancelComment.setVisible(false);
      textAreaComment.setEnabled(false);
      textAreaComment.setValue(comment);
      buttonEditComment.setEnabled(true);
    });

    Window uploadFileWindow = createUploadComponentWindow(commandGateway, documentService, fieldCheckItem.getApplicationId(), fieldCheckItem.getUnderwritingFieldId());
    addDocumentButton.addClickListener(e-> UI.getCurrent().addWindow(uploadFileWindow));

    fieldCheckItemDocumentGrid.addComponentColumn(documentDTO ->{
      CssLayout cssLayout = new CssLayout();
      Button buttonDelete = new Button("");
      Button buttonDownload = new Button("");
      buttonDownload.setIcon(VaadinIcons.DOWNLOAD);
      buttonDelete.setIcon(VaadinIcons.TRASH);
      buttonDelete.setStyleName(ValoTheme.BUTTON_LINK);
      buttonDownload.setStyleName(ValoTheme.BUTTON_LINK);
      buttonDelete.setEnabled(vaadinSecurity.getAuthentication().getName().equals(documentDTO.getEditorId()));
      buttonDelete.addClickListener(event -> {

        ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
        Window window = confirmationMessage.displayConfiguration();
        confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
          @Override
          public void onClosed() { window.close(); }
          @Override
          public void onNoButtonClicked() { window.close(); }
          @Override
          public void onYesButtonClicked() {
            try {
              documentService.deleteDocument(documentDTO.getDocumentDescriptor());
              commandGateway.sendAndWait(new DeleteDocumentFromFieldCheckingFieldCommand(
                      documentDTO.getDocumentDescriptor().getApplicationId(), documentDTO.getUnderwritingFieldId(),
                      documentDTO.getDocumentDescriptor()));
              fieldCheckItemDocumentGrid.getDataProvider().refreshAll();
            } catch (Exception e) {
              logger.error("Error when deleting a financial document", e);
            }
            window.close();
          }
        });
        window.setContent(confirmationMessage);
        UI.getCurrent().addWindow(window);
      });

      try {
        StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
          try {
            return documentService.downloadDocument(documentDTO.getDocumentDescriptor());
          } catch (Exception e) {
            logger.error("error when download financial document", e);
            throw new RuntimeException(e);
          }
        }, documentDTO.getFileName());
        FileDownloader fileDownloader = new FileDownloader(streamResource);
        fileDownloader.extend(buttonDownload);
      } catch (Exception e) {
        logger.error("error when download financial document", e);
        throw new RuntimeException(e);
      }
      cssLayout.addComponent(buttonDelete);
      cssLayout.addComponent(buttonDownload);
      return cssLayout;
    });


  }

  private void setDocumentDataProvider(FieldCheckItemDocumentRepository fieldCheckItemDocumentRepository, FieldCheckItemDTO fieldCheckItem) {
    fieldCheckItemDocumentGrid.setDataProvider(new AbstractBackEndDataProvider<FieldCheckItemDocumentDTO, String>() {

      @Override
      protected Stream<FieldCheckItemDocumentDTO> fetchFromBackEnd(Query query) {
        return fieldCheckItemDocumentRepository.findAllByFieldCheckItem(fieldCheckItem).parallelStream();
      }

      @Override
      protected int sizeInBackEnd(Query query) {
        return Math.toIntExact(fieldCheckItemDocumentRepository.countAllByFieldCheckItem(fieldCheckItem));
      }
    });
  }

  private Window createUploadComponentWindow(CommandGateway commandGateway, DocumentService documentService,
                                            String applicationId, String underwritingFieldId){
    Window result = new Window();
    result.center();
    result.removeAllCloseShortcuts();
    result.setResizable(false);
    result.setClosable(false);
    result.setModal(true);
    result.setWidth(600, Unit.PIXELS);
    result.setHeight(450, Unit.PIXELS);

    FieldCheckUploadDocumentComponent fieldCheckUploadDocumentComponent = new FieldCheckUploadDocumentComponent();
    fieldCheckUploadDocumentComponent.setListener(new FieldCheckUploadDocumentComponent.FieldCheckListUploadDocumentComponentListener() {
      @Override
      public void onClosed() {
        result.close();
        fieldCheckUploadDocumentComponent.clearUploadResults();
      }

      @Override
      public void onCancelButtonClicked() {
        result.close();
        fieldCheckUploadDocumentComponent.clearUploadResults();
      }

      @Override
      public void onSaveButtonClicked() {
        for (FileUploadResult fileUploadResult : fieldCheckUploadDocumentComponent.getFileUploadResults()) {
          // TODO: error should be handled more appropriately
          if (fileUploadResult.hasError())
            continue;
          // Save to minio
          try {
            DocumentDescriptor documentDescriptor = documentService.uploadDocument(fileUploadResult.getFilename(), applicationId,
                    fileUploadResult.getByteArrayInputStream(), ContentType.APPLICATION_OCTET_STREAM.toString());

            commandGateway.sendAndWait(new AttachDocumentToFieldCheckingFieldCommand(applicationId, underwritingFieldId,
                    documentDescriptor, fileUploadResult.getFilename()));
          } catch (Exception e) {
            Notification.show("Failed to uploaded document", Notification.Type.ERROR_MESSAGE);
            logger.error("Failed to uploaded document", e);
          }
        }
        // Once uploaded the files, clear the upload results to release byte array content
        fieldCheckUploadDocumentComponent.clearUploadResults();
        result.close();
        Notification.show("Saved");
        fieldCheckItemDocumentGrid.getDataProvider().refreshAll();
      }
    });
    result.setContent(fieldCheckUploadDocumentComponent);
    return result;
  }

  private Binder<FieldCheckReferenceDTO> createFieldCheckReferenceBinder(FieldCheckItemDTO fieldCheckItem) {
    Binder<FieldCheckReferenceDTO> result = new BeanValidationBinder<>(FieldCheckReferenceDTO.class);
    //set required field for Field
    if (fieldCheckItem.isTextRequired())
      result.forField(fieldLabel).asRequired("Not null value");
    //set required field for Attachment
    if (fieldCheckItem.isDocumentRequired())
      result.forField(attachmentLabel).asRequired("Not null value");
    return result;
  }
}
