package com.gl.csf.underwriting.ui.util;

import com.vaadin.ui.AbstractTextField;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/6/2017.
 */
public class NumeralFieldFormatterUtils {

  public static void formatNumeralTextField(AbstractTextField... fields){
    formatNumeralTextField(2, fields);
  }

  public static void formatNumeralTextField(int decimalScale, AbstractTextField... fields) {
    for (AbstractTextField field : fields) {
      new org.vaadin.textfieldformatter.NumeralFieldFormatter(field, ",", ".", decimalScale);
    }
  }
}
