package com.gl.csf.underwriting.ui.util.documentupload;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.vaadin.ui.Upload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/26/2017.
 */
public class DocumentUploader implements Upload.Receiver, Upload.SucceededListener, Upload.FailedListener {

  private ByteArrayOutputStream outputStream;
  private FileUploadConsumer fileUploadConsumer;

  private final static Logger logger = LoggerFactory.getLogger(DocumentUploader.class);

  public DocumentUploader(FileUploadConsumer fileUploadConsumer) {
    this.fileUploadConsumer = fileUploadConsumer;
  }

  @Override
  public OutputStream receiveUpload(String filename, String mimeType) {
    this.outputStream = new ByteArrayOutputStream();

    return outputStream;
  }

  @Override
  public void uploadFailed(Upload.FailedEvent failedEvent) {
    if (fileUploadConsumer != null) {
      fileUploadConsumer.onFail(failedEvent.getReason());
    }
  }

  @Override
  public void uploadSucceeded(Upload.SucceededEvent succeededEvent) {
    try {
      fileUploadConsumer.onReceiveFile(succeededEvent.getFilename(), new ByteArrayInputStream(this.outputStream.toByteArray()), succeededEvent.getMIMEType());
    } catch (Exception e) {
      logger.error("An error occurred: ", e);
      if (fileUploadConsumer != null) {
        fileUploadConsumer.onFail(e);
      }
    }
  }

  public interface FileUploadConsumer extends Serializable{

    void onSuccess(DocumentDescriptor descriptor);

    void onFail(Exception ex);

    void onReceiveFile(String fileName, InputStream inputStream, String mimeType);
  }
}
