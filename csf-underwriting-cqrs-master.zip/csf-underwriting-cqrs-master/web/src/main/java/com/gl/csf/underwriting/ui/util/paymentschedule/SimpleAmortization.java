package com.gl.csf.underwriting.ui.util.paymentschedule;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;

public class SimpleAmortization extends Amortization {

  /**
   * payment amount = interest + periodic principal
   * @param param given loan parameters
   * @return a periodic payment amount based on Simple interest calculation
   */
  public MonetaryAmount calculateInstallmentAmount(LoanParameter param) {
    return param.getLoanAmount()
            .multiply(param.getNominalInterestRate())
            .divide(param.getNumberOfCompoundingPeriods())
            .add(param.getLoanAmount().divide(param.getNumberOfPeriods()));
  }

  // return irr % per period
  public double irr(LoanParameter param) {
    MonetaryAmount pmt = calculateInstallmentAmount(param);
    MonetaryAmount[] values = new MonetaryAmount[param.getNumberOfPeriods() + 1];
    values[0] = param.getLoanAmount().multiply(-1);
    int npr = param.getNumberOfPeriods();

    for (int i = 1; i <= npr; i++) {
      values[i] = pmt;
    }

    BigDecimal rateOfReturn = IRRCalculator.irr(values, BigDecimal.valueOf(0.1), param.getScale(), param.getRoundingMode());

    return rateOfReturn.doubleValue();
  }
}