package com.gl.csf.underwriting.ui.component.underwriting;

import com.gl.csf.common.util.ConfirmDialogUtil;
import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.api.supportdocument.command.RemoveSupportingDocumentCommand;
import com.gl.csf.underwriting.api.supportdocument.command.SaveSupportingDocumentCommand;
import com.gl.csf.underwriting.api.supportdocument.command.UpdateSupportingDocumentCommand;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.common.model.supportingdocument.DocumentDTO;
import com.gl.csf.underwriting.config.storage.MinioConfiguration;
import com.gl.csf.underwriting.query.application.underwriting.supportingdocument.SupportingDocumentRepository;
import com.gl.csf.underwriting.service.DocumentService;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.gl.csf.underwriting.ui.component.common.FileUploadComponentListener;
import com.gl.csf.underwriting.ui.component.common.FileUploadResult;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import com.vaadin.ui.themes.ValoTheme;
import org.apache.commons.io.FilenameUtils;
import org.apache.http.entity.ContentType;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
public class DocumentComponent extends DocumentComponentDesign {

	private final CommandGateway commandGateway;
	private final DocumentService documentService;
	private final MinioConfiguration minioConfiguration;
	private final SupportingDocumentRepository supportingDocumentRepository;
	private final VaadinSecurity vaadinSecurity;
	private Logger logger = LoggerFactory.getLogger(DocumentComponent.class);
	private String applicationId;
	private Set<String> imageType = new HashSet<>(Arrays.asList("JPG", "PNG", "JPEG"));

	@Inject
	public DocumentComponent(VaadinSecurity vaadinSecurity, CommandGateway commandGateway, DocumentService documentService, MinioConfiguration minioConfiguration, SupportingDocumentRepository supportingDocumentRepository) {
		this.commandGateway = commandGateway;
		this.documentService = documentService;
		this.minioConfiguration = minioConfiguration;
		this.supportingDocumentRepository = supportingDocumentRepository;
		this.vaadinSecurity = vaadinSecurity;
		addDocumentButton.addClickListener(clickEvent -> UI.getCurrent().addWindow(createWindow(documentService, vaadinSecurity, applicationId)));

		initGridEditor();
		setGridDocumentDataProvider();
	}

	private void setGridDocumentDataProvider() {
		supportingDocumentGrid.setDataProvider(new AbstractBackEndDataProvider<DocumentDTO, String>() {
			@Override
			protected Stream<DocumentDTO> fetchFromBackEnd(Query<DocumentDTO, String> query) {
				return supportingDocumentRepository.findByDescriptorApplicationIdOrderByCreatedDateDesc(applicationId).parallelStream();
			}

			@Override
			protected int sizeInBackEnd(Query<DocumentDTO, String> query) {
				return supportingDocumentRepository.countByDescriptorApplicationId(applicationId);
			}
		});
	}

	private void initGridEditor() {
		BeanValidationBinder<DocumentDTO> editorBinder = new BeanValidationBinder<>(DocumentDTO.class);
		supportingDocumentGrid.getEditor().setBinder(editorBinder);

		TextField attachmentEditor = new TextField();
		Binder.Binding<DocumentDTO, String> attachmentBinding = editorBinder.bind(attachmentEditor, "attachment");
		supportingDocumentGrid.getColumn("attachment").setEditorBinding(attachmentBinding);

		TextField commentEditor = new TextField();
		Binder.Binding<DocumentDTO, String> commentBinding = editorBinder.bind(commentEditor, "comment");
		supportingDocumentGrid.getColumn("comment").setEditorBinding(commentBinding);

		//format local date time
		Grid.Column commentDate = supportingDocumentGrid.getColumn("createdDate");
		commentDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());

		supportingDocumentGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
		supportingDocumentGrid.getEditor().setEnabled(true);
		supportingDocumentGrid.getEditor().addSaveListener(event -> {
			commandGateway.send(new UpdateSupportingDocumentCommand(event.getBean().getDescriptor().getApplicationId(), event.getBean()));
			setGridDocumentDataProvider();
		});

		supportingDocumentGrid.addComponentColumn(dto -> {
			HorizontalLayout actionLayout = new HorizontalLayout();
			String fileExtension = FilenameUtils.getExtension(dto.getAttachment());
			if(imageType.contains(fileExtension.toUpperCase())) {
        Button buttonPreview = new Button();
        buttonPreview.setIcon(VaadinIcons.EYE);
        buttonPreview.setStyleName(ValoTheme.BUTTON_LINK);
        buttonPreview.addClickListener(event -> {
          try {
            StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
              try {
                return documentService.downloadDocument(new DocumentDescriptor(dto.getDescriptor().getDocumentId()
                        , minioConfiguration.getEndpoint(), dto.getDescriptor().getApplicationId()));
              } catch (Exception e) {
                throw new RuntimeException(e);
              }
            }, dto.getAttachment());
            Window window = new Window();
            window.center();
            window.setResizable(false);
            window.setContent(new Image(dto.getAttachment(), streamResource));
            UI.getCurrent().addWindow(window);
          } catch (Exception e) {
            e.printStackTrace();
          }
        });
        actionLayout.addComponent(buttonPreview);
      }
			
			Button buttonDownload = new Button();
			buttonDownload.setIcon(VaadinIcons.DOWNLOAD);
			buttonDownload.setStyleName(ValoTheme.BUTTON_LINK);
			try {
				StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
					try {
						return documentService.downloadDocument(new DocumentDescriptor(dto.getDescriptor().getDocumentId()
										, minioConfiguration.getEndpoint(), dto.getDescriptor().getApplicationId()));
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}, dto.getAttachment());
				FileDownloader fileDownloader = new FileDownloader(streamResource);
				fileDownloader.extend(buttonDownload);
			} catch (Exception e) {
				e.printStackTrace();
			}

			Button buttonDelete = new Button();
			buttonDelete.setStyleName(ValoTheme.BUTTON_LINK);
			buttonDelete.setIcon(VaadinIcons.TRASH);
			buttonDelete.addClickListener(event -> {

				ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
				Window window = confirmationMessage.displayConfiguration();
				confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
					@Override
					public void onClosed() { window.close(); }
					@Override
					public void onNoButtonClicked() { window.close(); }
					@Override
					public void onYesButtonClicked() {
						try {
							documentService.deleteDocument(new DocumentDescriptor(dto.getAttachment(), minioConfiguration.getEndpoint(), applicationId));
							commandGateway.send(new RemoveSupportingDocumentCommand(dto.getApplicationId(), dto.getId()));
							supportingDocumentGrid.getDataProvider().refreshAll();
						} catch (Exception e) {
							e.printStackTrace();
						}
						window.close();
					}
				});
				window.setContent(confirmationMessage);
				UI.getCurrent().addWindow(window);

			});

			actionLayout.addComponents(buttonDownload,buttonDelete);
			return actionLayout;
		}).setCaption("Action");

  }

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	private Window createWindow(DocumentService documentService, VaadinSecurity vaadinSecurity , String applicationId) {
		Window result = new Window();
		result.center();
		result.removeAllCloseShortcuts();
		result.setResizable(false);
		result.setClosable(false);
		result.setModal(true);
		result.setWidth(600, Unit.PIXELS);

		FormAddDocumentComponent addDocumentComponent = new FormAddDocumentComponent();

		addDocumentComponent.fileUploadComponent.setFileUploadComponentListener(new FileUploadComponentListener() {
			@Override
			public void uploadStarted() {
				addDocumentComponent.saveButton.setEnabled(false);
			}

			@Override
			public void uploadFinished() {
				addDocumentComponent.saveButton.setEnabled(true);
			}
		});

		addDocumentComponent.setListener(new FormAddDocumentComponent.ForAddDocumentComponentListener() {
			@Override
			public void onClosed() {
				result.close();
			}

			@Override
			public void onNoButtonClicked() {
				result.close();
			}

			@Override
			public void onYesButtonClicked() {
				for (FileUploadResult fileUploadResult : addDocumentComponent.fileUploadComponent.getFileUploadResults()) {
					// TODO: error should be handled more appropriately
					if (fileUploadResult.hasError())
						continue;

					// Save to minio
					try {
						DocumentDescriptor documentDescriptor = documentService.uploadDocument(fileUploadResult.getFilename(), applicationId,
										fileUploadResult.getByteArrayInputStream(), ContentType.APPLICATION_OCTET_STREAM.toString());

						// Send command
						DocumentDTO documentDTO = new DocumentDTO();
						documentDTO.setApplicationId(applicationId);
						documentDTO.setCreatedDate(LocalDateTime.now());
						documentDTO.setUploadBy(vaadinSecurity.getAuthentication().getName());
						documentDTO.setComment(addDocumentComponent.commentTextArea.getValue());
						documentDTO.setAttachment(fileUploadResult.getFilename());
						documentDTO.setDescriptor(documentDescriptor);
						commandGateway.sendAndWait(new SaveSupportingDocumentCommand(applicationId, documentDTO));
					} catch (Exception e) {
						Notification.show("Failed to uploaded supportingdocument", Notification.Type.ERROR_MESSAGE);
						logger.error("Failed to uploaded supportingdocument", e);
					}
				}
				// Once uploaded the files, clear the upload results to release byte array content
				addDocumentComponent.fileUploadComponent.clearUploadResults();
				result.close();
				supportingDocumentGrid.getDataProvider().refreshAll();
			}
		});
		result.setContent(addDocumentComponent);
		return result;
	}
}
