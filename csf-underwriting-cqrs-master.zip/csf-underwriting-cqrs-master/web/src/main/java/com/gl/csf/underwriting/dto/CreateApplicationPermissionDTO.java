package com.gl.csf.underwriting.dto;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/16/2017.
 */
public class CreateApplicationPermissionDTO {
  private boolean allowApply;
  private String description;

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public boolean isAllowApply() {
    return allowApply;
  }

  public void setAllowApply(boolean allowApply) {
    this.allowApply = allowApply;
  }
}
