package com.gl.csf.underwriting.ui.dataprovider;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/18/2017.
 */
@Value
public class SaleHistoryFilter {
  String businessId;
  String branchId;
  String startDate;
  String endDate;
}
