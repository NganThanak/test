package com.gl.csf.underwriting.ui.component.underwriting;

import com.gl.csf.underwriting.api.application.productinfo.command.UpdateProductInformationCommand;
import com.gl.csf.underwriting.common.model.loanpurpose.LoanPurpose;
import com.gl.csf.underwriting.common.model.parameter.LoanProductTemplate;
import com.gl.csf.underwriting.common.model.parameter.Term;
import com.gl.csf.underwriting.common.model.product.Interest;
import com.gl.csf.underwriting.common.model.product.ProductType;
import com.gl.csf.underwriting.common.model.productinfo.PaymentFrequencyDTO;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.message.GeneratePaymentScheduleEvent;
import com.gl.csf.underwriting.message.ProductInformationUpdatedEvent;
import com.gl.csf.underwriting.message.SessionScopeBus;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement.FinancialStatementDTO;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement.FinancialStatementRepository;
import com.gl.csf.underwriting.query.application.underwriting.productinfo.ProductInformationRepository;
import com.gl.csf.underwriting.query.application.util.CurrencyUtil;
import com.gl.csf.underwriting.service.InterestRateService;
import com.gl.csf.underwriting.service.LoanProductTemplateService;
import com.gl.csf.underwriting.service.LoanPurposeService;
import com.gl.csf.underwriting.ui.permission.Role;
import com.gl.csf.underwriting.ui.util.StringToMonetaryAmountConverter;
import com.gl.csf.underwriting.ui.util.paymentschedule.Installment;
import com.gl.csf.underwriting.ui.util.paymentschedule.LoanParameter;
import com.gl.csf.underwriting.ui.util.paymentschedule.LoanParameterBuilder;
import com.gl.csf.underwriting.ui.util.paymentschedule.SimpleAmortization;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.HasValue;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.ui.*;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vaadin.spring.security.VaadinSecurity;

import javax.money.MonetaryAmount;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
public class ProductInfoComponent extends ProductInfoComponentDesign {

  private static int LAST_CONTRACT_DAY_OF_MONTH = 28;
  private static MonetaryAmount installmentAmount;
  private final Logger logger = LoggerFactory.getLogger(ProductInfoComponent.class);
  private final List<Integer> termData = new ArrayList<>();
  private final List<PaymentFrequencyDTO> paymentFrequencyData = new ArrayList<>();
  private final SessionScopeBus bus;
  private final String OTHER = "Other";
  private LoanProductTemplateService loanProductTemplateService;
  private ProductInformationRepository productInformationRepository;
  private FinancialStatementRepository financialStatementRepository;
  private LoanPurposeService loanPurposeService;
  private Binder<ProductInformationDTO> updateProductInformationBinder;
  private Set<LoanPurpose> loanPurposes = new HashSet<>();
  private String applicationId;
  private ProductInformationDTO currentProductInformation;
  private List<Installment> paymentSchedule = new ArrayList<>();
  private VaadinSecurity vaadinSecurity;

  public ProductInfoComponent(SessionScopeBus bus, LoanProductTemplateService loanProductTemplateService, CommandGateway commandGateway,
                              ProductInformationRepository productInformationRepository, VaadinSecurity vaadinSecurity,
                              FinancialStatementRepository financialStatementRepository, LoanPurposeService loanPurposeService, String applicationId,
                              InterestRateService interestRateService) {
    this.loanProductTemplateService = loanProductTemplateService;
    this.productInformationRepository = productInformationRepository;
    this.financialStatementRepository = financialStatementRepository;
    this.loanPurposeService = loanPurposeService;
    this.applicationId = applicationId;
    this.bus = bus;
    this.updateProductInformationBinder = createUpdateProductInformationBinder();
    this.vaadinSecurity = vaadinSecurity;

    textFieldLoanAmount.addValueChangeListener(value -> {
      if (!value.getValue().isEmpty()) {
        Optional<Double> maybeDouble = Optional.empty();
        try {
          maybeDouble = Optional.of(Double.valueOf(value.getValue()));
        } catch (Exception ex) {
          Double doubleValue = Double.valueOf(value.getValue().replace(",", ""));
          if (!Double.valueOf(0).equals(doubleValue)) {
            maybeDouble = Optional.of(doubleValue);
          }
        }
        maybeDouble.ifPresent(dobleValue -> {
          textFieldLoanAmount.setValue(new DecimalFormat("###,##0").format(dobleValue));
        });
      }
    });

    loanPurposeComboBox.setRequiredIndicatorVisible(true);

    comboBoxTerm.setEnabled(false);

    comboxBoxLoanType.setDataProvider(new ListDataProvider<ProductType>(Arrays.asList(ProductType.values())));
    comboxBoxLoanType.addValueChangeListener(this::onSelectedProductType);

    comboBoxTerm.getDataProvider().refreshAll();
    comboxBoxLoanType.getDataProvider().refreshAll();

    buttonSave.setVisible(false);
    isEnableComponent(false);
    buttonEdit.addClickListener(e -> {
      if (buttonEdit.getCaption().equalsIgnoreCase("Edit")) {
        fetchData(applicationId);
        buttonSave.setVisible(true);
        buttonSimulationPayment.setVisible(true);
        buttonEdit.setCaption("Cancel");
        isEnableComponent(true);
      } else if (buttonEdit.getCaption().equalsIgnoreCase("Cancel")) {
        buttonEdit.setCaption("Edit");
        buttonSave.setVisible(false);
        buttonSimulationPayment.setVisible(false);
        fetchData(applicationId);
        isEnableComponent(false);
      }
    });

    loanPurposeComboBox.setDataProvider(new ListDataProvider<LoanPurpose>(sortLoanPurposes(loanPurposeService.getAllLoanPurposes())));

    //set visible for otherLoanPurposeTextArea
    loanPurposeComboBox.addValueChangeListener(event -> {
      if (loanPurposeComboBox.getSelectedItem().isPresent() && OTHER.equalsIgnoreCase(loanPurposeComboBox.getSelectedItem().get().getPurpose()))
        otherLoanPurposeTextArea.setVisible(true);
      else
        otherLoanPurposeTextArea.setVisible(false);
    });

    addLoanPurposeButton.addClickListener(event -> {
      //checking loan purpose is other purpose or not
      if (loanPurposeComboBox.getSelectedItem().isPresent() && !OTHER.equalsIgnoreCase(loanPurposeComboBox.getSelectedItem().get().getPurpose())) {
        //checking loan purpose already selected or not
        if (!loanPurposes.contains(loanPurposeComboBox.getSelectedItem().get())) {
          loanPurposeItemLayout.addComponent(createLoanPurposeItemComponent(loanPurposeComboBox.getSelectedItem().get()));
          loanPurposes.add(loanPurposeComboBox.getSelectedItem().get());
        } else
          Notification.show("Loan Purpose already selected", Notification.Type.ERROR_MESSAGE);
      } else if (loanPurposeComboBox.getSelectedItem().isPresent() && OTHER.equalsIgnoreCase(loanPurposeComboBox.getSelectedItem().get().getPurpose())) {
        //make sure before adding textArea must be none empty
        if (!otherLoanPurposeTextArea.getValue().isEmpty()) {
          LoanPurpose purpose = new LoanPurpose();
          purpose.setPurpose(otherLoanPurposeTextArea.getValue());
          loanPurposeItemLayout.addComponent(createLoanPurposeItemComponent(purpose));
          loanPurposes.add(purpose);
        }
      }
      //validated save button
      buttonSave.setEnabled(updateProductInformationBinder.isValid() && loanPurposeItemLayout.getComponentCount() != 0);
      otherLoanPurposeTextArea.clear();
    });

    buttonSave.addClickListener(event -> {
      try {
        //set list of purpose before save data
        updateProductInformationBinder.getBean().setLoanPurposes(loanPurposes);

        commandGateway.sendAndWait(new UpdateProductInformationCommand(updateProductInformationBinder.getBean()
                .getApplicationId(), updateProductInformationBinder.getBean()));
        ListDataProvider<Installment> dataProvider = createInstallmentDataProvider(updateProductInformationBinder.getBean());

        FinancialStatementDTO financialStatementDTO = financialStatementRepository.findOne(applicationId);
        financialStatementDTO.setInstallment(installmentAmount);
        // update ratio when installment change
        financialStatementDTO.setFinancialRatio(financialStatementDTO.getNetProfit().
                divide(installmentAmount.getNumber().doubleValueExact()));

        financialStatementDTO.setFinancialRatioLow(financialStatementDTO.getFinancialRatio().multiply(0.8));

        financialStatementRepository.save(financialStatementDTO);

        bus.post(new GeneratePaymentScheduleEvent(updateProductInformationBinder.getBean(), paymentSchedule, dataProvider)).now();
        bus.post(new ProductInformationUpdatedEvent()).now();

      } catch (Exception e) {
        logger.error(e.getStackTrace().toString());
      }
      buttonSimulationPayment.setVisible(false);
      buttonSave.setVisible(false);
      isEnableComponent(false);
      buttonEdit.setCaption("Edit");
      otherLoanPurposeTextArea.clear();
      otherLoanPurposeTextArea.setVisible(false);
      loanPurposeComboBox.setSelectedItem(null);
    });

    buttonSimulationPayment.addClickListener(clickEvent -> {
      ListDataProvider<Installment> dataProvider = createInstallmentDataProvider(updateProductInformationBinder.getBean());
      bus.post(new GeneratePaymentScheduleEvent(updateProductInformationBinder.getBean(), paymentSchedule, dataProvider)).now();
    });

    comboBoxTerm.setDataProvider(new ListDataProvider<Integer>(termData));
    comboBoxPaymentFrequency.setDataProvider(new ListDataProvider<PaymentFrequencyDTO>(paymentFrequencyData));
    interestRateComboBox.setDataProvider(new ListDataProvider<Interest>(interestRateService.getAllInterestRate()));
    textFieldID.setEnabled(false);
    buttonSave.setEnabled(false);
    buttonSimulationPayment.setEnabled(false);

    updateProductInformationBinder.addStatusChangeListener(e -> buttonSave.setEnabled(e.getBinder().isValid() && loanPurposeItemLayout.getComponentCount() != 0));
    updateProductInformationBinder.addStatusChangeListener(e -> buttonSimulationPayment.setEnabled(e.getBinder().isValid()));

    fetchData(applicationId);

    // Set permission for field checker
    if (vaadinSecurity.hasAuthority(Role.FIELDCHECKER))
      buttonEdit.setVisible(false);
  }

  private static LocalDate getFirstPossibleContractDate() {
    LocalDate now = LocalDate.now();
    // At the end of the month, will need skip
    if (now.getDayOfMonth() > LAST_CONTRACT_DAY_OF_MONTH) {
      return now.plusMonths(1).withDayOfMonth(1);
    }
    return now;
  }

  //sort loan Purpose
  private List<LoanPurpose> sortLoanPurposes(List<LoanPurpose> loanPurposes) {
    loanPurposes.sort((x, y) -> y.getPurpose().equalsIgnoreCase(OTHER) ? -1 : 0);
    return loanPurposes;
  }

  private ListDataProvider<Installment> createInstallmentDataProvider(ProductInformationDTO productInformation) {
    return new ListDataProvider<>(generatePaymentSchedule(productInformation));
  }

  private List<Installment> generatePaymentSchedule(ProductInformationDTO productInformation) {
    if (productInformation.getLoanAmount() == null || productInformation.getTerm() == null || productInformation.getPaymentFrequency() == null || productInformation.getInterest() == null)
      return new ArrayList<>();

    LocalDate firstPossibleContractDate = getFirstPossibleContractDate();

    Calendar calendar = Calendar.getInstance();
    calendar.set(Calendar.MONTH, firstPossibleContractDate.getMonthValue());
    calendar.set(Calendar.DAY_OF_MONTH, firstPossibleContractDate.getDayOfMonth());

    LoanParameter param = LoanParameterBuilder.createBuilder().numberOfCompoundingPeriods(productInformation.getPaymentFrequency().getValue())
            .loanAmount(productInformation.getLoanAmount())
            .loanTerm(productInformation.getTerm().doubleValue() / 12.0)
            .nominalInterestRate((productInformation.getInterest().getInterestRate().doubleValue() * 12) / 100)
            .startDate(calendar.getTime())
            .scale(10)
            .build();

    paymentSchedule = new SimpleAmortization().generatePaymentSchedule(param);

    installmentAmount = paymentSchedule.get(0).getAmount();

    return paymentSchedule;
  }

  private void onSelectedProductType(HasValue.ValueChangeEvent<ProductType> productTypeValueChangeEvent) {

    boolean isProductTypePresent = productTypeValueChangeEvent.getSource().getOptionalValue().isPresent();
    ProductInformationDTO productInformationDTO = updateProductInformationBinder.getBean();

    if (isProductTypePresent) {
      ProductType productType = productTypeValueChangeEvent.getValue();
      if (!productType.equals(currentProductInformation.getLoanType())) {
        // Fetch loan product template
        Optional<LoanProductTemplate> optionalLoanProductTemplate = loanProductTemplateService.getProductTemplate(productType);
        if (!optionalLoanProductTemplate.isPresent())
          throw new RuntimeException("There are no product available. Please contact your support");

        LoanProductTemplate loanProductTemplate = optionalLoanProductTemplate.get();

        // Set available terms
        termData.clear();
        termData.addAll(loanProductTemplate.getTerms().stream().map(Term::getValue).collect(Collectors.toList()));
        comboBoxTerm.getDataProvider().refreshAll();
        productInformationDTO.setAvailableTerm(loanProductTemplate.getTerms().stream().map(Term::getValue).collect(Collectors.toList()));

        paymentFrequencyData.clear();
        paymentFrequencyData.addAll(loanProductTemplate.getPaymentFrequencies());
        comboBoxPaymentFrequency.getDataProvider().refreshAll();
        productInformationDTO.setAvailablePaymentFrequency(loanProductTemplate.getPaymentFrequencies());

        productInformationDTO.setMaxLoanAmount(loanProductTemplate.getMaximumLoanAmount());
        productInformationDTO.setMinLoanAmount(loanProductTemplate.getMinimumLoanAmount());

        productInformationDTO.setInterest(loanProductTemplate.getInterest());
        productInformationDTO.setLoanType(productType);
      } else {
        termData.clear();
        termData.addAll(currentProductInformation.getAvailableTerm());
        comboBoxTerm.getDataProvider().refreshAll();

        paymentFrequencyData.clear();
        paymentFrequencyData.addAll(currentProductInformation.getAvailablePaymentFrequency());
        comboBoxPaymentFrequency.getDataProvider().refreshAll();

        productInformationDTO.setMinLoanAmount(currentProductInformation.getMinLoanAmount());
        productInformationDTO.setMaxLoanAmount(currentProductInformation.getMaxLoanAmount());

        productInformationDTO.setInterest(currentProductInformation.getInterest());
        productInformationDTO.setLoanType(currentProductInformation.getLoanType());
      }
    }
  }

  private Binder<ProductInformationDTO> createUpdateProductInformationBinder() {
    Binder<ProductInformationDTO> result = new BeanValidationBinder<>(ProductInformationDTO.class);
    result.bind(textFieldID, "referenceId");
    result.forField(comboBoxTerm).asRequired("Term").bind("term");
    result.forField(comboxBoxLoanType).asRequired("Loan type").bind("loanType");
    result.forField(textFieldLoanAmount).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
            .withValidator(loanAmount -> loanAmount.isLessThanOrEqualTo(updateProductInformationBinder.getBean().getMaxLoanAmount()),
                    "Loan amount must less than maximum loan amount.")
            .withValidator(loanAmount -> loanAmount.isGreaterThanOrEqualTo(updateProductInformationBinder.getBean().getMinLoanAmount()),
                    "Loan amount must greater than minimum loan amount.")
            .bind("loanAmount");

    result.forField(comboBoxPaymentFrequency).asRequired("Payment frequency").bind("paymentFrequency");
    result.forField(interestRateComboBox).bind("interest");
    return result;
  }

  private void fetchData(String applicationId) {
    Optional<ProductInformationDTO> productInformationOptional = productInformationRepository.findByApplicationId(applicationId);
    if (!productInformationOptional.isPresent())
      throw new RuntimeException("Could not find product information for application id: " + applicationId);

    // cache the current fetched value
    currentProductInformation = productInformationOptional.get();
    resetData();
  }

  private void resetData() {
    termData.clear();
    loanPurposes.clear();
    otherLoanPurposeTextArea.clear();
    otherLoanPurposeTextArea.setVisible(false);

    updateProductInformationBinder.setBean(currentProductInformation);
    loanPurposes = currentProductInformation.getLoanPurposes().stream().collect(Collectors.toSet());

    termData.addAll(currentProductInformation.getAvailableTerm());
    comboBoxTerm.getDataProvider().refreshAll();

    paymentFrequencyData.clear();
    paymentFrequencyData.addAll(currentProductInformation.getAvailablePaymentFrequency());
    comboBoxPaymentFrequency.getDataProvider().refreshAll();
    loanPurposeComboBox.getDataProvider().refreshAll();
    loanPurposeComboBox.setSelectedItem(null);

    // refresh data
    ListDataProvider<Installment> dataProvider = createInstallmentDataProvider(updateProductInformationBinder.getBean());
    paymentSchedule = generatePaymentSchedule(updateProductInformationBinder.getBean());
    bus.post(new GeneratePaymentScheduleEvent(updateProductInformationBinder.getBean(), paymentSchedule, dataProvider)).now();
    bus.post(new ProductInformationUpdatedEvent()).now();

    loanPurposeItemLayout.removeAllComponents();
    loanPurposes.forEach(loanPurpose -> loanPurposeItemLayout.addComponent(createLoanPurposeItemComponent(loanPurpose)));
  }

  private void isEnableComponent(boolean isEnable) {
    comboxBoxLoanType.setEnabled(isEnable);
    textFieldLoanAmount.setEnabled(isEnable);
    comboBoxPaymentFrequency.setEnabled(isEnable);
    comboBoxTerm.setEnabled(isEnable);
    loanPurposeComboBox.setEnabled(isEnable);
    loanPurposeItemLayout.setEnabled(isEnable);
    addLoanPurposeButton.setEnabled(isEnable);
    if(vaadinSecurity.hasAuthority(Role.SENIOR_UNDERWRITER))
      interestRateComboBox.setEnabled(isEnable);
  }

  private Component createLoanPurposeItemComponent(LoanPurpose loanPurpose) {
    CssLayout loanPurposeItem = new CssLayout();
    loanPurposeItem.setWidth(100, Unit.PERCENTAGE);
    loanPurposeItem.setHeight(50, Unit.PIXELS);
    loanPurposeItem.setStyleName("loan-purpose-item-layout");

    Label purposeLabel = new Label();
    purposeLabel.setStyleName("loan-purpose-item-label");
    purposeLabel.setValue(loanPurpose.getPurpose());

    Button deletePurposeItem = new Button();
    deletePurposeItem.setIcon(VaadinIcons.TRASH);
    deletePurposeItem.setStyleName("loan-purpose-item-delete-button borderless");
    deletePurposeItem.setId("deleteIcon");
    deletePurposeItem.addClickListener(event -> {
      loanPurposeItemLayout.removeComponent(loanPurposeItem);
      loanPurposes.remove(loanPurpose);
      buttonSave.setEnabled(updateProductInformationBinder.isValid() && loanPurposeItemLayout.getComponentCount() != 0);
    });

    loanPurposeItem.addComponent(purposeLabel);
    loanPurposeItem.addComponent(deletePurposeItem);
    return loanPurposeItem;
  }
}
