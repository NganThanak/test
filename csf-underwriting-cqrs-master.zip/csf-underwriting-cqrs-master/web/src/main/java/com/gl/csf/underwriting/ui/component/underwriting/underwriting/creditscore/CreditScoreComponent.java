package com.gl.csf.underwriting.ui.component.underwriting.underwriting.creditscore;


import com.gl.csf.underwriting.api.creditscoring.command.RateApplicationCommand;
import com.gl.csf.underwriting.api.document.CreditScoreDocument;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.message.CreditScoreUpdatedEvent;
import com.gl.csf.underwriting.message.SessionScopeBus;
import com.gl.csf.underwriting.query.application.underwriting.creditscore.CreditScoreDTO;
import com.gl.csf.underwriting.query.application.underwriting.creditscore.CreditScoreRepository;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryRepository;
import com.gl.csf.underwriting.service.DocumentService;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.gl.csf.underwriting.ui.util.documentupload.DocumentUploader;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import lombok.Value;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.io.InputStream;
import java.util.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
public class CreditScoreComponent extends CreditScoreComponentDesign implements DocumentUploader.FileUploadConsumer {
  private String applicationId;

  private Binder<CreditScoreDTO> creditScoreDTOBinder;

  private DocumentService documentService;
  private UnderwritingLoanApplicationSummaryRepository underwritingLoanApplicationSummaryRepository;
  private CommandGateway commandGateway;
  private CreditScoreRepository creditScoreRepository;

  private Map<String, FileWrapper> fildUploads = new HashMap<>();

  private final static Logger logger = LoggerFactory.getLogger(CreditScoreComponent.class);

  public CreditScoreComponent() {
  }

  @Inject
  public CreditScoreComponent(SessionScopeBus bus, DocumentService documentService,
                              UnderwritingLoanApplicationSummaryRepository underwritingLoanApplicationSummaryRepository,
                              CommandGateway commandGateway,
                              CreditScoreRepository creditScoreRepository) {
    this.documentService = documentService;
    this.underwritingLoanApplicationSummaryRepository = underwritingLoanApplicationSummaryRepository;
    this.commandGateway = commandGateway;
    this.creditScoreRepository = creditScoreRepository;

    List<String> mockScore = new ArrayList<>();
    mockScore.add("A");
    mockScore.add("B");
    mockScore.add("C");
    mockScore.add("D");
    mockScore.add("E");
    mockScore.add("F");

    creditScoreDTOBinder = new BeanValidationBinder<>(CreditScoreDTO.class);
    creditScoreDTOBinder.setBean(CreditScoreDTO.create());
    initializeBinder(creditScoreDTOBinder);

    comboBoxScore.setDataProvider(new ListDataProvider<String>(mockScore));

    List<CreditScoreDocument> creditScoreDocuments = new ArrayList<>();

    buttonRate.setEnabled(false);
    buttonRate.addClickListener(e -> {
      try {
        for (Map.Entry<String, FileWrapper> entry : fildUploads.entrySet()) {
          DocumentDescriptor documentDescriptor = documentService.uploadDocument(entry.getKey(), this.applicationId,
                  entry.getValue().inputStream, entry.getValue().getMimeType());
          creditScoreDocuments.add(new CreditScoreDocument(UUID.randomUUID().toString(), entry.getKey(), documentDescriptor));
        }

        CreditScoreDTO creditScoreDTO = creditScoreDTOBinder.getBean();
        this.commandGateway.sendAndWait(new RateApplicationCommand(this.applicationId, creditScoreDTO.getScore(), creditScoreDTO.getReason(), creditScoreDocuments));
        bus.post(new CreditScoreUpdatedEvent()).now();
        creditScoreDTOBinder.removeBean();
        creditScoreDTOBinder.setBean(CreditScoreDTO.create());
        fildUploads.clear();
        creditScoreDocuments.clear();
        renderHistoryComponent();
        documentView.removeAllComponents();
      } catch (Exception ex) {
        logger.error(ex.toString());
      }
    });

    creditScoreDTOBinder
            .addStatusChangeListener(e -> buttonRate.setEnabled(e.getBinder().isValid()));
  }

  public void initialize(String applicationId) {
    this.applicationId = applicationId;
    DocumentUploader uploader = new DocumentUploader(this);
    documentUpload.setReceiver(uploader);
    documentUpload.addSucceededListener(uploader);

    renderHistoryComponent();
  }

  private void renderHistoryComponent() {

    List<CreditScoreDTO> creditScoreDTOS;

    creditScoreDTOS = creditScoreRepository.findByApplicationIdOrderByRateOnDesc(this.applicationId);

    creditScoreHistoryContent.removeAllComponents();
    for (CreditScoreDTO creditScoreDTO : creditScoreDTOS) {
      creditScoreHistoryContent.addComponent(new CreditScoreHistoryListComponent(creditScoreDTO, this.documentService));
    }
  }

  private void initializeBinder(Binder<CreditScoreDTO> creditScoreDTOBinder) {
    Objects.requireNonNull(creditScoreDTOBinder);
    creditScoreDTOBinder.bind(comboBoxScore, "score");
    creditScoreDTOBinder.bind(textFieldReason, "reason");
  }

  @Override
  public void onSuccess(DocumentDescriptor descriptor) {
    // Not use in this case
  }

  @Override
  public void onFail(Exception ex) {
    // Not use in this case
  }

  @Override
  public void onReceiveFile(String fileName, InputStream inputStream, String mimeType) {

    String newFilename;
    Integer fileVersion = 0;

    String[] file = fileName.split("\\.");

    for (Map.Entry<String, FileWrapper> entry : fildUploads.entrySet()) {
      if (entry.getKey().split("\\.")[0].matches(file[0] + "(.*)")) {
        fileVersion++;
      }
    }

    newFilename = (fileVersion == 0) ? fileName : file[0] + "(" + fileVersion + ")." + file[1];

    CssLayout uploadLayout = new CssLayout();

    Button buttonDeleteFile = new Button("x");
    buttonDeleteFile.setStyleName("button-delete-upload pull-right");

    Label label = new Label(newFilename);
    label.setStyleName("upload-style");

    uploadLayout.setStyleName("upload-layout-credit-score");
    uploadLayout.addComponent(label);
    uploadLayout.addComponent(buttonDeleteFile);

    fildUploads.put(newFilename, new FileWrapper(inputStream, mimeType));

    buttonDeleteFile.addClickListener(e -> {

      ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
      Window window = confirmationMessage.displayConfiguration();
      confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
        @Override
        public void onClosed() { window.close(); }
        @Override
        public void onNoButtonClicked() { window.close(); }
        @Override
        public void onYesButtonClicked() {
          documentView.removeComponent(uploadLayout);
          try {
            fildUploads.remove(newFilename);
          } catch (Exception e1) {
            logger.error(e1.toString());
          }
          window.close();
        }
      });
      window.setContent(confirmationMessage);
      UI.getCurrent().addWindow(window);

    });
    documentView.addComponent(uploadLayout);
  }

  @Value
  private class FileWrapper {
    InputStream inputStream;
    String mimeType;
  }
}
