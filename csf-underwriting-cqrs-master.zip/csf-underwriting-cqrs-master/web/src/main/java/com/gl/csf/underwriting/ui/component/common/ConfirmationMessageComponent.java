package com.gl.csf.underwriting.ui.component.common;

import com.vaadin.ui.Window;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/24/2017.
 */
public class ConfirmationMessageComponent extends ConfirmationMessageComponentDesign {
	public interface ConfirmationMessageComponentListener {
		void onClosed();
		void onNoButtonClicked();
		void onYesButtonClicked();
	}

	private ConfirmationMessageComponentListener listener;

	public ConfirmationMessageComponent() {
		closeButton.addClickListener(e -> {
			if(listener != null)
				listener.onClosed();
		});
		noButton.addClickListener(e -> {
			if(listener != null)
				listener.onNoButtonClicked();
		});
		yesButton.addClickListener(e -> {
			if(listener != null)
				listener.onYesButtonClicked();
		});
	}

	public Window displayConfiguration() {
		Window window = new Window();
		window.center();
		window.removeAllCloseShortcuts();
		window.setResizable(false);
		window.setClosable(false);
		window.setModal(true);
		window.setWidth(600, Unit.PIXELS);
		return window;
	}

	public ConfirmationMessageComponentListener getListener() {
		return listener;
	}

	public void setListener(ConfirmationMessageComponentListener listener) {
		this.listener = listener;
	}

}
