package com.gl.csf.underwriting.ui.component.underwriting.fieldcheck;

import com.gl.csf.underwriting.ui.component.common.FileUploadResult;

import java.util.Set;

/**
 * Created by p.ly on 10/4/2017.
 */
public class FieldCheckUploadDocumentComponent extends FieldCheckUploadDocumentComponentDesign {
  public interface FieldCheckListUploadDocumentComponentListener{
    void onClosed();
    void onCancelButtonClicked();
    void onSaveButtonClicked();
  }

  private FieldCheckListUploadDocumentComponentListener listener;

  public FieldCheckUploadDocumentComponent(){
    closeButton.addClickListener(e -> {
      if(listener != null)
        listener.onClosed();
    });
    cancelButton.addClickListener(e -> {
      if(listener != null)
        listener.onCancelButtonClicked();
    });

    saveButton.addClickListener(e -> {
      if(listener != null)
        listener.onSaveButtonClicked();
    });
  }

  public void setListener(FieldCheckListUploadDocumentComponentListener listener) {
    this.listener = listener;
  }

  public Set<FileUploadResult> getFileUploadResults(){
    return fileUploadComponent.getFileUploadResults();
  }

  public void clearUploadResults(){
    fileUploadComponent.clearUploadResults();
  }
}
