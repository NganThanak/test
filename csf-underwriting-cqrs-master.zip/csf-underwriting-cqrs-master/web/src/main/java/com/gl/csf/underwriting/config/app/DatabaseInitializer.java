package com.gl.csf.underwriting.config.app;

import com.gl.csf.underwriting.common.model.address.District;
import com.gl.csf.underwriting.common.model.address.State;
import com.gl.csf.underwriting.common.model.address.Township;
import com.gl.csf.underwriting.common.model.product.Interest;
import com.gl.csf.underwriting.query.application.util.CurrencyUtil;
import com.gl.csf.underwriting.api.application.command.SubmitApplicationCommand;
import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.common.model.bank.BankAccount;
import com.gl.csf.underwriting.common.model.customer.Customer;
import com.gl.csf.underwriting.common.model.customer.Gender;
import com.gl.csf.underwriting.common.model.product.LoanProduct;
import com.gl.csf.underwriting.common.model.product.ProductType;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.javamoney.moneta.Money;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 09/10/2017.
 */
@Component
@Profile(value = {"default"})
public class DatabaseInitializer implements CommandLineRunner {

  private final CommandGateway commandGateway;

  @Inject
  public DatabaseInitializer(CommandGateway commandGateway){
    this.commandGateway = commandGateway;
  }

  @Override
  public void run(String... strings) throws Exception {
    //createMockApplication("John Doe");
    //createMockApplication("Jane Doe");
  }

  private void createMockApplication(String customerFullName){
    String applicationId = UUID.randomUUID().toString();
    Application application = new Application();
    application.setLoanProduct(createMockLoanProduct());
    application.setApplicant(createMockApplicant(customerFullName));
    SubmitApplicationCommand submitApplicationCommand = new SubmitApplicationCommand(applicationId, application);
    commandGateway.sendAndWait(submitApplicationCommand);
  }

  private Customer createMockApplicant(String customerFullName) {
    Customer result = new Customer();
    result.setUsername("test-customer");
    result.setBusinessName("Test business");
    result.setFullName(customerFullName);
    result.setGender(Gender.MALE);
    result.setDateOfBirth(LocalDate.now());
    result.setEmail("test@grouplease.co.th");
    result.setPhoneNumber("08712311234");
    result.setAddress(createMockAddress());
    result.setBankAccount(createMockBankAccount());
    return result;
  }

  private Address createMockAddress(){
    Address result = new Address();
    result.setText("Test address");
    result.setDistrict(new District());
    result.setState(new State());
    result.setTownship(new Township());
    result.setText("Default address");
    return result;
  }

  private BankAccount createMockBankAccount(){
    BankAccount result = new BankAccount();
    result.setAccountName("Test Account Name");
    result.setAccountNumber("Test Account Number");
    return result;
  }

  private LoanProduct createMockLoanProduct() {
    LoanProduct result = new LoanProduct();
    Interest interest = new Interest();
    interest.setDefaultValue(false);
    interest.setInterestRate(new BigDecimal(10));
    result.setLoanAmount(Money.of(1000000, CurrencyUtil.MMK_CURRENCY));
    result.setProductType(ProductType.STANDARD_LOAN);
    result.setTerm(24);
    result.setInterestRate(interest);
    return result;
  }
}
