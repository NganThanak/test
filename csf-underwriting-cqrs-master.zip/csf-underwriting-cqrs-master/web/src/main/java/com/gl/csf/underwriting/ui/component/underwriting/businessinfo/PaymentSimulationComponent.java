package com.gl.csf.underwriting.ui.component.underwriting.businessinfo;

import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.message.GeneratePaymentScheduleEvent;
import com.gl.csf.underwriting.message.SessionScopeBus;
import com.gl.csf.underwriting.ui.util.excel.PaymentScheduleExcelBuilder;
import com.gl.csf.underwriting.ui.util.paymentschedule.Installment;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.renderers.NumberRenderer;
import net.engio.mbassy.listener.Enveloped;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.subscription.MessageEnvelope;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 12/13/2017.
 */
public class PaymentSimulationComponent extends PaymentSimulationComponentDesign {

  private static final String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private static final String PAYMENT_SIMULATION_PATH = BASE_PATH + "/payment-simulation/download";
  private SessionScopeBus bus;
  private List<Installment> installments = new ArrayList<>();
  private ProductInformationDTO productInformationDTO;

  PaymentSimulationComponent(SessionScopeBus bus) {
    this.bus = bus;

    buttonExportToExcel.addClickListener(clickEvent -> {
      if (!installments.isEmpty()) {
        PaymentScheduleExcelBuilder.setInstallment(installments);
        PaymentScheduleExcelBuilder.setLoanType(productInformationDTO.getLoanType().getValue());
        PaymentScheduleExcelBuilder.setCustomer(productInformationDTO.getReferenceId());
        Page.getCurrent().open(PAYMENT_SIMULATION_PATH, "_blank");
      }
    });
    initPaymentGrid();
  }

  private void updateData(ProductInformationDTO productInformationDTO, List<Installment> installments, ListDataProvider<Installment> installmentDataProvider) {
    this.installments = installments;
    this.productInformationDTO = productInformationDTO;
    paymentGrid.setDataProvider(installmentDataProvider);
  }

  private void initPaymentGrid() {
    SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
    DateRenderer dateRenderer = new DateRenderer(df);

    NumberFormat formatter = new DecimalFormat("###,###.##");
    formatter.setMaximumFractionDigits(2);

    paymentGrid.setWidth(100, Unit.PERCENTAGE);
    paymentGrid.addColumn(Installment::getInstallmentNumber).setCaption("Period");
    paymentGrid.addColumn(Installment::getDueDate).setCaption("Installment Date").setRenderer(dateRenderer);

    paymentGrid.addColumn(installment -> installment.getAmount().getNumber().numberValue(BigDecimal.class)
            .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Installment").setRenderer(new NumberRenderer(formatter));
    paymentGrid.addColumn(installment -> installment.getInterest().getNumber().numberValue(BigDecimal.class)
            .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Interest").setRenderer(new NumberRenderer(formatter));
    paymentGrid.addColumn(installment -> installment.getPrincipal().getNumber().numberValue(BigDecimal.class)
            .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Principle").setRenderer(new NumberRenderer(formatter));
    paymentGrid.addColumn(installment -> installment.getEndBalance().getNumber().numberValue(BigDecimal.class)
            .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Remaining Balance").setRenderer(new NumberRenderer(formatter));
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  @Handler
  @Enveloped(messages = {GeneratePaymentScheduleEvent.class})
  public void handle(MessageEnvelope envelope) {
    GeneratePaymentScheduleEvent generatePaymentScheduleEvent = envelope.getMessage();
    updateData(generatePaymentScheduleEvent.getProductInformationDTO(), generatePaymentScheduleEvent.getInstallments(),
            generatePaymentScheduleEvent.getInstallmentDataProvider());
  }
}
