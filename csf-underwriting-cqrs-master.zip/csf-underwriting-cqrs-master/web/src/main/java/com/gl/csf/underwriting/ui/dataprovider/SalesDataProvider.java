package com.gl.csf.underwriting.ui.dataprovider;

import com.gl.csf.underwriting.query.application.underwriting.salesitem.SalesItemDTO;
import com.gl.csf.underwriting.service.adapter.boss.BossService;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;

import javax.inject.Inject;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/18/2017.
 */
@SpringComponent
public class SalesDataProvider extends AbstractBackEndDataProvider<SalesItemDTO, SaleHistoryFilter> {

  private final BossService bossService;

  @Inject
  public SalesDataProvider(BossService bossService) {
    this.bossService = bossService;
  }

  @Override
  protected Stream<SalesItemDTO> fetchFromBackEnd(Query<SalesItemDTO, SaleHistoryFilter> query) {
    int limit = query.getLimit();
    int offset = query.getOffset();

    Optional<SaleHistoryFilter> optionalFilter = query.getFilter();
    if (optionalFilter.isPresent()) {
      SaleHistoryFilter saleHistoryFilter = optionalFilter.get();

      return bossService.getSaleItemHistoryByBranch(saleHistoryFilter.getBusinessId(), saleHistoryFilter.getBranchId(),
              saleHistoryFilter.getStartDate(), saleHistoryFilter.getEndDate(), offset, limit).parallelStream();
    } else {
      return Stream.empty();
    }
  }

  @Override
  protected int sizeInBackEnd(Query<SalesItemDTO, SaleHistoryFilter> query) {

    Optional<SaleHistoryFilter> optionalFilter = query.getFilter();
    if (optionalFilter.isPresent()) {
      SaleHistoryFilter saleHistoryFilter = optionalFilter.get();
      return bossService.getTotalRow(saleHistoryFilter.getBusinessId(), saleHistoryFilter.getBranchId(),
              saleHistoryFilter.getStartDate(), saleHistoryFilter.getEndDate());
    }
    else {
      return 0;
    }
  }
}
