package com.gl.csf.underwriting.ui.component.common;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/11/2017.
 */
public class ConfirmationComponent extends ConfirmationComponentDesign {

	public interface ConfirmationComponentListener{
		void onClosed();
		void onNoButtonClicked();
		void onYesButtonClicked();
	}

	private ConfirmationComponentListener listener;

	public ConfirmationComponent() {
		closeButton.addClickListener(e -> {
			if(listener != null)
				listener.onClosed();
		});
		noButton.addClickListener(e -> {
			if(listener != null)
				listener.onNoButtonClicked();
		});

		yesButton.addClickListener(e -> {
			if(listener != null)
				listener.onYesButtonClicked();
		});
		reasonText.addValueChangeListener(e-> {
			yesButton.setEnabled(!reasonText.getValue().isEmpty());
		});

	}

	public ConfirmationComponentListener getListener() {
		return listener;
	}

	public void setListener(ConfirmationComponentListener listener) {
		this.listener = listener;
	}
	
	public String getDeclineReason(){return reasonText.getValue();}
}
