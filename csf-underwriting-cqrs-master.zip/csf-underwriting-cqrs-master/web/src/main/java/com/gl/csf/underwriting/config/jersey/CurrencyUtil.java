package com.gl.csf.underwriting.config.jersey;

import javax.money.CurrencyUnit;
import javax.money.Monetary;
import javax.money.format.AmountFormatQueryBuilder;
import javax.money.format.MonetaryAmountFormat;
import javax.money.format.MonetaryFormats;
import java.util.Locale;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 26/07/2017.
 */
public class CurrencyUtil {
  public static final CurrencyUnit MMK_CURRENCY = Monetary.getCurrency("MMK");

  private static final String PATTERN_KEY = "pattern";
  private static final String DEFAULT_PATTERN = "¤ #,##0.00";
  public final static MonetaryAmountFormat MONETARY_AMOUNT_FORMAT = MonetaryFormats.getAmountFormat(
          AmountFormatQueryBuilder.of(Locale.getDefault()).set(PATTERN_KEY, DEFAULT_PATTERN).build());
}
