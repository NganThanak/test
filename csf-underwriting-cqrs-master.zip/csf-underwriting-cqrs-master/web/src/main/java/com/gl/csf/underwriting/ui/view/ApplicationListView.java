package com.gl.csf.underwriting.ui.view;

import com.gl.csf.underwriting.ui.permission.Role;
import com.gl.csf.underwriting.ui.viewdeclaration.UIScopeUnderwritingViews;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeUnderwritingViews.APPLICATION_LIST)
@Secured({Role.FIELDCHECKER, Role.JUNIOR_UNDERWRITER, Role.SENIOR_UNDERWRITER})
public class ApplicationListView extends ApplicationListViewDesign implements View {


}
