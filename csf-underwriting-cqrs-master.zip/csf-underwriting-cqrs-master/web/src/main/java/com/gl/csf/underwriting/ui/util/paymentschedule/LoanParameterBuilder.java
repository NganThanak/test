package com.gl.csf.underwriting.ui.util.paymentschedule;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 30/10/2017.
 */

public class LoanParameterBuilder {
  private int calculatingRule = 1;

  // Financed amount
  private MonetaryAmount loanAmount;

  // For revolving loan withdrawal
  private List<Withdrawal> withdrawals = new ArrayList<>();

  // The interest rate earned per period is called periodic rate
  private double interestRatePerPeriod;

  // Quoted interest rate per annum
  private double nominalInterestRate;

  /**
   * Term of a loan in years
   */
  private double loanTerm;

  /**
   * Number of periods for the given compounding method.
   * e.g. for monthly compounding, 1 year = 12 months,
   * for quarterly compounding, 1year = 4 quarters,
   * for daily compounding, 1year = 365 days
   * for weekly compounding 1year = 52 weeks
   */
  private int numberOfCompoundingPeriods = LoanParameter.getNumberOfCompoundingPeriods(Compounding.YEARLY);

  // first payment due date
  private Date dueDate;

  // precision
  private int scale = 10;
  // rounding mode
  private int roundingMode = BigDecimal.ROUND_HALF_UP;

  public static LoanParameterBuilder createBuilder() {
    return new LoanParameterBuilder();
  }

  public LoanParameter build() {
    return new LoanParameter(this);
  }

  public LoanParameterBuilder loanTerm(double term) {
    this.loanTerm = term;
    return this;
  }

  public LoanParameterBuilder loanAmount(MonetaryAmount amount) {
    this.loanAmount = amount;
    return this;
  }

  public LoanParameterBuilder withdraw(Withdrawal w) {
    if (w != null)
      withdrawals.add(w);
    return this;
  }

  public LoanParameterBuilder ratePerPeriod(double interestRatePerPeriod) {
    this.interestRatePerPeriod = interestRatePerPeriod;
    return this;
  }

  public LoanParameterBuilder calculatingRule(int rule) {
    this.calculatingRule = rule;
    return this;
  }

  public LoanParameterBuilder numberOfCompoundingPeriods(int numberOfCompoundingPeriods){
    this.numberOfCompoundingPeriods = numberOfCompoundingPeriods;
    return this;
  }

  public LoanParameterBuilder numberOfCompoundingPeriods(Compounding compounding){
    return numberOfCompoundingPeriods(LoanParameter.getNumberOfCompoundingPeriods(compounding));
  }

  public LoanParameterBuilder nominalInterestRate(double quotedRate) {
    this.nominalInterestRate = quotedRate;
    return this;
  }

  public LoanParameterBuilder startDate(Date date) {
    this.dueDate = date;
    return this;
  }

  public LoanParameterBuilder scale(int newscale) {
    this.scale = newscale;
    return this;
  }

  public LoanParameterBuilder rounding(int mode) {
    this.roundingMode = mode;
    return this;
  }

  public int getCalculatingRule() {
    return calculatingRule;
  }

  public MonetaryAmount getLoanAmount() {
    return loanAmount;
  }

  public List<Withdrawal> getWithdrawals() {
    return withdrawals;
  }

  public double getInterestRatePerPeriod() {
    return interestRatePerPeriod;
  }

  public double getNominalInterestRate() {
    return nominalInterestRate;
  }

  public double getLoanTerm() {
    return loanTerm;
  }

  public int getNumberOfCompoundingPeriods() {
    return numberOfCompoundingPeriods;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public int getScale() {
    return scale;
  }

  public int getRoundingMode() {
    return roundingMode;
  }
}
