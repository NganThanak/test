package com.gl.csf.common.util;

import com.vaadin.ui.renderers.LocalDateTimeRenderer;

import java.time.format.DateTimeFormatter;

/**
 * Created by p.ly on 10/26/2017.
 */
public class LocalDateTimeFormat {

  public static LocalDateTimeRenderer createLocalDateTimeRenderer() {
    return new LocalDateTimeRenderer("dd-MM-yyyy h:mm a");
  }

  public static DateTimeFormatter createDateTimeformatter() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy h:mm a");
    return formatter;
  }


}
