package com.gl.csf.underwriting.ui.component.underwriting.underwriting;

import com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields.UnderwritingFieldsComponent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/26/2017.
 */
@UIScope
@SpringComponent
public class UnderwritingComponent extends UnderwritingComponentDesign {
  private String applicationId;

  public void setApplicationId(String applicationId){
    this.applicationId = applicationId;
    underwritingFieldsComponent.setApplicationId(this.applicationId);
    creditScoreComponent.initialize(this.applicationId);
    offerComponent.setApplicationId(this.applicationId);
  }
  
  public UnderwritingFieldsComponent getUnderwritingFieldsComponent() {
	  return underwritingFieldsComponent;
  }
}
