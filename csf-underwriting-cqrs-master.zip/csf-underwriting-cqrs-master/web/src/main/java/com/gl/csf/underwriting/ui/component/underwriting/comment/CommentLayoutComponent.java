package com.gl.csf.underwriting.ui.component.underwriting.comment;

import com.gl.csf.underwriting.api.application.command.CreateCommentCommand;
import com.gl.csf.underwriting.query.application.underwriting.comment.CommentDTO;
import com.gl.csf.underwriting.query.application.underwriting.comment.CommentRepository;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import org.axonframework.commandhandling.gateway.CommandGateway;

import javax.inject.Inject;
import java.util.List;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
public class CommentLayoutComponent extends CommentLayoutComponentDesign {

  private final CommentRepository commentRepository;
  private String applicationId;

  @Inject
  public CommentLayoutComponent(CommandGateway commandGateway, CommentRepository commentRepository) {
    this.commentRepository = commentRepository;

    setPastComments();

    buttonPostComment.addClickListener(e-> {
      if(!textareaComment.isEmpty()) {
        commandGateway.sendAndWait(new CreateCommentCommand(applicationId, textareaComment.getValue()));
        textareaComment.clear();
        setPastComments();
      }
    });
  }

  private void setPastComments(){
    List<CommentDTO> commentHistory = commentRepository.findByApplicationIdOrderByCommentedDateDesc(applicationId);
    pastComments.removeAllComponents();
    commentHistory.forEach(value -> {
      CommentComponent commentComponent = new CommentComponent(value);
      pastComments.addComponent(commentComponent);
    });
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
    setPastComments();
  }
}
