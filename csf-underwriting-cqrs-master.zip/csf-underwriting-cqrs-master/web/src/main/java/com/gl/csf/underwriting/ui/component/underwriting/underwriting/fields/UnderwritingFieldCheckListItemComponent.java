package com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.api.application.command.AttachDocumentToUnderwritingFieldCommand;
import com.gl.csf.underwriting.api.application.command.DeleteDocumentFromUnderwritingFieldCommand;
import com.gl.csf.underwriting.api.application.command.EditUnderwritingFieldCommand;
import com.gl.csf.underwriting.api.application.command.SaveFieldCheckCommentCommand;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.config.storage.MinioConfiguration;
import com.gl.csf.underwriting.message.UnderwritingFieldDocumentUpdatedEvent;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.comment.CommentFieldCheckDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.comment.CommentFieldCheckRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.document.UnderwritingFieldDocumentDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.document.UnderwritingFieldDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.UnderwritingFieldDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldhistory.UnderwritingFieldContentHistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldhistory.UnderwritingFieldContentHistoryRepository;
import com.gl.csf.underwriting.service.DocumentService;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.gl.csf.underwriting.ui.component.common.FileUploadResult;
import com.gl.csf.underwriting.ui.component.underwriting.fieldcheck.FieldCheckUploadDocumentComponent;
import com.gl.csf.underwriting.ui.dataprovider.DataProviderHelper;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.ui.*;
import com.vaadin.ui.themes.ValoTheme;
import liquibase.util.StringUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.http.entity.ContentType;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.vaadin.spring.security.VaadinSecurity;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * Created by p.ly on 9/28/2017.
 */
public class UnderwritingFieldCheckListItemComponent extends UnderwritingFieldCheckListItemComponentDesign {

  private final static Logger logger = LoggerFactory.getLogger(UnderwritingFieldCheckListItemComponent.class);
  private static final String NOT_NULL_VALUE = "Not null value";
  private final Binder<UnderwritingFieldDTO> underwritingFieldDTOBinder;
  private final Consumer<UnderwritingFieldDocumentUpdatedEvent> documentUpdateListener;
  private UnderwritingFieldDTO underwritingField;
  private boolean isFieldCheckRequested;
  private String field;
  private Set<String> imageType = new HashSet<>(Arrays.asList("JPG", "PNG", "JPEG"));
  
  private CommandGateway commandGateway;
  
  UnderwritingFieldCheckListItemComponent(DocumentService documentService, CommandGateway commandGateway, UnderwritingFieldDTO underwritingField,
                                          UnderwritingFieldDocumentRepository documentRepository, UnderwritingFieldContentHistoryRepository historyRepository,
                                          CommentFieldCheckRepository commentFieldCheckRepository, VaadinSecurity vaadinSecurity,
                                          Consumer<UnderwritingFieldDocumentUpdatedEvent> documentUpdateListener) {

    Objects.requireNonNull(documentService);
    Objects.requireNonNull(commandGateway);
    Objects.requireNonNull(underwritingField);
    Objects.requireNonNull(documentRepository);
    Objects.requireNonNull(historyRepository);
    Objects.requireNonNull(commentFieldCheckRepository);
    Objects.requireNonNull(vaadinSecurity);
    Objects.requireNonNull(documentUpdateListener);

    this.documentUpdateListener = documentUpdateListener;
    this.commandGateway = commandGateway;

    commentTextArea.setEnabled(false);
    fieldTextArea.setEnabled(false);

    underwritingFieldDTOBinder = createUnderwritingFieldBinder(underwritingField);

    setBean(underwritingField);
    Window popupWindow = createWindow(commandGateway, underwritingField.getApplicationId(), documentService, underwritingField.getUnderwritingFieldId());
    setDataProviderDocumentGrid(documentRepository);

    documentButton.addClickListener(e -> UI.getCurrent().addWindow(popupWindow));
    descriptionLabel.setValue(underwritingField.getDescription());
    yesButton.addClickListener(event -> {
      isFieldCheckRequested = true;
      this.yesButton.setStyleName("btn-rectangle");
      this.noButton.setStyleName("");
    });

    //format local date time
    Grid.Column dateModified = fieldGrid.getColumn("dateModified");
    dateModified.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());

    //format local date time
    Grid.Column commentDate = gridCommentFieldCheck.getColumn("commentedDate");
    commentDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());

    noButton.addClickListener(event -> {
      isFieldCheckRequested = false;
      this.noButton.setStyleName("btn-rectangle");
      this.yesButton.setStyleName("");
    });

    saveFieldButton.addClickListener(event -> {
      if (saveFieldButton.getCaption().equals("Save")) {
        saveFieldButton.setCaption("Edit");
        buttonCancelField.setVisible(false);
        fieldTextArea.setEnabled(false);
        commandGateway.sendAndWait(new EditUnderwritingFieldCommand(underwritingField.getApplicationId(), underwritingField.getUnderwritingFieldId(), fieldTextArea.getValue()));
        Notification.show("Saved");
        fieldGrid.getDataProvider().refreshAll();
        field = fieldTextArea.getValue();

      } else {
        buttonCancelField.setVisible(true);
        saveFieldButton.setCaption("Save");
        fieldTextArea.setEnabled(true);
        saveFieldButton.setEnabled(false);
      }
    });

    fieldTextArea.addValueChangeListener(e -> {
      if (saveFieldButton.getCaption().equals("Save"))
        saveFieldButton.setEnabled(!fieldTextArea.isEmpty() && !fieldTextArea.getValue().equals(field));
    });

    buttonCancelField.addClickListener(event -> {
      fieldTextArea.setEnabled(false);
      buttonCancelField.setVisible(false);
      saveFieldButton.setEnabled(true);
      saveFieldButton.setCaption("Edit");
      fieldTextArea.setValue(field);
    });

    saveCommentButton.addClickListener(event -> {
      if (saveCommentButton.getCaption().equals("Save")) {
        saveCommentButton.setCaption("Edit");
        buttonCancelComment.setVisible(false);
        commentTextArea.setEnabled(false);
        commandGateway.sendAndWait(new SaveFieldCheckCommentCommand(underwritingField.getApplicationId(), underwritingField.getUnderwritingFieldId(), commentTextArea.getValue()));
        Notification.show("Saved");
        gridCommentFieldCheck.getDataProvider().refreshAll();
        commentTextArea.clear();
      } else {
        buttonCancelComment.setVisible(true);
        saveCommentButton.setCaption("Save");
        commentTextArea.setEnabled(true);
        saveCommentButton.setEnabled(false);
      }
    });

    commentTextArea.addValueChangeListener(e -> {
      if (saveCommentButton.getCaption().equals("Save"))
        saveCommentButton.setEnabled(!commentTextArea.isEmpty());
    });

    buttonCancelComment.addClickListener(event -> {
      commentTextArea.setEnabled(false);
      buttonCancelComment.setVisible(false);
      saveCommentButton.setEnabled(true);
      saveCommentButton.setCaption("Edit");
      commentTextArea.clear();
    });

    initDocumentGrid(commandGateway, underwritingField.getUnderwritingFieldId(), documentService, vaadinSecurity);
    setDataProviderFieldGrid(historyRepository);
    yesButton.addClickListener(event -> isFieldCheckRequested = true);
    noButton.addClickListener(event -> isFieldCheckRequested = false);

    setDataProviderCommentGrid(commentFieldCheckRepository);
    field = fieldTextArea.getValue();
  }

  private void setDataProviderCommentGrid(CommentFieldCheckRepository repository){
    gridCommentFieldCheck.setDataProvider(new AbstractBackEndDataProvider<CommentFieldCheckDTO, String>() {
      @Override
      protected Stream<CommentFieldCheckDTO> fetchFromBackEnd(Query<CommentFieldCheckDTO, String> query) {
        Pageable pageable = DataProviderHelper.createPageable(query);
        return repository.findByUnderwritingFieldIdAndIsSubmittedOrderByCommentedDateDesc(underwritingField.getUnderwritingFieldId(),true, pageable).parallelStream();
      }

      @Override
      protected int sizeInBackEnd(Query<CommentFieldCheckDTO, String> query) {
        return repository.countByUnderwritingFieldIdAndIsSubmitted(underwritingField.getUnderwritingFieldId(),true);
      }
    });
  }

  private void setBean(UnderwritingFieldDTO underwritingFieldDTO) {
    this.underwritingField = underwritingFieldDTO;
    descriptionLabel.setValue(underwritingFieldDTO.getDescription());
    mandatoryCheckBox.setValue(underwritingFieldDTO.getName());
    fieldTextArea.setValue(StringUtils.isEmpty(underwritingFieldDTO.getContent()) ? "" : underwritingFieldDTO.getContent());
    if(underwritingFieldDTO.isFieldCheckRequested()){
      this.noButton.setStyleName("");
      this.yesButton.setStyleName("btn-rectangle");
    }else{
      this.noButton.setStyleName("btn-rectangle");
      this.yesButton.setStyleName("");
    }
  }

  boolean isFieldCheckRequested() {
    return isFieldCheckRequested;
  }

  private void setDataProviderFieldGrid(UnderwritingFieldContentHistoryRepository historyRepository){

    fieldGrid.setDataProvider(new AbstractBackEndDataProvider<UnderwritingFieldContentHistoryDTO, String>() {
      @Override
      protected Stream<UnderwritingFieldContentHistoryDTO> fetchFromBackEnd(Query<UnderwritingFieldContentHistoryDTO, String> query) {
        return historyRepository.findByApplicationIdAndUnderwritingFieldIdAndIsSubmittedOrderByDateModifiedDesc(underwritingField.getApplicationId(), underwritingField.getUnderwritingFieldId(), true).parallelStream();
      }
      @Override
      protected int sizeInBackEnd(Query<UnderwritingFieldContentHistoryDTO, String> query) {
        return Math.toIntExact(historyRepository.countByApplicationIdAndUnderwritingFieldIdAndIsSubmitted(underwritingField.getApplicationId(), underwritingField.getUnderwritingFieldId(), true));
      }
    });
  }

  private void setDataProviderDocumentGrid(UnderwritingFieldDocumentRepository documentRepository) {
    documentGrid.setDataProvider(new AbstractBackEndDataProvider<UnderwritingFieldDocumentDTO, String>(){

      @Override
      protected Stream<UnderwritingFieldDocumentDTO> fetchFromBackEnd(Query<UnderwritingFieldDocumentDTO, String> query) {
        return documentRepository.findByDocumentDescriptorApplicationIdAndUnderwritingFieldIdAndIsSubmittedOrderByDateModifiedDesc(underwritingField.getApplicationId(), underwritingField.getUnderwritingFieldId(), true).parallelStream();
      }

      @Override
      protected int sizeInBackEnd(Query<UnderwritingFieldDocumentDTO, String> query) {
        return Math.toIntExact(documentRepository.countByDocumentDescriptorApplicationIdAndUnderwritingFieldIdAndIsSubmitted(underwritingField.getApplicationId(), underwritingField.getUnderwritingFieldId(), true));
      }
    });
  }

  private void initDocumentGrid(CommandGateway commandGateway, String underwritingFieldId, DocumentService documentService, VaadinSecurity vaadinSecurity) {
    documentGrid.addColumn(UnderwritingFieldDocumentDTO::getFileName).setCaption("Filename");

    documentGrid.addColumn(UnderwritingFieldDocumentDTO::getDateModified).setCaption("Date of submit").setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());
    documentGrid.addColumn(UnderwritingFieldDocumentDTO::getEditorId).setCaption("Uploaded by");
    documentGrid.addComponentColumn(dto -> {
      String fileExtension = FilenameUtils.getExtension(dto.getFileName());
      HorizontalLayout actionLayout = new HorizontalLayout();
      if(imageType.contains(fileExtension.toUpperCase())) {
        MinioConfiguration minioConfiguration = new MinioConfiguration();
        Button buttonPreview = new Button();
        buttonPreview.setIcon(VaadinIcons.EYE);
        buttonPreview.setStyleName(ValoTheme.BUTTON_LINK);
        buttonPreview.addClickListener(event -> {
          try {
            StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
              try {
                return documentService.downloadDocument(new DocumentDescriptor(dto.getDocumentDescriptor().getDocumentId()
                        , minioConfiguration.getEndpoint(), dto.getDocumentDescriptor().getApplicationId()));
              } catch (Exception e) {
                throw new RuntimeException(e);
              }
            }, dto.getFileName());
            Window window = new Window();
            window.center();
            window.setResizable(false);
            window.setContent(new Image(dto.getFileName(), streamResource));
            UI.getCurrent().addWindow(window);
          } catch (Exception e) {
            e.printStackTrace();
          }
        });
        actionLayout.addComponent(buttonPreview);
      }

      Button downloadButton = new Button();
      downloadButton.setIcon(VaadinIcons.DOWNLOAD);
      downloadButton.setStyleName(ValoTheme.BUTTON_LINK);
      try {
        MinioConfiguration minioConfiguration = new MinioConfiguration();
        StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
          try {
            return documentService.downloadDocument(new DocumentDescriptor(dto.getDocumentDescriptor().getDocumentId()
                    , minioConfiguration.getEndpoint(), dto.getDocumentDescriptor().getApplicationId()));
          } catch (Exception e) {
            logger.error("error when download financial document", e);
            throw new RuntimeException(e);
          }
        }, dto.getFileName());

        FileDownloader fileDownloader = new FileDownloader(streamResource);
        fileDownloader.extend(downloadButton);
      } catch (Exception e) {
        logger.error("error when download financial document", e);
        throw new RuntimeException(e);
      }

      actionLayout.addComponent(downloadButton);

      Button buttonDelete = new Button();
      buttonDelete.setStyleName(ValoTheme.BUTTON_LINK);
      buttonDelete.setIcon(VaadinIcons.TRASH);
      buttonDelete.addClickListener(event -> {

        ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
        Window window = confirmationMessage.displayConfiguration();
        confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
          @Override
          public void onClosed() { window.close(); }
          @Override
          public void onNoButtonClicked() { window.close(); }
          @Override
          public void onYesButtonClicked() {
            try {
              documentService.deleteDocument(dto.getDocumentDescriptor());
              commandGateway.sendAndWait(new DeleteDocumentFromUnderwritingFieldCommand(dto.getDocumentDescriptor().getApplicationId(),dto.getUnderwritingFieldId(),dto.getDocumentDescriptor()));
              //set value for updating accordion caption
              documentUpdateListener.accept(new UnderwritingFieldDocumentUpdatedEvent(mandatoryCheckBox.getValue(), underwritingFieldId));

            } catch (Exception e) {
              logger.error("Error when deleting a financial document", e);
            }
            documentGrid.getDataProvider().refreshAll();
            window.close();
          }
        });
        window.setContent(confirmationMessage);
        UI.getCurrent().addWindow(window);

      });
      actionLayout.addComponent(buttonDelete);
      return actionLayout;
    }).setCaption("Action");

  }

  private Window createWindow(CommandGateway commandGateway, String applicationId, DocumentService documentService, String underwritingFieldId) {
    Window result = new Window();
    result.center();
    result.removeAllCloseShortcuts();
    result.setResizable(false);
    result.setClosable(false);
    result.setModal(true);
    result.setWidth(600, Unit.PIXELS);
    result.setHeight(450, Unit.PIXELS);

    FieldCheckUploadDocumentComponent fieldCheckUploadDocumentComponent = new FieldCheckUploadDocumentComponent();
    fieldCheckUploadDocumentComponent.setListener(new FieldCheckUploadDocumentComponent.FieldCheckListUploadDocumentComponentListener() {
      @Override
      public void onClosed() {
        result.close();
        fieldCheckUploadDocumentComponent.clearUploadResults();
      }

      @Override
      public void onCancelButtonClicked() {
        result.close();
        fieldCheckUploadDocumentComponent.clearUploadResults();
      }

      @Override
      public void onSaveButtonClicked() {
        for (FileUploadResult fileUploadResult : fieldCheckUploadDocumentComponent.getFileUploadResults()) {
          // TODO: error should be handled more appropriately
          if (fileUploadResult.hasError())
            continue;
          // Save to minio
          try {
            DocumentDescriptor documentDescriptor = documentService.uploadDocument(fileUploadResult.getFilename(), applicationId,
                    fileUploadResult.getByteArrayInputStream(), ContentType.APPLICATION_OCTET_STREAM.toString());
            // Send command
            commandGateway.sendAndWait(new AttachDocumentToUnderwritingFieldCommand(applicationId, underwritingFieldId, documentDescriptor,fileUploadResult.getFilename()));
            //set value for updating accordion caption
            documentUpdateListener.accept(new UnderwritingFieldDocumentUpdatedEvent(mandatoryCheckBox.getValue(), underwritingFieldId));
          } catch (Exception e) {
            Notification.show("Failed to uploaded document", Notification.Type.ERROR_MESSAGE);
            logger.error("Failed to uploaded document", e);
          }
        }
        // Once uploaded the files, clear the upload results to release byte array content
        fieldCheckUploadDocumentComponent.clearUploadResults();
        result.close();
        Notification.show("Saved");
        documentGrid.getDataProvider().refreshAll();
      }
    });
    result.setContent(fieldCheckUploadDocumentComponent);
    return result;
  }

  String underwritingFieldId(){
    return underwritingField.getUnderwritingFieldId();
  }

  private Binder<UnderwritingFieldDTO> createUnderwritingFieldBinder(UnderwritingFieldDTO underwritingField) {
    Binder<UnderwritingFieldDTO> result = new BeanValidationBinder<>(UnderwritingFieldDTO.class);
    //set required field for Field
    if (underwritingField.isTextRequired())
      result.forField(fieldLabel).asRequired(NOT_NULL_VALUE);
    //set required field for Attachment
    if (underwritingField.isDocumentRequired())
      result.forField(attachmentLabel).asRequired(NOT_NULL_VALUE);
    return result;
  }

  public TextArea getFieldTextArea() {
	  return fieldTextArea;
  } 
   
  public void saveFieldValue() {
	  commandGateway.sendAndWait(new EditUnderwritingFieldCommand(underwritingField.getApplicationId(), underwritingField.getUnderwritingFieldId(), fieldTextArea.getValue()));
  }
}