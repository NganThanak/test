package com.gl.csf.underwriting.ui.component.underwriting;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/5/2017.
 */
public class FormAddDocumentComponent extends FormAddDocumentComponentDesign {
	public interface ForAddDocumentComponentListener{
		void onClosed();
		void onNoButtonClicked();
		void onYesButtonClicked();
	}
	private ForAddDocumentComponentListener listener;

	FormAddDocumentComponent(){
		closeButton.addClickListener(e -> {
			if(listener != null)
				listener.onClosed();
		});
		cancelButton.addClickListener(e -> {
			if(listener != null)
				listener.onNoButtonClicked();
		});

		saveButton.addClickListener(e -> {
			if(listener != null)
				listener.onYesButtonClicked();
		});
	}

	public ForAddDocumentComponentListener getListener() {
		return listener;
	}

	public void setListener(ForAddDocumentComponentListener listener) {
		this.listener = listener;
	}
}
