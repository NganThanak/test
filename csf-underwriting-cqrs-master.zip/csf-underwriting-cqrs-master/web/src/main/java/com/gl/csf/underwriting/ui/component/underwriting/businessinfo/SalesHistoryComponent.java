package com.gl.csf.underwriting.ui.component.underwriting.businessinfo;

import com.gl.csf.underwriting.query.application.underwriting.salesitem.SalesItemDTO;
import com.gl.csf.underwriting.ui.dataprovider.SaleHistoryFilter;
import com.gl.csf.underwriting.ui.dataprovider.SalesDataProvider;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.ui.Window;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/18/2017.
 */
public class SalesHistoryComponent extends SalesHistoryDesign {

  public SalesHistoryComponent(Window window, SalesDataProvider salesDataProvider, String businessId, String branchName, String branchId, String startDate, String endDate){
    buttonClose.addClickListener(e -> window.close());

    labelBranch.setValue(branchName);
    labelDate.setValue("Detail from date " + startDate + " to " + endDate);

    ConfigurableFilterDataProvider<SalesItemDTO, Void, SaleHistoryFilter> configurableFilterDataProvider =
            salesDataProvider.withConfigurableFilter();

    configurableFilterDataProvider.setFilter(new SaleHistoryFilter(businessId, branchId, startDate, endDate));

    gridSaleHistory.setDataProvider(configurableFilterDataProvider);
  }
}
