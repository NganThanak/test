package com.gl.csf.underwriting.ui.component.task;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryDTO;
import com.gl.csf.underwriting.ui.dataprovider.ApplicationFilter;
import com.gl.csf.underwriting.ui.dataprovider.MyApplicationDataProvider;
import com.gl.csf.underwriting.ui.permission.Role;
import com.gl.csf.underwriting.ui.viewdeclaration.UIScopeUnderwritingViews;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.server.Page;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;
import com.vaadin.ui.UI;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;


/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 8/17/2017.
 */
@SpringComponent
@UIScope
public class MyApplicationComponent extends MyApplicationComponentDesign {

	@Inject
	public MyApplicationComponent(MyApplicationDataProvider myApplicationDataProvider, VaadinSecurity vaadinSecurity){

		ConfigurableFilterDataProvider<UnderwritingLoanApplicationSummaryDTO, Void, ApplicationFilter> configurableFilterDataProvider =
						myApplicationDataProvider.withConfigurableFilter();

		String role;
		if(vaadinSecurity.hasAuthority(Role.FIELDCHECKER)){
			role = Role.FIELDCHECKER;
		} else if (vaadinSecurity.hasAuthorities(Role.JUNIOR_UNDERWRITER)){
			role = Role.JUNIOR_UNDERWRITER;
		} else if (vaadinSecurity.hasAuthorities(Role.SENIOR_UNDERWRITER)){
			role = Role.SENIOR_UNDERWRITER;
		} else {
			throw new IllegalArgumentException("Couldn't find any supported role");
		}

		configurableFilterDataProvider.setFilter(new ApplicationFilter(vaadinSecurity.getAuthentication().getName(), role));

		myApplicationGrid.setDataProvider(configurableFilterDataProvider);

		myApplicationGrid.addItemClickListener(clickEvent -> {
			if(clickEvent.getMouseEventDetails().isDoubleClick() || Page.getCurrent().getWebBrowser().isTouchDevice())
				UI.getCurrent().getNavigator().navigateTo(UIScopeUnderwritingViews.APPLICATION + "/applicationid=" + clickEvent.getItem().getId());
		});

    //format local date time
    Grid.Column commentDate = myApplicationGrid.getColumn("applicationDate");
		commentDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());
	}
}
