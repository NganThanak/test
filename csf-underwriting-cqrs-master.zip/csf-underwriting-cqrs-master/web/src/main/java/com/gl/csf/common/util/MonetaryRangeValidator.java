package com.gl.csf.common.util;

import com.vaadin.data.validator.RangeValidator;

import javax.money.MonetaryAmount;
import java.util.Comparator;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/08/2017.
 */
public class MonetaryRangeValidator extends RangeValidator<MonetaryAmount> {
  /**
   * Creates a new range validator of the given type. Passing null to either
   * {@code minValue} or {@code maxValue} means there is no limit in that
   * direction. Both limits may be null; this can be useful if the limits are
   * resolved programmatically. The result of passing null to {@code apply}
   * depends on the given comparator.
   *
   * @param errorMessage the error message to return if validation fails, not null
   * @param minValue     the least value of the accepted range or null for no limit
   * @param maxValue
   */
  public MonetaryRangeValidator(String errorMessage, MonetaryAmount minValue, MonetaryAmount maxValue) {
    super(errorMessage, Comparator.naturalOrder(), minValue, maxValue);
  }
}
