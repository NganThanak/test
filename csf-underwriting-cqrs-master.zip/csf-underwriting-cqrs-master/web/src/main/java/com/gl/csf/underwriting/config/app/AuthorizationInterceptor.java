package com.gl.csf.underwriting.config.app;

import java.util.List;
import java.util.function.BiFunction;
import org.axonframework.commandhandling.CommandMessage;
import org.axonframework.messaging.MessageDispatchInterceptor;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * Created by jerome on 10/20/17.
 */
public class AuthorizationInterceptor implements
    MessageDispatchInterceptor<CommandMessage<?>> {

  private final static Logger logger = LoggerFactory.getLogger(AuthorizationInterceptor.class);


  @Override
  public BiFunction<Integer, CommandMessage<?>, CommandMessage<?>> handle(
      List<CommandMessage<?>> messages) {
    return (index, message) -> {
      final String[] fullyQualifiedCommandName = message.getCommandName().replace("Command", "")
          .split("\\.");
      String commandName = fullyQualifiedCommandName[fullyQualifiedCommandName.length - 1];
      logger.info("Checking {} permission", commandName);
      Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
      if (authentication != null && authentication.getPrincipal() != null && authentication
          .getPrincipal() instanceof KeycloakPrincipal) {
        KeycloakSecurityContext keycloakSecurityContext = (((KeycloakPrincipal) authentication
            .getPrincipal()).getKeycloakSecurityContext());
        if (!keycloakSecurityContext.getAuthorizationContext().hasScopePermission(commandName)) {
          throw new IllegalStateException(
              commandName + " permission denied for user " + keycloakSecurityContext
                  .getIdToken().getName());

        } else {
          logger.info("{} permission granted for user {}", commandName,
              keycloakSecurityContext.getIdToken().getName());
        }
      } else {
        logger.info("No authenticated principal, bypass the permission check");
      }
      return message;
    };
  }
}
