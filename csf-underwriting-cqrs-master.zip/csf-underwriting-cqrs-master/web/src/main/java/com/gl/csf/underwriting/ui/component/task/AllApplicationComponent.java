package com.gl.csf.underwriting.ui.component.task;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.api.application.command.BookApplicationForUnderwritingCommand;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryDTO;
import com.gl.csf.underwriting.ui.dataprovider.AllApplicationDataProvider;
import com.gl.csf.underwriting.ui.dataprovider.ApplicationFilter;
import com.gl.csf.underwriting.ui.permission.Role;
import com.gl.csf.underwriting.ui.viewdeclaration.UIScopeUnderwritingViews;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.server.Page;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
public class AllApplicationComponent extends AllApplicationComponentDesign {

  private UnderwritingLoanApplicationSummaryDTO selectedApplication;

  @Inject
  public AllApplicationComponent(AllApplicationDataProvider allApplicationDataProvider, CommandGateway commandGateway, VaadinSecurity vaadinSecurity) {
    Window popupWindow = createWindow(UI.getCurrent(), commandGateway, vaadinSecurity);

    ConfigurableFilterDataProvider<UnderwritingLoanApplicationSummaryDTO, Void, ApplicationFilter> configurableFilterDataProvider =
            allApplicationDataProvider.withConfigurableFilter();

    configurableFilterDataProvider.setFilter(new ApplicationFilter(vaadinSecurity.getAuthentication().getName(), getRole(vaadinSecurity)));

    homeGrid.setDataProvider(configurableFilterDataProvider);
    homeGrid.addItemClickListener(clickEvent -> {
      if (!popupWindow.isAttached() && (clickEvent.getMouseEventDetails().isDoubleClick() || Page.getCurrent().getWebBrowser().isTouchDevice())) {
        selectedApplication = clickEvent.getItem();
        UI.getCurrent().addWindow(popupWindow);
      }
    });

    //format local date time
    Grid.Column commentDate = homeGrid.getColumn("applicationDate");
    commentDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());
  }

  private Window createWindow(UI ui, CommandGateway commandGateway, VaadinSecurity vaadinSecurity){
    Window result = new Window();
    result.center();
    result.removeAllCloseShortcuts();
    result.setResizable(false);
    result.setClosable(false);
    result.setModal(true);
    result.setWidth(550, Unit.PIXELS);
    result.setHeight(370, Unit.PIXELS);

    TaskAssignmentConfirmationComponent taskAssignmentConfirmationComponent = new TaskAssignmentConfirmationComponent();
    taskAssignmentConfirmationComponent.setListener(new TaskAssignmentConfirmationComponent.TaskAssignmentConfirmationComponentListener() {
      @Override
      public void onClosed() {
        result.close();
      }

      @Override
      public void onNoButtonClicked() {
        result.close();
      }

      @Override
      public void onYesButtonClicked() {
        commandGateway.sendAndWait(new BookApplicationForUnderwritingCommand(selectedApplication.getId(), getRole(vaadinSecurity)));
        result.close();
        ui.getNavigator().navigateTo(UIScopeUnderwritingViews.APPLICATION + "/applicationid=" + selectedApplication.getId());
      }
    });

    result.setContent(taskAssignmentConfirmationComponent);

    return result;
  }

  private String getRole(VaadinSecurity vaadinSecurity){
    String role;
    if(vaadinSecurity.hasAuthority(Role.FIELDCHECKER)){
      role = Role.FIELDCHECKER;
    } else if (vaadinSecurity.hasAuthorities(Role.JUNIOR_UNDERWRITER)){
      role = Role.JUNIOR_UNDERWRITER;
    } else if (vaadinSecurity.hasAuthorities(Role.SENIOR_UNDERWRITER)){
      role = Role.SENIOR_UNDERWRITER;
    } else {
      throw new IllegalArgumentException("Couldn't find any supported role");
    }

    return role;
  }
}
