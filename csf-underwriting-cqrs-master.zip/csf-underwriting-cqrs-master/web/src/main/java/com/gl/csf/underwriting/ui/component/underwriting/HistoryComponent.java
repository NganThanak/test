package com.gl.csf.underwriting.ui.component.underwriting;

import com.gl.csf.common.OffsetPageRequest;
import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Label;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import javax.inject.Inject;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;


/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
public class HistoryComponent extends HistoryComponentDesign {

  private String applicationId;

  @Inject
  public HistoryComponent(HistoryRepository repository){

    historyGrid.setDataProvider(new AbstractBackEndDataProvider<HistoryDTO, String>() {
      @Override
      protected Stream<HistoryDTO> fetchFromBackEnd(Query<HistoryDTO, String> query) {
        if(applicationId == null)
          return Stream.empty();

        Pageable pageable = new OffsetPageRequest(query.getOffset(), query.getLimit(), new Sort(Sort.Direction.DESC, "occurredSince"));
        return StreamSupport.stream(repository.findAllByApplicationId(pageable, applicationId).spliterator(), true);
      }

      @Override
      protected int sizeInBackEnd(Query<HistoryDTO, String> query) {
        if(applicationId == null)
          return 0;

        return Math.toIntExact(repository.countAllByApplicationId(applicationId));
      }
    });

    //format local date time
    Grid.Column commentDate = historyGrid.getColumn("occurredSince");
    commentDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());

    //customer history grid
    historyGrid.addComponentColumn(HistoryDTO -> {
      CssLayout component = new CssLayout();
      component.setWidth(100, Unit.PERCENTAGE);
      component.setHeight(90, Unit.PIXELS);
      component.setStyleName("history-description-label");

      Label descriptionLabel = new Label(HistoryDTO.getDescription());
      descriptionLabel.setWidth(100, Unit.PERCENTAGE);
      descriptionLabel.setHeightUndefined();
      component.addComponent(descriptionLabel);

      return component;
    }).setCaption("Description");
  }

  public void setApplicationId(String applicationId){
    this.applicationId = applicationId;
    historyGrid.getDataProvider().refreshAll();
  }
}
