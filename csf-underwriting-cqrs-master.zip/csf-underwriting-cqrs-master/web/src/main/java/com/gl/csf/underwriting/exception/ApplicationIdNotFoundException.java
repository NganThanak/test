package com.gl.csf.underwriting.exception;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 04/10/2017.
 */
public class ApplicationIdNotFoundException extends RuntimeException {
  public ApplicationIdNotFoundException(String message){
    super(message);
  }

  public ApplicationIdNotFoundException(String message, Throwable throwable){
    super(message, throwable);
  }
}
