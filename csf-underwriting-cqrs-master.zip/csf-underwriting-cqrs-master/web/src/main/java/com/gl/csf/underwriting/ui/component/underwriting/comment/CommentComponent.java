package com.gl.csf.underwriting.ui.component.underwriting.comment;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.query.application.underwriting.comment.CommentDTO;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 07/10/2017.
 */
public class CommentComponent extends CommentComponentDesign {

  public CommentComponent(CommentDTO comment){
    this.comment.setValue(comment.getDescription());
    this.commentedBy.setValue(comment.getUsername());
    this.commentedDate.setValue(comment.getCommentedDate().format(LocalDateTimeFormat.createDateTimeformatter()));
  }
}
