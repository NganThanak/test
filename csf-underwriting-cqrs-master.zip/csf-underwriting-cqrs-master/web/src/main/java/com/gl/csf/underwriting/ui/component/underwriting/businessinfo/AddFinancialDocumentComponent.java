package com.gl.csf.underwriting.ui.component.underwriting.businessinfo;

import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.command.AddFinancialDocumentCommand;
import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.service.DocumentService;
import com.gl.csf.underwriting.ui.component.common.FileUploadComponentListener;
import com.gl.csf.underwriting.ui.component.common.FileUploadResult;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Notification;
import org.apache.http.entity.ContentType;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 04/10/2017.
 */
@SpringComponent
@UIScope
public class AddFinancialDocumentComponent extends AddFinancialDocumentComponentDesign {
  public interface AddFinancialDocumentComponentListener{
    void onClosed();
    void onCancel();
    void onSave();
  }

  private Logger logger = LoggerFactory.getLogger(AddFinancialDocumentComponent.class);
  private AddFinancialDocumentComponentListener listener;
  private String applicationId;

  @Inject
  public AddFinancialDocumentComponent(CommandGateway commandGateway, DocumentService documentService, VaadinSecurity vaadinSecurity){
    closeButton.addClickListener(event -> {
      if(listener != null)
        listener.onClosed();
    });
    buttonCancel.addClickListener(event -> {
      if(listener != null)
        listener.onCancel();
    });
    buttonAdd.addClickListener(event -> {
      if(listener!=null)
        listener.onSave();
    });

    fileUploadComponent.setFileUploadComponentListener(new FileUploadComponentListener() {
      @Override
      public void uploadStarted() {
        buttonAdd.setEnabled(false);
      }

      @Override
      public void uploadFinished() {
        buttonAdd.setEnabled(true);
      }
    });

    buttonAdd.addClickListener(event -> {
      for (FileUploadResult fileUploadResult : fileUploadComponent.getFileUploadResults()) {

        // TODO: error should be handled more appropriately
        if (fileUploadResult.hasError())
          continue;

        // Save to minio
        try {
          DocumentDescriptor documentDescriptor = documentService.uploadDocument(fileUploadResult.getFilename(), applicationId,
                  fileUploadResult.getByteArrayInputStream(), ContentType.APPLICATION_OCTET_STREAM.toString());

          FinancialDocumentDTO financialDocumentDTO = new FinancialDocumentDTO();
          financialDocumentDTO.setAttachment(fileUploadResult.getFilename());
          financialDocumentDTO.setComment(textAreaComment.getValue());
          financialDocumentDTO.setUploadBy(vaadinSecurity.getAuthentication().getName());
          financialDocumentDTO.setDescriptor(documentDescriptor);

          // Send command
          commandGateway.sendAndWait(new AddFinancialDocumentCommand(applicationId, financialDocumentDTO));
          textAreaComment.clear();
        } catch (Exception e) {
          Notification.show("Failed to uploaded document", Notification.Type.ERROR_MESSAGE);
          logger.error("Failed to uploaded document", e);
        }
      }

      // Once uploaded the files, clear the upload results to release byte array content
      fileUploadComponent.clearUploadResults();
    });
  }

  void setListener(AddFinancialDocumentComponentListener listener) {
    this.listener = listener;
  }

  void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
  }
}
