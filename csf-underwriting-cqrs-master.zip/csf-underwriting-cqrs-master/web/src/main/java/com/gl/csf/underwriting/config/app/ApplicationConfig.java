package com.gl.csf.underwriting.config.app;


import com.gl.csf.underwriting.core.application.LoanApplication;
import com.gl.csf.underwriting.core.application.LoanApplicationCommandHandler;
import com.gl.csf.underwriting.core.application.UnderwritingSaga;
import com.gl.csf.underwriting.core.service.ApplicationReferenceService;
import java.util.Locale;
import javax.inject.Inject;

import com.gl.csf.underwriting.service.LoanProductTemplateService;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.config.EventHandlingConfiguration;
import org.axonframework.config.SagaConfiguration;
import org.axonframework.messaging.interceptors.BeanValidationInterceptor;
import org.axonframework.spring.config.AxonConfiguration;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

/**
 * @author Sereysopheak
 */
@Configuration
@PropertySource("classpath:rest-endpoints.properties")
@EnableBinding(Source.class)
public class ApplicationConfig {

  @Bean
  public ResourceBundleMessageSource messageSource() {
    ResourceBundleMessageSource source = new ResourceBundleMessageSource();
    source.setBasenames("i18n/messages");
    source.setDefaultEncoding("UTF-8");
    return source;
  }

  @Bean
  public LocaleResolver localeResolver() {
    SessionLocaleResolver slr = new SessionLocaleResolver();
    slr.setDefaultLocale(new Locale("en"));
    return slr;
  }

  @Bean
  @Inject
  public LoanApplicationCommandHandler applicationCommandHandler(
          AxonConfiguration axonConfiguration,
          ApplicationReferenceService applicationReferenceService, LoanProductTemplateService loanProductTemplateService) {
    return new LoanApplicationCommandHandler(axonConfiguration.repository(LoanApplication.class),
        applicationReferenceService, loanProductTemplateService);
  }

  @Inject
  public void configure(SimpleCommandBus simpleCommandBus) {
    simpleCommandBus.registerDispatchInterceptor(new BeanValidationInterceptor<>());
    simpleCommandBus.registerDispatchInterceptor(new AuthenticationInterceptor());
    // We disable this interceptor for now as all permissions haven't been setup yet in Keycloak
    //simpleCommandBus.registerDispatchInterceptor(new AuthorizationInterceptor());
  }

  @Bean
  public SagaConfiguration underwritingSagaConfiguration() {
    return SagaConfiguration.trackingSagaManager(UnderwritingSaga.class);
  }

  @Inject
  public void configure(EventHandlingConfiguration eventHandlingConfiguration) {
    eventHandlingConfiguration
        .registerTrackingProcessor("com.gl.csf.underwriting.query.application.messaging");
  }


  @Bean
  @Inject
  public TopicExchange loanApplicationTopic(
      @Value("${spring.cloud.stream.bindings.output.destination}") String exchangeName) {
    return new TopicExchange(exchangeName, true, false);
  }


}