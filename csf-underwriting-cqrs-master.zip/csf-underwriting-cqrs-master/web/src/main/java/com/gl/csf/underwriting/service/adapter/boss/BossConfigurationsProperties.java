package com.gl.csf.underwriting.service.adapter.boss;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.validation.Valid;

/**
 * Created by jerome on 9/29/17.
 */
@ConfigurationProperties(prefix = "boss")
@Configuration
@Data
public class BossConfigurationsProperties {

  @Valid
  private Credentials credentials;
  private String endpoint;

  @Data
  public static class Credentials {

    @NotEmpty
    private String user;
    @NotEmpty
    private String password;
  }
}
