package com.gl.csf.underwriting.service.adapter.boss;

import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import com.gl.csf.underwriting.common.model.businessinfo.Business;
import com.gl.csf.underwriting.query.application.underwriting.salesitem.SalesItemDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/14/2017.
 */
@Service
public class BossService {
  private final RestTemplate restTemplate;
  private final MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;
  private final String endpoint;

  private final static Logger logger = LoggerFactory.getLogger(BossService.class);

  @Inject
  public BossService(BossConfigurationsProperties bossConfigurationsProperties, MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter) {
    this.restTemplate = new RestTemplateBuilder()
            .basicAuthorization(bossConfigurationsProperties.getCredentials().getUser(),
                    bossConfigurationsProperties.getCredentials().getPassword()).build();
    this.endpoint = bossConfigurationsProperties.getEndpoint();
    this.mappingJackson2HttpMessageConverter = mappingJackson2HttpMessageConverter;

    restTemplate.getMessageConverters().add(0, mappingJackson2HttpMessageConverter);
  }

  public Optional<Business> getBusinessInformation(String businessId) {
    Objects.requireNonNull(businessId);
    try {
      return Optional.of(restTemplate.getForObject(endpoint + "/{businessId}", Business.class, businessId));
    } catch (NotFoundException e) {
      logger.info("businessId: " + businessId + " can't be found in B.O.S.S", e);
      return Optional.empty();
    }
  }

  public List<Branch> getBranchByBusinessId(String businessId){
    Objects.requireNonNull(businessId);
    try{
      return restTemplate.exchange(endpoint + "/" + businessId+"/branches", HttpMethod.GET, null,
              new ParameterizedTypeReference<List<Branch>>(){}).getBody();
    }
    catch (NotFoundException ex){
      logger.info("businessId: " + businessId + " can't be found in B.O.S.S", ex);
      return new ArrayList<>();
    }
  }

  public List<SalesItemDTO> getSaleItemHistoryByBranch(String businessId, String branchId, String startDate, String endDate, int offset, int limit){
    Objects.requireNonNull(businessId);
    Objects.requireNonNull(branchId);
    Objects.requireNonNull(startDate);
    Objects.requireNonNull(endDate);

    Map<String, Object> response = new HashMap<>();

    try{
      return restTemplate.exchange(endpoint + "/" + businessId + "/sales?branchIds=" + branchId +
                      "&start_date=" + startDate + "&end_date=" + endDate + "&offset=" + offset + "&limit=" + limit, HttpMethod.GET, null,
              new ParameterizedTypeReference<List<SalesItemDTO>>(){}).getBody();
    }
    catch (NotFoundException ex){
      logger.info("businessId: " + businessId + " and branchId: " + branchId + " cannot be found in B.O.S.S", ex);
      return new ArrayList<>();
    }
  }

  public int getTotalRow(String businessId, String branchId, String startDate, String endDate){
    Objects.requireNonNull(businessId);
    Objects.requireNonNull(branchId);
    Objects.requireNonNull(startDate);
    Objects.requireNonNull(endDate);

    try{
      ResponseEntity<Object> responseEntity = restTemplate.exchange(endpoint + "/" + businessId + "/sales?branchIds=" + branchId +
              "&start_date=" + startDate + "&end_date=" + endDate , HttpMethod.GET, null, Object.class);
      HttpHeaders headers = responseEntity.getHeaders();
      return Integer.parseInt(headers.get("x-total-count").get(0));
    }
    catch (NotFoundException ex){
      logger.info("businessId: " + businessId + " and branchId: " + branchId + " cannot be found in B.O.S.S", ex);
      return 0;
    }
  }
}
