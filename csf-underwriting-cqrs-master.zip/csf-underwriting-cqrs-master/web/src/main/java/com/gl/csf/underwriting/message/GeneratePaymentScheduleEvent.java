package com.gl.csf.underwriting.message;

import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.ui.util.paymentschedule.Installment;
import com.vaadin.data.provider.ListDataProvider;
import lombok.Value;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 12/14/2017.
 */
@Value
public class GeneratePaymentScheduleEvent {
  ProductInformationDTO productInformationDTO;
  List<Installment> installments;
  ListDataProvider<Installment> installmentDataProvider;
}
