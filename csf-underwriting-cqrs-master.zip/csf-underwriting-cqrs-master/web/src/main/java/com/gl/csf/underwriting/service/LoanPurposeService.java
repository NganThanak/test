package com.gl.csf.underwriting.service;

import com.gl.csf.underwriting.common.model.loanpurpose.LoanPurpose;
import com.gl.csf.underwriting.config.Authenticated;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 12/12/2017.
 */
@Service
public class LoanPurposeService {
  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public LoanPurposeService(@Value("${endpoints.rest.parameter.purposes}") String baseUrl,
                            @Authenticated(Authenticated.With.CLIENT_CREDENTIALS) RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  public List<LoanPurpose> getAllLoanPurposes() {
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
            new ParameterizedTypeReference<List<LoanPurpose>>() {
            }).getBody();
  }

  public Optional<LoanPurpose> getLoanPurposeById(UUID loanPurposeId) {
    Objects.requireNonNull(loanPurposeId);

    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/" + loanPurposeId, HttpMethod.GET, null,
              new ParameterizedTypeReference<LoanPurpose>() {
              }).getBody());
    } catch (NotFoundException e) {
      return Optional.empty();
    }
  }
}
