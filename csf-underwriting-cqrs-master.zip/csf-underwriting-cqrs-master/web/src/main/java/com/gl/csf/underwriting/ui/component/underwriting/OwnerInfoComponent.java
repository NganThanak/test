package com.gl.csf.underwriting.ui.component.underwriting;

import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdateBankInformationCommand;
import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdateGuarantorBusinessInfoCommand;
import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdateGuarantorCommand;
import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdatePersonalInformationCommand;
import com.gl.csf.underwriting.common.model.bank.BankAccountType;
import com.gl.csf.underwriting.common.model.owerinfo.BankInformationDTO;
import com.gl.csf.underwriting.common.model.owerinfo.GuarantorBusinessInfoDTO;
import com.gl.csf.underwriting.common.model.owerinfo.GuarantorDTO;
import com.gl.csf.underwriting.common.model.owerinfo.PersonalInformationDTO;
import com.gl.csf.underwriting.message.CustomerInfoUpdatedEvent;
import com.gl.csf.underwriting.message.SessionScopeBus;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.BankInfoRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.GuarantorBusinessRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.GuarantorRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.PersonalInfoRepository;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Button;
import org.axonframework.commandhandling.gateway.CommandGateway;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Objects;

import static java.time.temporal.ChronoUnit.YEARS;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/31/2017.
 */
@SpringComponent
@UIScope
public class OwnerInfoComponent extends OwnerInfoComponentDesign {
  private final Binder<PersonalInformationDTO> personalInfoBinder;
  private final Binder<BankInformationDTO> bankInfoBinder;
  private final Binder<GuarantorDTO> guarantorBinder;
  private final Binder<GuarantorBusinessInfoDTO> guarantorBusinessBinder;
  private final PersonalInfoRepository personalInfoRepository;
  private final BankInfoRepository bankInfoRepository;
  private final GuarantorRepository guarantorRepository;
  private final GuarantorBusinessRepository guarantorBusinessRepository;
  private String applicationId;
  
  @Inject
  public OwnerInfoComponent(SessionScopeBus bus, CommandGateway commandGateway, PersonalInfoRepository personalInfoRepository, BankInfoRepository bankInfoRepository, GuarantorRepository guarantorRepository, GuarantorBusinessRepository guarantorBusinessRepository) {
    this.personalInfoRepository = personalInfoRepository;
    this.bankInfoRepository = bankInfoRepository;
    this.guarantorRepository = guarantorRepository;
    this.guarantorBusinessRepository = guarantorBusinessRepository;

    personalInfoBinder = createPersonalInfoBinder();
    bankInfoBinder = createBankInfoBinder();
    guarantorBinder = createGuarantorBinder();
    guarantorBusinessBinder = createBusinessInfoBinder();

    personalInfoBinder.addStatusChangeListener(event -> personalInfoComponent.buttonSave.setEnabled(event.getBinder().isValid()));
    bankInfoBinder.addStatusChangeListener(event -> personalInfoComponent.buttonSaveBankInfo.setEnabled(event.getBinder().isValid()));
    guarantorBinder.addStatusChangeListener(event -> guarantorComponent.buttonSave.setEnabled(event.getBinder().isValid()));
    personalInfoComponent.radioButtonBankAccountType.setDataProvider(new ListDataProvider<>(Arrays.asList(BankAccountType.values())));

    // save owner info
    personalInfoComponent.buttonSave.addClickListener(event -> {
      commandGateway.sendAndWait(new UpdatePersonalInformationCommand(personalInfoBinder.getBean().getApplicationId(), personalInfoBinder.getBean()));
      bus.post(new CustomerInfoUpdatedEvent()).now();
    });
    
    // save BankInfo
    personalInfoComponent.buttonSaveBankInfo.addClickListener(event -> {
      commandGateway.sendAndWait(new UpdateBankInformationCommand(bankInfoBinder.getBean().getApplicationId(), bankInfoBinder.getBean()));
    });
    
    // save guarantor info
    guarantorComponent.buttonSave.addClickListener(event -> {
      commandGateway.sendAndWait(new UpdateGuarantorCommand(guarantorBinder.getBean().getApplicationId(), guarantorBinder.getBean()));
    });

    // save guarantor business info
    guarantorComponent.buttonSaveBusiness.addClickListener(event -> {
      commandGateway.sendAndWait(new UpdateGuarantorBusinessInfoCommand(guarantorBusinessBinder.getBean().getApplicationId(), guarantorBusinessBinder.getBean()));
    });
    
    // cancel owner info
    personalInfoComponent.buttonEdit.addClickListener(event -> {
      if (personalInfoComponent.buttonEdit.getCaption().equalsIgnoreCase("Edit")){
        resetPersonalInfo();
      }
    });
    
    // cancel bankInfo
    personalInfoComponent.buttonEditBankInfo.addClickListener(event -> {
      if (personalInfoComponent.buttonEditBankInfo.getCaption().equalsIgnoreCase("Edit")){
        resetBankInfo();
      }
    });
    
    // cancel guarantor info
    guarantorComponent.buttonEdit.addClickListener(event -> {
      if (personalInfoComponent.buttonEdit.getCaption().equalsIgnoreCase("Edit")){
        resetGuarantorInfo();
      }
    });

    // cancel guarantor business info
    guarantorComponent.buttonEditBusiness.addClickListener(event -> {
      if (guarantorComponent.buttonEditBusiness.getCaption().equalsIgnoreCase("Edit")) {
        resetGuarantorBusinessInfo();
      }
    });
  }
  
  public PersonalInfoComponent getPersonalInfoComponent() {
	  return personalInfoComponent;
  }
  
  public GuarantorComponent getGuarantorComponent() {
	  return guarantorComponent;
  }
  
  public Button getPersonalInfoComponentSaveButton() {
	  return personalInfoComponent.buttonSave;
  }
  
  public Button getGuarantorComponentSaveButton() {
	  return guarantorComponent.buttonSave;
  }
  
  public Button getBankInfoSaveButton() {
	  return personalInfoComponent.buttonSaveBankInfo;
  }

  public void setApplicationId(String applicationId){
    this.applicationId = applicationId;
    updateBeans();
  }

  private void updateBeans(){
    Objects.requireNonNull(applicationId);
    personalInfoBinder.setBean(personalInfoRepository.findByApplicationId(applicationId));
    bankInfoBinder.setBean(bankInfoRepository.findByApplicationId(applicationId));
    guarantorBinder.setBean(guarantorRepository.findByApplicationId(applicationId));
    guarantorBusinessBinder.setBean(guarantorBusinessRepository.findByApplicationId(applicationId));
  }

  private Binder<PersonalInformationDTO> createPersonalInfoBinder(){
    Binder<PersonalInformationDTO> result = new BeanValidationBinder<>(PersonalInformationDTO.class);
    result.forField(personalInfoComponent.textFieldFullName).asRequired("Full name").bind("fullName");
    result.forField(personalInfoComponent.comboBoxGender).asRequired("Gender").bind("gender");
    result.forField(personalInfoComponent.dateFieldDOB).withValidator(dob -> YEARS.between(dob, LocalDate.now()) >= 18, "Age must be greater than 18.")
            .asRequired("Age must be greater than 18.").bind("dob");
    result.forField(personalInfoComponent.textFieldPhoneNumber).asRequired("Phone number").bind("phoneNumber");
    result.forField(personalInfoComponent.additionalPhoneNumberTextField1).bind("additionalPhoneNumber1");
    result.forField(personalInfoComponent.additionalPhoneNumberTextField2).bind("additionalPhoneNumber2");
    result.forField(personalInfoComponent.textFieldOwnerAddress).asRequired("Owner address").bind("ownerAddress.text");
    result.forField(personalInfoComponent.textFieldFatherName).asRequired("Father name").bind("fatherName");
    result.forField(personalInfoComponent.textFieldNRCID).asRequired("National ID").bind("nrcId");
    result.forField(personalInfoComponent.comboBoxState).asRequired("State").bind("ownerAddress.state");
    result.bind(personalInfoComponent.textFieldEmail,"email");
    result.forField(personalInfoComponent.comboBoxDistrict).asRequired("District").bind("ownerAddress.district");
    result.forField(personalInfoComponent.comboBoxTownship).asRequired("Township").bind("ownerAddress.township");
    return result;
  }

  private Binder<BankInformationDTO> createBankInfoBinder(){
    Binder<BankInformationDTO> result = new BeanValidationBinder<>(BankInformationDTO.class);
    result.forField(personalInfoComponent.textFieldBankHolderName).asRequired("Account name").bind("bankAccount.accountName");
    result.forField(personalInfoComponent.comboBoxBankName).asRequired("Bank name").bind("bankAccount.bank");
    result.forField(personalInfoComponent.textFieldBankNumber).asRequired("Bank number").bind("bankAccount.accountNumber");
    result.forField(personalInfoComponent.radioButtonBankAccountType).asRequired("Account type").bind("bankAccountType");
    result.bind(personalInfoComponent.textFieldDescription,"description");
    return result;
  }

  private boolean validateDate(LocalDate dob){
    if(dob==null) return true;
    if(YEARS.between(dob, LocalDate.now()) >= 18) return true;
        return false;
  }

  private Binder<GuarantorDTO> createGuarantorBinder(){
    Binder<GuarantorDTO> result = new BeanValidationBinder<>(GuarantorDTO.class);
    result.forField(guarantorComponent.textFieldFullName).asRequired("Full name").bind("fullName");
    result.forField(guarantorComponent.comboBoxGender).asRequired("Gender").bind("gender");
    result.forField(guarantorComponent.dateFieldDOB).withValidator(dob -> validateDate(dob), "Age must be greater than 18.").asRequired("Age must be greater than 18.")
            .bind("dob");
    result.forField(guarantorComponent.textFieldPhoneNumber).asRequired("Phone number").asRequired("Phone number").bind("phoneNumber");
    result.forField(guarantorComponent.textFieldOwnerAddress).asRequired("Owner address").bind("ownerAddress.text");
    result.forField(guarantorComponent.textFieldNRCID).asRequired("National ID").bind("nrcId");
    result.forField(guarantorComponent.comboBoxState).asRequired("State").bind("ownerAddress.state");
    result.bind(guarantorComponent.textFieldEmail,"email");
    result.forField(guarantorComponent.comboBoxDistrict).asRequired("District").bind("ownerAddress.district");
    result.forField(guarantorComponent.comboBoxTownship).asRequired("Township").bind("ownerAddress.township");
    result.forField(guarantorComponent.comboBoxRelationship).asRequired("relationship").bind("relationship");
    return result;
  }

  private Binder<GuarantorBusinessInfoDTO> createBusinessInfoBinder() {
    Binder<GuarantorBusinessInfoDTO> result = new BeanValidationBinder<>(GuarantorBusinessInfoDTO.class);
    result.forField(guarantorComponent.textFieldPhoneNumberBusiness).bind("businessInfoPhoneNumber");
    result.forField(guarantorComponent.textFieldOwnerAddressBusiness).bind("businessInfoAddress.text");
    result.forField(guarantorComponent.comboBoxStateBusiness).bind("businessInfoAddress.state");
    result.forField(guarantorComponent.comboBoxDistrictBusiness).bind("businessInfoAddress.district");
    result.forField(guarantorComponent.comboBoxTownshipBusiness).bind("businessInfoAddress.township");
    return result;
  }
  
  private void resetPersonalInfo(){
    personalInfoBinder.setBean(personalInfoRepository.findByApplicationId(applicationId));
  }
  
  private void resetBankInfo(){
    bankInfoBinder.setBean(bankInfoRepository.findByApplicationId(applicationId));
  }

  private void resetGuarantorBusinessInfo() {
    guarantorBusinessBinder.setBean(guarantorBusinessRepository.findByApplicationId(applicationId));
  }

  private void resetGuarantorInfo(){
    guarantorBinder.setBean(guarantorRepository.findByApplicationId(applicationId));
  }
  
  
}
