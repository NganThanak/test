package com.gl.csf.underwriting.ui.dataprovider;

import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryDTO;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;

import javax.inject.Inject;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/31/2017.
 */
@SpringComponent
public class AllApplicationDataProvider extends AbstractBackEndDataProvider<UnderwritingLoanApplicationSummaryDTO, ApplicationFilter> {

  private final UnderwritingLoanApplicationSummaryRepository underwritingLoanApplicationSummaryRepository;

  @Inject
  public AllApplicationDataProvider(UnderwritingLoanApplicationSummaryRepository underwritingLoanApplicationSummaryRepository) {
    this.underwritingLoanApplicationSummaryRepository = underwritingLoanApplicationSummaryRepository;
  }

  @Override
  protected Stream<UnderwritingLoanApplicationSummaryDTO> fetchFromBackEnd(Query<UnderwritingLoanApplicationSummaryDTO, ApplicationFilter> query) {
    Optional<ApplicationFilter> optionalFilter = query.getFilter();

    if(optionalFilter.isPresent()){
      ApplicationFilter filter = optionalFilter.get();
      return underwritingLoanApplicationSummaryRepository.findPublicApplicationByRole(filter.getRole()).parallelStream();
    } else {
      return Stream.empty();
    }
  }

  @Override
  protected int sizeInBackEnd(Query<UnderwritingLoanApplicationSummaryDTO, ApplicationFilter> query) {
    Optional<ApplicationFilter> optionalFilter = query.getFilter();

    if(optionalFilter.isPresent()){
      ApplicationFilter filter = optionalFilter.get();
      return underwritingLoanApplicationSummaryRepository.countPublicApplicationByRole(filter.getRole());
    } else {
      return 0;
    }
  }
}
