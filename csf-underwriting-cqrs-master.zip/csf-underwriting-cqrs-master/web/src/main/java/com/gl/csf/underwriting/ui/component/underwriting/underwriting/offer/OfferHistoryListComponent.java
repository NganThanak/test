package com.gl.csf.underwriting.ui.component.underwriting.underwriting.offer;

import com.gl.csf.underwriting.common.model.offeramount.Offer;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/13/2017.
 */
public class OfferHistoryListComponent extends OfferHistoryListComponentDesign {

  public OfferHistoryListComponent(Offer offer){
    NumberFormat formatter = new DecimalFormat("###,###.##");
    formatter.setMaximumFractionDigits(3);

    String pattern = "dd/MM/yyyy HH:mm a";
    DateTimeFormatter format =  DateTimeFormatter.ofPattern(pattern);

    nameLabel.setValue(offer.getUnderwriter());
    rateDateLabel.setValue("rate on " + format.format(offer.getRatedDate()));
    offerAmountLable.setValue("Amount offer: " + formatter.format(offer.getOfferAmount().getNumber().doubleValueExact()) + " Kyat");
    reasonLabel.setValue(offer.getOfferReason());
  }
}
