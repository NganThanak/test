package com.gl.csf.underwriting.ui.component.underwriting.underwriting.creditscore;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.query.application.underwriting.creditscore.CreditScoreDTO;
import com.gl.csf.underwriting.api.document.CreditScoreDocument;
import com.gl.csf.underwriting.service.DocumentService;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.ui.Button;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/30/2017.
 */
public class CreditScoreHistoryListComponent extends CreditScoreHistoryListComponentDesign {

  private final static Logger logger = LoggerFactory.getLogger(CreditScoreHistoryListComponent.class);

  public CreditScoreHistoryListComponent(CreditScoreDTO creditScoreDTO, DocumentService documentService){

    nameRater.setValue(creditScoreDTO.getUnderwriter());
    rateDate.setValue(creditScoreDTO.getRateOn().format(LocalDateTimeFormat.createDateTimeformatter()));
    gradeScore.setValue(creditScoreDTO.getScore());
    rateComment.setValue(creditScoreDTO.getReason());
    for(CreditScoreDocument document: creditScoreDTO.getCreditScoreDocumentDTOS()){
      Button downloadAttactmentButton = new Button(document.getFileName());
      downloadAttactmentButton.setStyleName("btn-download-credit-score");
      attachmentContainerLayout.addComponent(downloadAttactmentButton);

        StreamResource streamResource;
        try {
           streamResource = new StreamResource((StreamResource.StreamSource) () -> {
            try {
              return documentService.downloadDocument(new DocumentDescriptor(document.getDocumentDescriptor().getDocumentId()
                      , "", creditScoreDTO.getApplicationId()));
            } catch (Exception ex) {
              logger.error(ex.toString());
              throw new RuntimeException(ex);
            }
          }, document.getFileName());
          FileDownloader fileDownloader = new FileDownloader(streamResource);
          fileDownloader.extend(downloadAttactmentButton);
        } catch (Exception err) {
          logger.error(err.toString());
        }
    }
  }
}
