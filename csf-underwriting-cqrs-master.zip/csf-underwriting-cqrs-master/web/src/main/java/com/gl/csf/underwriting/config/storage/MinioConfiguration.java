package com.gl.csf.underwriting.config.storage;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Created by jerome on 9/18/17.
 */
@ConfigurationProperties(prefix = "minio")
@Configuration
@Data
public class MinioConfiguration {

  @NotEmpty
  private String endpoint;
  @NotEmpty
  private String accessKey;
  @NotEmpty
  private String secretKey;


}
