package com.gl.csf.underwriting.message;

import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/13/2017.
 */
@Value
public class BranchDetailDeletedEvent {
  Branch branch;
}
