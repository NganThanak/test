package com.gl.csf.underwriting.ui.component.task;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.Assignee;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryDTO;
import com.gl.csf.underwriting.query.application.underwriting.productinfo.ProductInformationRepository;
import com.gl.csf.underwriting.ui.dataprovider.ApplicationFilter;
import com.gl.csf.underwriting.ui.dataprovider.PendingApplicationDataProvider;
import com.gl.csf.underwriting.ui.permission.Role;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/20/2017.
 */
@SpringComponent
@UIScope
public class PendingApplicationComponent extends PendingApplicationComponentDesign{
  /**
   * 
  */
  private static final long serialVersionUID = 839087064367138914L;
  
  private static final String EMPTY = "";
  private static final String ASSIGNEE = "Assignee";
  private static final String TERM = "Term";
  private static final String LOAN_AMOUNT = "Loan amount(MMK)";
  private static final DecimalFormat MONEY_FORMATTER = new DecimalFormat("#,##0");
  
  private final ProductInformationRepository productInformationRepository;

  @Inject
  public PendingApplicationComponent(PendingApplicationDataProvider pendingApplicationDataProvider, CommandGateway commandGateway, VaadinSecurity vaadinSecurity, ProductInformationRepository productInformationRepository) {
    this.productInformationRepository = productInformationRepository;

    homeGrid.addColumn(loanAppSummaryDTO -> {
      Optional<ProductInformationDTO> productInformationDTOptional = productInformationRepository.findByApplicationId(loanAppSummaryDTO.getId());
      if (productInformationDTOptional.isPresent())
        return productInformationDTOptional.get().getTerm();
      return 0;
    }).setCaption(TERM);

    homeGrid.addColumn(loanAppSummaryDTO -> {
      Optional<ProductInformationDTO> productInformationDTOptional = productInformationRepository.findByApplicationId(loanAppSummaryDTO.getId());
      return productInformationDTOptional.isPresent() ?
    		  MONEY_FORMATTER.format(productInformationDTOptional.get().getLoanAmount().getNumber().doubleValue()) : EMPTY;
    }).setCaption(LOAN_AMOUNT);

    homeGrid.addColumn(loanAppSummaryDTO -> {
      Assignee assignee = loanAppSummaryDTO.getAssignees().stream().findFirst().orElse(null);
      return assignee != null ? assignee.toString() : EMPTY;
    }).setCaption(ASSIGNEE);

    ConfigurableFilterDataProvider<UnderwritingLoanApplicationSummaryDTO, Void, ApplicationFilter> configurableFilterDataProvider =
            pendingApplicationDataProvider.withConfigurableFilter();
    configurableFilterDataProvider.setFilter(new ApplicationFilter(vaadinSecurity.getAuthentication().getName(), getRole(vaadinSecurity)));
    homeGrid.setDataProvider(configurableFilterDataProvider);
    Grid.Column applicationDate = homeGrid.getColumn("applicationDate");
    applicationDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());
  }
  
  private String getRole(VaadinSecurity vaadinSecurity){
    String role;
    if(vaadinSecurity.hasAuthority(Role.FIELDCHECKER)){
      role = Role.FIELDCHECKER;
    } else if (vaadinSecurity.hasAuthorities(Role.JUNIOR_UNDERWRITER)){
      role = Role.JUNIOR_UNDERWRITER;
    } else if (vaadinSecurity.hasAuthorities(Role.SENIOR_UNDERWRITER)){
      role = Role.SENIOR_UNDERWRITER;
    } else {
      throw new IllegalArgumentException("Couldn't find any supported role");
    }
    
    return role;
  }
}
