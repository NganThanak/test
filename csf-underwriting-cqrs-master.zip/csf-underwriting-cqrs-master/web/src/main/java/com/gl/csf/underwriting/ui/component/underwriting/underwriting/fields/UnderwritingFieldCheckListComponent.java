package com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields;

import com.gl.csf.common.util.ConfirmDialogUtil;
import com.gl.csf.underwriting.api.application.command.RequestFieldCheckCommand;
import com.gl.csf.underwriting.message.BusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.message.SessionScopeBus;
import com.gl.csf.underwriting.message.UnderwritingFieldDocumentUpdatedEvent;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.comment.CommentFieldCheckRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.document.UnderwritingFieldDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.UnderwritingFieldRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldhistory.UnderwritingFieldContentHistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import com.gl.csf.underwriting.service.DocumentService;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by p.ly on 9/28/2017.
 */
@UIScope
@SpringComponent
public class UnderwritingFieldCheckListComponent extends UnderwritingFieldCheckListComponentDesign {
	
  /**
   * 
  */
  private static final long serialVersionUID = -1478421594887391768L;
	
  private static final String APPLICANT_NRC_ID = "Applicant NRC ID";
  private static final String GUARANTOR_NRC_ID = "Guarantor NRC ID";
  private static final String BANK_ACCOUNT = "Bank account";
  

  private final I18nMessage i18nMessage;
  private final VaadinSecurity vaadinSecurity;
  private final CommentFieldCheckRepository commentFieldCheckRepository;
  private DocumentService documentService;
  private CommandGateway commandGateway;
  private UnderwritingFieldDocumentRepository repository;
  private UnderwritingFieldRepository underwritingFieldRepository;
  private UnderwritingFieldContentHistoryRepository historyRepository;
  private String applicationId;
  private Set<UnderwritingFieldCheckListItemComponent> underwritingFieldCheckListItemComponents = new HashSet<>();
  
  private UnderwritingFieldCheckListItemComponent applicantFieldCheckItem;
  private UnderwritingFieldCheckListItemComponent guarantorFieldCheckItem;
  private UnderwritingFieldCheckListItemComponent bankFieldCheckItem;

  @Inject
  public UnderwritingFieldCheckListComponent(SessionScopeBus bus, DocumentService documentService, UnderwritingFieldRepository underwritingFieldRepository,
                                             CommandGateway commandGateway, UnderwritingFieldDocumentRepository repository,
                                             UnderwritingFieldContentHistoryRepository historyRepository, VaadinSecurity vaadinSecurity, CommentFieldCheckRepository commentFieldCheckRepository, I18nMessage i18nMessage) {
    this.commandGateway = commandGateway;
    this.repository = repository;
    this.documentService = documentService;
    this.underwritingFieldRepository = underwritingFieldRepository;
    this.historyRepository = historyRepository;
    this.vaadinSecurity = vaadinSecurity;
    this.commentFieldCheckRepository = commentFieldCheckRepository;
    this.i18nMessage = i18nMessage;

    //TODO will enable as soon as
    makeRequestButton.setVisible(false);
    makeRequestButton.addClickListener(event -> {
      if (selectedUnderwritingFieldsId().isEmpty()) {
        UI.getCurrent().addWindow(ConfirmDialogUtil.createSaveMessage("<p>" + ("No field check was selected to make request.") + "</p>"));
        return;
      }
      try {
        commandGateway.sendAndWait(new RequestFieldCheckCommand(applicationId, selectedUnderwritingFieldsId()));
        bus.post(new BusinessInfoUpdatedEvent()).now();
        UI.getCurrent().addWindow(ConfirmDialogUtil.createSaveMessage("<p>" + ("Requested field check successful!") + "</p>"));
      } catch (Exception e) {
        Notification.show(e.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
      }
    });
  }

  private Collection<String> selectedUnderwritingFieldsId() {
    return underwritingFieldCheckListItemComponents.stream().filter(UnderwritingFieldCheckListItemComponent::isFieldCheckRequested).map(UnderwritingFieldCheckListItemComponent::underwritingFieldId).collect(Collectors.toList());
  }

  void loadFieldCheckList(String applicationId) {
    content.removeAllComponents();
    underwritingFieldCheckListItemComponents.clear();
    this.applicationId = applicationId;
    createUnderwritingFields(applicationId);
  }

  private void createUnderwritingFields(String applicationId) {
    underwritingFieldRepository.findByApplicationIdOrderByIsMandatoryDescNameAsc(applicationId)
            .forEach(underwritingFieldDTO -> {
              UnderwritingFieldCheckListItemComponent underwritingFieldCheckListItemComponent = new UnderwritingFieldCheckListItemComponent(documentService, commandGateway,
                      underwritingFieldDTO, repository, historyRepository, commentFieldCheckRepository, vaadinSecurity, this::onDocumentUpdated);
              if (APPLICANT_NRC_ID.equals(underwritingFieldDTO.getName())) {
                  applicantFieldCheckItem = underwritingFieldCheckListItemComponent;
            	  underwritingFieldCheckListItemComponents.add(applicantFieldCheckItem);
              } else if (BANK_ACCOUNT.equals(underwritingFieldDTO.getName())) {
                  bankFieldCheckItem = underwritingFieldCheckListItemComponent;
            	  underwritingFieldCheckListItemComponents.add(bankFieldCheckItem);
              } else if (GUARANTOR_NRC_ID.equals(underwritingFieldDTO.getName())) {
                  guarantorFieldCheckItem = underwritingFieldCheckListItemComponent;
            	  underwritingFieldCheckListItemComponents.add(guarantorFieldCheckItem);
              } else {
            	  underwritingFieldCheckListItemComponents.add(underwritingFieldCheckListItemComponent);
              }

              int countingDocument = Math.toIntExact(repository.countByDocumentDescriptorApplicationIdAndUnderwritingFieldIdAndIsSubmitted(underwritingFieldDTO.getApplicationId(), underwritingFieldDTO.getUnderwritingFieldId(), true));
              //check is field mandatory
              if (underwritingFieldDTO.isMandatory()) {
            	  if (APPLICANT_NRC_ID.equals(underwritingFieldDTO.getName())) {
                      content.addTab(applicantFieldCheckItem, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument)).setStyleName("text-accordion-tab");
            	  } else if (BANK_ACCOUNT.equals(underwritingFieldDTO.getName())) {
            		  content.addTab(bankFieldCheckItem, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument)).setStyleName("text-accordion-tab");
            	  } else if (GUARANTOR_NRC_ID.equals(underwritingFieldDTO.getName())) {
            		  content.addTab(guarantorFieldCheckItem, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument)).setStyleName("text-accordion-tab");
            	  }
            	  else {
            		  content.addTab(underwritingFieldCheckListItemComponent, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument)).setStyleName("text-accordion-tab");
            	  }
              } else {
            	  if (APPLICANT_NRC_ID.equals(underwritingFieldDTO.getName())) {
                      content.addTab(applicantFieldCheckItem, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument));
            	  } else if (BANK_ACCOUNT.equals(underwritingFieldDTO.getName())) {
            		  content.addTab(bankFieldCheckItem, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument));
            	  } else if (GUARANTOR_NRC_ID.equals(underwritingFieldDTO.getName())) {
            		  content.addTab(guarantorFieldCheckItem, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument));
            	  } else {
            		  content.addTab(underwritingFieldCheckListItemComponent, underwritingFieldDTO.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument));
            	  }
             }	
  		});
  }

  //update accordion caption
  private void onDocumentUpdated(UnderwritingFieldDocumentUpdatedEvent e) {
    int countingDocument = Math.toIntExact(repository.countByDocumentDescriptorApplicationIdAndUnderwritingFieldIdAndIsSubmitted(applicationId, e.getUnderwritingFieldId(), true));
    content.getTab(content.getSelectedTab()).setCaption(e.getName() + "  |  " + i18nMessage.getMessage("count.document", countingDocument));
  }

  public UnderwritingFieldCheckListItemComponent getApplicantFieldCheckItem() {
	return applicantFieldCheckItem;
  }

  public UnderwritingFieldCheckListItemComponent getGuarantorFieldCheckItem() {
	return guarantorFieldCheckItem;
  }

  public UnderwritingFieldCheckListItemComponent getBankFieldCheckItem() {
	return bankFieldCheckItem;
  }
  
}


