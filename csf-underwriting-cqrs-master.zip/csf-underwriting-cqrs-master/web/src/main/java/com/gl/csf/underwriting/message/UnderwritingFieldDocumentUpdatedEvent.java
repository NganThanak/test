package com.gl.csf.underwriting.message;

import lombok.Value;

/**
 * Created by p.ly on 12/5/2017.
 */
@Value
public class UnderwritingFieldDocumentUpdatedEvent {
  String name;
  String underwritingFieldId;
}
