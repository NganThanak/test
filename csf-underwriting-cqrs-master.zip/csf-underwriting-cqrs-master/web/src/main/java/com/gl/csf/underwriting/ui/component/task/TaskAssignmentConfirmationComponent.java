package com.gl.csf.underwriting.ui.component.task;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 03/10/2017.
 */
public class TaskAssignmentConfirmationComponent extends TaskAssignmentConfirmationComponentDesign {
  public interface TaskAssignmentConfirmationComponentListener{
    void onClosed();
    void onNoButtonClicked();
    void onYesButtonClicked();
  }

  private TaskAssignmentConfirmationComponentListener listener;

  TaskAssignmentConfirmationComponent(){
    closeButton.addClickListener(e -> {
      if(listener != null)
        listener.onClosed();
    });
    noButton.addClickListener(e -> {
      if(listener != null)
        listener.onNoButtonClicked();
    });

    yesButton.addClickListener(e -> {
      if(listener != null)
        listener.onYesButtonClicked();
    });
  }

  public TaskAssignmentConfirmationComponentListener getListener() {
    return listener;
  }

  void setListener(TaskAssignmentConfirmationComponentListener listener) {
    this.listener = listener;
  }
}
