package com.gl.csf.underwriting.ui.component.underwriting.fieldcheck;

import com.gl.csf.common.util.ConfirmDialogUtil;
import com.gl.csf.underwriting.api.application.command.SubmitFieldCheckingResultCommand;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.FieldCheckItemDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.FieldCheckItemDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field.FieldCheckItemRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceRepository;
import com.gl.csf.underwriting.service.DocumentService;
import com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields.UnderwritingFieldReferenceComponent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 22, 2017.
 */
@UIScope
@SpringComponent
public class FieldCheckComponent extends FieldCheckComponentDesign {
  private final Logger logger = LoggerFactory.getLogger(FieldCheckComponent.class);
  private final FieldCheckItemRepository fieldCheckItemRepository;
  private final DocumentService documentService;
  private final CommandGateway commandGateway;
  private final FieldCheckItemDocumentRepository fieldCheckItemDocumentRepository;
  private final FieldCheckReferenceRepository fieldCheckReferenceRepository;
  private final FieldCheckReferenceDocumentRepository documentRepository;
  private final VaadinSecurity vaadinSecurity;
  private String applicationId;

  @Inject
  public FieldCheckComponent(FieldCheckItemRepository fieldCheckItemRepository, CommandGateway commandGateway, DocumentService documentService, FieldCheckItemDocumentRepository fieldCheckItemDocumentRepository, FieldCheckReferenceRepository fieldCheckReferenceRepository, FieldCheckReferenceDocumentRepository documentRepository, VaadinSecurity vaadinSecurity) {
    this.fieldCheckItemRepository = fieldCheckItemRepository;
    this.commandGateway = commandGateway;
    this.documentService = documentService;
    this.fieldCheckItemDocumentRepository = fieldCheckItemDocumentRepository;
    this.fieldCheckReferenceRepository = fieldCheckReferenceRepository;
    this.documentRepository = documentRepository;
    this.vaadinSecurity = vaadinSecurity;

    buttonSubmit.addClickListener(e -> {
      try {
        commandGateway.sendAndWait(new SubmitFieldCheckingResultCommand(this.applicationId));
        Window window = ConfirmDialogUtil.createSaveMessage("<p>" + ("Field Checks have been submitted successfully.") + "</p>");
        UI.getCurrent().addWindow(window);
        window.addCloseListener(closeEvent -> {
          getUI().getNavigator().navigateTo("");
        });
      } catch (IllegalStateException ex) {
        Notification.show("Can't submit field checking result: " + ex.getMessage(), Notification.Type.ERROR_MESSAGE);
        logger.error("Can't submit field checking result", ex);
      }
    });
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
    fetchFieldCheckData();
    fetchFieldCheckHistoryData();
  }

  private void fetchFieldCheckData() {
    accordionFieldCheckReference.removeAllComponents();
    List<FieldCheckItemDTO> fieldCheckItemDTOS = fieldCheckItemRepository.findAllByApplicationIdAndIsSubmitted(applicationId, false);
    buttonSubmit.setEnabled(!fieldCheckItemDTOS.isEmpty());

    fieldCheckItemDTOS.forEach(fieldCheckItem -> accordionFieldCheckReference.addTab(
            new FieldCheckItemComponent(documentService, commandGateway, fieldCheckItem, fieldCheckItemDocumentRepository, vaadinSecurity), fieldCheckItem.getName()));
  }

  private void fetchFieldCheckHistoryData() {
    content.removeAllComponents();

    Map<LocalDateTime, List<FieldCheckReferenceDTO>> tempFieldCheckReferenceGroupByFieldCheckId = fieldCheckReferenceRepository.findByApplicationIdOrderBySubmittedDateDesc(applicationId)
            .stream().collect(Collectors.groupingBy(FieldCheckReferenceDTO::getSubmittedDate));

    Map<LocalDateTime, List<FieldCheckReferenceDTO>> fieldCheckReferenceGroupByFieldCheckId = new TreeMap<>(Collections.reverseOrder());
    fieldCheckReferenceGroupByFieldCheckId.putAll(tempFieldCheckReferenceGroupByFieldCheckId);

    if (fieldCheckReferenceGroupByFieldCheckId.isEmpty()) {
      Label noHistory = new Label("There is no history references submitted to underwriters yet.");
      noHistory.addStyleName("no-history");
      content.addComponent(noHistory);
    }

    fieldCheckReferenceGroupByFieldCheckId.values().forEach(fieldCheckReferenceList -> {
      content.addComponent(new UnderwritingFieldReferenceComponent(documentRepository, fieldCheckReferenceList, documentService));
    });
  }
}
