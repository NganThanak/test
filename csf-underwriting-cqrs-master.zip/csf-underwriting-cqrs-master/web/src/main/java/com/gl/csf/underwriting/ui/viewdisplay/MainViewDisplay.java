package com.gl.csf.underwriting.ui.viewdisplay;

import com.gl.csf.underwriting.ui.component.common.MainMenuBar;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewDisplay;
import com.vaadin.spring.annotation.SpringViewDisplay;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.VerticalLayout;
import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 8/15/2017.
 */

@SpringViewDisplay
public class MainViewDisplay extends CustomComponent implements ViewDisplay {

  private final VerticalLayout content = new VerticalLayout();

  @Inject
  public MainViewDisplay(MainMenuBar mainMenuBar) {

    final VerticalLayout root = new VerticalLayout();
    root.setSpacing(false);
    root.setSizeFull();
    root.setMargin(false);

    root.addComponent(mainMenuBar);
    root.addComponent(content);
    setCompositionRoot(root);
  }

  @Override
  public void showView(View view) {
    content.removeAllComponents();
    content.setSpacing(false);
    content.setSizeFull();
    content.setMargin(false);
    content.addComponent((Component) view);
  }
}