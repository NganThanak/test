package com.gl.csf.underwriting.ui.dataprovider;

import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryDTO;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary.UnderwritingLoanApplicationSummaryRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;

import javax.inject.Inject;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/9/2017.
 */
@SpringComponent
public class MyApplicationDataProvider extends AbstractBackEndDataProvider<UnderwritingLoanApplicationSummaryDTO, ApplicationFilter> {

  private final UnderwritingLoanApplicationSummaryRepository underwritingLoanApplicationSummaryRepository;

  @Inject
  public MyApplicationDataProvider(UnderwritingLoanApplicationSummaryRepository underwritingLoanApplicationSummaryRepository) {
    this.underwritingLoanApplicationSummaryRepository = underwritingLoanApplicationSummaryRepository;
  }

  @Override
  protected Stream<UnderwritingLoanApplicationSummaryDTO> fetchFromBackEnd(Query<UnderwritingLoanApplicationSummaryDTO, ApplicationFilter> query) {
    Optional<ApplicationFilter> optionalFilter = query.getFilter();

    if(optionalFilter.isPresent()){
      ApplicationFilter filter = optionalFilter.get();
      return underwritingLoanApplicationSummaryRepository.findPrivateApplicationByUsername(filter.getRole(), filter.getUsername()).parallelStream();
    } else {
      return Stream.empty();
    }
  }

  @Override
  protected int sizeInBackEnd(Query<UnderwritingLoanApplicationSummaryDTO, ApplicationFilter> query) {
    Optional<ApplicationFilter> optionalFilter = query.getFilter();
    if(optionalFilter.isPresent()){
      ApplicationFilter filter = optionalFilter.get();
      return underwritingLoanApplicationSummaryRepository.countPrivateApplicationByUsername(filter.getRole(), filter.getUsername());
    } else {
      return 0;
    }
  }
}