package com.gl.csf.underwriting.ui.util.jackson;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gl.csf.underwriting.config.jersey.JerseyConfig;
import org.springframework.stereotype.Component;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

/**
 * Created by jerome on 13/01/2016.
 */
@Provider
@Component
public class ObjectMapperProvider implements ContextResolver<ObjectMapper> {

  private ObjectMapper defaultObjectMapper = JerseyConfig.createDefaultMapper();

  @Override
  public ObjectMapper getContext(Class<?> type) {
    return defaultObjectMapper;
  }
}