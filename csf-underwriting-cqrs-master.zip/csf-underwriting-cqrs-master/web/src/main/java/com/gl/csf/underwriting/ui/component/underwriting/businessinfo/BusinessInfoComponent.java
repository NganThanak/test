package com.gl.csf.underwriting.ui.component.underwriting.businessinfo;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.api.application.businessinfo.branch.command.AddBranchCommand;
import com.gl.csf.underwriting.api.application.businessinfo.business.command.UpdateBusinessInfoCommand;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.command.DeleteFinancialDocumentCommand;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.command.UpdateFinancialDocumentCommand;
import com.gl.csf.underwriting.common.model.address.BusinessType;
import com.gl.csf.underwriting.common.model.address.District;
import com.gl.csf.underwriting.common.model.address.State;
import com.gl.csf.underwriting.common.model.address.Township;
import com.gl.csf.underwriting.common.model.businessinfo.*;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.config.storage.MinioConfiguration;
import com.gl.csf.underwriting.message.BranchDetailDeletedEvent;
import com.gl.csf.underwriting.message.BusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.message.ProductInformationUpdatedEvent;
import com.gl.csf.underwriting.message.SessionScopeBus;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.branch.BranchRepository;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.business.BusinessRepository;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialdocument.FinancialDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement.FinancialStatementDTO;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement.FinancialStatementRepository;
import com.gl.csf.underwriting.query.application.underwriting.productinfo.ProductInformationRepository;
import com.gl.csf.underwriting.query.application.util.CurrencyUtil;
import com.gl.csf.underwriting.service.*;
import com.gl.csf.underwriting.service.adapter.boss.BossService;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.gl.csf.underwriting.ui.component.underwriting.ProductInfoComponent;
import com.gl.csf.underwriting.ui.dataprovider.SalesDataProvider;
import com.gl.csf.underwriting.ui.permission.Role;
import com.gl.csf.underwriting.ui.util.NumeralFieldFormatterUtils;
import com.gl.csf.underwriting.ui.util.StringToMonetaryAmountConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import com.vaadin.ui.themes.ValoTheme;
import net.engio.mbassy.listener.Enveloped;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.subscription.MessageEnvelope;
import org.apache.commons.io.FilenameUtils;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.javamoney.moneta.Money;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 8/16/2017.
 */
@SpringComponent
@UIScope
public class BusinessInfoComponent extends BusinessInfoComponentDesign {

  private final DocumentService documentService;
  private final MinioConfiguration minioConfiguration;
  private final CommandGateway commandGateway;
  private final AddFinancialDocumentComponent addFinancialDocumentComponent;
  private final TownshipService townshipService;
  private final StateService stateService;
  private final DistrictService districtService;
  private final Binder<Business> businessBinder = new BeanValidationBinder<>(Business.class);
  private final FinancialStatementRepository financialStatementRepository;
  private final BusinessRepository businessRepository;
  private final BranchRepository branchRepository;
  private final FinancialDocumentRepository financialDocumentRepository;
  private final Binder<FinancialStatementDTO> financialStatementBinder = new BeanValidationBinder<>(FinancialStatementDTO.class);
  private final Accordion branchAccordion = new Accordion();
  private final BossService bossService;
  private final SalesDataProvider salesDataProvider;
  private final List<BranchDTO> mainBranchNames = new ArrayList<>();
  private final VaadinSecurity vaadinSecurity;
  private final BusinessTypeService businessTypeService;
  private final LoanPurposeService loanPurposeService;
  private final ProductInformationRepository productInformationRepository;
  private final LoanProductTemplateService loanProductTemplateService;
  private final InterestRateService interestRateService;
  private final String OTHER = "other";
  private Logger logger = LoggerFactory.getLogger(BusinessInfoComponent.class);
  private String applicationId;
  private Business currentBusiness;
  private SessionScopeBus bus;
  private Set<String> imageType = new HashSet<>(Arrays.asList("JPG", "PNG", "JPEG"));

  @Inject
  public BusinessInfoComponent(SessionScopeBus bus, DocumentService documentService, MinioConfiguration minioConfiguration,
                               FinancialDocumentRepository financialDocumentRepository, CommandGateway commandGateway,
                               AddFinancialDocumentComponent addFinancialDocumentComponent, TownshipService townshipService,
                               StateService stateService, DistrictService districtService,
                               FinancialStatementRepository financialStatementRepository, BusinessRepository businessRepository,
                               BranchRepository branchRepository, BossService bossService, SalesDataProvider salesDataProvider,
                               VaadinSecurity vaadinSecurity, BusinessTypeService businessTypeService, LoanProductTemplateService loanProductTemplateService,
                               ProductInformationRepository productInformationRepository, LoanPurposeService loanPurposeService, InterestRateService interestRateService) {
    this.documentService = documentService;
    this.minioConfiguration = minioConfiguration;
    this.commandGateway = commandGateway;
    this.addFinancialDocumentComponent = addFinancialDocumentComponent;
    this.townshipService = townshipService;
    this.stateService = stateService;
    this.districtService = districtService;
    this.financialStatementRepository = financialStatementRepository;
    this.businessRepository = businessRepository;
    this.branchRepository = branchRepository;
    this.financialDocumentRepository = financialDocumentRepository;
    this.bossService = bossService;
    this.salesDataProvider = salesDataProvider;
    this.vaadinSecurity = vaadinSecurity;
    this.bus = bus;
    this.businessTypeService = businessTypeService;
    this.loanPurposeService = loanPurposeService;
    this.productInformationRepository = productInformationRepository;
    this.loanProductTemplateService = loanProductTemplateService;
    this.interestRateService = interestRateService;
  
    setGridFinancialDataProvider();
    initGridEditor();

    // add payment simulation component
    paymentSimulationLayout.addComponent(new PaymentSimulationComponent(bus));

    NumeralFieldFormatterUtils.formatNumeralTextField(revenueTextField, expenseTextField, marginTextField,
            staffExpenseTextField, netProfitTextField);

    saveButton.setEnabled(false);

    buttonRefreshData.addClickListener(event -> {
      Optional<Business> businessOptional = businessRepository.findFirstByApplicationId(applicationId);
      Business business;
      if (businessOptional.isPresent()) {
        business = businessOptional.get();
        // check if this customer from BOSS or not
        if (business.getBusinessId() != null && business.getIsBoss()) {

          List<Branch> branches = this.bossService.getBranchByBusinessId(business.getBusinessId());
          for (Branch branch : branches) {

            if (!branchRepository.findFirstByBranchId(branch.getBranchId()).isPresent()) {
              branch.setId(UUID.randomUUID().toString());
              branch.setApplicationId(business.getApplicationId());
              branch.setIsBoss(true);

              if (branch.getIsActive().equals("1"))
                branch.setBranchStatus(BranchStatus.ACTIVE);
              else
                branch.setBranchStatus(BranchStatus.INACTIVE);
              branch.setNumberOfStaff(0);
              branch.setOpenSince(LocalDate.now());
              branch.setLocationOwner(LocationOwner.OWNER);

              // ========== Will update after B.O.S.S provide data ============
              branch.setExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
              branch.setMargin(Money.of(0, CurrencyUtil.MMK_CURRENCY));
              branch.setNetProfit(Money.of(0, CurrencyUtil.MMK_CURRENCY));
              branch.setStaffExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
              branch.setRentAmount(Money.of(0, CurrencyUtil.MMK_CURRENCY));
              branch.setOtherExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
              branch.setRevenue(Money.of(0, CurrencyUtil.MMK_CURRENCY));
              branch.setAddress(" ");

              createBranchDetailComponent(branch);

              // Will update after B.O.S.S provide data
              branch.setDistrict(new District());
              branch.setState(new State());
              branch.setTownship(new Township());

              commandGateway.send(new AddBranchCommand(applicationId, branch));
            }
          }
          financialStatementBinder.setBean(financialStatementRepository
                  .findOne(financialStatementBinder.getBean().getApplicationId()));
        }
      }
    });

    Window subWindow = new Window();
    addFinancialDocumentComponent.setListener(new AddFinancialDocumentComponent.AddFinancialDocumentComponentListener() {
      @Override
      public void onClosed() {
        subWindow.close();
      }

      @Override
      public void onCancel() {
        subWindow.close();
      }

      @Override
      public void onSave() {
        subWindow.close();
        gridFinancialDocument.getDataProvider().refreshAll();
      }

    });

    buttonAddDocument.addClickListener(event -> {
      addFinancialDocumentComponent.fileUploadComponent.clearUploadResults();
      subWindow.setContent(addFinancialDocumentComponent);
      UI.getCurrent().addWindow(createSubWindow(subWindow));
    });

    saveBranchButton.addClickListener(e -> {
      subWindow.setContent(new AddNewBranchComponent(businessTypeService, subWindow, stateService::getAllStates
              , districtService::getDistrictsByState
              , townshipService::getTownships
              , this.commandGateway
              , this.applicationId
              , branch -> {
        BranchDetailComponent result = new BranchDetailComponent(businessTypeService, stateService::getAllStates
                , districtService::getDistrictsByState
                , townshipService::getTownships
                , this.commandGateway
                , branchRepository
                , updatedBranch -> {
          financialStatementBinder.setBean(financialStatementRepository
                  .findOne(financialStatementBinder.getBean().getApplicationId()));
          currentBusiness = businessRepository.findFirstByApplicationId(applicationId).get();
          Business clone = new Business();
          BeanUtils.copyProperties(currentBusiness, clone);
          bind(clone);
        }, vaadinSecurity
                , salesDataProvider, businessBinder.getBean(), this::onUpdatedBranchDetail);
        result.bind(branch);
        branchAccordion.addTab(result).setCaption(branch.getBranchName());
        branchAccordion.setSelectedTab(result);
        mainBranchNames.add(new BranchDTO(branch.getBranchId(), branch.getBranchName(), branch.getBusinessType(), branch.getBusinessTypeDescription()));

        mainBranchComboBox.setItems(mainBranchNames);

        financialStatementBinder.setBean(financialStatementRepository
                .findOne(financialStatementBinder.getBean().getApplicationId()));

        businessBinder.setBean(currentBusiness);

        mainBranchComboBox.setSelectedItem(currentBusiness.getMainBranch());
      }));
      Window window = displayConfigurationAddBranch(subWindow);
      Collection<Window> windowsList = UI.getCurrent().getWindows();
      if (windowsList.contains(window)) {
        window.attach();
      } else {
        UI.getCurrent().addWindow(window);
      }
    });

    editButton.addClickListener(e -> {
      if (editButton.getCaption().equalsIgnoreCase("Edit")) {
        saveButton.setVisible(true);
        editButton.setCaption("Cancel");
        enableBusinessInfoComponent(true);
        refreshMainBanchCombobox();
      } else {
        businessBinder.getBean().setApplicationId(this.applicationId);
        saveButton.setVisible(false);
        editButton.setCaption("Edit");
        saveButton.setVisible(false);
        enableBusinessInfoComponent(false);
        refreshMainBanchCombobox();
        reset();
      }
    });

    saveButton.addClickListener(e -> {
      editButton.setCaption("Edit");
      saveButton.setVisible(false);
      refreshBusinessTypeCombobox(businessBinder.getBean().getMainBranch().getBusinessType(),
              businessBinder.getBean().getMainBranch().getBusinessTypeDescription(), businessBinder.getBean().getMainBranch().getBranchName());
      commandGateway.sendAndWait(new UpdateBusinessInfoCommand(businessBinder.getBean().getApplicationId(), businessBinder.getBean()));
      bus.post(new BusinessInfoUpdatedEvent()).now();
      enableBusinessInfoComponent(false);
      BeanUtils.copyProperties(businessBinder.getBean(), currentBusiness);
    });

    businessBinder.addStatusChangeListener(e -> saveButton.setEnabled(e.getBinder().isValid()));

    //set permission for field checker
    if (vaadinSecurity.hasAuthority(Role.FIELDCHECKER)) {
      editButton.setVisible(false);
      saveBranchButton.setVisible(false);
      buttonAddDocument.setVisible(false);
    }
  }

  private void enableBusinessInfoComponent(boolean value) {
    businessIDTextField.setEnabled(value);
    businessNameTextField.setEnabled(value);
    mainBranchComboBox.setEnabled(value);
  }

  public void bind(Business business, FinancialStatementDTO financialStatement, List<Branch> branches) {
    businessBinder.setBean(business);
    financialStatementBinder.setBean(financialStatement);
    initializeBinder(businessBinder, financialStatementBinder, branches);
    // cache the current fetched value
    currentBusiness = business;
    // create clone to bind
    Business clone = new Business();
    BeanUtils.copyProperties(currentBusiness, clone);
    bind(clone);
  }

  private void renderListBranchDetail(List<Branch> branches) {
    for (Branch branch : branches) {
      BranchDTO branchDTO = new BranchDTO();
      branchDTO.setBranchId(branch.getBranchId());
      branchDTO.setBranchName(branch.getBranchName());
      branchDTO.setBusinessType(branch.getBusinessType());
      branchDTO.setBusinessTypeDescription(branch.getBusinessTypeDescription());
      mainBranchNames.add(branchDTO);
      createBranchDetailComponent(branch);
    }
  }

  private void initializeBinder(Binder<Business> businessBinder, Binder<FinancialStatementDTO> financialStatementBinder, List<Branch> branches) {
    Objects.requireNonNull(businessBinder);
    businessBinder.bind(businessIDTextField, "businessId");
    businessBinder.bind(businessNameTextField, "businessName");
    businessBinder.forField(mainBranchComboBox).asRequired("main branch cannot empty").bind("mainBranch");
    businessBinder.bind(businessTypeComboBox, "mainBranch.businessType");
    businessBinder.bind(otherBusinessType, "mainBranch.businessTypeDescription");

    branchAccordion.removeAllComponents();

    renderListBranchDetail(branches);

    mainBranchComboBox.setItems(mainBranchNames);

    financialStatementBinder.forField(totalBranchTextField)
            .withConverter(new StringToIntegerConverter("")).bind("totalBranch");
    financialStatementBinder.forField(revenueTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("revenue");
    financialStatementBinder.forField(expenseTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("expense");
    financialStatementBinder.forField(marginTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("margin");
    financialStatementBinder.forField(numberOfStaffTextField)
            .withConverter(new StringToIntegerConverter("")).bind("numberOfStaff");
    financialStatementBinder.forField(staffExpenseTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("staffExpense");
    financialStatementBinder.forField(netProfitTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("netProfit");
    financialStatementBinder.forField(totalRentAmountTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("totalRent");
    financialStatementBinder.forField(otherExpenseTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("otherExpense");
    financialStatementBinder.forField(financialRatioTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("financialRatio");
    financialStatementBinder.forField(financialRatioLowTextField)
            .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("financialRatioLow");
    branchVerticlLayout.addComponent(branchAccordion);
  }

  private void createBranchDetailComponent(Branch branch) {
    BranchDetailComponent result = new BranchDetailComponent(businessTypeService, stateService::getAllStates
            , districtService::getDistrictsByState
            , townshipService::getTownships
            , this.commandGateway
            , branchRepository
            , updatedBranch -> {
      refreshBusinessTypeCombobox(updatedBranch.getBusinessType(), updatedBranch.getBusinessTypeDescription(), updatedBranch.getBranchName());
      financialStatementBinder.setBean(financialStatementRepository
              .findOne(financialStatementBinder.getBean().getApplicationId()));
      currentBusiness = businessRepository.findFirstByApplicationId(applicationId).get();
      Business clone = new Business();
      BeanUtils.copyProperties(currentBusiness, clone);
      bind(clone);
    }
            , vaadinSecurity, salesDataProvider, businessBinder.getBean(), this::onUpdatedBranchDetail);
    result.bind(branch);
    branchAccordion.addTab(result).setCaption(branch.getBranchName());
  }

  private Window createSubWindow(Window result) {
    result.center();
    result.removeAllCloseShortcuts();
    result.setResizable(false);
    result.setClosable(false);
    result.setModal(true);
    result.setWidth(600, Unit.PIXELS);
    result.setHeight(620, Unit.PIXELS);
    return result;
  }

  private Window displayConfigurationAddBranch(Window window) {
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setSizeFull();
    return window;
  }

  private void reset() {
    Business clone = new Business();
    BeanUtils.copyProperties(currentBusiness, clone);
    bind(clone);
  }

  private void bind(Business business) {
    businessBinder.setBean(business);
  }

  private void refreshMainBanchCombobox() {
    mainBranchNames.clear();
    for (Branch br : branchRepository.findAllByApplicationId(this.applicationId)) {
      mainBranchNames.add(new BranchDTO(br.getBranchId(), br.getBranchName(), br.getBusinessType(), br.getBusinessTypeDescription()));
    }

    mainBranchComboBox.clear();
    mainBranchComboBox.setItems(mainBranchNames);

    currentBusiness = businessRepository.findFirstByApplicationId(applicationId).get();
    Business clone = new Business();
    BeanUtils.copyProperties(currentBusiness, clone);
    bind(clone);
  }

  private void refreshBusinessTypeCombobox(BusinessType businessType, String businessTypeDescription, String branchName) {
    if (businessBinder.getBean().getMainBranch().getBranchName() != null && branchName != null) {
      if (businessBinder.getBean().getMainBranch().getBranchName().equals(branchName)) {
        if (businessType != null) {
          if (businessType.getName() != null && OTHER.equalsIgnoreCase(businessType.getName())){
            otherBusinessType.setVisible(true);
            otherBusinessType.setValue(businessTypeDescription);
          }else
            otherBusinessType.setVisible(false);
          businessTypeComboBox.setValue(businessType);
        }
      }
    }
  }

  private void initGridEditor() {
    BeanValidationBinder<FinancialDocumentDTO> editorBinder = new BeanValidationBinder<>(FinancialDocumentDTO.class);
    gridFinancialDocument.getEditor().setBinder(editorBinder);

    TextField commentEditor = new TextField();
    Binder.Binding<FinancialDocumentDTO, String> commentBinding = editorBinder.bind(commentEditor, "comment");
    gridFinancialDocument.getColumn("comment").setEditorBinding(commentBinding);

    //format local date time
    Grid.Column commentDate = gridFinancialDocument.getColumn("dateTime");
    commentDate.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());

    gridFinancialDocument.getEditor().setEnabled(true);
    gridFinancialDocument.getEditor().addSaveListener(e -> {
      commandGateway.send(new UpdateFinancialDocumentCommand(e.getBean().getDescriptor().getApplicationId(), e.getBean()));
      setGridFinancialDataProvider();
    });

    gridFinancialDocument.addComponentColumn(financialDocumentDTO -> {
      CssLayout cssLayout = new CssLayout();
      String fileExtension = FilenameUtils.getExtension(financialDocumentDTO.getAttachment());
      if (imageType.contains(fileExtension.toUpperCase())) {
        Button previewButton = new Button();
        previewButton.setIcon(VaadinIcons.EYE);
        previewButton.setStyleName(ValoTheme.BUTTON_LINK);
        previewButton.addClickListener(event -> {
          try {
            StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
              try {
                return documentService.downloadDocument(new DocumentDescriptor(financialDocumentDTO.getDescriptor().getDocumentId(), minioConfiguration.getEndpoint(),
                        financialDocumentDTO.getDescriptor().getApplicationId()));
              } catch (Exception e) {
                logger.error("error when download financial document", e);
                throw new RuntimeException(e);
              }
            }, financialDocumentDTO.getAttachment());
            Window window = new Window();
            window.center();
            window.setResizable(false);
            window.setContent(new Image(financialDocumentDTO.getAttachment(), streamResource));
            UI.getCurrent().addWindow(window);
          } catch (Exception e) {
            logger.error("error when download financial document", e);
            throw new RuntimeException(e);
          }
        });
        cssLayout.addComponent(previewButton);
      }

      Button button = new Button("");
      button.setIcon(VaadinIcons.DOWNLOAD);
      button.setStyleName(ValoTheme.BUTTON_LINK);
      try {
        StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
          try {
            return documentService.downloadDocument(new DocumentDescriptor(financialDocumentDTO.getDescriptor().getDocumentId(),
                    minioConfiguration.getEndpoint(), financialDocumentDTO.getDescriptor().getApplicationId()));
          } catch (Exception e) {
            logger.error("error when download financial document", e);
            throw new RuntimeException(e);
          }
        }, financialDocumentDTO.getAttachment());

        FileDownloader fileDownloader = new FileDownloader(streamResource);
        fileDownloader.extend(button);
      } catch (Exception e) {
        logger.error("error when download financial document", e);
        throw new RuntimeException(e);
      }

      Button deleteButton = new Button("");
      deleteButton.setIcon(VaadinIcons.TRASH);
      deleteButton.setStyleName(ValoTheme.BUTTON_LINK);
      deleteButton.addClickListener(event -> {

        ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
        Window window = confirmationMessage.displayConfiguration();
        confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
          @Override
          public void onClosed() {
            window.close();
          }

          @Override
          public void onNoButtonClicked() {
            window.close();
          }

          @Override
          public void onYesButtonClicked() {
            try {
              documentService.deleteDocument(new DocumentDescriptor(financialDocumentDTO.getDescriptor().getDocumentId(),
                      minioConfiguration.getEndpoint(), financialDocumentDTO.getDescriptor().getApplicationId()));
              commandGateway.send(new DeleteFinancialDocumentCommand(financialDocumentDTO.getDescriptor().getApplicationId(), financialDocumentDTO.getDescriptor()));
              gridFinancialDocument.getDataProvider().refreshAll();
            } catch (Exception e) {
              logger.error("Error when deleting a financial document", e);
            }
            window.close();
          }
        });
        window.setContent(confirmationMessage);
        UI.getCurrent().addWindow(window);

      });
      cssLayout.addComponent(button);
      cssLayout.addComponent(deleteButton);
      return cssLayout;
    }).setCaption("Action");
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
    mainBranchNames.clear();
    Optional<Business> businessOptional = businessRepository.findFirstByApplicationId(applicationId);
    if (businessOptional.isPresent()) {
      Business business = businessRepository.findFirstByApplicationId(applicationId).get();
      bind(business, financialStatementRepository.findOne(applicationId), branchRepository.findAllByApplicationId(applicationId));
      otherBusinessType.setVisible(business.getMainBranch() != null && business.getMainBranch().getBusinessType() != null &&
              business.getMainBranch().getBusinessType().getName().equalsIgnoreCase(OTHER));
    } else {
      Business business = new Business();
      business.setApplicationId(applicationId);
      bind(business
              , financialStatementRepository.findOne(applicationId)
              , branchRepository.findAllByApplicationId(applicationId));
    }

    addFinancialDocumentComponent.setApplicationId(applicationId);


    // add product information component
    productInfoLayout.removeAllComponents();
    productInfoLayout.addComponent(new ProductInfoComponent(bus, this.loanProductTemplateService, commandGateway,
            productInformationRepository, vaadinSecurity, financialStatementRepository, loanPurposeService, applicationId, this.interestRateService));
  }

  private void setGridFinancialDataProvider() {
    gridFinancialDocument.setDataProvider(new AbstractBackEndDataProvider<FinancialDocumentDTO, DocumentDescriptor>() {
      @Override
      protected Stream<FinancialDocumentDTO> fetchFromBackEnd(Query<FinancialDocumentDTO, DocumentDescriptor> query) {
        return financialDocumentRepository.findByDescriptor_ApplicationId(applicationId).parallelStream();
      }

      @Override
      protected int sizeInBackEnd(Query<FinancialDocumentDTO, DocumentDescriptor> query) {
        return financialDocumentRepository.countByDescriptor_ApplicationId(applicationId);
      }
    });
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  private void updateData() {
    financialStatementBinder.setBean(financialStatementRepository.findOne(financialStatementBinder.getBean().getApplicationId()));
  }

  @Handler
  @Enveloped(messages = {ProductInformationUpdatedEvent.class})
  public void handle(MessageEnvelope envelope) {
    updateData();
  }

  //update accordion caption
  private void onUpdatedBranchDetail(BranchDetailDeletedEvent e) {
    branchAccordion.removeComponent(branchAccordion.getSelectedTab());
    financialStatementBinder.setBean(financialStatementRepository
            .findOne(financialStatementBinder.getBean().getApplicationId()));
    currentBusiness = businessRepository.findFirstByApplicationId(applicationId).get();
    Business clone = new Business();
    BeanUtils.copyProperties(currentBusiness, clone);
    bind(clone);
  }
}
