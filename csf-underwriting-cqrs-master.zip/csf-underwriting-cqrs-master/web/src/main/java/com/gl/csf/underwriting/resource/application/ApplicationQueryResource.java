package com.gl.csf.underwriting.resource.application;

import com.gl.csf.underwriting.query.application.customer.loanapplication.LoanApplicationDTO;
import com.gl.csf.underwriting.query.application.customer.loanapplicationsummary.LoanApplicationSummaryDTO;
import com.gl.csf.underwriting.service.ApplicationQueryService;
import liquibase.util.StringUtils;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/18/2017.
 */
@Component
@Path("")
public class ApplicationQueryResource {

  private final ApplicationQueryService applicationQueryService;

  public ApplicationQueryResource(ApplicationQueryService applicationQueryService) {
    this.applicationQueryService = applicationQueryService;
  }

  @GET
  @Path("/applications/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response getApplicationById(@PathParam("id") String id){
    com.gl.csf.underwriting.dto.LoanApplicationDTO applicationQueryDTO = new com.gl.csf.underwriting.dto.LoanApplicationDTO();
    Optional<LoanApplicationDTO> loanApplicationQuery = applicationQueryService.getApplicationById(id);
    if(!loanApplicationQuery.isPresent())
      throw new NotFoundException();
    applicationQueryDTO.setApplication(loanApplicationQuery.get().getApplication());
    applicationQueryDTO.setCustomerApplicationStatus(loanApplicationQuery.get().getCustomerApplicationStatus());
    return Response.ok(applicationQueryDTO).build();
  }

  @GET
  @Path("/applications")
  @Produces(MediaType.APPLICATION_JSON)
  public Response getApplicationsByCustomer(@QueryParam("customerusername") String customerId){
    List<LoanApplicationSummaryDTO> loanApplicationLists = applicationQueryService.getApplicationListByCustomer(customerId);
    return Response.ok().entity(loanApplicationLists).build();
  }

  @GET
  @Path("/createapplicationpermission")
  @Produces(MediaType.APPLICATION_JSON)
  public Response createApplicationPermission(@QueryParam("customerusername") String customerId, @Context HttpHeaders headers){
    String language = headers.getHeaderString("Accept-Language");
    Locale locale = (StringUtils.isEmpty(language)) ? Locale.ENGLISH : new Locale(language);
    return Response.ok().entity(applicationQueryService.getCreateApplicationPermission(customerId, locale)).build();
  }
}
