package com.gl.csf.underwriting.ui.permission;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 10/6/2017.
 */
public class Role {
  public static final String FIELDCHECKER = "ROLE_FIELD_CHECKER";
 	public static final String JUNIOR_UNDERWRITER = "ROLE_JUNIOR_UNDERWRITER";
 	public static final String SENIOR_UNDERWRITER = "ROLE_SENIOR_UNDERWRITER";
	public static final String ADMINISTRATOR = "ROLE_ADMINISTRATOR";
	public static final String CUSTOMER = "ROLE_CUSTOMER";
}
