package com.gl.csf.underwriting.dto;

import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.common.model.customer.CustomerApplicationStatus;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/29/2017.
 */

/*Application detail for customer ui*/
public class LoanApplicationDTO {

  private Application application;
  private CustomerApplicationStatus customerApplicationStatus;

  public Application getApplication() {
    return application;
  }

  public void setApplication(Application application) {
    this.application = application;
  }

  public CustomerApplicationStatus getCustomerApplicationStatus() {
    return customerApplicationStatus;
  }

  public void setCustomerApplicationStatus(CustomerApplicationStatus customerApplicationStatus) {
    this.customerApplicationStatus = customerApplicationStatus;
  }
}
