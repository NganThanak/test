package com.gl.csf.underwriting.ui.component.underwriting.applicationsummary;

import com.gl.csf.underwriting.api.application.command.DeclineApplicationCommand;
import com.gl.csf.underwriting.api.application.command.RecommendApplicationApprovalCommand;
import com.gl.csf.underwriting.api.application.command.RecommendApplicationRejectionCommand;
import com.gl.csf.underwriting.common.model.businessinfo.Business;
import com.gl.csf.underwriting.common.model.owerinfo.BankInformationDTO;
import com.gl.csf.underwriting.common.model.owerinfo.GuarantorDTO;
import com.gl.csf.underwriting.common.model.owerinfo.PersonalInformationDTO;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.config.jersey.CurrencyUtil;
import com.gl.csf.underwriting.message.*;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.business.BusinessRepository;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationheader.LoanApplicationHeaderDTO;
import com.gl.csf.underwriting.query.application.underwriting.loanapplicationheader.LoanApplicationHeaderRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.BankInfoRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.GuarantorRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.PersonalInfoRepository;
import com.gl.csf.underwriting.query.application.underwriting.productinfo.ProductInformationRepository;
import com.gl.csf.underwriting.ui.component.common.ConfirmationComponent;
import com.gl.csf.underwriting.ui.component.common.ConfirmationMessageComponent;
import com.gl.csf.underwriting.ui.permission.Role;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import liquibase.util.StringUtils;
import net.engio.mbassy.listener.Enveloped;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;
import net.engio.mbassy.subscription.MessageEnvelope;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/6/2017.
 */
@Listener
@SpringComponent
@UIScope
public class UnderwritingHeaderComponent extends UnderwritingHeaderComponentDesign {
	private final LoanApplicationHeaderRepository repository;
	private final BankInfoRepository bankInfoRepository;
	private final PersonalInfoRepository personalInfoRepository;
	private final ProductInformationRepository productInformationRepository;
	private final GuarantorRepository guarantorRepository;
  private final BusinessRepository businessRepository;
	private String applicationId;
	private SessionScopeBus bus;

	@Inject
	public UnderwritingHeaderComponent(SessionScopeBus bus, LoanApplicationHeaderRepository repository, CommandGateway commandGateway, UI ui, VaadinSecurity vaadinSecurity, BankInfoRepository bankInfoRepository, PersonalInfoRepository personalInfoRepository, ProductInformationRepository productInformationRepository, GuarantorRepository guarantorRepository, BusinessRepository businessRepository) {
		this.repository = repository;
		this.bus = bus;
		this.bankInfoRepository = bankInfoRepository;
		this.personalInfoRepository = personalInfoRepository;
		this.productInformationRepository = productInformationRepository;
		this.guarantorRepository = guarantorRepository;
    this.businessRepository = businessRepository;
    
    buttonDecline.addClickListener(e -> {
			Window window = confirmationDecline();

			final ConfirmationComponent confirmationComponent = new ConfirmationComponent();
			confirmationComponent.setListener(new ConfirmationComponent.ConfirmationComponentListener() {
				@Override
				public void onClosed() {
					window.close();
				}

				@Override
				public void onNoButtonClicked() {
					window.close();
				}

				@Override
				public void onYesButtonClicked() {
					try {
						commandGateway.sendAndWait(new DeclineApplicationCommand(applicationId,  confirmationComponent.getDeclineReason()));
						window.close();
						ui.getNavigator().navigateTo("");
					} catch (IllegalStateException e1) {
						Notification.show("Error can't decline an application", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
					}
				}
			});
			window.setContent(confirmationComponent);
			UI.getCurrent().addWindow(window);
		});
		
    buttonReject.addClickListener(e -> {
      ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
      confirmationMessage.confirmationTitle.setValue("Recommend rejection");
      confirmationMessage.messageLabel.setValue("Do you want to recommend to reject?");
      Window window = confirmationMessage.displayConfiguration();
      confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
        
        @Override
        public void onClosed() {
          window.close();
        }
        
        @Override
        public void onNoButtonClicked() {
          window.close();
        }
        
        @Override
        public void onYesButtonClicked() {
          try {
            isUnderwrittenValidate();
            commandGateway.sendAndWait(new RecommendApplicationRejectionCommand(applicationId));
            window.close();
            Notification.show("Recommend to reject successful", Notification.Type.HUMANIZED_MESSAGE);
            ui.getNavigator().navigateTo("");
          }catch (IllegalStateException e1) {
            window.close();
            Notification.show(e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
          }
        }
      });
      window.setContent(confirmationMessage);
      UI.getCurrent().addWindow(window);
    });
    buttonApprove.addClickListener(e->{
      ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
      confirmationMessage.confirmationTitle.setValue("Recommend Approval");
      confirmationMessage.messageLabel.setValue("Do you want to recommend to approve?");
      Window window = confirmationMessage.displayConfiguration();
      confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
        
        @Override
        public void onClosed() {
          window.close();
        }
        
        @Override
        public void onNoButtonClicked() {
          window.close();
        }
        
        @Override
        public void onYesButtonClicked() {
          try {
            isUnderwrittenValidate();
            commandGateway.sendAndWait(new RecommendApplicationApprovalCommand(applicationId));
            window.close();
            Notification.show("Recommend to approve successful", Notification.Type.HUMANIZED_MESSAGE);
            getUI().getNavigator().navigateTo("");
          }catch (IllegalStateException e1) {
            window.close();
            Notification.show(e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
          }
        }
      });
      window.setContent(confirmationMessage);
      UI.getCurrent().addWindow(window);
    });
    //set role permission for FIELD CHECKER
    if (vaadinSecurity.hasAuthorities(Role.FIELDCHECKER)){
      buttonReject.setVisible(false);
      buttonApprove.setVisible(false);
      buttonDecline.setVisible(false);
    }
	}

	

	@Override
	public void attach() {
		super.attach();
		bus.subscribe(this);
	}

	@Override
	public void detach() {
		super.detach();
		bus.unsubscribe(this);
	}

	private Window confirmationDecline() {
		Window window = new Window();
		window.center();
		window.removeAllCloseShortcuts();
		window.setResizable(false);
		window.setClosable(false);
		window.setModal(true);
		window.setWidth(600, Unit.PIXELS);
		return window;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
		updateData();
	}

	private void updateData(){
		LoanApplicationHeaderDTO loanApplicationHeaderDTO = repository.findByApplicationId(applicationId);
		labelCustomerName.setValue(loanApplicationHeaderDTO.getCustomerName());
		labelApplicationId.setValue(loanApplicationHeaderDTO.getReferenceId());
		labelBusinessName.setValue(loanApplicationHeaderDTO.getBusinessName());
		labelTerm.setValue(loanApplicationHeaderDTO.getTerm() + " months");
		labelStatus.setValue(loanApplicationHeaderDTO.getStatus().toString());
		labelProductName.setValue(loanApplicationHeaderDTO.getProductName().toString());
		labelCreditScore.setValue(loanApplicationHeaderDTO.getCreditScore());
		labelRequestAmount.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(loanApplicationHeaderDTO.getRequestAmount()));
	}
	
	private void isUnderwrittenValidate(){
    PersonalInformationDTO personalInformationDTO = personalInfoRepository.findByApplicationId(applicationId);
    if(StringUtils.isEmpty(personalInformationDTO.getNrcId()))
      throw new IllegalStateException("NRC ID cannot be empty.");
	  
		BankInformationDTO bankInformationDTO = bankInfoRepository.findByApplicationId(applicationId);
		if(bankInformationDTO.getBankAccountType() == null)
      throw new IllegalStateException("Bank account type cannot be empty.");
    
    GuarantorDTO guarantorDTO = guarantorRepository.findByApplicationId(applicationId);
    if(StringUtils.isEmpty(guarantorDTO.getFullName()))
      throw new IllegalStateException("Guarantor information is require.");
    
    Business business = businessRepository.findByApplicationId(applicationId);
    if (business.getMainBranch().getBranchName() == null)
      throw new IllegalStateException("Main branch cannot be empty.");
    
		Optional<ProductInformationDTO> productInformationDTO = productInformationRepository.findByApplicationId(applicationId);
    if(productInformationDTO.get().getPaymentFrequency() == null)
      throw new IllegalStateException("Payment Frequency cannot be empty.");
	}

	@Handler
	@Enveloped(messages = {CreditScoreUpdatedEvent.class, ProductInformationUpdatedEvent.class, BusinessInfoUpdatedEvent.class, CustomerInfoUpdatedEvent.class})
	public void handle(MessageEnvelope envelope){
		updateData();
	}
	
}
