package com.gl.csf.underwriting.ui.component.common;

import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.server.StreamVariable;
import com.vaadin.server.ThemeResource;
import com.vaadin.ui.*;
import com.vaadin.ui.dnd.FileDropTarget;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 02/10/2017.
 */
public class FileUploadComponent extends FileUploadComponentDesign implements Upload.Receiver, Upload.SucceededListener, Upload.FailedListener {
  private final Set<FileUploadResult> fileUploadResults = new HashSet<>();
  private Logger logger = LoggerFactory.getLogger(FileUploadComponent.class);
  private FileUploadComponentListener fileUploadComponentListener;
  private ByteArrayOutputStream tmpByteArrayOutputStream;

  public FileUploadComponent(){
    buttonUpload.setReceiver(this);
    buttonUpload.addFailedListener(this);
    buttonUpload.addSucceededListener(this);

    progressBar.setIndeterminate(true);
    progressBar.setVisible(false);
    uploadPanel.addComponent(progressBar);


    new FileDropTarget<>(uploadPanel, event -> {

      if(fileUploadComponentListener != null)
        fileUploadComponentListener.uploadStarted();

      // Get list of uploaded file
      Collection<Html5File> files = event.getFiles();
      long totalFileSize = files.stream().mapToLong(Html5File::getFileSize).sum();
      final long[] currentReceivedBytes = {0};
      final int[] numberOfUploadedFile = {0};

      progressBar.setVisible(true);

      // Process each file
      files.forEach(file-> file.setStreamVariable(new StreamVariable() {
        // Create output stream for this file
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        @Override
        public OutputStream getOutputStream() {
          return outputStream;
        }

        @Override
        public boolean listenProgress() {
          return true;
        }

        @Override
        public void onProgress(StreamingProgressEvent event) {
          currentReceivedBytes[0] += event.getBytesReceived();
          progressBar.setValue(currentReceivedBytes[0]/totalFileSize);
        }

        @Override
        public void streamingStarted(StreamingStartEvent event) {
        }

        @Override
        public void streamingFinished(StreamingEndEvent event) {
          FileUploadResult fileUploadResult = new FileUploadResult(event.getFileName(), new ByteArrayInputStream(outputStream.toByteArray()), false, null);
          FileUploadResult temp = new FileUploadResult(event.getFileName(), new ByteArrayInputStream(outputStream.toByteArray()), false, null);
          fileUploadResults.add(fileUploadResult);
          addUploadedComponent(temp, fileUploadResult);

          ++numberOfUploadedFile[0];

          if(numberOfUploadedFile[0] == files.size()) {
            progressBar.setVisible(false);
            if (fileUploadComponentListener != null)
              fileUploadComponentListener.uploadFinished();
          }
        }

        @Override
        public void streamingFailed(StreamingErrorEvent event) {
          fileUploadResults.add(new FileUploadResult(event.getFileName(), null, true, event.getException()));
          Notification.show("Failed to upload file: " + file.getFileName(), Notification.Type.ERROR_MESSAGE);

          if(numberOfUploadedFile[0] == files.size()) {
            progressBar.setVisible(false);
            if (fileUploadComponentListener != null)
              fileUploadComponentListener.uploadFinished();
          }
        }

        @Override
        public boolean isInterrupted() {
          return false;
        }
      }));
    });
  }
  public void setFileUploadComponentListener(FileUploadComponentListener fileUploadComponentListener){
    this.fileUploadComponentListener = fileUploadComponentListener;
  }

  public Set<FileUploadResult> getFileUploadResults() {
    return fileUploadResults;
  }

  public void clearUploadResults(){
    for(FileUploadResult fileUploadResult : fileUploadResults){
      try {
        fileUploadResult.getByteArrayInputStream().close();
      } catch (IOException e) {
        logger.error("Failed to close input array", e);
      }
    }
    fileUploadResults.clear();
    contentUploadLayout.removeAllComponents();
  }

  private void addUploadedComponent(FileUploadResult temp, FileUploadResult fileUploadResult){
    Component uploadedComponent = createUploadedComponent(temp, fileUploadResult, LocalDateTime.now());
    contentUploadLayout.addComponent(uploadedComponent);
  }

  private Component createUploadedComponent(FileUploadResult temp,FileUploadResult fileUploadResult, LocalDateTime date){
    CssLayout uploadLayout = new CssLayout();
    uploadLayout.setWidth(498, Unit.PIXELS);
    uploadLayout.setHeight(42,Unit.PIXELS);
    uploadLayout.setStyleName("field_check-references-document-attachment-file");

    HorizontalLayout subUploadLayout = new HorizontalLayout();
    subUploadLayout.setWidth(100,Unit.PERCENTAGE);
    Button fileNameButton = new Button();
    fileNameButton.setCaption(fileUploadResult.getFilename());
    fileNameButton.setStyleName("borderless field_check-references-document-file-button");

    Label dateModified = new Label(date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    dateModified.setStyleName("field_check-references-document-modified-date-label");

    CssLayout buttonLayout = new CssLayout();
    buttonLayout.setStyleName("field_check-button-layout");

    Button downloadButton = new Button();
    downloadButton.setIcon(new ThemeResource("images/download3.png"));
    downloadButton.setStyleName("borderless field_check-references-document-download-button");
    
    try {
      StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
        try {
          return temp.getByteArrayInputStream();
        } catch (Exception ex) {
          logger.error(ex.toString());
          throw new RuntimeException(ex);
        }
      }, temp.getFilename());

      FileDownloader fileDownloader = new FileDownloader(streamResource);
      fileDownloader.extend(downloadButton);
    } catch (Exception err) {
      logger.error(err.toString());
    }

    Button deleteButton = new Button();
    deleteButton.setIcon(new ThemeResource("images/close.png"));
    deleteButton.setStyleName("field_check-references-document-close-button borderless");

    deleteButton.addClickListener(e->{

      ConfirmationMessageComponent confirmationMessage = new ConfirmationMessageComponent();
      Window window = confirmationMessage.displayConfiguration();
      confirmationMessage.setListener(new ConfirmationMessageComponent.ConfirmationMessageComponentListener() {
        @Override
        public void onClosed() { window.close(); }
        @Override
        public void onNoButtonClicked() { window.close(); }
        @Override
        public void onYesButtonClicked() {
          contentUploadLayout.removeComponent(uploadLayout);
          fileUploadResults.remove(temp);
          fileUploadResults.remove(fileUploadResult);
          
          window.close();
        }
      });
      window.setContent(confirmationMessage);
      UI.getCurrent().addWindow(window);
    });

    buttonLayout.addComponent(deleteButton);
    buttonLayout.addComponent(downloadButton);

    subUploadLayout.addComponent(fileNameButton);
    subUploadLayout.addComponent(dateModified);
    subUploadLayout.addComponent(buttonLayout);

    uploadLayout.addComponent(subUploadLayout);

    return uploadLayout;
  }

  @Override
  public void uploadFailed(Upload.FailedEvent event) {
    fileUploadResults.add(new FileUploadResult(event.getFilename(), null, true, event.getReason()));
    Notification.show("Failed to upload file: " + event.getFilename(), Notification.Type.ERROR_MESSAGE);
  }

  @Override
  public OutputStream receiveUpload(String filename, String mimeType) {
    if(fileUploadComponentListener != null)
      fileUploadComponentListener.uploadStarted();

    tmpByteArrayOutputStream = new ByteArrayOutputStream();
    return tmpByteArrayOutputStream;
  }

  @Override
  public void uploadSucceeded(Upload.SucceededEvent event) {
    FileUploadResult fileUploadResult = new FileUploadResult(event.getFilename(), new ByteArrayInputStream(tmpByteArrayOutputStream.toByteArray()), false, null);
    FileUploadResult temp = new FileUploadResult(event.getFilename(), new ByteArrayInputStream(tmpByteArrayOutputStream.toByteArray()), false, null);

    fileUploadResults.add(fileUploadResult);
    addUploadedComponent(temp,fileUploadResult);

    if (fileUploadComponentListener != null)
      fileUploadComponentListener.uploadFinished();
  }
}