package com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields;

import com.gl.csf.common.OffsetPageRequest;
import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDocumentDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDocumentRepository;
import com.gl.csf.underwriting.service.DocumentService;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Notification;
import liquibase.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 10/13/2017.
 */
public class UnderwritingFieldReferenceItemComponent extends UnderwritingFieldReferenceItemComponentDesign {
  private final static Logger logger = LoggerFactory.getLogger(UnderwritingFieldReferenceItemComponent.class);

  public UnderwritingFieldReferenceItemComponent(FieldCheckReferenceDocumentRepository documentRepository, FieldCheckReferenceDTO fieldCheckReference, DocumentService documentService) {

    commentTextArea.setValue(fieldCheckReference.getComment() == null ? "" : fieldCheckReference.getComment());
    fieldTextArea.setValue(StringUtils.isEmpty(fieldCheckReference.getText()) ? "" : fieldCheckReference.getText());
    Grid.Column dateModified = documentGrid.getColumn("dateModified");
    dateModified.setRenderer(LocalDateTimeFormat.createLocalDateTimeRenderer());
  
    documentGrid.setDataProvider(new AbstractBackEndDataProvider<FieldCheckReferenceDocumentDTO, String>() {
      @Override
      protected Stream<FieldCheckReferenceDocumentDTO> fetchFromBackEnd(Query<FieldCheckReferenceDocumentDTO, String> query) {
        Pageable pageable = new OffsetPageRequest(query.getOffset(), query.getLimit(), new Sort(Sort.Direction.DESC, "dateModified"));
        return StreamSupport.stream(documentRepository.findAllByFieldCheckReference(pageable, fieldCheckReference).spliterator(), true);
      }
    
      @Override
      protected int sizeInBackEnd(Query<FieldCheckReferenceDocumentDTO, String> query) {
        return documentRepository.countAllByFieldCheckReference(fieldCheckReference);
      }
    });

    documentGrid.addComponentColumn(FieldCheckReferenceDocumentDTO -> {
      Button buttonDownload = new Button("");
      buttonDownload.setIcon(VaadinIcons.DOWNLOAD);
      buttonDownload.setStyleName("grid-download-button");
      try {
        StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
          try {
            return documentService.downloadDocument(FieldCheckReferenceDocumentDTO.getDocumentDescriptor());
          } catch (Exception e) {
            Notification.show("error when download financial document", Notification.Type.ERROR_MESSAGE);
            logger.error("error when download financial document", e);
            return null;
          }
        }, FieldCheckReferenceDocumentDTO.getFileName());

        FileDownloader fileDownloader = new FileDownloader(streamResource);
        fileDownloader.extend(buttonDownload);

      } catch (Exception e) {
        logger.error("error when download financial document", e);
        throw new RuntimeException(e);
      }
      return buttonDownload;
    }).setCaption("Download");
  }

}
