package com.gl.csf.underwriting.service;

import com.gl.csf.underwriting.common.model.product.Interest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 2/6/2018.
 */

@Service
public class InterestRateService {
  private final String baseUrl;
  private final RestTemplate restTemplate;
  
  @Inject
  public InterestRateService(@Value("${endpoints.rest.parameter.interest}") String baseUrl, RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }
  
  // TODO: Improve the performance by introducing the pagination here
  public List<Interest> getAllInterestRate() {
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
            new ParameterizedTypeReference<List<Interest>>(){}).getBody();
  }
  
  public Optional<Interest> getDefaultInterestRate() {
    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/defaultinterest", HttpMethod.GET, null,
              new ParameterizedTypeReference<Interest>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
