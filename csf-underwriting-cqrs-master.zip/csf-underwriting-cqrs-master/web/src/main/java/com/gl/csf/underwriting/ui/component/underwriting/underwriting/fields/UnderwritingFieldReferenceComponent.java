package com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields;

import com.gl.csf.common.util.LocalDateTimeFormat;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDTO;
import com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference.FieldCheckReferenceDocumentRepository;
import com.gl.csf.underwriting.service.DocumentService;

import java.util.List;
import java.util.Optional;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 18/10/2017.
 */
public class UnderwritingFieldReferenceComponent extends UnderwritingFieldReferenceComponentDesign {

	public UnderwritingFieldReferenceComponent(FieldCheckReferenceDocumentRepository documentRepository, List<FieldCheckReferenceDTO> fieldCheckReferences, DocumentService documentService) {
    Optional<FieldCheckReferenceDTO> optionalFieldCheckReference = fieldCheckReferences.stream().findAny();

    if(!optionalFieldCheckReference.isPresent()){
      throw new IllegalArgumentException("fieldCheckReferences can't be empty");
    }

    FieldCheckReferenceDTO anyFieldCheckReference = optionalFieldCheckReference.get();
    userNameLabel.setValue(anyFieldCheckReference.getFieldCheckerId());
    dateLabel.setValue(anyFieldCheckReference.getSubmittedDate().format(LocalDateTimeFormat.createDateTimeformatter()));

    fieldCheckReferences.forEach(fieldCheckReference -> 
    	content.addTab(new UnderwritingFieldReferenceItemComponent(documentRepository, fieldCheckReference, documentService)
    				).setCaption(fieldCheckReference.getName())
    	
    );
  }
}
