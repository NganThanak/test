package com.gl.csf.underwriting.ui.util.jersey;

import com.gl.csf.underwriting.ui.util.jackson.ObjectMapperProvider;
import org.glassfish.jersey.jackson.JacksonFeature;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/08/2017.
 */
public class JerseyClientUtils {

  public static <T> T get(Class<T> clazz, String url) {
    return get(new GenericType<>(clazz), url);
  }

  public static <T> T get(GenericType<T> genericType, String url) {
    return operate(Operation.Get, genericType, url, MediaType.APPLICATION_JSON, null);
  }

  public static <T, P> T post(Class<T> clazz, String url, P payload) {
    return post(new GenericType<>(clazz), url, payload);
  }

  public static <T, P> T post(Class<T> clazz, String url, String contentType, P payload) {
    return post(new GenericType<>(clazz), url, contentType, payload);
  }

  public static <T, P> T post(GenericType<T> genericType, String url, P payload) {
    return operate(Operation.Post, genericType, url, MediaType.APPLICATION_JSON, payload);
  }

  public static <T, P> T post(GenericType<T> genericType, String url, String contentType, P payload) {
    return operate(Operation.Post, genericType, url, contentType, payload);
  }

  public static <T, P> T put(GenericType<T> genericType, String url, String contentType, P payload) {
    return operate(Operation.Put, genericType, url, contentType, payload);
  }

  public static <T, P> T put(Class<T> clazz, String url, String contentType, P payload) {
    return put(new GenericType<>(clazz), url, contentType, payload);
  }

  public static <T, P> T put(Class<T> clazz, String url, P payload) {
    return put(new GenericType<>(clazz), url, payload);
  }

  public static <T, P> T put(GenericType<T> genericType, String url, P payload) {
    return operate(Operation.Put, genericType, url, MediaType.APPLICATION_JSON, payload);
  }

  public static <T> T delete(Class<T> clazz, String url) {
    return operate(Operation.Delete, new GenericType<>(clazz), url, MediaType.APPLICATION_JSON, null);
  }

  public static <T> T delete(GenericType<T> genericType, String url) {
    return operate(Operation.Delete, genericType, url, MediaType.APPLICATION_JSON, null);
  }

  private static <T, P> T operate(Operation operation, GenericType<T> genericType, String url, String contentType,
                                  P payload) {

    Client client = ClientBuilder.newClient();
    client.register(ErrorResponseFilter.class);
    client.register(JacksonFeature.class);
    client.register(ObjectMapperProvider.class);
    Invocation.Builder builder = client.target(url).request(MediaType.APPLICATION_JSON);
    System.out.println(operation + " " + url);
    switch (operation) {
      case Post:
        return builder.post(Entity.entity(payload, contentType), genericType);
      case Get:
        return builder.get(genericType);
      case Put:
        return builder.put(Entity.entity(payload, contentType), genericType);
      case Delete:
        return builder.delete(genericType);
      default:
        throw new RuntimeException("Not supported operation: " + operation);
    }
  }

  private enum Operation {
    Post, Get, Put, Delete
  }
}
