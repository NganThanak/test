package com.gl.csf.underwriting.ui.component.common;

import java.io.ByteArrayInputStream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/3/2017.
 */
public class FileUploadResult {
  private String filename;
  private ByteArrayInputStream byteArrayInputStream;
  private boolean hasError;
  private Exception exception;

  public FileUploadResult(){

  }

  public FileUploadResult(String filename, ByteArrayInputStream byteArrayInputStream, boolean hasError, Exception exception) {
    this.filename = filename;
    this.byteArrayInputStream = byteArrayInputStream;
    this.hasError = hasError;
    this.exception = exception;
  }

  public String getFilename() {
    return filename;
  }

  public ByteArrayInputStream getByteArrayInputStream() {
    return byteArrayInputStream;
  }
  
  public boolean hasError() {
    return hasError;
  }

  public Exception getException() {
    return exception;
  }
}
