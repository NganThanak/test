package com.gl.csf.underwriting.ui.util.paymentschedule;

import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;


public class CompoundAmortization extends Amortization {

  public MonetaryAmount calculateInstallmentAmount(LoanParameter param) {
    double effectiveInterestRate = calculateEffectiveInterestRate(param);
    MonetaryAmount fv = param.getLoanAmount().multiply(Math.pow(1 + effectiveInterestRate, param.getLoanTerm()));
    // calculate like a simple interest.
    MonetaryAmount compoundInterestPerPeriod = fv.subtract(param.getLoanAmount()).divide(param.getNumberOfPeriods());

    return compoundInterestPerPeriod.add(param.getLoanAmount().divide(param.getNumberOfPeriods()));
  }

  // return irr % per period
  public double irr(LoanParameter param) {
    MonetaryAmount pmt = calculateInstallmentAmount(param);
    MonetaryAmount[] values = new MonetaryAmount[param.getNumberOfPeriods() + 1];
    values[0] = param.getLoanAmount().multiply(-1);
    int npr = param.getNumberOfPeriods();

    for (int i = 1; i <= npr; i++) {
      values[i] = pmt;
    }

    BigDecimal rateOfReturn = IRRCalculator.irr(values, BigDecimal.valueOf(0.1), param.getScale(), param.getRoundingMode());

    return rateOfReturn.doubleValue();

  }

    /*
     * Adjust interest rate according to the compounding method.
	 *
 	 * r = (1 + i/n)^n - 1
	 * where r: effective interest rate
	 *       i: nominal interest rate or stated interest rate per year
	 *       n: number of compounding periods per year,
	 *          i.e. if compounding monthly: n=12, if compounding quarterly: n=4,
	 *               if compounding daily: n=365, if compounding weekly: n=52.
	 * @compoundingMethod: 1: daily, 2: weekly, 3: monthly, 4: quarterly, 5: yearly
	 */
  private static double calculateEffectiveInterestRate(LoanParameter param) {
    return Math.pow(1 + param.getNominalInterestRate() / param.getNumberOfCompoundingPeriods(), param.getNumberOfCompoundingPeriods()) - 1;
  }

  public static void main(String[] args) {

    Calendar wcal1 = Calendar.getInstance();
    Calendar wcal2 = Calendar.getInstance();
    Calendar wcal3 = Calendar.getInstance();
    Calendar wcal4 = Calendar.getInstance();

    wcal1.set(Calendar.MONTH, 0);
    wcal1.set(Calendar.DATE, 5);
    wcal2.set(Calendar.MONTH, 3);
    wcal2.set(Calendar.DATE, 5);
    wcal3.set(Calendar.MONTH, 6);
    wcal3.set(Calendar.DATE, 10);
    wcal4.set(Calendar.MONTH, 9);
    wcal4.set(Calendar.DATE, 10);

    LoanParameter param = LoanParameterBuilder.createBuilder()
            .numberOfCompoundingPeriods(Compounding.MONTHLY)
            .loanAmount(Money.of(10000, "MMK"))
            .loanTerm(1)
            .nominalInterestRate(0.276)
            .startDate(wcal1.getTime())
            .withdraw(new Withdrawal(Money.of(2500, "MMK"), wcal1.getTime()))
            .withdraw(new Withdrawal(Money.of(2500, "MMK"), wcal2.getTime()))
            .withdraw(new Withdrawal(Money.of(2500, "MMK"), wcal3.getTime()))
            .withdraw(new Withdrawal(Money.of(2500, "MMK"), wcal4.getTime()))
            .scale(8)
            .build();

    // generate compound payment schedule:
    CompoundAmortization amortization = new CompoundAmortization();
    List<Installment> amortizationTable = amortization.generateRevolvingPaymentSchedule(param);

    System.out.println("Payment#\tDue Date\t\t\t\tBegin Balance\t\t\tPayment\t\t\t\tInterest\t\t\tPrincipal\t\t\tEnd Balance");
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");

    for (Installment payment : amortizationTable) {
      System.out.println("" + payment.getInstallmentNumber() + "\t\t\t\t"
              + df.format(payment.getDueDate()) + "\t\t\t\t"
              + payment.getBeginBalance().getNumber().round(new MathContext(6, RoundingMode.HALF_UP)) + "\t\t\t\t"
              + payment.getAmount().getNumber().round(new MathContext(6, RoundingMode.HALF_UP)) + "\t\t\t\t"
              + payment.getInterest().getNumber().round(new MathContext(6, RoundingMode.HALF_UP)) + "\t\t\t\t"
              + payment.getPrincipal().getNumber().round(new MathContext(6, RoundingMode.HALF_UP)) + "\t\t\t\t"
              + payment.getEndBalance().getNumber().round(new MathContext(6, RoundingMode.HALF_UP)));
    }
  }
}