package com.gl.csf.underwriting.ui.view;

import com.gl.csf.underwriting.exception.ApplicationIdNotFoundException;
import com.gl.csf.underwriting.ui.permission.Role;
import com.gl.csf.underwriting.ui.viewdeclaration.UIScopeUnderwritingViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Notification;

import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;
import java.util.Map;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeUnderwritingViews.APPLICATION)
public class ApplicationView extends ApplicationViewDesign implements View {

  @Inject
  public ApplicationView(VaadinSecurity vaadinSecurity){

    //set permission for tap
    if (vaadinSecurity.hasAuthority(Role.FIELDCHECKER))
      tabSheet.getTab(underwritingComponent).setVisible(false);
    else
      tabSheet.getTab(fieldCheckComponent).setVisible(false);

    //set permission for header
    if (vaadinSecurity.hasAuthority(Role.SENIOR_UNDERWRITER))
      underwritingHeaderComponent.setVisible(false);
    else
      underwritingSeniorHeaderComponent.setVisible(false);
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    Map<String, String> parameterMap = event.getParameterMap();
    String applicationId = parameterMap.getOrDefault("applicationid", null);
    tabSheet.setSelectedTab(0);
    if (applicationId != null) {
      businessInfoComponent.setApplicationId(applicationId);
      ownerInfoComponent.setApplicationId(applicationId);
      underwritingHeaderComponent.setApplicationId(applicationId);
      commentLayoutComponent.setApplicationId(applicationId);
      underwritingComponent.setApplicationId(applicationId);
      fieldCheckComponent.setApplicationId(applicationId);
      documentComponent.setApplicationId(applicationId);
      historyComponent.setApplicationId(applicationId);
      underwritingSeniorHeaderComponent.setApplicationId(applicationId);
    
      ownerInfoComponent.getPersonalInfoComponentSaveButton().addClickListener(e -> {
        if(underwritingComponent.getUnderwritingFieldsComponent()
                .getUnderwritingFieldCheckListComponent().getApplicantFieldCheckItem().getFieldTextArea().getValue() !=
                ownerInfoComponent.getPersonalInfoComponent().getTextFieldNRCID().getValue()) {
  
          underwritingComponent.getUnderwritingFieldsComponent()
                  .getUnderwritingFieldCheckListComponent().getApplicantFieldCheckItem().getFieldTextArea()
                  .setValue(ownerInfoComponent.getPersonalInfoComponent().getTextFieldNRCID().getValue());
          
          underwritingComponent.getUnderwritingFieldsComponent()
                  .getUnderwritingFieldCheckListComponent().getApplicantFieldCheckItem().saveFieldValue();
        }
      });
      
	  ownerInfoComponent.getGuarantorComponentSaveButton().addClickListener(e -> {
		  underwritingComponent.getUnderwritingFieldsComponent()
			.getUnderwritingFieldCheckListComponent().getGuarantorFieldCheckItem().getFieldTextArea()
			.setValue(ownerInfoComponent.getGuarantorComponent().getTextFieldNRCID().getValue());
		  
		  underwritingComponent.getUnderwritingFieldsComponent()
			.getUnderwritingFieldCheckListComponent().getGuarantorFieldCheckItem().saveFieldValue();
	  });
	  
	  ownerInfoComponent.getBankInfoSaveButton().addClickListener(e -> {
		  underwritingComponent.getUnderwritingFieldsComponent()
			.getUnderwritingFieldCheckListComponent().getBankFieldCheckItem().getFieldTextArea()
			.setValue(ownerInfoComponent.getPersonalInfoComponent().getBankAccountNumber().getValue());
		  
      underwritingComponent.getUnderwritingFieldsComponent().getUnderwritingFieldCheckListComponent()
                .getBankFieldCheckItem().saveFieldValue();
	  });
	  
    }
    else
      throw new ApplicationIdNotFoundException("Can't find application id");
  }
}
