package com.gl.csf.common;

import org.springframework.data.domain.AuditorAware;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 22/07/2017.
 */
public class AuditorAwareImpl implements AuditorAware<String> {

  @Override
  public String getCurrentAuditor() {
    // TODO inject proper user
    return "system";
  }
}
