package com.gl.csf.underwriting.ui.util.excel;

import com.gl.csf.underwriting.ui.util.paymentschedule.Installment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxStreamingView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/18/2017.
 */
public class PaymentScheduleExcelBuilder extends AbstractXlsxStreamingView {

  private static List<Installment> installments;
  private static String referenceID;
  private static String loanType;

  @Override
  protected void buildExcelDocument(Map<String, Object> map, Workbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
    String pattern = "yyyy-MMM-dd@hh-mm-ss aaa";
    SimpleDateFormat format = new SimpleDateFormat(pattern);

    SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");

    String filename = referenceID + "-" + loanType + "-Payment-Simulation-" + format.format(new Date());
    // change the file name
    response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + ".xlsx\"");

    // create excel sheet
    Sheet sheet = workbook.createSheet("Payment Schedule Simulation");

    // create header row
    Row header = sheet.createRow(1);
    header.createCell(0).setCellValue("Period");
    header.createCell(1).setCellValue("Installment Date");
    header.createCell(2).setCellValue("Installment");
    header.createCell(3).setCellValue("Interest");
    header.createCell(4).setCellValue("Principle");
    header.createCell(5).setCellValue("Remaining Balance");

    // create data row
    Row dataRow;
    for (int i = 2; i <= installments.size() + 1; i++) {
      dataRow = sheet.createRow(i);
      dataRow.createCell(0).setCellValue(installments.get(i - 2).getInstallmentNumber());
      dataRow.createCell(1).setCellValue(df.format(installments.get(i - 2).getDueDate()));
      dataRow.createCell(2).setCellValue(installments.get(i - 2).getAmount().getNumber().numberValue(BigDecimal.class)
              .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()) ;
      dataRow.createCell(3).setCellValue(installments.get(i - 2).getInterest().getNumber().numberValue(BigDecimal.class)
              .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(4).setCellValue(installments.get(i - 2).getPrincipal().getNumber().numberValue(BigDecimal.class)
              .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(5).setCellValue(installments.get(i - 2).getEndBalance().getNumber().numberValue(BigDecimal.class)
              .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
    }
  }

  public static void setInstallment(List<Installment> paymentSchedule) {
    installments = paymentSchedule;
  }

  public static void setCustomer(String id) {
    referenceID = id;
  }

  public static void setLoanType(String productType) {
    loanType = productType;
  }
}
