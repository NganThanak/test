package com.gl.csf.underwriting.ui.component.underwriting;

import com.gl.csf.underwriting.common.model.address.District;
import com.gl.csf.underwriting.common.model.address.State;
import com.gl.csf.underwriting.common.model.address.Township;
import com.gl.csf.underwriting.common.model.customer.Gender;
import com.gl.csf.underwriting.common.model.customer.Relationship;
import com.gl.csf.underwriting.service.DistrictService;
import com.gl.csf.underwriting.service.RelationshipService;
import com.gl.csf.underwriting.service.StateService;
import com.gl.csf.underwriting.service.TownshipService;
import com.gl.csf.underwriting.ui.permission.Role;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.TextField;

import org.vaadin.spring.security.VaadinSecurity;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/13/2017.
 */
@SpringComponent
@UIScope
public class GuarantorComponent extends GuarantorComponentDesign{
  private final TownshipService townshipService;
  private final DistrictService districtService;
  private final StateService stateService;
  private final RelationshipService relationshipService;
  private final VaadinSecurity vaadinSecurity;
  public GuarantorComponent(TownshipService townshipService, DistrictService districtService, StateService stateService,
                            RelationshipService relationshipService, VaadinSecurity vaadinSecurity){
    this.townshipService = townshipService;
    this.districtService = districtService;
    this.stateService = stateService;
    this.relationshipService = relationshipService;
    this.vaadinSecurity = vaadinSecurity;

    buttonSave.setVisible(false);
    enableAndDisableComponent(false);
    buttonEdit.addClickListener(e->{
      if(buttonEdit.getCaption().equalsIgnoreCase("Edit")){
        buttonSave.setVisible(true);
        buttonEdit.setCaption("Cancel");
        enableAndDisableComponent(true);
      }else if(buttonEdit.getCaption().equalsIgnoreCase("Cancel")) {
        buttonEdit.setCaption("Edit");
        buttonSave.setVisible(false);
        enableAndDisableComponent(false);
      }
    });

    buttonSave.addClickListener(event -> {
      buttonSave.setVisible(false);
      buttonEdit.setCaption("Edit");
      enableAndDisableComponent(false);
    });

    buttonSaveBusiness.setVisible(false);
    enableAndDisableBusinessInfoComponent(false);
    buttonEditBusiness.addClickListener(e -> {
      if (buttonEditBusiness.getCaption().equalsIgnoreCase("Edit")) {
        buttonSaveBusiness.setVisible(true);
        buttonEditBusiness.setCaption("Cancel");
        enableAndDisableBusinessInfoComponent(true);
      } else if (buttonEditBusiness.getCaption().equalsIgnoreCase("Cancel")) {
        buttonEditBusiness.setCaption("Edit");
        buttonSaveBusiness.setVisible(false);
        enableAndDisableBusinessInfoComponent(false);
      }
    });

    buttonSaveBusiness.addClickListener(event -> {
      buttonSaveBusiness.setVisible(false);
      buttonEditBusiness.setCaption("Edit");
      enableAndDisableBusinessInfoComponent(false);
    });

    ListDataProvider<Relationship> relationshipListDataProvider = new ListDataProvider<>(relationshipService.getAllRelationships());
    comboBoxRelationship.setDataProvider(relationshipListDataProvider);
    comboBoxGender.setDataProvider(new ListDataProvider<Gender>(Arrays.asList(Gender.values())));
    ListDataProvider<State> stateListDataProvider = new ListDataProvider<>(stateService.getAllStates());
    comboBoxState.setDataProvider(stateListDataProvider);
    addListeners(districtService, townshipService);

    comboBoxStateBusiness.setDataProvider(stateListDataProvider);
    addListenersBusinessInfo(districtService, townshipService);
    //set permission for field checker
    if (vaadinSecurity.hasAuthority(Role.FIELDCHECKER)) {
      buttonEdit.setVisible(false);
      buttonEditBusiness.setVisible(false);
    }
  
    dateFieldDOB.setRangeEnd(LocalDate.now().minusYears(18));
  }

  public void enableAndDisableComponent(boolean value){
    textFieldNRCID.setEnabled(value);
    textFieldFullName.setEnabled(value);
    comboBoxGender.setEnabled(value);
    dateFieldDOB.setEnabled(value);
    textFieldPhoneNumber.setEnabled(value);
    textFieldEmail.setEnabled(value);
    textFieldOwnerAddress.setEnabled(value);
    comboBoxDistrict.setEnabled(value);
    comboBoxTownship.setEnabled(value);
    comboBoxState.setEnabled(value);
    comboBoxRelationship.setEnabled(value);
  }


  private void addListeners(DistrictService districtService, TownshipService townshipService) {

    comboBoxState.addValueChangeListener(e -> {
      comboBoxDistrict.clear();
      ListDataProvider<District> districtListDataProvider = e.getSource().getOptionalValue().isPresent()
              ? new ListDataProvider<>(districtService.getDistrictsByState(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
      comboBoxDistrict.setDataProvider(districtListDataProvider);
    });

    comboBoxDistrict.addValueChangeListener(e -> {
      comboBoxTownship.clear();
      ListDataProvider<Township> townshipListDataProvider = e.getSource().getOptionalValue().isPresent()
              ? new ListDataProvider<>(townshipService.getTownships(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
      comboBoxTownship.setDataProvider(townshipListDataProvider);
    });

  }

  public void enableAndDisableBusinessInfoComponent(boolean value) {
    textFieldOwnerAddressBusiness.setEnabled(value);
    comboBoxDistrictBusiness.setEnabled(value);
    comboBoxTownshipBusiness.setEnabled(value);
    comboBoxStateBusiness.setEnabled(value);
    textFieldPhoneNumberBusiness.setEnabled(value);
  }

  private void addListenersBusinessInfo(DistrictService districtService, TownshipService townshipService) {

    comboBoxStateBusiness.addValueChangeListener(e -> {
      comboBoxDistrictBusiness.clear();
      ListDataProvider<District> districtListDataProvider = e.getSource().getOptionalValue().isPresent()
              ? new ListDataProvider<>(districtService.getDistrictsByState(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
      comboBoxDistrictBusiness.setDataProvider(districtListDataProvider);
    });

    comboBoxDistrictBusiness.addValueChangeListener(e -> {
      comboBoxTownshipBusiness.clear();
      ListDataProvider<Township> townshipListDataProvider = e.getSource().getOptionalValue().isPresent()
              ? new ListDataProvider<>(townshipService.getTownships(e.getValue())) : new ListDataProvider<>(Collections.emptyList());
      comboBoxTownshipBusiness.setDataProvider(townshipListDataProvider);
    });

  }
  
  public TextField getTextFieldNRCID() {
  	return textFieldNRCID;
  }
}
