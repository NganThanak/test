package com.gl.csf.underwriting.service;

import com.gl.csf.underwriting.common.model.customer.Relationship;
import com.gl.csf.underwriting.config.Authenticated;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/21/2017.
 */
@Service
public class RelationshipService {
	private final String baseUrl;
	private final RestTemplate restTemplate;

	@Inject
	public RelationshipService(@Value("${endpoints.rest.parameter.relationship}") String baseUrl,
	                    @Authenticated(Authenticated.With.CLIENT_CREDENTIALS) RestTemplate restTemplate) {
		this.baseUrl = baseUrl;
		this.restTemplate = restTemplate;
	}

	public List<Relationship> getAllRelationships(){
		return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
						new ParameterizedTypeReference<List<Relationship>>(){}).getBody();
	}

	public Optional<Relationship> getRelationshipById(UUID relationshipId){
		Objects.requireNonNull(relationshipId);

		try {
			return Optional.of(restTemplate.exchange(baseUrl + "/" + relationshipId, HttpMethod.GET, null,
							new ParameterizedTypeReference<Relationship>(){}).getBody());
		} catch (NotFoundException e){
			return Optional.empty();
		}
	}
}
