package com.gl.csf.underwriting.ui.component.chart;

import com.vaadin.addon.charts.ChartOptions;
import com.vaadin.addon.charts.model.style.Color;
import com.vaadin.addon.charts.model.style.Theme;
import com.vaadin.addon.charts.themes.ValoLightTheme;
import com.vaadin.ui.Component;
import com.vaadin.ui.VerticalLayout;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 8/18/2017.
 */
public abstract class AbstractVaadinChart extends VerticalLayout {

  private final VerticalLayout content;

  public AbstractVaadinChart() {
    content = this;
    content.setSizeFull();
    content.setMargin(true);
    content.setSpacing(false);
  }

  protected abstract Component getChart();

  @Override
  public void attach() {
    super.attach();
    setup();
  }

  public Component getWrappedComponent() {
    setup();
    content.getComponent(0).setSizeFull();
    return content;
  }

  protected void setup() {
    if (content.getComponentCount() == 0) {
      final Component map = getChart();
      content.addComponent(map);
      content.setExpandRatio(map, 1);
    }
  }

  protected Color[] getThemeColors() {
    Theme theme = ChartOptions.get().getTheme();
    return (theme != null) ? theme.getColors() : new ValoLightTheme()
            .getColors();
  }

  protected Theme getCurrentTheme() {
    Theme theme = ChartOptions.get().getTheme();
    return (theme != null) ? theme : new ValoLightTheme();
  }
}

