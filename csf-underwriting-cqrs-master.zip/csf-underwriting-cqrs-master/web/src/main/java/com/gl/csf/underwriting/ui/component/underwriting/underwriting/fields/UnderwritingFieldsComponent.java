package com.gl.csf.underwriting.ui.component.underwriting.underwriting.fields;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
/**
 * Created by p.ly on 9/29/2017.
 */
@UIScope
@SpringComponent
public class UnderwritingFieldsComponent extends UnderwritingFieldsComponentDesign {

  private String applicationId;

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
    underwritingFieldCheckListComponent.loadFieldCheckList(this.applicationId);
    underwritingFieldReferencesComponent.setApplicationId(applicationId);
  }
  
  public UnderwritingFieldCheckListComponent getUnderwritingFieldCheckListComponent() {
	  return underwritingFieldCheckListComponent;
  }
  
}
