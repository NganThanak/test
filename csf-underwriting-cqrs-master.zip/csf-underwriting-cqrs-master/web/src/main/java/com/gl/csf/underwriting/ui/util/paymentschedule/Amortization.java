package com.gl.csf.underwriting.ui.util.paymentschedule;

import org.javamoney.moneta.Money;

import javax.money.CurrencyUnit;
import javax.money.Monetary;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by Calvin Phibol on 8/28/2017.
 * <p>
 * This class is used to generate the payment schedule either for Simple or Compound Interest,
 * approximate internal rate of return(irr) using Newton Rapson's method and calculate installment amount.
 * <p>
 * Usage:
 * <code>
 * LoanParameter param = LoanParameter.createBuilder().compounding(Compounding.MONTHLY).loanAmount(10000).loanTerm(2).nominalInterestRate(0.276).build();
 * <p>
 * SimpleAmortization amortization = new SimpleAmortization();
 * <p>
 * List<Installment> amortizationTable = amortization.generatePaymentSchedule(param);
 * </code>
 */

public abstract class Amortization {

  /**
   * Generate amortization table based on the given loan parameters.
   */

  public List<Installment> generatePaymentSchedule(LoanParameter param) {
    MonetaryAmount paymentAmount = calculateInstallmentAmount(param);
    double irr = irr(param);

//    System.out.println("periodic irr=" + irr + ", payment amount: " + paymentAmount.getNumber().round(new MathContext(param.getScale(), RoundingMode.HALF_UP)) + "\n");

    List<Installment> amortizedTable = new ArrayList<>();

    MonetaryAmount balance = param.getLoanAmount();

    for (int i = 0; i < param.getNumberOfPeriods(); i++) {

      MonetaryAmount interest = balance.multiply(irr);
      MonetaryAmount principal = paymentAmount.subtract(interest);
      Date paymentDate = null;

      if (i == 0) {
        paymentDate = param.getDueDate();
      } else {
        Installment prevInstallment = amortizedTable.get(i - 1);
        paymentDate = getNextPaymentDate(prevInstallment.getDueDate(), 1);
      }

      Installment p = new Installment();
      BigDecimal endBalance = balance.getNumber().numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP)
              .subtract(principal.getNumber().numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP));
      CurrencyUnit currency = Monetary.getCurrency("MMK");

      p.setPrincipal(principal);
      p.setInterest(interest);
      p.setAmount(paymentAmount);
      p.setBeginBalance(balance);
      p.setEndBalance(Money.of(endBalance, currency));
      p.setInstallmentNumber(i + 1);
      p.setInterestRatePerPeriod(irr);
      p.setDueDate(paymentDate);

      amortizedTable.add(p);

      balance = balance.subtract(principal);

    }

    return amortizedTable;
  }

  /**
   * Generate revolving amortization table based on the given loan parameters.
   */
  public List<Installment> generateRevolvingPaymentSchedule(LoanParameter param) {
    List<Installment> amortizedTable = new ArrayList<>();

    if (param.getWithdrawals().size() == 0)
      return amortizedTable;

    LoanParameter loanParameter = LoanParameterBuilder.createBuilder()
            .loanAmount(param.getLoanAmount())
            .loanTerm(param.getLoanTerm())
            .numberOfCompoundingPeriods(param.getNumberOfCompoundingPeriods())
            .nominalInterestRate(param.getNominalInterestRate())
            .build();

    MonetaryAmount paymentAmount = calculateInstallmentAmount(loanParameter);
    double irr = irr(loanParameter);

//    System.out.println("periodic irr=" + irr + ", payment amount: " + paymentAmount.getNumber().round(new MathContext(param.getScale(), RoundingMode.HALF_UP)) + "\n");

    int curWithdrawalIndx = 0;
    int prevWithdrawalIndx = curWithdrawalIndx;

    MonetaryAmount withdrawalSubtotal = param.getWithdrawal(curWithdrawalIndx).getAmount();
    MonetaryAmount balance = withdrawalSubtotal;

    for (int i = 0; i < param.getNumberOfPeriods(); i++) {

      if (i == 0) {
        withdrawalSubtotal = param.getWithdrawal(curWithdrawalIndx).getAmount();
        balance = withdrawalSubtotal;
      } else {

        Installment prevInstallment = amortizedTable.get(i - 1);

        if (curWithdrawalIndx + 1 < param.getWithdrawals().size()) {
          Withdrawal nextW = param.getWithdrawal(curWithdrawalIndx + 1);

          if (isNewWithdrawal(prevInstallment.getDueDate(), nextW.getWithdrawalDate())) {
            prevWithdrawalIndx = curWithdrawalIndx;
            curWithdrawalIndx++;

            MonetaryAmount newSubtotal = Money.of(0, "MMK");

            for (int j = 0; j <= curWithdrawalIndx; j++) {
              newSubtotal = newSubtotal.add(param.getWithdrawal(j).getAmount());
            }

            withdrawalSubtotal = newSubtotal;
          }
        }
      }

      LoanParameter withdrawalParam = LoanParameterBuilder.createBuilder()
              .loanAmount(withdrawalSubtotal)
              .loanTerm(param.getLoanTerm())
              .numberOfCompoundingPeriods(param.getNumberOfCompoundingPeriods())
              .nominalInterestRate(param.getNominalInterestRate())
              .build();

      paymentAmount = calculateInstallmentAmount(withdrawalParam);

      MonetaryAmount interest = balance.multiply(irr);
      MonetaryAmount principal = paymentAmount.subtract(interest);
      MonetaryAmount beginBalance = balance;
      MonetaryAmount endBalance = null;
      Date paymentDate = null;

      if (i == 0) {
        Calendar firstPaymentCal = Calendar.getInstance();
        firstPaymentCal.setTime(param.getWithdrawal(0).getWithdrawalDate());
        firstPaymentCal.set(Calendar.MONTH, firstPaymentCal.get(Calendar.MONTH) + 1);
        paymentDate = firstPaymentCal.getTime();

      } else {
        Installment prevInstallment = amortizedTable.get(i - 1);
        paymentDate = getNextPaymentDate(prevInstallment.getDueDate(), 1);
      }


      // if new withdrawal, new begin bal = prev balance + withdrawal amount, but interest is calculated based on the prev balance
      if (curWithdrawalIndx > prevWithdrawalIndx) {
        balance = balance.add(param.getWithdrawal(curWithdrawalIndx).getAmount());
        beginBalance = balance;
        prevWithdrawalIndx = curWithdrawalIndx;
      }

      // the final installment amount = prev balance + interest
      if (i + 1 == param.getNumberOfPeriods()) {
        paymentAmount = beginBalance.add(interest);
        principal = paymentAmount.subtract(interest);
        endBalance = beginBalance.subtract(principal);
      }

      endBalance = balance.subtract(principal);

      Installment p = new Installment();

      p.setDueDate(paymentDate);
      p.setAmount(paymentAmount);
      p.setPrincipal(principal);
      p.setInterest(interest);
      p.setInstallmentNumber(i + 1);
      p.setInterestRatePerPeriod(irr);
      p.setBeginBalance(beginBalance);
      p.setEndBalance(endBalance);

      amortizedTable.add(p);

      balance = balance.subtract(principal);

    }

    return amortizedTable;
  }


  private boolean isNewWithdrawal(Date curDate, Date withdrawalDate) {
    // monthly withdrawal
    Calendar cal = Calendar.getInstance();
    cal.setTime(curDate);

    Calendar cal2 = Calendar.getInstance();
    cal2.setTime(withdrawalDate);

    return cal.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal.get(Calendar.MONTH) >= cal2.get(Calendar.MONTH);

  }


  // calculate payment amount based on the given loan paramerters.
  public abstract MonetaryAmount calculateInstallmentAmount(LoanParameter param);

  // return irr % per period
  public abstract double irr(LoanParameter param);


  /**
   * npva = ln[(1 - (PV x r)/PMT)^(-1) ] / ln (1 + r)
   * <p>
   * where npva: number of periods
   * PV: loanAmount
   * r: periodic interest rate in decimal not percentage.
   * PMT: payment amount per period
   * ln: logarithm base e, which e = 2.71828...
   * <p>
   * e.g. given a loan amount A, interest rate per month B and payment amount per month C,
   * we can find the number of payments needs to pay off the loan amount A.
   */

  public static int calculateNumberOfPaymentPeriods(double loanAmount, double ratePerPeriod, double paymentAmountPerPeriod) {

    int n = 0;
    n = roundUp(Math.log(Math.pow(1 - (loanAmount * ratePerPeriod / paymentAmountPerPeriod), -1)) / Math.log(1 + ratePerPeriod));

    return n;
  }

  /**
   * PMT = r * PV / (1 - (1 + r)^-n )
   * where r: interest rate per period
   * PV: loan amount
   * n: number of loan periods, i.e. loan term
   * PMT: installment amount each period
   * <p>
   * Note: r and n must agree each other, i.e. if n is in month, r should also be in month.
   * payment is done at the end of each period.
   */

    /*
    public static double pmt(LoanParameter param){
        double r = calculatePeriodicEffectiveInterestRate(param);

        double paymentAmount = r * param.getLoanAmount() / (1 - Math.pow((1 + r), -1* param.getNumberOfPeriods()));

        return paymentAmount;
    }

    */
  public static int roundUp(double d) {
    double dAbs = Math.abs(d);
    int i = (int) dAbs;
    double result = dAbs - (double) i;
    if (result == 0.0) {
      return (int) d;
    } else {
      return (int) d < 0 ? -(i + 1) : i + 1;
    }
  }

  public static Date getNextPaymentDate(Date startDate, int rule) {
    // rule  actual/365
    Calendar cal = Calendar.getInstance();
    cal.setTime(startDate);
    int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

    int currentDay = cal.get(Calendar.DATE);
    int daysTillEndOfMonth = days - currentDay + 1;
    int daysLeft = days - daysTillEndOfMonth;

    //System.out.println("days in month of "+ startDate + " : "+ days +", days end of month:"+ daysTillEndOfMonth +", daysLeft:"+ daysLeft);

    if (daysLeft < 0) {
      cal.set(Calendar.DATE, days);
    } else if (daysLeft == 0) {
      cal.add(Calendar.MONTH, 1);
      cal.set(Calendar.DATE, 1);
    } else if (daysLeft > 0) {
      cal.add(Calendar.MONTH, 1);
      cal.set(Calendar.DATE, daysLeft + 1);
    }


    return cal.getTime();
  }
}
