package com.gl.csf.underwriting.ui.component.underwriting.underwriting.offer;

import com.gl.csf.common.util.MonetaryRangeValidator;
import com.gl.csf.underwriting.api.offeramount.command.MakeOfferCommand;
import com.gl.csf.underwriting.common.model.offeramount.Offer;
import com.gl.csf.underwriting.common.model.parameter.LoanProductTemplate;
import com.gl.csf.underwriting.common.model.product.ProductType;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.query.application.underwriting.offeramount.OfferRepository;
import com.gl.csf.underwriting.query.application.underwriting.productinfo.ProductInformationRepository;
import com.gl.csf.underwriting.query.application.util.CurrencyUtil;
import com.gl.csf.underwriting.service.LoanProductTemplateService;
import com.gl.csf.underwriting.ui.util.NumeralFieldFormatterUtils;
import com.gl.csf.underwriting.ui.util.StringToMonetaryAmountConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.data.domain.Sort;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
@SpringComponent
@UIScope
public class OfferComponent extends OfferComponentDesign {
  private final Binder<Offer> offerBinder = new BeanValidationBinder<>(Offer.class);
  private final OfferRepository offerRepository;
  private final ProductInformationRepository productInformationRepository;
  private final LoanProductTemplateService loanProductTemplateService;
  private String applicationId;

  @Inject
  public OfferComponent(CommandGateway commandGateway, OfferRepository offerRepository, ProductInformationRepository productInformationRepository, LoanProductTemplateService loanProductTemplateService) {
    this.offerRepository = offerRepository;
    this.productInformationRepository = productInformationRepository;
    this.loanProductTemplateService = loanProductTemplateService;

    initializeBinder(offerBinder);
    fetchOfferHistoryComponent();

    NumeralFieldFormatterUtils.formatNumeralTextField(offerAmountTextField);

    makeOfferButton.setEnabled(false);

    makeOfferButton.addClickListener(event -> {
      commandGateway.send(new MakeOfferCommand(this.applicationId, offerBinder.getBean()));
      makeOfferButton.setEnabled(false);
      offerBinder.setBean(new Offer());
      fetchOfferHistoryComponent();
    });

    offerBinder.addStatusChangeListener(e -> makeOfferButton.setEnabled(e.getBinder().isValid()));
  }

  public void setApplicationId(String applicationId){
    this.applicationId = applicationId;
    fetchOfferHistoryComponent();
    setOfferAmountValidator();
  }

  private void setOfferAmountValidator() {
    Optional<ProductInformationDTO> optionalProductType = productInformationRepository.findByApplicationId(applicationId);

    if (optionalProductType.isPresent()) {
      ProductType productType = optionalProductType.get().getLoanType();

      // Fetch loan product template
      Optional<LoanProductTemplate> optionalLoanProductTemplate = loanProductTemplateService.getProductTemplate(productType);
      if (!optionalLoanProductTemplate.isPresent())
        throw new RuntimeException("There are no product available. Please contact your support");

      LoanProductTemplate loanProductTemplate = optionalLoanProductTemplate.get();

      // Bind loan amount field with minimum loan and maximum loan amount validator
      MonetaryAmount minimumLoanAmount = loanProductTemplate.getMinimumLoanAmount();
      MonetaryAmount maximumLoanAmount = loanProductTemplate.getMaximumLoanAmount();

      offerBinder.forField(offerAmountTextField)
              .withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
              .withValidator(new MonetaryRangeValidator(
                      "Minimum loan: " + minimumLoanAmount + " Maximum loan: " + maximumLoanAmount,
                      minimumLoanAmount, maximumLoanAmount))
              .bind("offerAmount");
    }
  }

  private void fetchOfferHistoryComponent() {
    Sort sort = new Sort(Sort.Direction.DESC, "ratedDate");
    List<Offer> offers = offerRepository.findAllByApplicationId(this.applicationId, sort);

    offerHistoryLayout.removeAllComponents();

    for (Offer offer : offers)
      offerHistoryLayout.addComponent(new OfferHistoryListComponent(offer));
  }

  private void initializeBinder(Binder<Offer> binder){
    Objects.requireNonNull(binder);
    binder.bind(reasonTextField, "offerReason");
    offerBinder.setBean(new Offer());
  }
}
