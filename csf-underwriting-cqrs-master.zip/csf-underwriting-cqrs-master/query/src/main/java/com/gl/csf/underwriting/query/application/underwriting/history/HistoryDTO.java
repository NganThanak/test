package com.gl.csf.underwriting.query.application.underwriting.history;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 21, 2017.
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class HistoryDTO {
  @Id
  private String id;
  private String applicationId;
  private LocalDateTime occurredSince;
  private String actorId;
  private String action;

  @Type(type = "text")
  private String description;
}
