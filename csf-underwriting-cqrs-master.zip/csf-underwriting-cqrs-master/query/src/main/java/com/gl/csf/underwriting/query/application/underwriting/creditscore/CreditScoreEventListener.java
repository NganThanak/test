package com.gl.csf.underwriting.query.application.underwriting.creditscore;

import com.gl.csf.underwriting.api.creditscoring.event.ApplicationRatedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/28/2017.
 */
@Component
public class CreditScoreEventListener {

  private final CreditScoreRepository creditScoreRepository;

  @Inject
  public CreditScoreEventListener(CreditScoreRepository creditScoreRepository) {
    this.creditScoreRepository = creditScoreRepository;
  }

  @EventHandler
  public void on(ApplicationRatedEvent event) {

    CreditScoreDTO creditScoreDTO = new CreditScoreDTO();
    creditScoreDTO.setApplicationId(event.getApplicationId());
    creditScoreDTO.setId(UUID.randomUUID().toString());
    creditScoreDTO.setRateOn(LocalDateTime.now());
    creditScoreDTO.setReason(event.getReason());
    creditScoreDTO.setScore(event.getScore());
    creditScoreDTO.setUnderwriter(event.getUnderwriter());

    creditScoreDTO.setCreditScoreDocumentDTOS(event.getDocuments());

    creditScoreRepository.save(creditScoreDTO);
  }
}
