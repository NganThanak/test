package com.gl.csf.underwriting.query.application.underwriting.offeramount;

import com.gl.csf.underwriting.common.model.offeramount.Offer;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/13/2017.
 */
public interface OfferRepository extends PagingAndSortingRepository<Offer, String> {
  List<Offer> findAllByApplicationId(String applicationId, Sort sort);
}
