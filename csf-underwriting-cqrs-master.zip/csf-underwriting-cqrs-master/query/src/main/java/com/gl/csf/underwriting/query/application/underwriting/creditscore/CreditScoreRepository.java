package com.gl.csf.underwriting.query.application.underwriting.creditscore;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/28/2017.
 */
@Repository
public interface CreditScoreRepository extends PagingAndSortingRepository<CreditScoreDTO, String> {
  List<CreditScoreDTO> findByApplicationIdOrderByRateOnDesc(String applicationId);
}
