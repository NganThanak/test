package com.gl.csf.underwriting.query.application.underwriting.ownerinfo;

import com.gl.csf.underwriting.common.model.owerinfo.PersonalInformationDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/8/2017.
 */
@Repository
public interface PersonalInfoRepository extends JpaRepository<PersonalInformationDTO, String>{
  public PersonalInformationDTO findByApplicationId(String applicationId);
}
