package com.gl.csf.underwriting.query.application.underwriting.loanapplicationheader;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/6/2017.
 */
public interface LoanApplicationHeaderRepository extends JpaRepository<LoanApplicationHeaderDTO, String> {
  public LoanApplicationHeaderDTO findByApplicationId(String applicationId);
}
