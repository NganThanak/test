package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import com.gl.csf.underwriting.api.application.event.FieldCheckRequestedEvent;
import com.gl.csf.underwriting.api.application.event.FieldCheckingResultSubmittedEvent;
import com.gl.csf.underwriting.api.application.event.UnderwritingFieldEditedEvent;
import com.gl.csf.underwriting.api.application.event.UnderwritingInitializedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.stream.Collectors;

/**
 * Created by p.ly on 10/5/2017.
 */
@Component
public class UnderwritingFieldEventListener {
  private final UnderwritingFieldRepository repository;

  @Inject
  public UnderwritingFieldEventListener(UnderwritingFieldRepository repository) {
    this.repository = repository;
  }

  @EventHandler
  public void on(UnderwritingInitializedEvent event) {
    repository.save(event.getUnderwritingFieldsDefinitions().entrySet().stream().map(entry -> new UnderwritingFieldDTO(event.getApplicationId(), entry.getKey(), "", entry.getValue().getName(), entry.getValue().getDescription(), false, entry.getValue().isDocumentRequired(), entry.getValue().isTextRequired(), entry.getValue().isMandatory())).collect(Collectors.toList()));
  }

  @EventHandler
  public void on(UnderwritingFieldEditedEvent event){
    UnderwritingFieldDTO underwritingFieldDTO = repository.findOne(event.getUnderwritingFieldId());
    underwritingFieldDTO.setContent(event.getContent());
    repository.save(underwritingFieldDTO);
  }

  @EventHandler
  public void on(FieldCheckingResultSubmittedEvent event){
    event.getFieldCheckResults().forEach(result->{
      UnderwritingFieldDTO underwritingFieldDTO = repository.findOne(result.getUnderwritingFieldId());
      underwritingFieldDTO.setContent(result.getText());
      underwritingFieldDTO.setFieldCheckRequested(false);
      repository.save(underwritingFieldDTO);
    });
  }
  
  @EventHandler
  public void on(FieldCheckRequestedEvent event) {
    event.getUnderwritingFields().keySet().forEach(underwritingFieldId -> {
      UnderwritingFieldDTO underwritingFieldDTO = repository.findOne(underwritingFieldId);
      underwritingFieldDTO.setFieldCheckRequested(true);
      repository.save(underwritingFieldDTO);
    });
  }
}
