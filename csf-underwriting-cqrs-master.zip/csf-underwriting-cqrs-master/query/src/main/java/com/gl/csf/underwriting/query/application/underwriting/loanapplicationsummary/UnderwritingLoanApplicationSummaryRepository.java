package com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/31/2017.
 */
public interface UnderwritingLoanApplicationSummaryRepository extends PagingAndSortingRepository<UnderwritingLoanApplicationSummaryDTO, String> {
//  @Query("select app from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 in (KEY(a)) and VALUE(a) is null)")
  @Query("select app from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 = a.role) and a.username is null")
  List<UnderwritingLoanApplicationSummaryDTO> findPublicApplicationByRole(String role);
//  @Query("select app from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 in (KEY(a)) and ?2 = VALUE(a))")
  @Query("select app from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 = a.role) and ?2 = a.username")
  List<UnderwritingLoanApplicationSummaryDTO> findPrivateApplicationByUsername(String role, String username);

//  @Query("select count(*) from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 in (KEY(a)) and VALUE(a) is null)")
  @Query("select count(*) from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 = a.role) and a.username is null")
  int countPublicApplicationByRole(String role);

//  @Query("select count(*) from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 in (KEY(a)) and ?2 = VALUE(a))")
  @Query("select count(*) from UnderwritingLoanApplicationSummaryDTO app join app.assignees a where (?1 = a.role) and ?2 = a.username")
  int countPrivateApplicationByUsername(String role, String username);
  
  //pending list
  @Query("select app from UnderwritingLoanApplicationSummaryDTO app join app.assignees a " +
          "where ('PENDING_UNDERWRITING' = app.applicationStatus) or ('UNDERWRITING_IN_PROGRESS' = app.applicationStatus) " +
          "order by app.applicationStatus asc, app.applicationDate desc")
  List<UnderwritingLoanApplicationSummaryDTO> findPendingApplicationByApplicationStatus();
  
  //counting pending
  @Query("select count(*) from UnderwritingLoanApplicationSummaryDTO app join app.assignees a " +
          "where ('PENDING_UNDERWRITING' = app.applicationStatus) or ('UNDERWRITING_IN_PROGRESS' = app.applicationStatus)")
  int countPendingApplicationByApplicationStatus();
}
