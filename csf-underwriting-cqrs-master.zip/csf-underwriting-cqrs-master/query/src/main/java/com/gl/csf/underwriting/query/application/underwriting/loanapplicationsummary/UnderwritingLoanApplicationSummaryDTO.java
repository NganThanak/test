package com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary;

import com.gl.csf.underwriting.common.model.application.ApplicationStatus;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * Created by p.ly on 8/21/2017.
 */
@Entity
@Data
public class UnderwritingLoanApplicationSummaryDTO {
  @Id
  private String id;

  @Column(name = "application_status")
  @Enumerated(EnumType.STRING)
  private ApplicationStatus applicationStatus;

  @Column(name = "reference_number")
  private String referenceNumber;

  @Column(name = "application_date")
  private LocalDateTime applicationDate;

  @Column(name = "customer_name")
  private String customerName;

  @Column(name = "gender")
  private String gender;

  @Column(name = "phone_number")
  private String phoneNumber;

  @Column(name = "business_name")
  private String businessName;

  @Column(name = "address")
  private String address;

  @Column(name = "state")
  private String state;

  @Column(name = "district")
  private String district;

  @Column(name = "township")
  private String township;

  @Column(name = "version")
  private long version;
  
  @Column(name ="decline_reason")
  private String declineReason;

  @ElementCollection(fetch = FetchType.EAGER)
  private Set<Assignee> assignees;
}
