package com.gl.csf.underwriting.query.application.customer.loanapplication;

import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.common.model.customer.CustomerApplicationStatus;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Component
public class LoanApplicationEventListener {

  private final LoanApplicationRepository loanApplicationRepository;

  @Inject
  public LoanApplicationEventListener(LoanApplicationRepository loanApplicationRepository) {
    this.loanApplicationRepository = loanApplicationRepository;
  }

  @EventHandler
  public void on(ApplicationCreatedEvent event){
    LoanApplicationDTO loanApplicationDTO = new LoanApplicationDTO();
    loanApplicationDTO.setCreatedDate(LocalDate.now());
    loanApplicationDTO.setId(event.getId());
    loanApplicationDTO.setReferenceNumber(event.getReferenceNumber());
    loanApplicationDTO.setApplication(event.getApplication());
    loanApplicationDTO.setCustomerApplicationStatus(CustomerApplicationStatus.SAVED);
    loanApplicationRepository.save(loanApplicationDTO);
  }

  @EventHandler
  public void on(ApplicationSavedEvent event){
    updateLoanApplication(event.getId(), event.getApplication(), CustomerApplicationStatus.SAVED);
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    updateLoanApplication(event.getApplicationId(), event.getApplication(),
            CustomerApplicationStatus.APPLICATION_IN_PROGRESS);
  }

  @EventHandler
  public void on(ApplicationDraftDeletedEvent event){
    Optional<LoanApplicationDTO> optionalLoanApplication = loanApplicationRepository.findById(event.getId());
    if (!optionalLoanApplication.isPresent()) {
      return;
    }

    LoanApplicationDTO loanApplicationDTO = optionalLoanApplication.get();
    loanApplicationDTO.setCustomerApplicationStatus(CustomerApplicationStatus.APPLICATION_DECLINED);
    loanApplicationRepository.save(loanApplicationDTO);
  }

  private void updateLoanApplication(String id, Application application, CustomerApplicationStatus status) {
    Optional<LoanApplicationDTO> optionalLoanApplication = loanApplicationRepository.findById(id);

    if (!optionalLoanApplication.isPresent()) {
      return;
    }

    LoanApplicationDTO loanApplicationDTO = optionalLoanApplication.get();
    loanApplicationDTO.setApplication(application);
    loanApplicationDTO.setCustomerApplicationStatus(status);

    loanApplicationRepository.save(loanApplicationDTO);
  }

  @EventHandler
  public void on(ApplicationApprovedEvent event){
    LoanApplicationDTO loanApplicationDTO = loanApplicationRepository.findOne(event.getApplicationId());
    loanApplicationDTO.setCustomerApplicationStatus(CustomerApplicationStatus.APPLICATION_VALIDATED);

    loanApplicationRepository.save(loanApplicationDTO);
  }

  @EventHandler
  public void on(ApplicationRejectedEvent event) {
    LoanApplicationDTO loanApplicationDTO = loanApplicationRepository.findOne(event.getApplicationId());
    loanApplicationDTO.setCustomerApplicationStatus(CustomerApplicationStatus.APPLICATION_DECLINED);
    loanApplicationDTO.setRejectedDate(LocalDate.now());
    loanApplicationRepository.save(loanApplicationDTO);
  }

  @EventHandler
  public void on(ApplicationDeclinedEvent event) {
    LoanApplicationDTO loanApplicationDTO = loanApplicationRepository.findOne(event.getApplicationId());
    loanApplicationDTO.setCustomerApplicationStatus(CustomerApplicationStatus.APPLICATION_DECLINED);
    loanApplicationDTO.setRejectedDate(LocalDate.now());
    loanApplicationRepository.save(loanApplicationDTO);
  }
}
