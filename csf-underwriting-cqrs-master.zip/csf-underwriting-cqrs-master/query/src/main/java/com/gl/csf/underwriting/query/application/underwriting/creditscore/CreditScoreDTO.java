package com.gl.csf.underwriting.query.application.underwriting.creditscore;

import com.gl.csf.underwriting.api.document.CreditScoreDocument;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/28/2017.
 */
@Entity
@Data
public class CreditScoreDTO {
  @Id
  @Column(name = "credit_score_id")
  private String id;

  private String applicationId;
  private String underwriter;

  @OneToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
  @JoinTable(name = "CREDIT_CREDIT_DOCUMENT", joinColumns = { @JoinColumn(name = "credit_score_id") }, inverseJoinColumns = { @JoinColumn(name = "credit_score_documents_id") })
  private List<CreditScoreDocument> creditScoreDocumentDTOS;

  @NotEmpty
  private String score;

  @Type(type = "text")
  @NotEmpty
  private String reason;

  private LocalDateTime rateOn;

  public CreditScoreDTO(){
  }

  public static CreditScoreDTO create(){
    CreditScoreDTO creditScoreDTO = new CreditScoreDTO();
    return creditScoreDTO;
  }
}
