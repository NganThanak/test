package com.gl.csf.underwriting.query.application.underwriting.businessinfo.business;

import com.gl.csf.underwriting.common.model.businessinfo.Business;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/8/2017.
 */
public interface BusinessRepository extends PagingAndSortingRepository<Business, String> {
  Optional<Business> findFirstByApplicationId(String applicationId);

  Business findByApplicationId(String applicationId);
}
