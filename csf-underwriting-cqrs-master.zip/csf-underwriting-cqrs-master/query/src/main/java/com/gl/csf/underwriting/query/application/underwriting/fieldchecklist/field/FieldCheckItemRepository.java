package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 14/10/2017.
 */
public interface FieldCheckItemRepository extends JpaRepository<FieldCheckItemDTO, String> {
  List<FieldCheckItemDTO> findAllByApplicationIdAndIsSubmitted(String applicationId, Boolean isSubmitted);
  FieldCheckItemDTO findOneByUnderwritingFieldIdAndIsSubmitted(String underwritingFieldId, Boolean isSubmitted);
}
