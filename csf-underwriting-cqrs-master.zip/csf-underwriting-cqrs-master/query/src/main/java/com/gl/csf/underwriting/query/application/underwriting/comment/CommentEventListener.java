package com.gl.csf.underwriting.query.application.underwriting.comment;

import com.gl.csf.underwriting.api.application.event.CommentCreatedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 9/9/2017.
 */
@Component
public class CommentEventListener {
  private final CommentRepository commentRepository;
  
  @Inject
  public CommentEventListener(CommentRepository commentRepository) {
    this.commentRepository = commentRepository;
  }
  
  @EventHandler
  public void on(CommentCreatedEvent event){

    CommentDTO commentDTO = new CommentDTO();
    commentDTO.setId(UUID.randomUUID().toString());
    commentDTO.setApplicationId(event.getApplicationId());
    commentDTO.setDescription(event.getDescription());
    commentDTO.setUsername(event.getUsername());
    commentDTO.setCommentedDate(LocalDateTime.now());

    commentRepository.save(commentDTO);
  }
}