package com.gl.csf.underwriting.query.application.underwriting.history;

import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/10/2017.
 */
@Component
public class HistoryEventListener {
  private final HistoryRepository repository;
  private final I18nMessage i18nMessage;

  public HistoryEventListener(HistoryRepository repository, I18nMessage i18nMessage){
    this.repository = repository;
	  this.i18nMessage = i18nMessage;
  }

  @EventHandler
  private void on(ApplicationSubmittedEvent event){
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), event.getSubmittedDate(), event.getUsername(), i18nMessage.getMessage("application.submitted.action"), i18nMessage.getMessage("application.submitted.description"));
    repository.save(history);
  }

  @EventHandler
  private void on(ApplicationBookedForUnderwritingEvent event){
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), event.getOccurredOn(), event.getAssigneeId(), i18nMessage.getMessage("application.booked.task.action"), i18nMessage.getMessage("application.booked.task.description"));
    repository.save(history);
  }

	@EventHandler
	private void on(ApplicationDeclinedEvent event){
		HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), event.getRecordedBy(), i18nMessage.getMessage("application.declined.action"), i18nMessage.getMessage("application.declined.description", event.getDeclineReason()));
		repository.save(history);
	}

  @EventHandler
  private void on(FieldCheckRequestedEvent event){
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), event.getUnderwriterId(), i18nMessage.getMessage("requested.field.check.action"), i18nMessage.getMessage("requested.field.check.description"));
    repository.save(history);
  }

  @EventHandler
  private void on(FieldCheckingResultSubmittedEvent event){
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), event.getUsername(), i18nMessage.getMessage("submit.field.check.action"), i18nMessage.getMessage("submit.field.check.description"));
    repository.save(history);
  }

  @EventHandler
  private void on(ApplicationApprovalRecommendedEvent event){
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), event.getApprovalRecommendedOn(), event.getUnderwriterId(), i18nMessage.getMessage("application.recommended.approve.action"), i18nMessage.getMessage("application.recommended.approve.description"));
    repository.save(history);
  }

  @EventHandler
  public void on(ApplicationRejectionRecommendedEvent event) {
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), event.getUnderwriterId(), i18nMessage.getMessage("application.recommended.reject.action"), i18nMessage.getMessage("application.recommended.reject.description"));
    repository.save(history);
  }

  @EventHandler
  private void on(ApplicationApprovedEvent event) {
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), event.getApprovedOn(), event.getUnderwriterId(), i18nMessage.getMessage("application.approval.action"), i18nMessage.getMessage("application.approval.description"));
    repository.save(history);
  }

  @EventHandler
  private void on(ApplicationRejectedEvent event) {
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), event.getRejectedOn(), event.getUnderwriterId(), i18nMessage.getMessage("application.rejected.action"), i18nMessage.getMessage("application.rejected.description"));
    repository.save(history);
  }

}
