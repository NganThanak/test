package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldhistory;

import lombok.Data;
import org.hibernate.annotations.Type;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by p.ly on 10/7/2017.
 */
@Data
@Entity
public class UnderwritingFieldContentHistoryDTO {

  @Id
  private UUID id;
  private String applicationId;
  private String underwritingFieldId;
  @Type(type = "text")
  private String content;
  private String name;
  private LocalDateTime dateModified;
  private boolean isSubmitted;
}
