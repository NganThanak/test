package com.gl.csf.underwriting.query.application.underwriting.businessinfo.branch;

import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import com.gl.csf.underwriting.common.model.businessinfo.BranchStatus;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/4/2017.
 */
public interface BranchRepository extends PagingAndSortingRepository<Branch, String> {
  List<Branch> findAllByApplicationId(String applicationId);
  List<Branch> findAllByApplicationIdAndBranchStatus(String applicationId, BranchStatus branchStatus);
  Optional<Branch> findFirstByBranchId(String branchId);
}
