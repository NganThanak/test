package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.comment;

import com.gl.csf.underwriting.api.application.event.CommentEditedEvent;
import com.gl.csf.underwriting.api.application.event.FieldCheckCommentSavedEvent;
import com.gl.csf.underwriting.api.application.event.FieldCheckingResultSubmittedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/29/2017.
 */
@Component
public class CommentFieldCheckEventListener {

	private final CommentFieldCheckRepository repository;

	public CommentFieldCheckEventListener(CommentFieldCheckRepository commentFieldCheckRepository) {
		this.repository = commentFieldCheckRepository;
	}

	@EventHandler
	public void on(FieldCheckCommentSavedEvent event){
		CommentFieldCheckDTO commentFieldCheckDTO = new CommentFieldCheckDTO();
		commentFieldCheckDTO.setId(UUID.randomUUID().toString());
		commentFieldCheckDTO.setCommentedDate(LocalDateTime.now());
		commentFieldCheckDTO.setApplicationId(event.getApplicationId());
		commentFieldCheckDTO.setUnderwritingFieldId(event.getUnderwritingFieldId());
		commentFieldCheckDTO.setBy(event.getUsername());
		commentFieldCheckDTO.setSubmitted(true);
		commentFieldCheckDTO.setComment(event.getComment());
		repository.save(commentFieldCheckDTO);
	}

	@EventHandler
	public void on(CommentEditedEvent event){
		CommentFieldCheckDTO commentFieldCheckDTO = repository.findOne(event.getCommentId());
		commentFieldCheckDTO.setComment(event.getContent());
		repository.save(commentFieldCheckDTO);
	}

	@EventHandler
	private void on(FieldCheckingResultSubmittedEvent event){
		event.getFieldCheckResults().forEach(result ->{
			if(result.getComment()!=null) {
				CommentFieldCheckDTO commentFieldCheckDTO = new CommentFieldCheckDTO();
				commentFieldCheckDTO.setId(UUID.randomUUID().toString());
				commentFieldCheckDTO.setCommentedDate(LocalDateTime.now());
				commentFieldCheckDTO.setApplicationId(event.getApplicationId());
				commentFieldCheckDTO.setUnderwritingFieldId(result.getUnderwritingFieldId());
				commentFieldCheckDTO.setBy(event.getUsername());
				commentFieldCheckDTO.setComment(result.getComment());
				commentFieldCheckDTO.setSubmitted(true);
				repository.save(commentFieldCheckDTO);
			}
		});
	}
}
