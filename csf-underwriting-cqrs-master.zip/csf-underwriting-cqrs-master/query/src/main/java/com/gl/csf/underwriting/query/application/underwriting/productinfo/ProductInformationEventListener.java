package com.gl.csf.underwriting.query.application.underwriting.productinfo;

import com.gl.csf.underwriting.api.application.event.ApplicationCreatedEvent;
import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.api.application.productinfo.event.ProductInformationUpdateEvent;
import com.gl.csf.underwriting.common.model.loanpurpose.LoanPurpose;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/14/2017.
 */
@Component
public class ProductInformationEventListener {

  private final ProductInformationRepository repository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public ProductInformationEventListener(ProductInformationRepository repository, HistoryRepository historyRepository, I18nMessage i18nMessage) {
    this.repository = repository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    Optional<ProductInformationDTO> optionalProductInformation = repository.findByApplicationId(event.getApplicationId());

    optionalProductInformation.ifPresent(productInformation->{

      ProductInformationDTO productInformationDTO = event.getProductInformationDTO();
      productInformationDTO.setId(productInformation.getId());
      productInformationDTO.setApplicationId(productInformation.getApplicationId());
      productInformationDTO.setReferenceId(productInformation.getReferenceId());
      productInformationDTO.setInterest(event.getApplication().getLoanProduct().getInterestRate());

      repository.save(productInformationDTO);
    });
  }

  @EventHandler
  public void on (ApplicationCreatedEvent event){
    ProductInformationDTO productInformation = new ProductInformationDTO();
    List<LoanPurpose> loanPurposes = new ArrayList<>();
    productInformation.setId(UUID.randomUUID().toString());
    productInformation.setApplicationId(event.getId());
    productInformation.setReferenceId(event.getReferenceNumber());
    productInformation.setLoanPurposes(loanPurposes);
    repository.save(productInformation);
  }

  @EventHandler
  public void on(ProductInformationUpdateEvent event){
    //save to history database
    saveHistory(event.getProductInformation().getApplicationId(), event.getUserName());

    repository.save(event.getProductInformation());
  }

  private void saveHistory(String applicationId, String userName) {
    Optional<ProductInformationDTO> optionalProductInfo = repository.findByApplicationId(applicationId);

    optionalProductInfo.ifPresent(productInfo->{
      String purpose = "-";
     /* if(!productInfo.getLoanPurposes().isEmpty()) {
        for (int i = 0; i <= productInfo.getLoanPurposes().size(); i++)
          purpose += "," + productInfo.getLoanPurposes().get(i).getPurpose();
      }*/

      HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), applicationId, LocalDateTime.now(), userName,
              i18nMessage.getMessage("application.updated.product.info"),
              i18nMessage.getMessage("application.updated.product.info.description", productInfo.getLoanAmount(),
                      productInfo.getTerm(), productInfo.getPaymentFrequency() != null ? productInfo.getPaymentFrequency() : "-",
                      productInfo.getInterest(), productInfo.getLoanType(), purpose));

      historyRepository.save(history);
    });
  }
}
