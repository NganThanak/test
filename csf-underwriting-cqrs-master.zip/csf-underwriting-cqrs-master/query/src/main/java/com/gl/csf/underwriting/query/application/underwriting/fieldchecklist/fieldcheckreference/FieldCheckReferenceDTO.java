package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 10/17/2017.
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class FieldCheckReferenceDTO {
  @Id
  private String Id;
  private String fieldCheckId;
  @Type(type = "text")
  private String text;
  @Type(type = "text")
  private String comment;
  private String name;
  private String description;
  private String applicationId;
  @OneToMany(mappedBy = "fieldCheckReference", cascade = CascadeType.ALL, orphanRemoval = true)
  private Set<FieldCheckReferenceDocumentDTO> referenceDocuments;
  private String fieldCheckerId;
  private LocalDateTime submittedDate;
}
