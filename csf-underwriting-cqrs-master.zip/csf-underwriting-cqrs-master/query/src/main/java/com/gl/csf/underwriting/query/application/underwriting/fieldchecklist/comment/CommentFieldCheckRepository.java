package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.comment;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/9/2017.
 */
@Repository
public interface CommentFieldCheckRepository extends PagingAndSortingRepository<CommentFieldCheckDTO, String> {
	Integer countByUnderwritingFieldIdAndIsSubmitted(String underwritingFieldId, boolean submit);
	List<CommentFieldCheckDTO> findByUnderwritingFieldIdAndIsSubmittedOrderByCommentedDateDesc(String underwritingFieldId, boolean isSubmitted, Pageable pageable);
	List<CommentFieldCheckDTO> findByApplicationId(String applicationId);
	List<CommentFieldCheckDTO> findByUnderwritingFieldId(String id);
	CommentFieldCheckDTO findFirstByUnderwritingFieldIdOrderByCommentedDateDesc(String underwritingFieldId);
}
