package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.document;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by p.ly on 9/30/2017.
 */
@Repository
public interface UnderwritingFieldDocumentRepository extends PagingAndSortingRepository<UnderwritingFieldDocumentDTO, String> {
  Integer countByDocumentDescriptorApplicationIdAndUnderwritingFieldIdAndIsSubmitted(String applicationId, String underwritingFieldId, boolean submit);
  List<UnderwritingFieldDocumentDTO> findByDocumentDescriptorApplicationIdAndUnderwritingFieldIdAndIsSubmittedOrderByDateModifiedDesc(String applicationId, String underwritingFieldId, boolean submit);
  void deleteByDocumentDescriptor(DocumentDescriptor documentDescriptor);
  UnderwritingFieldDocumentDTO findByDocumentDescriptor(DocumentDescriptor documentDescriptor);
}
