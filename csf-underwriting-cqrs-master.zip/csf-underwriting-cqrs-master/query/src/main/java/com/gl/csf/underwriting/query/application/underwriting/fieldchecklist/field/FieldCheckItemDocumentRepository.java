package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/10/2017.
 */
public interface FieldCheckItemDocumentRepository extends JpaRepository<FieldCheckItemDocumentDTO, DocumentDescriptor> {
  List<FieldCheckItemDocumentDTO> findAllByFieldCheckItem(FieldCheckItemDTO fieldCheckItem);
  FieldCheckItemDocumentDTO findByUnderwritingFieldId(String underwritingFieldId);
  int countAllByFieldCheckItem(FieldCheckItemDTO fieldCheckItem);
}
