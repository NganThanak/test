package com.gl.csf.underwriting.query.application.underwriting.product;

import lombok.Data;

/**
 * Created by jerome on 8/30/17.
 */
@Data
public class ProductInformationDTO {
  private String period;
  private String installment;
  private String interest;
  private String principal;
  private String remainingBalance;
}
