package com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary;

import lombok.Data;

import javax.persistence.Embeddable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 09/10/2017.
 */
@Data
@Embeddable
public class Assignee {
  private String role;
  private String username;

  public Assignee(){
  }

  public Assignee(String role, String username){
    this.role = role;
    this.username = username;
  }

  @Override
  public String toString() {
    if(username == null)
      return "";
    return username;
  }
}
