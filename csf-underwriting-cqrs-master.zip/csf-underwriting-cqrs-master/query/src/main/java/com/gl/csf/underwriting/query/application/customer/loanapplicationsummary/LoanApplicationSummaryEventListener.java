package com.gl.csf.underwriting.query.application.customer.loanapplicationsummary;


import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.common.model.application.ApplicationStatus;
import com.gl.csf.underwriting.common.model.customer.CustomerApplicationStatus;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Optional;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 23/08/2017.
 */
@Component
public class LoanApplicationSummaryEventListener {
  private final LoanApplicationSummaryRepository loanApplicationSummaryRepository;

  @Inject
  public LoanApplicationSummaryEventListener(LoanApplicationSummaryRepository loanApplicationSummaryRepository) {
    this.loanApplicationSummaryRepository = loanApplicationSummaryRepository;
  }

  @EventHandler
  public void on(ApplicationCreatedEvent event){
    LoanApplicationSummaryDTO loanApplicationList = new LoanApplicationSummaryDTO();
    loanApplicationList.setCreatedDate(LocalDate.now());
    loanApplicationList.setId(event.getId());
    loanApplicationList.setReferenceNumber(event.getReferenceNumber());
    loanApplicationList.setUsername(event.getApplication().getApplicant().getUsername());

    loanApplicationList.setStatus(CustomerApplicationStatus.SAVED.name());

    if(event.getApplication().getLoanProduct() != null && event.getApplication().getLoanProduct().getProductType() != null)
      loanApplicationList.setLoanType(event.getApplication().getLoanProduct().getProductType().name());

    loanApplicationSummaryRepository.save(loanApplicationList);
  }

  @EventHandler
  public void on(ApplicationSavedEvent event){
    updateLoanApplication(event.getId(), event.getApplication(), CustomerApplicationStatus.SAVED);
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    updateLoanApplication(event.getApplicationId(), event.getApplication(),
            CustomerApplicationStatus.APPLICATION_IN_PROGRESS);
  }

  @EventHandler
  public void on(ApplicationDraftDeletedEvent event){
    Optional<LoanApplicationSummaryDTO> optionalLoanApplicationList = loanApplicationSummaryRepository.findById(event.getId());

    if (!optionalLoanApplicationList.isPresent()) {
      return;
    }

    loanApplicationSummaryRepository.delete(event.getId());
  }

  @EventHandler
  public void on(ApplicationDeclinedEvent event){
    LoanApplicationSummaryDTO loanApplicationSummary = loanApplicationSummaryRepository.findOne(event.getApplicationId());
    loanApplicationSummary.setStatus(ApplicationStatus.DECLINED.name());
    loanApplicationSummaryRepository.save(loanApplicationSummary);
  }

  @EventHandler
  public void on(ApplicationRejectedEvent event){
    LoanApplicationSummaryDTO loanApplicationSummary = loanApplicationSummaryRepository.findOne(event.getApplicationId());
    loanApplicationSummary.setStatus(ApplicationStatus.REJECTED.name());
    loanApplicationSummaryRepository.save(loanApplicationSummary);
  }

  private void updateLoanApplication(String id, Application application, CustomerApplicationStatus customerApplicationStatus) {
    Optional<LoanApplicationSummaryDTO> optionalLoanApplicationList = loanApplicationSummaryRepository.findById(id);

    if (!optionalLoanApplicationList.isPresent()) {
      return;
    }

    LoanApplicationSummaryDTO loanApplicationList = optionalLoanApplicationList.get();

    loanApplicationList.setStatus(customerApplicationStatus.name());

    if(application.getLoanProduct() != null && application.getLoanProduct().getProductType() != null)
      loanApplicationList.setLoanType(application.getLoanProduct().getProductType().name());

    loanApplicationSummaryRepository.save(loanApplicationList);
  }

  @EventHandler
  public void on(ApplicationApprovedEvent event) {
    LoanApplicationSummaryDTO loanApplicationSummary = loanApplicationSummaryRepository.findOne(event.getApplicationId());
    loanApplicationSummary.setStatus(CustomerApplicationStatus.APPLICATION_VALIDATED.name());
    loanApplicationSummaryRepository.save(loanApplicationSummary);
  }
}
