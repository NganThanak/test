package com.gl.csf.underwriting.query.application.underwriting.loanapplicationheader;

import com.gl.csf.underwriting.api.application.businessinfo.business.event.BusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.api.application.ownerinfo.event.PersonalInformationUpdatedEvent;
import com.gl.csf.underwriting.api.application.productinfo.event.ProductInformationUpdateEvent;
import com.gl.csf.underwriting.api.creditscoring.event.ApplicationRatedEvent;
import com.gl.csf.underwriting.common.model.application.ApplicationStatus;
import com.gl.csf.underwriting.common.model.user.Role;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/6/2017.
 */
@Component
public class LoanApplicationHeaderEventListener {
  private final LoanApplicationHeaderRepository repository;

  @Inject
  public LoanApplicationHeaderEventListener(LoanApplicationHeaderRepository repository) {
    this.repository = repository;
  }

  @EventHandler
  public void on(ApplicationCreatedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = new LoanApplicationHeaderDTO();
    loanApplicationHeader.setId(UUID.randomUUID().toString());
    loanApplicationHeader.setApplicationId(event.getId());
    loanApplicationHeader.setReferenceId(event.getReferenceNumber());
    loanApplicationHeader.setBusinessName(event.getApplication().getApplicant().getBusinessName());
    loanApplicationHeader.setRequestAmount(event.getApplication().getLoanProduct().getLoanAmount());
    loanApplicationHeader.setTerm(event.getApplication().getLoanProduct().getTerm());
    loanApplicationHeader.setCustomerName(event.getApplication().getApplicant().getFullName());
    loanApplicationHeader.setProductName(event.getApplication().getLoanProduct().getProductType());
    loanApplicationHeader.setStatus(ApplicationStatus.DRAFT);
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setStatus(ApplicationStatus.PENDING_UNDERWRITING);
    loanApplicationHeader.setTerm(event.getApplication().getLoanProduct().getTerm());
    loanApplicationHeader.setProductName(event.getApplication().getLoanProduct().getProductType());
    loanApplicationHeader.setRequestAmount(event.getApplication().getLoanProduct().getLoanAmount());
    loanApplicationHeader.setBusinessName(event.getApplication().getApplicant().getBusinessName());
    loanApplicationHeader.setCustomerName(event.getApplication().getApplicant().getFullName());
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(ApplicationBookedForUnderwritingEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());

    if(event.getRole().equals(Role.JUNIOR_UNDERWRITER.toString())){
      loanApplicationHeader.setStatus(ApplicationStatus.UNDERWRITING_IN_PROGRESS);
    } else if (event.getRole().equals(Role.FIELD_CHECKER.toString())){
      loanApplicationHeader.setStatus(ApplicationStatus.FIELD_CHECK_IN_PROGRESS);
    } else if (event.getRole().equals(Role.SENIOR_UNDERWRITER.toString())){
      loanApplicationHeader.setStatus(ApplicationStatus.REVIEW_IN_PROGRESS);
    } else {
      throw new IllegalArgumentException("Unsupported role: " + event.getRole());
    }

    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(FieldCheckingResultSubmittedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    // TODO: Classify if it the task goes back to underwriter or senior underwriter
    loanApplicationHeader.setStatus(loanApplicationHeader.isHasRecommendedDecision() ? ApplicationStatus.REVIEW_IN_PROGRESS : ApplicationStatus.UNDERWRITING_IN_PROGRESS);

    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(PersonalInformationUpdatedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getId());
    loanApplicationHeader.setCustomerName(event.getPersonalInformationDTO().getFullName());
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(BusinessInfoUpdatedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setBusinessName(event.getBusiness().getBusinessName());
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(ProductInformationUpdateEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getId());
    loanApplicationHeader.setProductName(event.getProductInformation().getLoanType());
    loanApplicationHeader.setTerm(event.getProductInformation().getTerm());
    loanApplicationHeader.setRequestAmount(event.getProductInformation().getLoanAmount());
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(ApplicationRatedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setCreditScore(event.getScore());
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(FieldCheckRequestedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setStatus(ApplicationStatus.WAITING_FOR_FIELD_CHECK);
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(ApplicationRejectionRecommendedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setStatus(ApplicationStatus.WAITING_FOR_REVIEW);
    loanApplicationHeader.setUnderwritingDecision("Recommended to Reject");
    loanApplicationHeader.setHasRecommendedDecision(true);
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(ApplicationApprovalRecommendedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setUnderwritingDecision("Recommended to Approve");
    loanApplicationHeader.setStatus(ApplicationStatus.WAITING_FOR_REVIEW);
    loanApplicationHeader.setHasRecommendedDecision(true);
    repository.save(loanApplicationHeader);
  }

  @EventHandler
  public void on(ApplicationRejectedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setStatus(ApplicationStatus.REJECTED);
    loanApplicationHeader.setUnderwritingDecision("Rejected Application");
    repository.save(loanApplicationHeader);
  }
  
  @EventHandler
  public void on(ApplicationApprovedEvent event){
    LoanApplicationHeaderDTO loanApplicationHeader = repository.findByApplicationId(event.getApplicationId());
    loanApplicationHeader.setStatus(ApplicationStatus.APPROVED);
    loanApplicationHeader.setUnderwritingDecision("Approved Application");
    repository.save(loanApplicationHeader);
  }
}
