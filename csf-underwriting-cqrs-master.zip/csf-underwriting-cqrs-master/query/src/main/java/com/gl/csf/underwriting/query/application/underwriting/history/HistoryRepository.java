package com.gl.csf.underwriting.query.application.underwriting.history;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/10/2017.
 */
public interface HistoryRepository extends JpaRepository<HistoryDTO, String> {
  Page<HistoryDTO> findAllByApplicationId(Pageable pageable, String applicationId);
  int countAllByApplicationId(String applicationId);
}
