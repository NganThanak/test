package com.gl.csf.underwriting.query.application.underwriting.productinfo;

import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/14/2017.
 */
@Repository
public interface ProductInformationRepository extends JpaRepository<ProductInformationDTO, String>{
   Optional<ProductInformationDTO> findByApplicationId(String applicationId);
}
