package com.gl.csf.underwriting.query.application.underwriting.supportingdocument;

import com.gl.csf.underwriting.common.model.supportingdocument.DocumentDTO;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/3/2017.
 */
@Repository
public interface SupportingDocumentRepository extends PagingAndSortingRepository<DocumentDTO, String > {
	public List<DocumentDTO> findByDescriptorApplicationIdOrderByCreatedDateDesc(String applicationId);
	int countByDescriptorApplicationId(String applicationId);
}
