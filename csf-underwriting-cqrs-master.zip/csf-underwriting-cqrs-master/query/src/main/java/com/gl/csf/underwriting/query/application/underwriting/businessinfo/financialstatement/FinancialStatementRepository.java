package com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement;

import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/5/2017.
 */
public interface FinancialStatementRepository extends PagingAndSortingRepository<FinancialStatementDTO, String> {
}
