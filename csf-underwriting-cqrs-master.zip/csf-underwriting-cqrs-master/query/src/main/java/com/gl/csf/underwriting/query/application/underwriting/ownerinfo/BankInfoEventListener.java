package com.gl.csf.underwriting.query.application.underwriting.ownerinfo;

import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.api.application.ownerinfo.event.BankInformationUpdatedEvent;
import com.gl.csf.underwriting.common.model.bank.Bank;
import com.gl.csf.underwriting.common.model.bank.BankAccount;
import com.gl.csf.underwriting.common.model.owerinfo.BankInformationDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/8/2017.
 */
@Component
public class BankInfoEventListener {

  private final BankInfoRepository repository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public BankInfoEventListener(BankInfoRepository repository, HistoryRepository historyRepository, I18nMessage i18nMessage) {
    this.repository = repository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    BankInformationDTO bankInfoDTO= new BankInformationDTO();
    bankInfoDTO.setId(UUID.randomUUID().toString());
    bankInfoDTO.setApplicationId(event.getApplicationId());
    bankInfoDTO.setBankAccount(event.getApplication().getApplicant().getBankAccount());
    bankInfoDTO.setDescription("");
    //bankInfoDTO.setBankAccountType(BankAccountType.BUSINESS.getValue().toString());
    repository.save(bankInfoDTO);

  }

  @EventHandler
  public void on(BankInformationUpdatedEvent event){
    //save to history database
    saveHistory(event.getBankInformationDTO().getApplicationId(), event.getUsername());

    repository.save(event.getBankInformationDTO());
  }

  private void saveHistory(String applicationId, String userName) {
    //catch history object
    BankInformationDTO historyBankInformation = new BankInformationDTO();
    historyBankInformation = repository.findByApplicationId(applicationId);

    if (historyBankInformation.getBankAccount() == null)
      historyBankInformation.setBankAccount(new BankAccount());

    if (historyBankInformation.getBankAccount().getBank() == null)
      historyBankInformation.getBankAccount().setBank(new Bank());

    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), applicationId, LocalDateTime.now(), userName,
            i18nMessage.getMessage("application.updated.bank.info"),
            i18nMessage.getMessage("application.updated.bank.info.description",
                    historyBankInformation.getBankAccount().getAccountName() != null ? historyBankInformation.getBankAccount().getAccountName() : "-",
                    historyBankInformation.getBankAccount().getBank().getName() != null ? historyBankInformation.getBankAccount().getBank().getName() : "-",
                    historyBankInformation.getBankAccount().getAccountNumber() != null ? historyBankInformation.getBankAccount().getAccountNumber() : "-",
                    historyBankInformation.getBankAccountType() != null ? historyBankInformation.getBankAccountType().toString() : "-",
                    historyBankInformation.getDescription() != null ? historyBankInformation.getDescription() : "-"));

    historyRepository.save(history);
  }
}
