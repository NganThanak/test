package com.gl.csf.underwriting.query.application.underwriting.salesitem;

import java.io.Serializable;
import java.time.LocalDate;
import javax.money.MonetaryAmount;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/19/2017.
 */
public class SalesItemDTO implements Serializable {

  private String saleId;
  private LocalDate date;
  private String invoiceId;
  private String productName;
  private String category;

  private MonetaryAmount price;

  private int quantity;
  private double discount;
  private double vat;

  private MonetaryAmount subtotal;

  public String getSaleId() {
    return saleId;
  }

  public void setSaleId(String saleId) {
    this.saleId = saleId;
  }

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public String getInvoiceId() {
    return invoiceId;
  }

  public void setInvoiceId(String invoiceId) {
    this.invoiceId = invoiceId;
  }

  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public MonetaryAmount getPrice() {
    return price;
  }

  public void setPrice(MonetaryAmount price) {
    this.price = price;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  public double getDiscount() {
    return discount;
  }

  public void setDiscount(double discount) {
    this.discount = discount;
  }

  public double getVat() {
    return vat;
  }

  public void setVat(double vat) {
    this.vat = vat;
  }

  public MonetaryAmount getSubtotal() {
    return subtotal;
  }

  public void setSubtotal(MonetaryAmount subtotal) {
    this.subtotal = subtotal;
  }
}
