package com.gl.csf.underwriting.query.application.underwriting.businessinfo.branch;

import com.gl.csf.underwriting.api.application.businessinfo.branch.event.*;
import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import com.gl.csf.underwriting.common.model.businessinfo.BranchStatus;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.CurrencyUtil;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/4/2017.
 */
@Component
public class BranchEventListener {

  private final BranchRepository branchRepository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public BranchEventListener(BranchRepository branchRepository, HistoryRepository historyRepository, I18nMessage i18nMessage) {
    this.branchRepository = branchRepository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  public void on(BranchAddedEvent event) {
    branchRepository.save(event.getBranch());
    saveHistory(event.getBranch(), event.getUseName(), false);
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    Address address = event.getApplication().getApplicant().getAddress();
    Branch branch = Branch.create();
    branch.setApplicationId(event.getApplicationId());
    branch.setAddress(address.getText());
    branch.setState(address.getState());
    branch.setTownship(address.getTownship());
    branch.setDistrict(address.getDistrict());
    branch.setBranchName(event.getApplication().getApplicant().getBusinessName());
    branch.setExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    branch.setMargin(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    branch.setNetProfit(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    branch.setStaffExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    branch.setRentAmount(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    branch.setOtherExpense(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    branch.setRevenue(Money.of(0, CurrencyUtil.MMK_CURRENCY));
    branch.setBranchStatus(BranchStatus.ACTIVE);
    branch.setNumberOfStaff(0);
    branch.setPhoneNumber(event.getApplication().getApplicant().getPhoneNumber());

    branchRepository.save(branch);
  }

  @EventHandler
  public void on(BranchUpdatedEvent event){
    //save to story database
    saveHistory(event.getOldBranch(), event.getUseName(), true);

    branchRepository.save(event.getNewBranch());
  }
  
  @EventHandler
  public void on(BranchDeletedEvent event){
    Branch branch = branchRepository.findOne(event.getBranchId());
    if (branch != null) {
      branchRepository.delete(event.getBranchId());
    }
  }

  public void saveHistory(Branch branch, String userName, Boolean isUpdate) {

    String title;
    String description;

    if(isUpdate){
      title = "application.updated.branch.info";
      description = "application.updated.branch.info.description";
    }
    else{
      title = "application.added.branch.info";
      description = "application.added.branch.info.description";
    }

    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), branch.getApplicationId(), LocalDateTime.now(), userName,
            i18nMessage.getMessage(title),
            i18nMessage.getMessage(description, branch.getBranchName(),
                    branch.getEmail(), branch.getPhoneNumber(), branch.getAddress(), branch.getState(), branch.getDistrict(),
                    branch.getTownship(), branch.getLocationOwner(), branch.getRentAmount(),
                    branch.getOpenSince(), branch.getNumberOfStaff(), branch.getRevenue(), branch.getExpense(), branch.getMargin(),
                    branch.getStaffExpense(), branch.getNetProfit(), branch.getOtherExpense(), branch.getBranchStatus()));

    historyRepository.save(history);
  }

  @EventHandler
  public void on(BranchMarkedAsActiveEvent event){
    Branch branch = branchRepository.findOne(event.getBranchId());
    branch.setBranchStatus(event.getStatus());
    branchRepository.save(branch);
  }

  @EventHandler
  public void on(BranchMarkedAsInactiveEvent event){
    Branch branch = branchRepository.findOne(event.getBranchId());
    branch.setBranchStatus(event.getStatus());
    branchRepository.save(branch);
  }
}
