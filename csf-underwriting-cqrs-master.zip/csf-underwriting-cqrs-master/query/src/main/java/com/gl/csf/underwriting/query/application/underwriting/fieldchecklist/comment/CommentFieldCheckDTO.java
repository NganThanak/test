package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.comment;

import lombok.Data;
import org.hibernate.annotations.Type;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/9/2017.
 */
@Data
@Entity
public class CommentFieldCheckDTO {
	@Id
	private String id;
	private String applicationId;
	private String underwritingFieldId;
	private String by;
	private LocalDateTime commentedDate;
	@Type(type = "text")
	private String comment;
	private boolean isSubmitted;
}
