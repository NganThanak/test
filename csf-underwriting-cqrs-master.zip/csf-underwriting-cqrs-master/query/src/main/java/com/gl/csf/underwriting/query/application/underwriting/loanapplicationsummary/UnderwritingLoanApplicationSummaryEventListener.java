package com.gl.csf.underwriting.query.application.underwriting.loanapplicationsummary;

import com.gl.csf.underwriting.api.application.businessinfo.business.event.BusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.api.application.ownerinfo.event.PersonalInformationUpdatedEvent;
import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.common.model.application.ApplicationStatus;
import com.gl.csf.underwriting.common.model.customer.Customer;
import com.gl.csf.underwriting.common.model.user.Role;
import org.axonframework.eventhandling.EventHandler;
import org.axonframework.eventsourcing.SequenceNumber;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/31/2017.
 */
@Component
public class UnderwritingLoanApplicationSummaryEventListener {
  private final UnderwritingLoanApplicationSummaryRepository applicationRepository;

  @Inject
  public UnderwritingLoanApplicationSummaryEventListener(UnderwritingLoanApplicationSummaryRepository applicationRepository) {
    this.applicationRepository = applicationRepository;
  }

  @EventHandler
  public void on(ApplicationCreatedEvent event, @SequenceNumber long version) {
    UnderwritingLoanApplicationSummaryDTO application = new UnderwritingLoanApplicationSummaryDTO();

    application.setId(event.getId());
    application.setApplicationDate(LocalDateTime.now());
    application.setReferenceNumber(event.getReferenceNumber());
    application.setApplicationStatus(ApplicationStatus.DRAFT);
    application.setVersion(version);

    if (event.getApplication().getApplicant() != null) {
      Customer applicant = event.getApplication().getApplicant();

      application.setBusinessName(applicant.getBusinessName());
      application.setCustomerName(applicant.getFullName());
      application.setPhoneNumber(applicant.getPhoneNumber());

      if (applicant.getAddress() != null) {
        Address address = applicant.getAddress();
        application.setAddress(address.getText());

        if(address.getState() != null)
          application.setState(address.getState().getName());

        if (address.getDistrict() != null)
          application.setDistrict(address.getDistrict().getName());

        if (address.getTownship() != null)
          application.setTownship(address.getTownship().getName());
      }

      if (event.getApplication().getApplicant().getGender() != null) {
        application.setGender(event.getApplication().getApplicant().getGender().getValue());
      }
    }

    applicationRepository.save(application);
  }

  @EventHandler
  public void on(ApplicationBookedForUnderwritingEvent event) {
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    Set<Assignee> assignees = application.getAssignees();
    for(Assignee assignee : assignees){
      if(assignee.getRole().equals(event.getRole())) {
        assignee.setUsername(event.getAssigneeId());
        break;
      }
    }

    if(event.getRole().equals(Role.FIELD_CHECKER.toString()))
      application.setApplicationStatus(ApplicationStatus.FIELD_CHECK_IN_PROGRESS);
    else if(event.getRole().equals(Role.JUNIOR_UNDERWRITER.toString()))
      application.setApplicationStatus(ApplicationStatus.UNDERWRITING_IN_PROGRESS);
    else if(event.getRole().equals(Role.SENIOR_UNDERWRITER.toString()))
      application.setApplicationStatus(ApplicationStatus.REVIEW_IN_PROGRESS);

    applicationRepository.save(application);
  }
  
  @EventHandler
  public void on(ApplicationBookedForFieldCheckEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    application.setApplicationStatus(ApplicationStatus.FIELD_CHECK_IN_PROGRESS);
    applicationRepository.save(application);
  }

  @EventHandler
  public void on(ApplicationSavedEvent event,  @SequenceNumber long version) {
    updateLoanApplication(event.getId(), event.getApplication(), ApplicationStatus.DRAFT, version);
  }

  @EventHandler
  public void on(ApplicationDraftDeletedEvent event) {
    applicationRepository.delete(event.getId());
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event, @SequenceNumber long version) {
    updateLoanApplication(event.getApplicationId(), event.getApplication(), ApplicationStatus.PENDING_UNDERWRITING, version);
  }

  @EventHandler
  public void on(UnderwritingInitializedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());

    Assignee assignee = new Assignee();
    assignee.setRole(event.getRole());

    Set<Assignee> assignees = new HashSet<>();
    assignees.add(assignee);
    application.setAssignees(assignees);

    applicationRepository.save(application);
  }
  
  @EventHandler
  public void on(FieldCheckRequestedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    application.setApplicationStatus(ApplicationStatus.WAITING_FOR_FIELD_CHECK);
    application.getAssignees().add(new Assignee(Role.FIELD_CHECKER.toString(), null));
    applicationRepository.save(application);
  }

  @EventHandler
  public void on(ApplicationDeclinedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    application.setApplicationStatus(ApplicationStatus.DECLINED);
    application.setDeclineReason(event.getDeclineReason());
    application.getAssignees().clear();
    applicationRepository.save(application);
  }

  private void updateLoanApplication(String id, Application applicationDTO, ApplicationStatus applicationStatus, long version) {
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(id);
    application.setApplicationStatus(applicationStatus);
    application.setVersion(version);
    if (applicationDTO.getApplicant() != null) {
      Customer applicant = applicationDTO.getApplicant();

      application.setBusinessName(applicant.getBusinessName());
      application.setCustomerName(applicant.getFullName());
      application.setPhoneNumber(applicant.getPhoneNumber());

      if (applicant.getAddress() != null) {
        Address address = applicant.getAddress();
        application.setAddress(address.getText());

        if (address.getState() != null)
          application.setState(address.getState().getName());

        if (address.getDistrict() != null)
          application.setDistrict(address.getDistrict().getName());

        if (address.getTownship() != null)
          application.setTownship(address.getTownship().getName());
      }

      if (applicationDTO.getApplicant().getGender() != null) {
        application.setGender(applicationDTO.getApplicant().getGender().getValue());
      }
    }

    applicationRepository.save(application);
  }

  @EventHandler
  public void on(FieldCheckingResultSubmittedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    
    // Remove field check role
    application.getAssignees().removeIf(e-> e.getRole().equals(Role.FIELD_CHECKER.toString()));
    application.getAssignees().forEach(e-> {
      if(e.getRole().equals(Role.JUNIOR_UNDERWRITER.toString()))
        application.setApplicationStatus(ApplicationStatus.UNDERWRITING_IN_PROGRESS);
      else if(e.getRole().equals(Role.SENIOR_UNDERWRITER.toString()))
        application.setApplicationStatus(ApplicationStatus.REVIEW_IN_PROGRESS);
    });
    applicationRepository.save(application);
  }
  
  @EventHandler
  public void on(PersonalInformationUpdatedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getPersonalInformationDTO().getApplicationId());
    application.setCustomerName(event.getPersonalInformationDTO().getFullName());
    application.setGender(event.getPersonalInformationDTO().getGender().getValue());
    application.setPhoneNumber(event.getPersonalInformationDTO().getPhoneNumber());
    application.setAddress(event.getPersonalInformationDTO().getOwnerAddress().getText());
    if (event.getPersonalInformationDTO().getOwnerAddress().getState() != null)
      application.setState(event.getPersonalInformationDTO().getOwnerAddress().getState().getName());
    if (event.getPersonalInformationDTO().getOwnerAddress().getDistrict() != null)
      application.setDistrict(event.getPersonalInformationDTO().getOwnerAddress().getDistrict().getName());
    if (event.getPersonalInformationDTO().getOwnerAddress().getTownship() != null)
      application.setTownship(event.getPersonalInformationDTO().getOwnerAddress().getTownship().getName());
    applicationRepository.save(application);
  }
  
  @EventHandler
  public void on(BusinessInfoUpdatedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    application.setBusinessName(event.getBusiness().getBusinessName());
    applicationRepository.save(application);
  }

  @EventHandler
  public void on(ApplicationRejectionRecommendedEvent event){
    UnderwritingLoanApplicationSummaryDTO loanApplication = applicationRepository.findOne(event.getApplicationId());
    loanApplication.setApplicationStatus(ApplicationStatus.WAITING_FOR_REVIEW);
    loanApplication.getAssignees().clear();
    loanApplication.getAssignees().add(new Assignee(Role.SENIOR_UNDERWRITER.toString(), null));
    applicationRepository.save(loanApplication);
  }

  @EventHandler
  public void on(ApplicationApprovalRecommendedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    application.setApplicationStatus(ApplicationStatus.WAITING_FOR_REVIEW);
    application.getAssignees().clear();
    application.getAssignees().add(new Assignee(Role.SENIOR_UNDERWRITER.toString(), null));
    applicationRepository.save(application);
  }

  @EventHandler
  public void on(ApplicationRejectedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    application.setApplicationStatus(ApplicationStatus.REJECTED);
    application.getAssignees().clear();
    applicationRepository.save(application);
  }

  @EventHandler
  public void on(ApplicationApprovedEvent event){
    UnderwritingLoanApplicationSummaryDTO application = applicationRepository.findOne(event.getApplicationId());
    application.setApplicationStatus(ApplicationStatus.APPROVED);
    application.getAssignees().clear();
    applicationRepository.save(application);
  }

}
