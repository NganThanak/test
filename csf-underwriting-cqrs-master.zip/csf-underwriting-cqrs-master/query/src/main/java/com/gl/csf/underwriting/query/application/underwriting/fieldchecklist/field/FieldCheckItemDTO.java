package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.Set;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 14/10/2017.
 */
@Data
@Entity
@NoArgsConstructor
public class FieldCheckItemDTO {
  @Id
  private String id;
  private String applicationId;
  private String fieldCheckId;
  private String underwritingFieldId;

  // definitions
  private String name;
  private String description;
  private boolean isMandatory;
  private boolean isTextRequired;
  private boolean isDocumentRequired;

  // values
  @Type(type = "text")
  private String fieldValue;
  @Type(type = "text")
  private String commentValue;
  @OneToMany(mappedBy = "fieldCheckItem", cascade = CascadeType.ALL, orphanRemoval = true)
  private Set<FieldCheckItemDocumentDTO> documents;

  /**
   * isSubmitted keeps the state of field check item:
   * false - indicates that the field check item is requested and the field checker is processing
   * true - indicates that the field check item has already been submitted to underwriter
   */
  private Boolean isSubmitted;

  FieldCheckItemDTO(String id, String applicationId, String fieldCheckId, String underwritingFieldId, String name, String description, boolean isMandatory, boolean isTextRequired, boolean isDocumentRequired){
    this.id = id;
    this.applicationId = applicationId;
    this.fieldCheckId = fieldCheckId;
    this.underwritingFieldId = underwritingFieldId;
    this.name = name;
    this.description = description;
    this.isMandatory = isMandatory;
    this.isTextRequired = isTextRequired;
    this.isDocumentRequired = isDocumentRequired;
  }
}
