package com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialdocument;

import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event.FinancialDocumentAddedEvent;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event.FinancialDocumentDeletedEvent;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event.FinancialDocumentUpdatedEvent;
import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/2/2017.
 */
@Component
public class FinancialDocumentEventListener {

  private final FinancialDocumentRepository repository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public FinancialDocumentEventListener(FinancialDocumentRepository repository, HistoryRepository historyRepository, I18nMessage i18nMessage) {
    this.repository = repository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  public void on(FinancialDocumentAddedEvent event){
    FinancialDocumentDTO financialDocumentDTO = new FinancialDocumentDTO();
    financialDocumentDTO.setAttachment(event.getFinancialDocumentDTO().getAttachment());
    financialDocumentDTO.setDateTime(LocalDateTime.now());
    financialDocumentDTO.setUploadBy(event.getFinancialDocumentDTO().getUploadBy());
    financialDocumentDTO.setComment(event.getFinancialDocumentDTO().getComment());
    financialDocumentDTO.setDescriptor(event.getFinancialDocumentDTO().getDescriptor());
    repository.save(financialDocumentDTO);
  }

  @EventHandler
  public void on(FinancialDocumentDeletedEvent event){
    FinancialDocumentDTO financialDocumentDTO = repository.findByDescriptor(event.getDocumentDescriptor());

    // Save delete history
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), financialDocumentDTO.getUploadBy(), i18nMessage.getMessage("deleted.financial.document.action"), i18nMessage.getMessage("deleted.financial.document.description", financialDocumentDTO.getAttachment()));
    historyRepository.save(history);

    repository.delete(event.getDocumentDescriptor());
  }

  @EventHandler
  public void on(FinancialDocumentUpdatedEvent event){
    FinancialDocumentDTO financialDocumentDTO = repository.getOne(event.getFinancialDocumentDTO().getDescriptor());
    financialDocumentDTO.setComment(event.getFinancialDocumentDTO().getComment());
    repository.save(financialDocumentDTO);
  }
}
