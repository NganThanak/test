package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference;

import com.gl.csf.underwriting.api.application.event.FieldCheckingResultSubmittedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 10/17/2017.
 */
@Component
public class FieldCheckReferenceEventListener {
  private final FieldCheckReferenceRepository repository;

  @Inject
  public FieldCheckReferenceEventListener(FieldCheckReferenceRepository repository) {
    this.repository = repository;
  }
  
  @EventHandler
  private void on(FieldCheckingResultSubmittedEvent event){
    event.getFieldCheckResults().forEach(result->{
      FieldCheckReferenceDTO fieldCheckReference = new FieldCheckReferenceDTO();
      fieldCheckReference.setId(UUID.randomUUID().toString());
      fieldCheckReference.setFieldCheckId(event.getFieldCheckId());
      fieldCheckReference.setName(result.getName());
      fieldCheckReference.setDescription(result.getDescription());

      fieldCheckReference.setText(result.getText());
      fieldCheckReference.setComment(result.getComment());
      fieldCheckReference.setSubmittedDate(event.getSubmittedDate());
      fieldCheckReference.setFieldCheckerId(event.getUsername());

      fieldCheckReference.setApplicationId(event.getApplicationId());
      Set<FieldCheckReferenceDocumentDTO> referenceDocuments = new HashSet<>();
      result.getAttachedDocuments().forEach(document ->{
        FieldCheckReferenceDocumentDTO referenceDocument = new FieldCheckReferenceDocumentDTO(document.getDocumentDescriptor(), fieldCheckReference, event.getUsername(), document.getFilename(), event.getSubmittedDate());
        referenceDocuments.add(referenceDocument);
      });
      fieldCheckReference.setReferenceDocuments(referenceDocuments);
      repository.save(fieldCheckReference);
    });
  }
}
