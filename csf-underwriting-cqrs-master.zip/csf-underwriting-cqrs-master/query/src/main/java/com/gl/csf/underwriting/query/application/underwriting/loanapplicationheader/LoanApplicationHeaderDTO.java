package com.gl.csf.underwriting.query.application.underwriting.loanapplicationheader;

import com.gl.csf.underwriting.common.model.application.ApplicationStatus;
import com.gl.csf.underwriting.common.model.product.ProductType;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;
import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/6/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class LoanApplicationHeaderDTO {
  @Id
  private String id;
  private String applicationId;
  private String referenceId;
  private String customerName;
  private String BusinessName;
  private ProductType productName;
  @Type(type = "Money")
  @Positive(message = "Maximum loan amount cannot be zero or negative number.")
  @Columns(columns = {@Column(name = "request_amount_currency"), @Column(name = "request_loan_amount")})
  private MonetaryAmount requestAmount;
  private Integer term;
  private String creditScore;
  private ApplicationStatus status;
  private String underwritingDecision;
  private boolean hasRecommendedDecision;
}
