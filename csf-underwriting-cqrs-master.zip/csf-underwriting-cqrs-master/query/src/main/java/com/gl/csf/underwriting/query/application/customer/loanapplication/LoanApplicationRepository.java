package com.gl.csf.underwriting.query.application.customer.loanapplication;


import com.gl.csf.underwriting.common.model.customer.CustomerApplicationStatus;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Repository
public interface LoanApplicationRepository extends PagingAndSortingRepository<LoanApplicationDTO, String> {
  Optional<LoanApplicationDTO> findById(String id);
  List<LoanApplicationDTO> findByApplication_Applicant_Username(String username);

  Optional<LoanApplicationDTO> findFirstByApplication_Applicant_UsernameAndCustomerApplicationStatus(String username, CustomerApplicationStatus customerApplicationStatus);
}
