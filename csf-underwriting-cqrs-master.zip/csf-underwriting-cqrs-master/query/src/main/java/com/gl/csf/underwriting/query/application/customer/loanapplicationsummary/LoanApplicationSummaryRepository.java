package com.gl.csf.underwriting.query.application.customer.loanapplicationsummary;


import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/22/2017.
 */
@Repository
public interface LoanApplicationSummaryRepository extends PagingAndSortingRepository<LoanApplicationSummaryDTO, String> {
  Optional<LoanApplicationSummaryDTO> findById(String id);
  List<LoanApplicationSummaryDTO> findAllByUsername(String username);
}
