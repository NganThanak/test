package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import java.util.Collection;
import java.util.List;

/**
 * Created by p.ly on 10/5/2017.
 */
@Repository
public interface UnderwritingFieldRepository extends PagingAndSortingRepository<UnderwritingFieldDTO, String> {
  
  Collection<UnderwritingFieldDTO> findByApplicationIdOrderByIsMandatoryDescNameAsc(String applicationId);
  Collection<UnderwritingFieldDTO> findByApplicationIdAndIsFieldCheckRequested(String applicationId, boolean fieldCheckRequest);
}
