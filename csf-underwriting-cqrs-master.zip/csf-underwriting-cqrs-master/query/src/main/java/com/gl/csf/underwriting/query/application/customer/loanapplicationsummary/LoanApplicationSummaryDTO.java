package com.gl.csf.underwriting.query.application.customer.loanapplicationsummary;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Data;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/18/2017.
 */
@Data
@Entity
public class LoanApplicationSummaryDTO {
  @Id
  private String id;

  @JsonIgnore
  @Column(name = "customer_username")
  private String username;

  @Column(name = "reference_number")
  private String referenceNumber;

  @Column(name = "created_date")
  private LocalDate createdDate;

  @Column(name = "status")
  private String status;

  @Column(name = "loan_type")
  private String loanType;
}
