package com.gl.csf.underwriting.query.application.messaging;

import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import com.gl.csf.underwriting.common.model.businessinfo.Business;
import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import com.gl.csf.underwriting.common.model.owerinfo.BankInformationDTO;
import com.gl.csf.underwriting.common.model.owerinfo.GuarantorBusinessInfoDTO;
import com.gl.csf.underwriting.common.model.owerinfo.GuarantorDTO;
import com.gl.csf.underwriting.common.model.owerinfo.PersonalInformationDTO;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.branch.BranchRepository;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.business.BusinessRepository;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialdocument.FinancialDocumentRepository;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement.FinancialStatementDTO;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement.FinancialStatementRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.BankInfoRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.GuarantorBusinessRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.GuarantorRepository;
import com.gl.csf.underwriting.query.application.underwriting.ownerinfo.PersonalInfoRepository;
import com.gl.csf.underwriting.query.application.underwriting.productinfo.ProductInformationRepository;
import java.util.List;
import javax.inject.Inject;
import lombok.Value;
import org.axonframework.eventhandling.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Service;

/**
 * Created by jerome on 11/17/17.
 */
@Service
public class EventForwarder {

  private final static Logger logger = LoggerFactory.getLogger(EventForwarder.class);


  @Inject
  private Source messagingChannel;
  @Inject
  private PersonalInfoRepository personalInfoRepository;
  @Inject
  private BankInfoRepository bankInfoRepository;
  @Inject
  private BusinessRepository businessRepository;
  @Inject
  private FinancialStatementRepository financialStatementRepository;
  @Inject
  private BranchRepository branchRepository;
  @Inject
  private FinancialDocumentRepository financialDocumentRepository;
  @Inject
  private ProductInformationRepository productInformationRepository;
  @Inject
  private GuarantorRepository guarantorRepository;
  @Inject
  private GuarantorBusinessRepository guarantorBusinessRepository;

  @EventHandler
  public void on(
      com.gl.csf.underwriting.api.application.event.ApplicationApprovedEvent applicationApprovedEvent) {

    final String applicationId = applicationApprovedEvent.getApplicationId();
    messagingChannel.output().send(MessageBuilder
        .withPayload(new ApplicationApprovedEvent(applicationId,
            personalInfoRepository.findByApplicationId(applicationId),
            bankInfoRepository.findByApplicationId(applicationId),
            guarantorRepository.findByApplicationId(applicationId),
            guarantorBusinessRepository.findByApplicationId(applicationId),
            businessRepository.findByApplicationId(applicationId),
            branchRepository.findAllByApplicationId(applicationId),
            financialStatementRepository.findOne(applicationId),
            financialDocumentRepository
                .findByDescriptor_ApplicationId(applicationId),
            productInformationRepository
                .findByApplicationId(applicationId
                ).get())).build());
    logger.info("Application approval event successfully forwarded for application {}",
        applicationId);

  }


  @Value
  public static class ApplicationApprovedEvent {
    private String applicationId;
    private PersonalInformationDTO personalInformation;
    private BankInformationDTO bankInformation;
    private GuarantorDTO guarantorInformation;
    private GuarantorBusinessInfoDTO guarantorBusinessInformation;
    private Business businessInformation;
    private List<Branch> branches;
    private FinancialStatementDTO financialStatement;
    private List<FinancialDocumentDTO> financialDocuments;
    private ProductInformationDTO productionInformation;
  }


}




