package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 10/17/2017.
 */
public interface FieldCheckReferenceRepository extends JpaRepository<FieldCheckReferenceDTO, String> {
  List<FieldCheckReferenceDTO> findByApplicationIdOrderBySubmittedDateDesc(String applicationId);

}
