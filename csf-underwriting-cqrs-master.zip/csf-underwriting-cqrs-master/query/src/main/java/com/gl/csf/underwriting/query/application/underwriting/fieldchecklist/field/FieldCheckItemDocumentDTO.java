package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/10/2017.
 */
@Entity
public class FieldCheckItemDocumentDTO {
  @EmbeddedId
  private DocumentDescriptor documentDescriptor;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn
  private FieldCheckItemDTO fieldCheckItem;
  private String editorId;
  private String underwritingFieldId;
  private String fileName;
  private LocalDateTime dateModified;

  public FieldCheckItemDocumentDTO(){
  }

  FieldCheckItemDocumentDTO(DocumentDescriptor documentDescriptor, FieldCheckItemDTO fieldCheckItem, String editorId, String underwritingFieldId, String fileName, LocalDateTime dateModified){
    this.documentDescriptor = documentDescriptor;
    this.fieldCheckItem = fieldCheckItem;
    this.editorId = editorId;
    this.underwritingFieldId = underwritingFieldId;
    this.fileName = fileName;
    this.dateModified = dateModified;
  }

  public DocumentDescriptor getDocumentDescriptor() {
    return documentDescriptor;
  }

  public void setDocumentDescriptor(DocumentDescriptor documentDescriptor) {
    this.documentDescriptor = documentDescriptor;
  }

  public FieldCheckItemDTO getFieldCheckItem() {
    return fieldCheckItem;
  }

  public void setFieldCheckItem(FieldCheckItemDTO fieldCheckItem) {
    this.fieldCheckItem = fieldCheckItem;
  }

  public String getEditorId() {
    return editorId;
  }

  public void setEditorId(String editorId) {
    this.editorId = editorId;
  }

  public String getUnderwritingFieldId() {
    return underwritingFieldId;
  }

  public void setUnderwritingFieldId(String underwritingFieldId) {
    this.underwritingFieldId = underwritingFieldId;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public LocalDateTime getDateModified() {
    return dateModified;
  }

  public void setDateModified(LocalDateTime dateModified) {
    this.dateModified = dateModified;
  }
}
