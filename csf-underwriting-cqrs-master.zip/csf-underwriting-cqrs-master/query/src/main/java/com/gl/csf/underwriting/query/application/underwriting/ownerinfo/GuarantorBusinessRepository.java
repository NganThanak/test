package com.gl.csf.underwriting.query.application.underwriting.ownerinfo;

import com.gl.csf.underwriting.common.model.owerinfo.GuarantorBusinessInfoDTO;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by p.ly on 11/21/2017.
 */
public interface GuarantorBusinessRepository extends JpaRepository<GuarantorBusinessInfoDTO, String> {
  GuarantorBusinessInfoDTO findByApplicationId(String applicationId);
}