package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.document;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.time.LocalDateTime;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 14/10/2017.
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class FieldCheckDocumentDTO {
  @EmbeddedId
  private DocumentDescriptor documentDescriptor;
  private String underwriterId;
  private String underwritingFieldId;
  private String fileName;
  private LocalDateTime dateModified;
}
