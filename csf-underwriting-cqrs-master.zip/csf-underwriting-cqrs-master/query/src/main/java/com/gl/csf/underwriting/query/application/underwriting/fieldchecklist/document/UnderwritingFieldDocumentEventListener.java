package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.document;

import com.gl.csf.underwriting.api.application.event.FieldCheckingResultSubmittedEvent;
import com.gl.csf.underwriting.api.application.event.UnderwritingFieldDocumentAttachedEvent;
import com.gl.csf.underwriting.api.application.event.UnderwritingFieldDocumentDeletedEvent;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by p.ly on 9/30/2017.
 */
@Component
public class UnderwritingFieldDocumentEventListener {
  private final UnderwritingFieldDocumentRepository underwritingFieldDocumentRepository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public UnderwritingFieldDocumentEventListener(UnderwritingFieldDocumentRepository underwritingFieldDocumentRepository, HistoryRepository historyRepository, I18nMessage i18nMessage) {
    this.underwritingFieldDocumentRepository = underwritingFieldDocumentRepository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  public void on(UnderwritingFieldDocumentAttachedEvent event) {
    UnderwritingFieldDocumentDTO documentDTO = new UnderwritingFieldDocumentDTO();
    documentDTO.setDocumentDescriptor(event.getDocumentDescriptor());
    documentDTO.setEditorId(event.getUsername());
    documentDTO.setDateModified(LocalDateTime.now());
    documentDTO.setUnderwritingFieldId(event.getUnderwritingFieldId());
    documentDTO.setFileName(event.getFileName());
    documentDTO.setSubmitted(true);
    underwritingFieldDocumentRepository.save(documentDTO);
  }

  @EventHandler
  private void on(UnderwritingFieldDocumentDeletedEvent event){
    UnderwritingFieldDocumentDTO fieldDocumentDTO = underwritingFieldDocumentRepository.findByDocumentDescriptor(event.getDocumentDescriptor());

    // Save history when deleting the document
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), event.getUserName(), i18nMessage.getMessage("deleted.fieldcheck.document.action"), i18nMessage.getMessage("deleted.fieldcheck.document.description", fieldDocumentDTO.getFileName()));
    historyRepository.save(history);

    underwritingFieldDocumentRepository.deleteByDocumentDescriptor(event.getDocumentDescriptor());
  }

  @EventHandler
  public void on(FieldCheckingResultSubmittedEvent event){
    event.getFieldCheckResults().forEach(result-> result.getAttachedDocuments().forEach(attachedDocument -> {
      UnderwritingFieldDocumentDTO documentDTO = new UnderwritingFieldDocumentDTO();
      documentDTO.setDocumentDescriptor(attachedDocument.getDocumentDescriptor());
      documentDTO.setEditorId(event.getUsername());
      // TODO pass in the date of modification
      documentDTO.setDateModified(LocalDateTime.now());
      documentDTO.setUnderwritingFieldId(result.getUnderwritingFieldId());
      documentDTO.setFileName(attachedDocument.getFilename());
      documentDTO.setSubmitted(true);
      underwritingFieldDocumentRepository.save(documentDTO);
    }));
  }
}
