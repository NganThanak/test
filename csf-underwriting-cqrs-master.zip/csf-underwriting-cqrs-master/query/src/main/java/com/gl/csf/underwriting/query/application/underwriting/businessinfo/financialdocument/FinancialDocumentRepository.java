package com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialdocument;

import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/26/2017.
 */
public interface FinancialDocumentRepository extends JpaRepository<FinancialDocumentDTO, DocumentDescriptor> {
  List<FinancialDocumentDTO> findByDescriptor_ApplicationId(String applicationId);
  int countByDescriptor_ApplicationId(String applicationId);
  FinancialDocumentDTO findByDescriptor(DocumentDescriptor documentDescriptor);
}
