package com.gl.csf.underwriting.query.application.underwriting.supportingdocument;

import com.gl.csf.underwriting.api.supportdocument.event.SupportingDocumentRemovedEvent;
import com.gl.csf.underwriting.api.supportdocument.event.SupportingDocumentSavedEvent;
import com.gl.csf.underwriting.api.supportdocument.event.SupportingDocumentUpdatedEvent;
import com.gl.csf.underwriting.common.model.supportingdocument.DocumentDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/3/2017.
 */
@Component
public class SupportingDocumentEventListener {

	private final SupportingDocumentRepository repository;
	private final HistoryRepository historyRepository;
	private final I18nMessage i18nMessage;

	@Inject
	public SupportingDocumentEventListener(SupportingDocumentRepository supportingDocumentRepository, HistoryRepository historyRepository, I18nMessage i18nMessage){
		this.repository = supportingDocumentRepository;
		this.historyRepository = historyRepository;
		this.i18nMessage = i18nMessage;
	}

	@EventHandler
	public void on(SupportingDocumentSavedEvent event) {
		DocumentDTO documentDTO = new DocumentDTO();
		documentDTO.setId(UUID.randomUUID().toString());
		documentDTO.setApplicationId(event.getDocumentDTO().getApplicationId());
		documentDTO.setCreatedDate(LocalDateTime.now());
		documentDTO.setUploadBy(event.getDocumentDTO().getUploadBy());
		documentDTO.setComment(event.getDocumentDTO().getComment());
		documentDTO.setAttachment(event.getDocumentDTO().getAttachment());
		documentDTO.setDescriptor(event.getDocumentDTO().getDescriptor());
		repository.save(documentDTO);
	}

	@EventHandler
	public void on(SupportingDocumentUpdatedEvent event){
		repository.save(event.getDocumentDTO());
	}

	@EventHandler
	private void on(SupportingDocumentRemovedEvent event){
		DocumentDTO documentDTO = repository.findOne(event.getSupportingDocumentId());

		// Save history when deleting a supporting document
		HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), event.getUserName(), i18nMessage.getMessage("deleted.supporting.document.action"), i18nMessage.getMessage("deleted.supporting.document.description", documentDTO.getAttachment()));
		historyRepository.save(history);

		repository.delete(event.getSupportingDocumentId());
	}

}
