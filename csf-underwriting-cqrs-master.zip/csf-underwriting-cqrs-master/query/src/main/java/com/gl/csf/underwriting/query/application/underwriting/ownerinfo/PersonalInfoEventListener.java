package com.gl.csf.underwriting.query.application.underwriting.ownerinfo;

import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.api.application.ownerinfo.event.PersonalInformationUpdatedEvent;
import com.gl.csf.underwriting.common.model.owerinfo.PersonalInformationDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import liquibase.util.StringUtils;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/8/2017.
 */
@Component
public class PersonalInfoEventListener {

  private final PersonalInfoRepository repository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public PersonalInfoEventListener(PersonalInfoRepository repository, HistoryRepository historyRepository, I18nMessage i18nMessage) {
    this.repository = repository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    PersonalInformationDTO personalInfoDTO = new PersonalInformationDTO();

    personalInfoDTO.setId(UUID.randomUUID().toString());
    personalInfoDTO.setApplicationId(event.getApplicationId());
    personalInfoDTO.setDob(event.getApplication().getApplicant().getDateOfBirth());
    personalInfoDTO.setFullName(event.getApplication().getApplicant().getFullName());
    personalInfoDTO.setEmail(event.getApplication().getApplicant().getEmail());
    personalInfoDTO.setPhoneNumber(event.getApplication().getApplicant().getPhoneNumber());
    personalInfoDTO.setOwnerAddress(event.getApplication().getApplicant().getAddress());
    personalInfoDTO.setGender(event.getApplication().getApplicant().getGender());
    repository.save(personalInfoDTO);
  }

  @EventHandler
  public void on (PersonalInformationUpdatedEvent event){
    saveHistoryObject(event.getPersonalInformationDTO().getApplicationId(), event.getUsername());
    repository.save(event.getPersonalInformationDTO());
  }

  private void saveHistoryObject(String applicationId, String userName) {
    PersonalInformationDTO personalInfoDTO = repository.findByApplicationId(applicationId);
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), applicationId, LocalDateTime.now(), userName,
            i18nMessage.getMessage("application.personal.info.action"), i18nMessage.getMessage("application.personal.info.description",
            transformEmptyValuePresentation(personalInfoDTO.getFullName()),
            transformEmptyValuePresentation(personalInfoDTO.getNrcId()),
            personalInfoDTO.getGender(),
            transformEmptyValuePresentation(personalInfoDTO.getPhoneNumber()),
            transformEmptyValuePresentation(personalInfoDTO.getFatherName()),
            transformEmptyValuePresentation(personalInfoDTO.getDob() == null ? "..." : personalInfoDTO.getDob().toString()),
            transformEmptyValuePresentation(personalInfoDTO.getEmail()),
            transformEmptyValuePresentation(personalInfoDTO.getOwnerAddress().getText()),
            transformEmptyValuePresentation(personalInfoDTO.getOwnerAddress().getState() == null ? "..." : personalInfoDTO.getOwnerAddress().getState().toString()),
            transformEmptyValuePresentation(personalInfoDTO.getOwnerAddress().getDistrict() == null ? "..." : personalInfoDTO.getOwnerAddress().getDistrict().toString()),
            transformEmptyValuePresentation(personalInfoDTO.getOwnerAddress().getTownship() == null ? "..." : personalInfoDTO.getOwnerAddress().getTownship().toString())));
    historyRepository.save(history);
  }

  private String transformEmptyValuePresentation(String value) {
    return StringUtils.isEmpty(value) ? "..." : value;
  }
}
