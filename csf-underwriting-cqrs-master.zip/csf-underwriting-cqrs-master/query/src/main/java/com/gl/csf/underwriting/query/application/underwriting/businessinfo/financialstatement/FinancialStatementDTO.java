package com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/4/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class FinancialStatementDTO {

  @Id
  private String applicationId;

  private Integer totalBranch;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "revenue_currency"), @Column(name = "revenue")})
  private MonetaryAmount revenue;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "expense_currency"), @Column(name = "expense")})
  private MonetaryAmount expense;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "margin_currency"), @Column(name = "margin")})
  private MonetaryAmount margin;

  private Integer numberOfStaff;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "staff_expense_currency"), @Column(name = "staff_expense")})
  private MonetaryAmount staffExpense;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "net_profit_currency"), @Column(name = "net_profit")})
  private MonetaryAmount netProfit;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "total_rent_currency"), @Column(name = "total_rent")})
  private MonetaryAmount totalRent;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "other_expense_currency"), @Column(name = "other_expense")})
  private MonetaryAmount otherExpense;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "financial_ratio_currency"), @Column(name = "financial_ratio")})
  private MonetaryAmount financialRatio;

  // update this field when user add payment frequency
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "installment_currency"), @Column(name = "installment")})
  private MonetaryAmount installment;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "financial_ratio_low_currency"), @Column(name = "financial_ratio_low")})
  private MonetaryAmount financialRatioLow;

}
