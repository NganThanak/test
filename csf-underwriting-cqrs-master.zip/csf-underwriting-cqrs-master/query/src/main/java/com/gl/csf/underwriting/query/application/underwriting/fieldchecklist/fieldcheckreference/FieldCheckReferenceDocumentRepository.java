package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/10/2017.
 */
public interface FieldCheckReferenceDocumentRepository extends JpaRepository<FieldCheckReferenceDocumentDTO, DocumentDescriptor> {

  Page<FieldCheckReferenceDocumentDTO> findAllByFieldCheckReference(Pageable pageable, FieldCheckReferenceDTO fieldCheckReference);
  int countAllByFieldCheckReference(FieldCheckReferenceDTO fieldCheckReference);

}
