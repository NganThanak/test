package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldhistory;

import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * Created by p.ly on 10/7/2017.
 */
public interface UnderwritingFieldContentHistoryRepository extends PagingAndSortingRepository<UnderwritingFieldContentHistoryDTO, String> {
  Integer countByApplicationIdAndUnderwritingFieldIdAndIsSubmitted(String applicationId, String underwritingFieldId, boolean submit);
  List<UnderwritingFieldContentHistoryDTO> findByApplicationIdAndUnderwritingFieldIdAndIsSubmittedOrderByDateModifiedDesc(String applicationId, String underwritingFieldId, boolean submit);
}
