package com.gl.csf.underwriting.query.application.underwriting.ownerinfo;

import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.api.application.ownerinfo.event.GuarantorUpdatedEvent;
import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.owerinfo.GuarantorDTO;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/12/2017.
 */
@Component
public class GuarantorEventListener {

  private final GuarantorRepository repository;

  @Inject
  public GuarantorEventListener(GuarantorRepository repository) {
    this.repository = repository;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    GuarantorDTO guarantorDTO = new GuarantorDTO();
    Address address =new Address();
    address.setText("");
    guarantorDTO.setId(UUID.randomUUID().toString());
    guarantorDTO.setApplicationId(event.getApplicationId());
    guarantorDTO.setFullName("");
    guarantorDTO.setEmail("");
    guarantorDTO.setPhoneNumber("");
    guarantorDTO.setOwnerAddress(address);
    repository.save(guarantorDTO);
  }

  @EventHandler
  public void on(GuarantorUpdatedEvent event){
    repository.save(event.getGuarantorDTO());
  }
}
