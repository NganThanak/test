package com.gl.csf.underwriting.query.application.underwriting.ownerinfo;

import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.api.application.ownerinfo.event.GuarantorBusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.owerinfo.GuarantorBusinessInfoDTO;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.UUID;

/**
 * Created by p.ly on 11/21/2017.
 */
@Component
public class GuarantorBusinessEventListener {
  private final GuarantorBusinessRepository businessRepository;

  @Inject
  public GuarantorBusinessEventListener(GuarantorBusinessRepository businessRepository) {
    this.businessRepository = businessRepository;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event) {
    GuarantorBusinessInfoDTO guarantorBusiness = new GuarantorBusinessInfoDTO();
    guarantorBusiness.setId(UUID.randomUUID().toString());
    guarantorBusiness.setApplicationId(event.getApplicationId());
    guarantorBusiness.setBusinessInfoPhoneNumber("");
    Address businessInfoAddress = new Address();
    businessInfoAddress.setText("");
    guarantorBusiness.setBusinessInfoAddress(businessInfoAddress);
    businessRepository.save(guarantorBusiness);
  }

  @EventHandler
  public void on(GuarantorBusinessInfoUpdatedEvent event) {
    businessRepository.save(event.getGuarantorBusiness());
  }

}
