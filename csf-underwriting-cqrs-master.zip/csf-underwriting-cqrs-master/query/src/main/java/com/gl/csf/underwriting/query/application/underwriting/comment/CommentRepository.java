package com.gl.csf.underwriting.query.application.underwriting.comment;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 9/9/2017.
 */
@Repository
public interface CommentRepository extends PagingAndSortingRepository<CommentDTO, String> {
  Page<CommentDTO> findByApplicationId(String applicationId, Pageable pageable);
  List<CommentDTO> findByApplicationIdOrderByCommentedDateDesc(String applicationId);
  int countByApplicationId(String applicationId);
}
