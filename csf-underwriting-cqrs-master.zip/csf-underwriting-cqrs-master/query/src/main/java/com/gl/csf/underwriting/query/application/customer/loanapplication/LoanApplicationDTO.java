package com.gl.csf.underwriting.query.application.customer.loanapplication;

import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.common.model.customer.CustomerApplicationStatus;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
@Entity
public class LoanApplicationDTO {
  @Id
  private String id;
  @Embedded
  private Application application;

  @Column(name = "reference_number")
  private String referenceNumber;

  @Column(name = "application_status")
  @Enumerated(EnumType.STRING)
  private CustomerApplicationStatus customerApplicationStatus;

  @Column(name = "rejected_date")
  private LocalDate rejectedDate;

  @Column(name = "created_date")
  private LocalDate createdDate;
}
