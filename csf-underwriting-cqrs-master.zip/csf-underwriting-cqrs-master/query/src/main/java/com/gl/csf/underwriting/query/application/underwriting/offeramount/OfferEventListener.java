package com.gl.csf.underwriting.query.application.underwriting.offeramount;

import com.gl.csf.underwriting.api.offeramount.event.OfferMadeEvent;
import com.gl.csf.underwriting.common.model.offeramount.Offer;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/13/2017.
 */
@Component
public class OfferEventListener {

  private final OfferRepository offerRepository;

  @Inject
  public OfferEventListener(OfferRepository offerRepository) {
    this.offerRepository = offerRepository;
  }

  @EventHandler
  public void on(OfferMadeEvent event){
    Offer offerDTO = event.getOffer();
    offerDTO.setId(UUID.randomUUID().toString());
    offerDTO.setApplicationId(event.getApplicationId());
    offerDTO.setRatedDate(LocalDateTime.now());
    offerDTO.setUnderwriter(event.getUnderwriter());

    offerRepository.save(offerDTO);
  }
}