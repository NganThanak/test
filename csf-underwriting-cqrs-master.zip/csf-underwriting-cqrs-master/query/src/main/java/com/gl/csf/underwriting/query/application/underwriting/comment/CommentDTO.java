package com.gl.csf.underwriting.query.application.underwriting.comment;

import lombok.Data;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 9/9/2017.
 */
@Data
@Entity
public class CommentDTO {
  @Id
  private String id;
  @Column(name ="application_id")
  private String applicationId;

  @Column(name = "user_name")
  private String username;

  @Type(type = "text")
  @Column(name = "description")
  private String description;

  @Column(name = "commented_date")
  private LocalDateTime commentedDate;
}
