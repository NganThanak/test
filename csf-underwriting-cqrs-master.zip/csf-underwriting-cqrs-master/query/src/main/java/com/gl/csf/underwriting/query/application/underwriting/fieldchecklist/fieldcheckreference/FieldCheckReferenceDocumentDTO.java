package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldcheckreference;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/10/2017.
 */
@Entity
public class FieldCheckReferenceDocumentDTO {

  @EmbeddedId
  private DocumentDescriptor documentDescriptor;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn
  private FieldCheckReferenceDTO fieldCheckReference;
  private String editorId;
  private String fileName;
  private LocalDateTime dateModified;

  public FieldCheckReferenceDocumentDTO(){
  }

  FieldCheckReferenceDocumentDTO(DocumentDescriptor documentDescriptor, FieldCheckReferenceDTO fieldCheckReference, String editorId, String fileName, LocalDateTime dateModified){
    this.documentDescriptor = documentDescriptor;
    this.fieldCheckReference = fieldCheckReference;
    this.editorId = editorId;
    this.fileName = fileName;
    this.dateModified = dateModified;
  }

  public DocumentDescriptor getDocumentDescriptor() {
    return documentDescriptor;
  }

  public void setDocumentDescriptor(DocumentDescriptor documentDescriptor) {
    this.documentDescriptor = documentDescriptor;
  }

  public FieldCheckReferenceDTO getFieldCheckReference() {
    return fieldCheckReference;
  }

  public void setFieldCheckReference(FieldCheckReferenceDTO fieldCheckReference) {
    this.fieldCheckReference = fieldCheckReference;
  }

  public String getEditorId() {
    return editorId;
  }

  public void setEditorId(String editorId) {
    this.editorId = editorId;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public LocalDateTime getDateModified() {
    return dateModified;
  }

  public void setDateModified(LocalDateTime dateModified) {
    this.dateModified = dateModified;
  }
}
