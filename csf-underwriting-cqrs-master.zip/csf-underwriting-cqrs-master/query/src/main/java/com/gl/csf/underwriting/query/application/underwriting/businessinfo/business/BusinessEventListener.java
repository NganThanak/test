package com.gl.csf.underwriting.query.application.underwriting.businessinfo.business;

import com.gl.csf.underwriting.api.application.businessinfo.branch.event.BranchUpdatedEvent;
import com.gl.csf.underwriting.api.application.businessinfo.business.event.BusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.common.model.address.BusinessType;
import com.gl.csf.underwriting.common.model.businessinfo.BranchDTO;
import com.gl.csf.underwriting.common.model.businessinfo.Business;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/8/2017.
 */
@Component
public class BusinessEventListener {

  private static final String SPACE = " ";
  private final BusinessRepository businessRepository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public BusinessEventListener(BusinessRepository businessRepository, HistoryRepository historyRepository, I18nMessage i18nMessage) {
    this.businessRepository = businessRepository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  public void on(BusinessInfoUpdatedEvent event) {
    //save to history database
    saveHistory(event.getApplicationId(), event.getUserName());

    businessRepository.save(event.getBusiness());
  }

  @EventHandler
  public void on(BranchUpdatedEvent event) {
    Business business = businessRepository.findByApplicationId(event.getApplicationId());
    if (business.getMainBranch() != null && business.getMainBranch().getBranchId() != null) {
      if(business.getMainBranch().getBranchId().equals(event.getNewBranch().getBranchId())){
        BranchDTO branchDTO = new BranchDTO();
        branchDTO.setBranchId(event.getNewBranch().getBranchId());
        branchDTO.setBranchName(event.getNewBranch().getBranchName());
        branchDTO.setBusinessType(event.getNewBranch().getBusinessType());
        branchDTO.setBusinessTypeDescription(event.getNewBranch().getBusinessTypeDescription());
        business.setMainBranch(branchDTO);
      }
    }
  }

  public void saveHistory(String applicationId, String userName) {
    //catch history object
    Business business = new Business();
    business = businessRepository.findByApplicationId(applicationId);

    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), applicationId, LocalDateTime.now(), userName,
            i18nMessage.getMessage("application.updated.business.info"),
            i18nMessage.getMessage("application.updated.business.description",
                    business.getBusinessId() != null ? business.getBusinessId() : "-",
                    business.getBusinessName() != null ? business.getBusinessName() : "-",
                    business.getMainBranch() != null ? business.getMainBranch() : "-"));

    historyRepository.save(history);
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    Business business = new Business();
    business.setApplicationId(event.getApplicationId());
    business.setBusinessName(event.getApplication().getApplicant().getBusinessName());
    business.setMainBranch(new BranchDTO(new BusinessType(), SPACE));
    if(event.getApplication().getApplicant().getBusinessId() != null){
      business.setBusinessId(event.getApplication().getApplicant().getBusinessId());
      business.setIsBoss(true);
    }
    else
      business.setIsBoss(false);
    businessRepository.save(business);
  }
}
