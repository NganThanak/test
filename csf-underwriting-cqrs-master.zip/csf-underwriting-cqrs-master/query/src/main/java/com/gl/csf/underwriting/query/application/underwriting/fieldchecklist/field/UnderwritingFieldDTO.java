package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by p.ly on 10/5/2017.
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class UnderwritingFieldDTO {

  private String applicationId;
  @Id
  private String underwritingFieldId;
  @Type(type = "text")
  private String content;
  private String name;
  private String description;
  private boolean isFieldCheckRequested;
  private boolean isDocumentRequired;
  private boolean isTextRequired;
  private boolean isMandatory;

}
