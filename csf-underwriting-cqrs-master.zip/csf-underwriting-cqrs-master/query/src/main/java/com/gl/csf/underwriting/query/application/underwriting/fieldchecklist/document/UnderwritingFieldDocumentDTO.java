package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.document;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Data;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.time.LocalDateTime;

/**
 * Created by p.ly on 9/30/2017.
 */
@Entity
@Data
public class UnderwritingFieldDocumentDTO {
  private String editorId;
  private String underwritingFieldId;
  private String fileName;
  private LocalDateTime dateModified;
  private boolean isSubmitted;
  @EmbeddedId
  private DocumentDescriptor documentDescriptor;
}
