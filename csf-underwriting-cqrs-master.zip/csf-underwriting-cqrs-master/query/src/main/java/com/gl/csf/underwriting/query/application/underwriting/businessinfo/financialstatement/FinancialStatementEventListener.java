package com.gl.csf.underwriting.query.application.underwriting.businessinfo.financialstatement;

import com.gl.csf.underwriting.api.application.businessinfo.branch.event.*;
import com.gl.csf.underwriting.api.application.event.UnderwritingInitializedEvent;
import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import com.gl.csf.underwriting.common.model.businessinfo.BranchStatus;
import com.gl.csf.underwriting.query.application.underwriting.businessinfo.branch.BranchRepository;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.Monetary;
import javax.money.MonetaryAmount;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 09/10/2017.
 */
@Component
public class FinancialStatementEventListener {
  private static final MonetaryAmount ZERO = Money.zero(Monetary.getCurrency("MMK"));
  private final FinancialStatementRepository repository;
  private final BranchRepository branchRepository;
  private Logger logger = LoggerFactory.getLogger(FinancialStatementEventListener.class);

  @Inject
  public FinancialStatementEventListener(FinancialStatementRepository repository, BranchRepository branchRepository) {
    this.repository = repository;
    this.branchRepository = branchRepository;
  }

  @EventHandler
  public void on(UnderwritingInitializedEvent event) {
    FinancialStatementDTO financialStatement = new FinancialStatementDTO();
    financialStatement.setApplicationId(event.getApplicationId());
    financialStatement.setExpense(ZERO);
    financialStatement.setMargin(ZERO);
    financialStatement.setNetProfit(ZERO);
    financialStatement.setRevenue(ZERO);
    financialStatement.setStaffExpense(ZERO);
    financialStatement.setTotalRent(ZERO);
    financialStatement.setOtherExpense(ZERO);
    financialStatement.setFinancialRatio(ZERO);
    financialStatement.setFinancialRatioLow(ZERO);
    financialStatement.setNumberOfStaff(0);
    financialStatement.setInstallment(ZERO);
    // we have default main branch when customer submit
    financialStatement.setTotalBranch(1);
    repository.save(financialStatement);
  }

  @EventHandler
  public void on(BranchAddedEvent event) {
    Branch newBranch = event.getBranch();
    FinancialStatementDTO financialStatement = repository.findOne(event.getApplicationId());
    
    if (BranchStatus.ACTIVE.equals(newBranch.getBranchStatus())){
      financialStatement.setExpense(financialStatement.getExpense().add(newBranch.getExpense()));
      financialStatement.setMargin(financialStatement.getMargin().add(newBranch.getMargin()));
      financialStatement.setNetProfit(financialStatement.getNetProfit().add(newBranch.getNetProfit()));
      financialStatement.setRevenue(financialStatement.getRevenue().add(newBranch.getRevenue()));
      financialStatement.setStaffExpense(financialStatement.getStaffExpense().add(newBranch.getStaffExpense()));
      financialStatement.setTotalRent(financialStatement.getTotalRent().add(newBranch.getRentAmount()));
    try {
      financialStatement.setFinancialRatio(financialStatement.getNetProfit().
              divide(financialStatement.getInstallment().getNumber().doubleValueExact()));
    } catch (ArithmeticException ex) {
      logger.error("Cannot divide by zero!");
    }

    financialStatement.setFinancialRatioLow(financialStatement.getFinancialRatio().multiply(0.8));
    financialStatement.setOtherExpense(financialStatement.getOtherExpense().add(newBranch.getOtherExpense()));
    financialStatement.setNumberOfStaff(financialStatement.getNumberOfStaff() + newBranch.getNumberOfStaff());
    }
    financialStatement.setTotalBranch(financialStatement.getTotalBranch() + 1);
    repository.save(financialStatement);
  }

  @EventHandler
  public void on(BranchUpdatedEvent event) {
    FinancialStatementDTO financialStatement = repository.findOne(event.getApplicationId());

    Branch previousBranch = event.getOldBranch();
    Branch updatedBranch = event.getNewBranch();

    if (BranchStatus.ACTIVE.equals(event.getNewBranch().getBranchStatus())) {
      MonetaryAmount diffExpense = updatedBranch.getExpense().subtract(previousBranch.getExpense());
      MonetaryAmount diffMargin = updatedBranch.getMargin().subtract(previousBranch.getMargin());
      MonetaryAmount diffNetProfit = updatedBranch.getNetProfit().subtract(previousBranch.getNetProfit());
      MonetaryAmount diffRevenue = updatedBranch.getRevenue().subtract(previousBranch.getRevenue());
      MonetaryAmount diffStaffExpense = updatedBranch.getStaffExpense().subtract(previousBranch.getStaffExpense());
      int diffNumberOfStaff = updatedBranch.getNumberOfStaff() - previousBranch.getNumberOfStaff();
      MonetaryAmount diffTotalRent = updatedBranch.getRentAmount().subtract(previousBranch.getRentAmount());
      MonetaryAmount diffOtherExpense = updatedBranch.getOtherExpense().subtract(previousBranch.getOtherExpense());

      financialStatement.setExpense(financialStatement.getExpense().add(diffExpense));
      financialStatement.setMargin(financialStatement.getMargin().add(diffMargin));
      financialStatement.setNetProfit(financialStatement.getNetProfit().add(diffNetProfit));
      financialStatement.setRevenue(financialStatement.getRevenue().add(diffRevenue));
      financialStatement.setStaffExpense(financialStatement.getStaffExpense().add(diffStaffExpense));
      financialStatement.setNumberOfStaff(financialStatement.getNumberOfStaff() + diffNumberOfStaff);
      financialStatement.setTotalRent(financialStatement.getTotalRent().add(diffTotalRent));
      financialStatement.setOtherExpense(financialStatement.getOtherExpense().add(diffOtherExpense));
      try {
        financialStatement.setFinancialRatio(financialStatement.getNetProfit().
                divide(financialStatement.getInstallment().getNumber().doubleValueExact()));
      } catch (ArithmeticException ex) {
        logger.error("Cannot divide by zero!");
      }
      financialStatement.setFinancialRatioLow(financialStatement.getFinancialRatio().multiply(0.8));
      repository.save(financialStatement);
    }
  }

  @EventHandler
  public void on(BranchMarkedAsActiveEvent event) {
    Branch branch = branchRepository.findOne(event.getBranchId());
    FinancialStatementDTO financialStatement = repository.findOne(event.getApplicationId());
    financialStatement.setExpense(financialStatement.getExpense().add(branch.getExpense()));
    financialStatement.setMargin(financialStatement.getMargin().add(branch.getMargin()));
    financialStatement.setNetProfit(financialStatement.getNetProfit().add(branch.getNetProfit()));
    financialStatement.setRevenue(financialStatement.getRevenue().add(branch.getRevenue()));
    financialStatement.setStaffExpense(financialStatement.getStaffExpense().add(branch.getStaffExpense()));
    financialStatement.setNumberOfStaff(financialStatement.getNumberOfStaff() + branch.getNumberOfStaff());
    financialStatement.setTotalRent(financialStatement.getTotalRent().add(branch.getRentAmount()));
    financialStatement.setOtherExpense(financialStatement.getOtherExpense().add(branch.getOtherExpense()));
    try {
      financialStatement.setFinancialRatio(financialStatement.getNetProfit().
              divide(financialStatement.getInstallment().getNumber().doubleValueExact()));
    } catch (ArithmeticException ex) {
      logger.error("Cannot divide by zero!");
    }
    financialStatement.setFinancialRatioLow(financialStatement.getFinancialRatio().multiply(0.8));

    repository.save(financialStatement);
  }

  @EventHandler
  public void on(BranchMarkedAsInactiveEvent event) {
    Branch branch = branchRepository.findOne(event.getBranchId());
    FinancialStatementDTO financialStatement = repository.findOne(event.getApplicationId());
    financialStatement.setExpense(financialStatement.getExpense().subtract(branch.getExpense()));
    financialStatement.setMargin(financialStatement.getMargin().subtract(branch.getMargin()));
    financialStatement.setNetProfit(financialStatement.getNetProfit().subtract(branch.getNetProfit()));
    financialStatement.setRevenue(financialStatement.getRevenue().subtract(branch.getRevenue()));
    financialStatement.setStaffExpense(financialStatement.getStaffExpense().subtract(branch.getStaffExpense()));
    financialStatement.setNumberOfStaff(financialStatement.getNumberOfStaff() - branch.getNumberOfStaff());
    financialStatement.setTotalRent(financialStatement.getTotalRent().subtract(branch.getRentAmount()));
    financialStatement.setOtherExpense(financialStatement.getOtherExpense().subtract(branch.getOtherExpense()));
    try {
      financialStatement.setFinancialRatio(financialStatement.getNetProfit().
              divide(financialStatement.getInstallment().getNumber().doubleValueExact()));
    } catch (ArithmeticException ex) {
      logger.error("Cannot divide by zero!");
    }
    financialStatement.setFinancialRatioLow(financialStatement.getFinancialRatio().multiply(0.8));

    repository.save(financialStatement);
  }

  @EventHandler
  public void on(BranchDeletedEvent event) {
    Branch branch = branchRepository.findOne(event.getBranchId());
    FinancialStatementDTO financialStatement = repository.findOne(event.getId());
    financialStatement.setTotalBranch((financialStatement.getTotalBranch() - 1));
    financialStatement.setExpense(financialStatement.getExpense().subtract(branch.getExpense()));
    financialStatement.setMargin(financialStatement.getMargin().subtract(branch.getMargin()));
    financialStatement.setNetProfit(financialStatement.getNetProfit().subtract(branch.getNetProfit()));
    financialStatement.setRevenue(financialStatement.getRevenue().subtract(branch.getRevenue()));
    financialStatement.setStaffExpense(financialStatement.getStaffExpense().subtract(branch.getStaffExpense()));
    financialStatement.setNumberOfStaff(financialStatement.getNumberOfStaff() - branch.getNumberOfStaff());
    financialStatement.setTotalRent(financialStatement.getTotalRent().subtract(branch.getRentAmount()));
    financialStatement.setOtherExpense(financialStatement.getOtherExpense().subtract(branch.getOtherExpense()));
    try {
      financialStatement.setFinancialRatio(financialStatement.getNetProfit().
              divide(financialStatement.getInstallment().getNumber().doubleValueExact()));
    } catch (ArithmeticException ex) {
      logger.error("Cannot divide by zero!");
    }
    financialStatement.setFinancialRatioLow(financialStatement.getFinancialRatio().multiply(0.8));

    repository.save(financialStatement);
  }
}
