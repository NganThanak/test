package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.field;

import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryDTO;
import com.gl.csf.underwriting.query.application.underwriting.history.HistoryRepository;
import com.gl.csf.underwriting.query.application.util.I18nMessage;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 14/10/2017.
 */
@Component
public class FieldCheckItemEventListener {
  private final FieldCheckItemRepository repository;
  private final FieldCheckItemDocumentRepository documentRepository;
  private final HistoryRepository historyRepository;
  private final I18nMessage i18nMessage;

  @Inject
  public FieldCheckItemEventListener(FieldCheckItemRepository repository, FieldCheckItemDocumentRepository documentRepository, HistoryRepository historyRepository, I18nMessage i18nMessage){
    this.repository = repository;
    this.documentRepository = documentRepository;
    this.historyRepository = historyRepository;
    this.i18nMessage = i18nMessage;
  }

  @EventHandler
  private void on(FieldCheckRequestedEvent event) {
    for(Map.Entry<String, FieldDefinition> entry : event.getUnderwritingFields().entrySet()){
      String underwritingFieldId = entry.getKey();
      FieldDefinition fieldDefinition = entry.getValue();
      FieldCheckItemDTO fieldCheckItem = new FieldCheckItemDTO(UUID.randomUUID().toString(), event.getApplicationId(), event.getFieldCheckId(), underwritingFieldId,
              fieldDefinition.getName(), fieldDefinition.getDescription(), fieldDefinition.isMandatory(), fieldDefinition.isTextRequired(), fieldDefinition.isDocumentRequired());
      fieldCheckItem.setIsSubmitted(false);
      repository.save(fieldCheckItem);
    }
  }

  @EventHandler
  private void on(FieldCheckingFieldEditedEvent event){
    FieldCheckItemDTO fieldCheckItem = repository.findOneByUnderwritingFieldIdAndIsSubmitted(event.getUnderwritingFieldId(), false);
    fieldCheckItem.setFieldValue(event.getContent());
    repository.save(fieldCheckItem);
  }

  @EventHandler
  private void on(FieldCheckingFieldCommentEditedEvent event){
    FieldCheckItemDTO fieldCheckItem = repository.findOneByUnderwritingFieldIdAndIsSubmitted(event.getUnderwritingFieldId(), false);
    fieldCheckItem.setCommentValue(event.getComment());
    repository.save(fieldCheckItem);
  }

  @EventHandler
  private void on(FieldCheckingResultSubmittedEvent event){
    event.getFieldCheckResults().forEach(result->{
      FieldCheckItemDTO fieldCheckItem = repository.findOneByUnderwritingFieldIdAndIsSubmitted(result.getUnderwritingFieldId(), false);
      fieldCheckItem.setIsSubmitted(true);
      repository.save(fieldCheckItem);
    });
  }

  @EventHandler
  private void on(FieldCheckingFieldDocumentAttachedEvent event){
    FieldCheckItemDTO fieldCheckItem = repository.findOneByUnderwritingFieldIdAndIsSubmitted(event.getUnderwritingFieldId(), false);
    FieldCheckItemDocumentDTO fieldCheckItemDocument = new FieldCheckItemDocumentDTO(event.getDocumentDescriptor(), fieldCheckItem,
            event.getUsername(), event.getUnderwritingFieldId(), event.getFileName(), LocalDateTime.now());
    documentRepository.save(fieldCheckItemDocument);
  }

  @EventHandler
  private void on(FieldCheckingFieldDocumentDeletedEvent event){
    FieldCheckItemDocumentDTO fieldCheckItemDocumentDTO = documentRepository.findByUnderwritingFieldId(event.getUnderwritingFieldId());
    HistoryDTO history = new HistoryDTO(UUID.randomUUID().toString(), event.getApplicationId(), LocalDateTime.now(), fieldCheckItemDocumentDTO.getEditorId(), i18nMessage.getMessage("deleted.fieldcheck.document.action"), i18nMessage.getMessage("deleted.fieldcheck.document.description", fieldCheckItemDocumentDTO.getFileName()));
    historyRepository.save(history);

    documentRepository.delete(event.getDocumentDescriptor());
  }
}
