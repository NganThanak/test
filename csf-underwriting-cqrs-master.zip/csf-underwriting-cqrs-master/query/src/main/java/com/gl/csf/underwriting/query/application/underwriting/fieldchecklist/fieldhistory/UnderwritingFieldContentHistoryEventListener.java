package com.gl.csf.underwriting.query.application.underwriting.fieldchecklist.fieldhistory;

import com.gl.csf.underwriting.api.application.event.FieldCheckingResultSubmittedEvent;
import com.gl.csf.underwriting.api.application.event.UnderwritingFieldEditedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by p.ly on 10/7/2017.
 */
@Component
public class UnderwritingFieldContentHistoryEventListener {
  private final UnderwritingFieldContentHistoryRepository repository;

  @Inject
  public UnderwritingFieldContentHistoryEventListener(UnderwritingFieldContentHistoryRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(UnderwritingFieldEditedEvent event){
    UnderwritingFieldContentHistoryDTO underwritingFieldContentHistoryDTO = new UnderwritingFieldContentHistoryDTO();
    underwritingFieldContentHistoryDTO.setId(UUID.randomUUID());
    underwritingFieldContentHistoryDTO.setApplicationId(event.getApplicationId());
    underwritingFieldContentHistoryDTO.setDateModified(LocalDateTime.now());
    underwritingFieldContentHistoryDTO.setName(event.getUsername());
    underwritingFieldContentHistoryDTO.setContent(event.getContent());
    underwritingFieldContentHistoryDTO.setUnderwritingFieldId(event.getUnderwritingFieldId());
    underwritingFieldContentHistoryDTO.setSubmitted(true);
    repository.save(underwritingFieldContentHistoryDTO);
  }

  @EventHandler
  public void on(FieldCheckingResultSubmittedEvent event){
    event.getFieldCheckResults().forEach(result->{
      UnderwritingFieldContentHistoryDTO underwritingFieldContentHistoryDTO = new UnderwritingFieldContentHistoryDTO();
      underwritingFieldContentHistoryDTO.setId(UUID.randomUUID());
      underwritingFieldContentHistoryDTO.setApplicationId(event.getApplicationId());
      underwritingFieldContentHistoryDTO.setDateModified(LocalDateTime.now());
      underwritingFieldContentHistoryDTO.setName(event.getUsername());
      underwritingFieldContentHistoryDTO.setContent(result.getText());
      underwritingFieldContentHistoryDTO.setUnderwritingFieldId(result.getUnderwritingFieldId());
      underwritingFieldContentHistoryDTO.setSubmitted(true);
      repository.save(underwritingFieldContentHistoryDTO);
    });
  }
}
