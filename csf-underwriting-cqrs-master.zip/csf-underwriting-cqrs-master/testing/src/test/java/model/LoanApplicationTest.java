package model;

import com.gl.csf.underwriting.api.application.command.BookFieldCheckCommand;
import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import com.gl.csf.underwriting.core.application.LoanApplication;
import com.gl.csf.underwriting.core.application.LoanApplicationCommandHandler;
import com.gl.csf.underwriting.core.service.ApplicationReferenceService;
import com.gl.csf.underwriting.service.LoanProductTemplateService;
import org.axonframework.commandhandling.CommandMessage;
import org.axonframework.messaging.MessageDispatchInterceptor;
import org.axonframework.test.aggregate.AggregateTestFixture;
import org.axonframework.test.aggregate.FixtureConfiguration;
import org.junit.Before;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.UUID;

/**
 * Created by jerome on 8/8/17.
 */
public class LoanApplicationTest {

  private FixtureConfiguration fixture;
  private ApplicationReferenceService applicationReferenceService;
  private LoanProductTemplateService loanProductTemplateService;


  @Before
  public void setUp() {
    fixture = new AggregateTestFixture(LoanApplication.class);
    applicationReferenceService = new ApplicationReferenceService();
    fixture.registerAnnotatedCommandHandler(
            new LoanApplicationCommandHandler(fixture.getRepository(), applicationReferenceService, loanProductTemplateService));
    fixture.registerCommandDispatchInterceptor(
            (MessageDispatchInterceptor<CommandMessage<?>>) commandMessages -> (index, commandMessage) -> {
              if (BookFieldCheckCommand.class.getName().equals(commandMessage.getCommandName())) {
                return commandMessage.andMetaData(Collections.singletonMap("username", "FC1"));
              } else {
                return commandMessage.andMetaData(Collections.singletonMap("username", "UW1"));
              }
            });


  }

//  @Test
//  public void testInitializeUnderwriting() {
//
//    Application application = new Application();
//    String applicationId = UUID.randomUUID().toString();
//    String referenceNumber = applicationReferenceService.getReferenceNumber();
//    String fieldCheckId = UUID.randomUUID().toString();
//    String underwriterId = "UW1";
//    String fieldCheckerId = "FC1";
//
//    final Collection<FieldDefinition> fieldDefinitions = mockedFieldDefinitions();
//    fixture.given(new ApplicationCreatedEvent(applicationId, application, referenceNumber),
//        new UnderwritingInitializedEvent(applicationId, fieldDefinitions),
//        new FieldCheckRequestedEvent(fieldCheckId, applicationId,
//            fieldDefinitions.stream().map(FieldDefinition::getId).collect(
//                Collectors.toList()), underwriterId))
//        .when(new BookFieldCheckCommand(applicationId, fieldCheckId))
//        .expectEvents(new FieldCheckBookedEvent(applicationId, fieldCheckId, fieldCheckerId))
//        .expectSuccessfulHandlerExecution();
//
//  }

  private Collection<FieldDefinition> mockedFieldDefinitions() {

    return Arrays.asList(
            new FieldDefinition(UUID.randomUUID().toString(), "Field Definition 1", "Description",
                    true,
                    true, true),
            new FieldDefinition(UUID.randomUUID().toString(), "Field Definition 2", "Description",
                    true,
                    true, true));
  }


}