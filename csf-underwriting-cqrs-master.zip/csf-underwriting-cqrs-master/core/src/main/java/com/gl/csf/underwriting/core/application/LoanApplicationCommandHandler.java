package com.gl.csf.underwriting.core.application;

import com.gl.csf.underwriting.api.application.command.CreateApplicationCommand;
import com.gl.csf.underwriting.api.application.command.SaveApplicationCommand;
import com.gl.csf.underwriting.api.application.command.SubmitApplicationCommand;
import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.core.service.ApplicationReferenceService;
import com.gl.csf.underwriting.service.LoanProductTemplateService;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.Aggregate;
import org.axonframework.commandhandling.model.AggregateNotFoundException;
import org.axonframework.commandhandling.model.Repository;
import org.axonframework.messaging.annotation.MetaDataValue;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
public class LoanApplicationCommandHandler {

  private Repository<LoanApplication> repository;
  private ApplicationReferenceService applicationReferenceService;
  private LoanProductTemplateService loanProductTemplateService;

  public LoanApplicationCommandHandler(Repository<LoanApplication> loanApplicationRepository, ApplicationReferenceService applicationReferenceService,
                                       LoanProductTemplateService loanProductTemplateService) {
    this.repository = loanApplicationRepository;
    this.applicationReferenceService = applicationReferenceService;
    this.loanProductTemplateService = loanProductTemplateService;
  }

  @CommandHandler
  public void handle(SaveApplicationCommand saveApplicationCommand){
    try {
      // Try to submit
      Aggregate<LoanApplication> loanApplication = repository.load(saveApplicationCommand.getId());
      loanApplication.execute(l -> l.save(saveApplicationCommand));
    } catch(AggregateNotFoundException exception){
      try {
        // Create
        createApplication(saveApplicationCommand.getId(), saveApplicationCommand.getApplication());
        // Save
        Aggregate<LoanApplication> loanApplication = repository.load(saveApplicationCommand.getId());
        loanApplication.execute(l -> l.save(saveApplicationCommand));
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  @CommandHandler
  public void handle(SubmitApplicationCommand submitApplicationCommand, @MetaDataValue("username") String username){
    try {
      // Try to submit
      Aggregate<LoanApplication> loanApplication = repository.load(submitApplicationCommand.getId());
      loanApplication.execute(l -> l.submit(submitApplicationCommand, username, loanProductTemplateService));
    } catch(AggregateNotFoundException exception){
      try {
        // Create
        createApplication(submitApplicationCommand.getId(), submitApplicationCommand.getApplication());
        // Submit
        Aggregate<LoanApplication> loanApplication = repository.load(submitApplicationCommand.getId());
        loanApplication.execute(l -> l.submit(submitApplicationCommand, username, loanProductTemplateService));
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  private void createApplication(String id, Application application) throws Exception {
    CreateApplicationCommand createApplicationCommand = new CreateApplicationCommand();
    createApplicationCommand.setId(id);
    createApplicationCommand.setApplication(application);
    createApplicationCommand.setReferenceNumber(applicationReferenceService.getReferenceNumber());
    repository.newInstance(() -> new LoanApplication(createApplicationCommand));
  }
}
