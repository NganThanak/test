package com.gl.csf.underwriting.core.application;

import com.gl.csf.underwriting.api.application.command.InitializeUnderwritingCommand;
import com.gl.csf.underwriting.api.application.command.StartUnderwritingCommand;
import com.gl.csf.underwriting.api.application.event.ApplicationBookedForUnderwritingEvent;
import com.gl.csf.underwriting.api.application.event.ApplicationSubmittedEvent;
import com.gl.csf.underwriting.core.service.FieldCheckListService;
import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.callbacks.LoggingCallback;
import org.axonframework.eventhandling.saga.EndSaga;
import org.axonframework.eventhandling.saga.SagaEventHandler;
import org.axonframework.eventhandling.saga.StartSaga;
import org.axonframework.spring.stereotype.Saga;

import javax.inject.Inject;

import static org.axonframework.commandhandling.GenericCommandMessage.asCommandMessage;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/) Author: Kuylim Tith
 * (k.tith@gl-f.com) on 9/6/2017.
 */
@Saga
public class UnderwritingSaga {

  @Inject
  private transient FieldCheckListService fieldCheckListService;
  @Inject
  private transient CommandBus commandBus;

  @StartSaga
  @SagaEventHandler(associationProperty = "applicationId")
  public void on(ApplicationSubmittedEvent event){
    InitializeUnderwritingCommand command = new InitializeUnderwritingCommand(event.getApplicationId(), fieldCheckListService.getFieldDefinitions());
    commandBus.dispatch(asCommandMessage(command), LoggingCallback.INSTANCE);
  }

  @EndSaga
  @SagaEventHandler(associationProperty = "applicationId")
  public void on(ApplicationBookedForUnderwritingEvent event) {
    StartUnderwritingCommand command = new StartUnderwritingCommand(event.getApplicationId());
    commandBus.dispatch(asCommandMessage(command), LoggingCallback.INSTANCE);
  }

}
