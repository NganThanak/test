package com.gl.csf.underwriting.core.application;

import com.gl.csf.underwriting.api.application.businessinfo.branch.command.*;
import com.gl.csf.underwriting.api.application.businessinfo.branch.event.*;
import com.gl.csf.underwriting.api.application.businessinfo.business.command.UpdateBusinessInfoCommand;
import com.gl.csf.underwriting.api.application.businessinfo.business.event.BusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.command.AddFinancialDocumentCommand;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.command.DeleteFinancialDocumentCommand;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.command.UpdateFinancialDocumentCommand;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event.FinancialDocumentAddedEvent;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event.FinancialDocumentDeletedEvent;
import com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event.FinancialDocumentUpdatedEvent;
import com.gl.csf.underwriting.api.application.command.*;
import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdateBankInformationCommand;
import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdateGuarantorBusinessInfoCommand;
import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdateGuarantorCommand;
import com.gl.csf.underwriting.api.application.ownerinfo.command.UpdatePersonalInformationCommand;
import com.gl.csf.underwriting.api.application.ownerinfo.event.BankInformationUpdatedEvent;
import com.gl.csf.underwriting.api.application.ownerinfo.event.GuarantorBusinessInfoUpdatedEvent;
import com.gl.csf.underwriting.api.application.ownerinfo.event.GuarantorUpdatedEvent;
import com.gl.csf.underwriting.api.application.ownerinfo.event.PersonalInformationUpdatedEvent;
import com.gl.csf.underwriting.api.application.productinfo.command.UpdateProductInformationCommand;
import com.gl.csf.underwriting.api.application.productinfo.event.ProductInformationUpdateEvent;
import com.gl.csf.underwriting.api.creditscoring.command.RateApplicationCommand;
import com.gl.csf.underwriting.api.creditscoring.event.ApplicationRatedEvent;
import com.gl.csf.underwriting.api.document.command.RemoveDocumentCommand;
import com.gl.csf.underwriting.api.document.command.UploadDocumentCommand;
import com.gl.csf.underwriting.api.document.event.DocumentRemovedEvent;
import com.gl.csf.underwriting.api.document.event.DocumentUploadedEvent;
import com.gl.csf.underwriting.api.offeramount.command.MakeOfferCommand;
import com.gl.csf.underwriting.api.offeramount.event.OfferMadeEvent;
import com.gl.csf.underwriting.api.supportdocument.command.RemoveSupportingDocumentCommand;
import com.gl.csf.underwriting.api.supportdocument.command.SaveSupportingDocumentCommand;
import com.gl.csf.underwriting.api.supportdocument.command.UpdateSupportingDocumentCommand;
import com.gl.csf.underwriting.api.supportdocument.event.SupportingDocumentRemovedEvent;
import com.gl.csf.underwriting.api.supportdocument.event.SupportingDocumentSavedEvent;
import com.gl.csf.underwriting.api.supportdocument.event.SupportingDocumentUpdatedEvent;
import com.gl.csf.underwriting.common.model.document.Document;
import com.gl.csf.underwriting.common.model.underwriting.FieldCheckResult;
import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import com.gl.csf.underwriting.common.model.user.Role;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.AggregateMember;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.messaging.annotation.MetaDataValue;

import java.util.*;
import java.util.stream.Collectors;

import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;
/**
 * Created by jerome on 8/28/17.
 */
public class Underwriting {
  
  private String applicationId;
  private Status status;
  private Map<String, String> assignees;
  @AggregateMember
  private Map<String, UnderwritingField> underwritingFields = new HashMap<>();
  @AggregateMember
  private FieldCheck fieldCheck;

  Underwriting(String applicationId,
      Map<String, FieldDefinition> underwritingFieldDefinitions, String startRole) {
    this.applicationId = applicationId;
    this.status = Status.NEW;
    this.assignees = new HashMap<>();
    this.assignees.put(startRole, null);
    underwritingFieldDefinitions.forEach((underwritingFieldId, fieldDefinition) ->
        this.underwritingFields.put(underwritingFieldId,
            new UnderwritingField(underwritingFieldId, applicationId, fieldDefinition)));
  }
  
  @EventSourcingHandler
  private void on(UnderwritingFieldDocumentDeletedEvent event) {
    underwritingFields.remove(event.getDocumentDescriptor());
  }
  
  @EventSourcingHandler
  private void on(UnderwritingFieldDocumentAttachedEvent event) {
    UnderwritingField underwritingField = underwritingFields.get(event.getUnderwritingFieldId());
    underwritingField.getAttachedDocuments().add(event.getDocumentDescriptor());
  }
  
  @EventSourcingHandler
  private void on(UnderwritingFieldEditedEvent event) {
    UnderwritingField underwritingField = underwritingFields.get(event.getUnderwritingFieldId());
    underwritingField.setHasText(true);
  }

  @EventSourcingHandler
  public void on(FieldCheckingResultSubmittedEvent event) {
    // Merge result of field checking to underwriting fields
    for(FieldCheckResult fieldCheckResult : event.getFieldCheckResults()){
      UnderwritingField underwritingField = underwritingFields.get(fieldCheckResult.getUnderwritingFieldId());
      underwritingField.setHasText(fieldCheckResult.hasText());
      underwritingField.getAttachedDocuments().addAll(
          fieldCheckResult.getAttachedDocuments().stream().map(Document::getDocumentDescriptor)
              .collect(Collectors.toList()));
    }
    // Remove field checker from assignee as he/she has finished the job
    assignees.remove(Role.FIELD_CHECKER.toString());
  }

  @CommandHandler
  public void bookApplicationForUnderwriting(BookApplicationForUnderwritingCommand command,
      @MetaDataValue("username") String username) {
    if (!assignees.containsKey(command.getRole()) || assignees.get(command.getRole()) != null) {
      throw new IllegalStateException("Application can't be booked");
    }

    apply(new ApplicationBookedForUnderwritingEvent(command.getApplicationId(), username,
        command.getRole()));
  }

  @CommandHandler
  public void start(StartUnderwritingCommand command) {
    apply(new UnderwritingStartedEvent(command.getApplicationId()));
  }

  private boolean hasPendingFieldCheck() {
    return fieldCheck != null && !fieldCheck.isDone();
  }

  private boolean areAllMandatoryFieldsUnderwritten() {
    return !underwritingFields.values().stream().filter(UnderwritingField::isMandatory)
        .anyMatch(underwritingField -> !underwritingField.isUnderwritten());
  }

  private void checkUnderwritingDecisionConditions() {
    if (!areAllMandatoryFieldsUnderwritten()) {
      Optional<UnderwritingField> result = underwritingFields.values().stream().filter(underwritingField -> !underwritingField.isUnderwritten() && underwritingField.isMandatory()).findFirst();
      throw new IllegalStateException(result.get().fieldDefinition().getName() + " need to be underwritten.");
    }
    if (hasPendingFieldCheck()) {
      throw new IllegalStateException("A field check is in progress");
    }
  }

  @CommandHandler
  public void recommendApplicationApproval(
      RecommendApplicationApprovalCommand recommendApplicationApprovalCommand,
      @MetaDataValue("username") String underwriterId) {
    checkUnderwritingDecisionConditions();
    apply(new ApplicationApprovalRecommendedEvent(applicationId, underwriterId));
  }

  @EventSourcingHandler
  private void on(ApplicationApprovalRecommendedEvent event) {
    this.assignees.put(Role.SENIOR_UNDERWRITER.toString(), null);
  }

  @CommandHandler
  public void recommendApplicationRejection(
      RecommendApplicationRejectionCommand recommendApplicationRejectionCommand,
      @MetaDataValue("username") String underwriterId) {
    checkUnderwritingDecisionConditions();
    apply(new ApplicationRejectionRecommendedEvent(applicationId, underwriterId));
  }

  @EventSourcingHandler
  private void on(ApplicationRejectionRecommendedEvent event) {
    this.assignees.put(Role.SENIOR_UNDERWRITER.toString(), null);
  }


  @CommandHandler
  public void updatePersionalInformation(UpdatePersonalInformationCommand command, @MetaDataValue("username") String username) {
    apply(new PersonalInformationUpdatedEvent(command.getApplicationId(), command.getPersonalInformationDTO(), username));
  }

  @CommandHandler
  public void updateBankInfomation(UpdateBankInformationCommand command, @MetaDataValue("username") String username) {
    apply(new BankInformationUpdatedEvent(command.getApplicationId(), username,
        command.getBankInformationDTO()));
  }

  @CommandHandler
  public void updateGuarantor(UpdateGuarantorCommand command) {
    apply(new GuarantorUpdatedEvent(command.getApplicationId(), command.getGuarantorDTO()));
  }

  @CommandHandler
  public void updateGuarantorBusiness(UpdateGuarantorBusinessInfoCommand command, @MetaDataValue("username") String username) {
    apply(new GuarantorBusinessInfoUpdatedEvent(command.getApplicationId(), username,
            command.getGuarantorBusiness()));
  }

  @CommandHandler
  public void decline(DeclineApplicationCommand declineApplicationCommand,
      @MetaDataValue("username") String username) {
    apply(new ApplicationDeclinedEvent(applicationId, username,
        declineApplicationCommand.getDeclineReason()));
  }

  @CommandHandler
  public void approveApplication(ApproveApplicationCommand approveApplicationCommand,
      @MetaDataValue("username") String username) {
    checkUnderwritingDecisionConditions();
    apply(new ApplicationApprovedEvent(applicationId, username));
  }

  @EventSourcingHandler
  private void on(ApplicationApprovedEvent event) {
    this.assignees.clear();
    this.status = Status.END;
  }
  
  @CommandHandler
  public void rejectApplication(RejectApplicationCommand rejectApplicationCommand,
      @MetaDataValue("username") String username) {
    checkUnderwritingDecisionConditions();
    apply(new ApplicationRejectedEvent(applicationId, username));
  }

  @EventSourcingHandler
  private void on(ApplicationRejectedEvent event) {
    this.assignees.clear();
    this.status = Status.END;
  }

  @CommandHandler
  public void requestFieldCheck(RequestFieldCheckCommand requestFieldCheckCommand,
      @MetaDataValue("username") String username) {
    if (hasPendingFieldCheck()) {
      throw new IllegalStateException("A field check is already in progress");
    }

    apply(new FieldCheckRequestedEvent(UUID.randomUUID().toString(), applicationId,
        underwritingFields.values().stream().filter(underwritingField ->
            requestFieldCheckCommand.getUnderwritingFieldIds().contains(underwritingField.id()))
            .collect(Collectors.toMap(UnderwritingField::id, UnderwritingField::fieldDefinition)),
        username));
  }

  @CommandHandler
  public void submitFieldCheckingResult(SubmitFieldCheckingResultCommand command,
      @MetaDataValue("username") String username) {
    fieldCheck.submitFieldCheckingResults(username);
  }

  @EventSourcingHandler
  private void on(ApplicationDeclinedEvent event) {
    this.status = Status.END;
    this.assignees.clear();
  }

  @EventSourcingHandler
  private void on(FieldCheckRequestedEvent event) {
    this.fieldCheck = new FieldCheck(applicationId, event.getFieldCheckId(),
        event.getUnderwritingFields());
    this.assignees.put(Role.FIELD_CHECKER.toString(), null);
  }

  @EventSourcingHandler
  private void on(UnderwritingStartedEvent event) {
    this.status = Status.STARTED;
  }

  @CommandHandler
  public void creditScoring(RateApplicationCommand command,
      @MetaDataValue("username") String username) {
    apply(new ApplicationRatedEvent(command.getApplicationId(), username, command.getScore(),
        command.getReason(), command.getDocuments()));
  }

  @EventSourcingHandler
  private void on(ApplicationBookedForUnderwritingEvent event) {
    assignees.put(event.getRole(), event.getAssigneeId());
  }

  @CommandHandler
  public void rate(RateApplicationCommand command, @MetaDataValue("username") String username) {
    apply(new ApplicationRatedEvent(command.getApplicationId(), username, command.getScore(),
        command.getReason(), command.getDocuments()));
  }

  @CommandHandler
  public void makeOffer(MakeOfferCommand command, @MetaDataValue("username") String username) {
    apply(new OfferMadeEvent(command.getApplicationId(), username, command.getOffer()));
  }

  @CommandHandler
  public void uploadDocument(UploadDocumentCommand comment) {
    apply(new DocumentUploadedEvent(comment.getApplicationId(), comment.getDocumentDescriptor()));
  }

  @CommandHandler
  public void removeDocument(RemoveDocumentCommand command) {
    apply(new DocumentRemovedEvent(command.getApplicationId(), command.getDocumentDescriptor()));
  }

  @CommandHandler
  private void updateBusinessInfo(UpdateBusinessInfoCommand command, @MetaDataValue("username") String username) {
    apply(new BusinessInfoUpdatedEvent(command.getApplicationId(), command.getBusiness(), username));
  }

  @CommandHandler
  private void addBusinessBranch(AddBranchCommand command, @MetaDataValue("username") String username) {
    apply(new BranchAddedEvent(command.getApplicationId(), command.getBranch(), username));
  }

  @CommandHandler
  public void updateBusinessBranch(UpdateBranchCommand command, @MetaDataValue("username") String username) {
    apply(new BranchUpdatedEvent(command.getApplicationId(), command.getOldBranch(),
            command.getNewBranch(), username));
  }
  
  @CommandHandler
  public void deleteBusinessBranch(DeleteBranchCommand command) {
    apply(new BranchDeletedEvent(command.getId(),command.getBranchId()));
  }

  @CommandHandler
  private void markBusinessBranchAsActive(MarkBranchAsActiveCommand command) {
    apply(new BranchMarkedAsActiveEvent(command.getApplicationId(), command.getBranchId(),
        command.getStatus()));
  }

  @CommandHandler
  private void markBusinessBranchAsInactive(MarkBranchAsInactiveCommand command) {
    apply(new BranchMarkedAsInactiveEvent(command.getApplicationId(), command.getBranchId(),
        command.getStatus()));
  }

  @CommandHandler
  public void addFinancialDocument(AddFinancialDocumentCommand comment) {
    apply(new FinancialDocumentAddedEvent(comment.getApplicationId(),
        comment.getFinancialDocumentDTO()));
  }

  @CommandHandler
  public void updateFinancialDocument(UpdateFinancialDocumentCommand command) {
    apply(new FinancialDocumentUpdatedEvent(command.getApplicationId(),
        command.getFinancialDocumentDTO()));
  }

  @CommandHandler
  public void deleteFinancialDocument(DeleteFinancialDocumentCommand command) {
    apply(new FinancialDocumentDeletedEvent(command.getApplicationId(), command.getDocumentDescriptor()));
  }

  @CommandHandler
  public void updateProductInformation(UpdateProductInformationCommand command, @MetaDataValue("username") String username) {
    apply(new ProductInformationUpdateEvent(command.getId(), command.getProductInformation(), username));
  }

  @CommandHandler
  public void saveSupportingDocument(SaveSupportingDocumentCommand command) {
    apply(new SupportingDocumentSavedEvent(command.getApplicationId(), command.getDocumentDTO()));
  }

  @CommandHandler
  public void uploadSupportingDocument(UpdateSupportingDocumentCommand command) {
    apply(new SupportingDocumentUpdatedEvent(command.getApplicationId(), command.getDocumentDTO()));
  }

  @CommandHandler
  public void removeSupportingDocument(RemoveSupportingDocumentCommand command, @MetaDataValue("username") String username) {
    apply(new SupportingDocumentRemovedEvent(command.getApplicationId(),
            command.getSupportingDocumentId(), username));
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Underwriting that = (Underwriting) o;
    return Objects.equals(applicationId, that.applicationId);
  }
  
  @Override
  public int hashCode() {
    return Objects.hash(applicationId);
  }
  public enum Status {
    NEW,
    STARTED,
    END
  }
}
