package com.gl.csf.underwriting.core.application;

import com.gl.csf.underwriting.api.application.command.*;
import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.EntityId;
import org.axonframework.messaging.annotation.MetaDataValue;

import java.util.HashSet;
import java.util.Set;

import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;

public class UnderwritingField {

  @EntityId
  private final String underwritingFieldId;
  private final FieldDefinition fieldDefinition;
  private final String applicationId;
  private boolean hasText;
  private Set<DocumentDescriptor> attachedDocuments = new HashSet<>();

  UnderwritingField(String underwritingFieldId, String applicationId, FieldDefinition fieldDefinition) {
    this.fieldDefinition = fieldDefinition;
    this.underwritingFieldId = underwritingFieldId;
    this.applicationId = applicationId;
  }

  FieldDefinition fieldDefinition() {
    return fieldDefinition;
  }

  public String id() {
    return underwritingFieldId;
  }
  Set<DocumentDescriptor> getAttachedDocuments() {
    return attachedDocuments;
  }

  void setHasText(boolean hasText) {
    this.hasText = hasText;
  }
  @CommandHandler
  public void edit(EditCommentCommand command, @MetaDataValue("username") String username) {
    apply(new CommentEditedEvent(applicationId, underwritingFieldId, command.getCommentId(), command.getContent(), username));
  }

  @CommandHandler
  public void edit(SaveFieldCheckCommentCommand command, @MetaDataValue("username") String username) {
    apply(new FieldCheckCommentSavedEvent(applicationId,underwritingFieldId,command.getComment(),username));
  }

  boolean isMandatory() {
    return fieldDefinition.isMandatory();
  }

  boolean isUnderwritten() {
    return (!fieldDefinition.isTextRequired() || hasText) && (!fieldDefinition.isDocumentRequired() || !attachedDocuments.isEmpty());
  }

  @CommandHandler
  public void edit(EditUnderwritingFieldCommand command, @MetaDataValue("username") String username) {
    apply(new UnderwritingFieldEditedEvent(applicationId, underwritingFieldId, command.getContent(), username));
  }

  @CommandHandler
  public void attachDocument(AttachDocumentToUnderwritingFieldCommand command, @MetaDataValue("username") String username) {
    apply(
        new UnderwritingFieldDocumentAttachedEvent(command.getApplicationId(), underwritingFieldId,
            command.getFileName(), command.getDocumentDescriptor(), username));
  }

  @CommandHandler
  public void deleteDocument(DeleteDocumentFromUnderwritingFieldCommand command, @MetaDataValue("username") String username) {
    apply(new UnderwritingFieldDocumentDeletedEvent(command.getApplicationId(),
            command.getUnderwritingFieldId(), command.getDocumentDescriptor(), username));
  }
}
