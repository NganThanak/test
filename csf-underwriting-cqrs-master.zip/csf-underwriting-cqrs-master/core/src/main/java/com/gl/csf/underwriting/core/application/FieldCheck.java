package com.gl.csf.underwriting.core.application;

import com.gl.csf.underwriting.api.application.command.AttachDocumentToFieldCheckingFieldCommand;
import com.gl.csf.underwriting.api.application.command.DeleteDocumentFromFieldCheckingFieldCommand;
import com.gl.csf.underwriting.api.application.command.EditFieldCheckingFieldCommand;
import com.gl.csf.underwriting.api.application.command.EditFieldCheckingFieldCommentCommand;
import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.common.model.document.Document;
import com.gl.csf.underwriting.common.model.underwriting.FieldCheckResult;
import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import com.gl.csf.underwriting.common.model.user.Role;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.EntityId;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.messaging.annotation.MetaDataValue;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;

public class FieldCheck {

  @EntityId
  private String fieldCheckId;
  private String applicationId;
  private Map<String, FieldCheckingField> fieldCheckingFields = new HashMap<>();
  private String fieldCheckerId;
  private Status status;

  FieldCheck(String applicationId, String fieldCheckId, Map<String, FieldDefinition> underwritingFieldIds) {
    this.fieldCheckId = fieldCheckId;
    this.applicationId = applicationId;
    this.status = Status.PENDING;
    underwritingFieldIds.forEach((key, value) -> this.fieldCheckingFields.put(key, new FieldCheckingField(key, applicationId, value)));
  }

  boolean isDone() {
    return status == Status.DONE;
  }

  void submitFieldCheckingResults(String username){
    for(FieldCheckingField fieldCheckingField : fieldCheckingFields.values()){
      if(fieldCheckingField.getFieldDefinition().isTextRequired() && !fieldCheckingField.hasText()){
        throw new IllegalStateException("Text is required");
      }

      if(fieldCheckingField.getFieldDefinition().isDocumentRequired() && !fieldCheckingField.hasDocument()){
        throw new IllegalStateException("Document is required");
      }
    }

    List<FieldCheckResult> fieldCheckResults = new ArrayList<>();
    fieldCheckingFields.values().forEach(field-> fieldCheckResults.add(
            new FieldCheckResult(field.getFieldDefinition().getName(), field.getFieldDefinition().getDescription(),
              field.getUnderwritingFieldId(), field.getText(), field.getComment(),
              field.getAttachedDocument().entrySet().stream()
                    .map(entry->new Document(entry.getValue(), entry.getKey()))
                    .collect(Collectors.toSet()))));

    apply(new FieldCheckingResultSubmittedEvent(applicationId, fieldCheckId, fieldCheckResults, username, LocalDateTime.now()));
  }

  @EventSourcingHandler
  private void on(FieldCheckingResultSubmittedEvent event){
    status = Status.DONE;
  }

  @EventSourcingHandler
  private void on(ApplicationBookedForUnderwritingEvent event) {
    if(event.getRole().equals(Role.FIELD_CHECKER.toString())) {
      this.status = Status.IN_PROGRESS;
      this.fieldCheckerId = event.getAssigneeId();
    }
  }

  @EventSourcingHandler
  private void on(ApplicationDeclinedEvent event) {
    if (!isDone()) {
      apply(new FieldCheckCancelledEvent(applicationId, fieldCheckId));
    }
  }

  @EventSourcingHandler
  private void on(FieldCheckCancelledEvent event) {
    this.status = Status.CANCELLED;
  }

  // Field checking field command and event handlers
  @CommandHandler
  private void edit(EditFieldCheckingFieldCommand command, @MetaDataValue("username") String username) {
    apply(new FieldCheckingFieldEditedEvent(command.getApplicationId(), command.getUnderwritingFieldId(), command.getContent(), username));
  }

  @EventSourcingHandler
  public void on(FieldCheckingFieldEditedEvent event){
    FieldCheckingField fieldCheckingField = fieldCheckingFields.get(event.getUnderwritingFieldId());
    fieldCheckingField.setText(event.getContent());
  }

  @CommandHandler
  private void attachDocument(AttachDocumentToFieldCheckingFieldCommand command, @MetaDataValue("username") String username){
    apply(new FieldCheckingFieldDocumentAttachedEvent(command.getApplicationId(), command.getUnderwritingFieldId(), command.getFileName(), command.getDocumentDescriptor(), username));
  }

  @EventSourcingHandler
  public void on(FieldCheckingFieldDocumentAttachedEvent event){
    FieldCheckingField fieldCheckingField = fieldCheckingFields.get(event.getUnderwritingFieldId());
    fieldCheckingField.getAttachedDocument().put(event.getDocumentDescriptor(), event.getFileName());
  }

  @CommandHandler
  private void deleteDocument(DeleteDocumentFromFieldCheckingFieldCommand command, @MetaDataValue("username") String username){
    apply(new FieldCheckingFieldDocumentDeletedEvent(command.getApplicationId(), command.getUnderwritingFieldId(), command.getDocumentDescriptor(), username));
  }

  @EventSourcingHandler
  public void on(FieldCheckingFieldDocumentDeletedEvent event) {
    FieldCheckingField fieldCheckingField = fieldCheckingFields.get(event.getUnderwritingFieldId());
    fieldCheckingField.getAttachedDocument().remove(event.getDocumentDescriptor());
  }

  @CommandHandler
  private void editComment(EditFieldCheckingFieldCommentCommand command, @MetaDataValue("username") String username){
    apply(new FieldCheckingFieldCommentEditedEvent(command.getApplicationId(), command.getUnderwritingFieldId(), command.getComment(), username));
  }

  @EventSourcingHandler
  public void on(FieldCheckingFieldCommentEditedEvent event){
    FieldCheckingField fieldCheckingField = fieldCheckingFields.get(event.getUnderwritingFieldId());
    fieldCheckingField.setComment(event.getComment());
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FieldCheck that = (FieldCheck) o;
    return Objects.equals(fieldCheckId, that.fieldCheckId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(fieldCheckId);
  }

  public enum Status {
    PENDING,
    IN_PROGRESS,
    CANCELLED,
    DONE
  }
}