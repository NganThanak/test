package com.gl.csf.underwriting.core.application;

import com.gl.csf.underwriting.api.application.command.*;
import com.gl.csf.underwriting.api.application.event.*;
import com.gl.csf.underwriting.common.model.application.ApplicationStatus;
import com.gl.csf.underwriting.common.model.parameter.LoanProductTemplate;
import com.gl.csf.underwriting.common.model.parameter.Term;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import com.gl.csf.underwriting.common.model.user.Role;
import com.gl.csf.underwriting.service.LoanProductTemplateService;
import javassist.NotFoundException;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.AggregateIdentifier;
import org.axonframework.commandhandling.model.AggregateMember;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.messaging.annotation.MetaDataValue;
import org.axonframework.spring.stereotype.Aggregate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;


/**
 * Created by jerome on 8/8/17.
 */
@Aggregate
public class LoanApplication {

  private final static Logger logger = LoggerFactory.getLogger(LoanApplication.class);

  @AggregateIdentifier
  private String id;
  private ApplicationStatus applicationStatus;
  @AggregateMember
  private Underwriting underwriting;

  private LoanApplication() {
  }

  public LoanApplication(CreateApplicationCommand createApplicationCommand) {
    apply(new ApplicationCreatedEvent(createApplicationCommand.getId(),
        createApplicationCommand.getApplication(), createApplicationCommand.getReferenceNumber()));
  }

  @EventSourcingHandler
  private void on(ApplicationDeclinedEvent event) {
    this.applicationStatus = ApplicationStatus.DECLINED;
  }

  @EventSourcingHandler
  private void on(ApplicationCreatedEvent event) {
    this.id = event.getId();
    this.applicationStatus = ApplicationStatus.DRAFT;
  }

  @EventSourcingHandler
  private void on(ApplicationSubmittedEvent event) {
    this.id = event.getApplicationId();
    this.applicationStatus = ApplicationStatus.PENDING_UNDERWRITING;
  }

  @EventSourcingHandler
  private void on(UnderwritingInitializedEvent event) {
    this.underwriting = new Underwriting(event.getApplicationId(),
        event.getUnderwritingFieldsDefinitions(), event.getRole());
  }

  @EventSourcingHandler
  private void on(ApplicationApprovalRecommendedEvent event) {
    this.applicationStatus = ApplicationStatus.WAITING_FOR_REVIEW;
  }

  @EventSourcingHandler
  private void on(ApplicationRejectionRecommendedEvent event) {
    this.applicationStatus = ApplicationStatus.WAITING_FOR_REVIEW;
  }

  @EventSourcingHandler
  private void on(ApplicationApprovedEvent event) {
    this.applicationStatus = ApplicationStatus.APPROVED;
  }

  @EventSourcingHandler
  private void on(ApplicationRejectedEvent event) {
    this.applicationStatus = ApplicationStatus.REJECTED;
  }

  public void save(SaveApplicationCommand saveApplicationCommand) {
    apply(new ApplicationSavedEvent(saveApplicationCommand.getId(),
        saveApplicationCommand.getApplication()));
  }

  void submit(SubmitApplicationCommand submitApplicationCommand, String username, LoanProductTemplateService loanProductTemplateService) {
    try{
      Optional<LoanProductTemplate> optionalLoanProductTemplate = loanProductTemplateService.getProductTemplate
              (submitApplicationCommand.getApplication().getLoanProduct().getProductType());
      if(optionalLoanProductTemplate.isPresent()){

        ProductInformationDTO productInformation = new ProductInformationDTO();
        productInformation.setInterest(optionalLoanProductTemplate.get().getInterest());
        productInformation.setMaxLoanAmount(optionalLoanProductTemplate.get().getMaximumLoanAmount());
        productInformation.setMinLoanAmount(optionalLoanProductTemplate.get().getMinimumLoanAmount());
        productInformation.setAvailableTerm(optionalLoanProductTemplate.get().getTerms().stream().map(Term::getValue).collect(Collectors.toList()));
        productInformation.setAvailablePaymentFrequency(optionalLoanProductTemplate.get().getPaymentFrequencies());
        productInformation.setTerm(submitApplicationCommand.getApplication().getLoanProduct().getTerm());
        productInformation.setLoanType(submitApplicationCommand.getApplication().getLoanProduct().getProductType());
        productInformation.setLoanAmount(submitApplicationCommand.getApplication().getLoanProduct().getLoanAmount());

        apply(new ApplicationSubmittedEvent(submitApplicationCommand.getId(),
                submitApplicationCommand.getApplication(), LocalDateTime.now(), username, productInformation));
      }
      else {
        throw new NotFoundException("This product information not found");
      }
    }
    catch (Exception ex){
      logger.info("Fetch product information error : " , ex);
    }
  }

  @CommandHandler
  public void delete(DeleteApplicationDraftCommand command) {
    apply(new ApplicationDraftDeletedEvent(command.getId()));
  }

  @CommandHandler
  public void initializeUnderwriting(InitializeUnderwritingCommand command) {
    apply(new UnderwritingInitializedEvent(command.getApplicationId(),
        Role.JUNIOR_UNDERWRITER.toString(),
        command.getFieldDefinitions().stream().collect(Collectors
            .toMap(fieldDefinition -> UUID.randomUUID().toString(), Function.identity()))));
  }

  @CommandHandler
  public void createComment(CreateCommentCommand command,
      @MetaDataValue("username") String username) {
    apply(new CommentCreatedEvent(command.getApplicationId(), command.getDescription(), username));
  }

}
