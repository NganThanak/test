package com.gl.csf.underwriting.core.application;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import liquibase.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/10/2017.
 */
public class FieldCheckingField {
  private final String underwritingFieldId;
  private final FieldDefinition fieldDefinition;
  private final String applicationId;
  private final Map<DocumentDescriptor, String> attachedDocument = new HashMap<>();
  private String text;
  private String comment;

  FieldCheckingField(String underwritingFieldId, String applicationId, FieldDefinition fieldDefinition){
    this.underwritingFieldId = underwritingFieldId;
    this.applicationId = applicationId;
    this.fieldDefinition = fieldDefinition;
    this.text = null;
  }

  public String id() {
    return underwritingFieldId;
  }

  Map<DocumentDescriptor, String> getAttachedDocument() {
    return attachedDocument;
  }

  String getUnderwritingFieldId() {
    return underwritingFieldId;
  }

  FieldDefinition getFieldDefinition() {
    return fieldDefinition;
  }

  public String getText() {
    return text;
  }

  public String getComment() {
    return comment;
  }

  boolean hasText() {
    return !StringUtils.isEmpty(text);
  }

  boolean hasDocument(){
    return !attachedDocument.isEmpty();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FieldCheckingField that = (FieldCheckingField) o;
    return Objects.equals(underwritingFieldId, that.underwritingFieldId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(underwritingFieldId);
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setText(String text) {
    this.text = text;
  }
}
