package com.gl.csf.underwriting.core.service;

import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import java.util.List;
import javax.inject.Inject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * Created by p.ly on 9/27/2017.
 */
@Service
public class FieldCheckListService {

  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public FieldCheckListService(@Value("${endpoints.rest.parameter.fieldchecklist}") String baseUrl, RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  // TODO: Improve the performance by introducing the pagination here
  public List<FieldDefinition> getFieldDefinitions() {
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
        new ParameterizedTypeReference<List<FieldDefinition>>() {
        }).getBody();
  }

}
