package com.gl.csf.underwriting.core.service;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.springframework.stereotype.Service;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/16/2017.
 */
@Service
public class ApplicationReferenceService {

  private final static SecureRandom random = new SecureRandom();

  public String getReferenceNumber() {
    return "CSF-" + new BigInteger(28, random).toString();
  }
}
