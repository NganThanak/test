package com.gl.csf.underwriting.api.application.ownerinfo.event;

import com.gl.csf.underwriting.common.model.owerinfo.GuarantorBusinessInfoDTO;
import lombok.Value;

/**
 * Created by p.ly on 11/21/2017.
 */
@Value
public class GuarantorBusinessInfoUpdatedEvent {
  String id;
  String username;
  GuarantorBusinessInfoDTO guarantorBusiness;
}
