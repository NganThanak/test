package com.gl.csf.underwriting.api.application.command;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

/**
 * Created by p.ly on 10/9/2017.
 */
@Value
public class DeleteDocumentFromUnderwritingFieldCommand {

  @TargetAggregateIdentifier
  String applicationId;
  String underwritingFieldId;
  DocumentDescriptor documentDescriptor;

}
