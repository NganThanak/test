package com.gl.csf.underwriting.api.offeramount.event;

import com.gl.csf.underwriting.common.model.offeramount.Offer;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/13/2017.
 */
@Value
public class OfferMadeEvent {
  String applicationId;
  String underwriter;
  Offer offer;
}
