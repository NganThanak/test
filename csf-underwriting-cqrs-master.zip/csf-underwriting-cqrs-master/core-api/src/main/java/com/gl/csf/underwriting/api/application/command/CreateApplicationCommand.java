package com.gl.csf.underwriting.api.application.command;

import com.gl.csf.underwriting.common.model.application.Application;
import javax.validation.constraints.NotNull;
import lombok.Data;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 23/08/2017.
 */
@Data
public class CreateApplicationCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  private String id;
  @NotNull
  private Application application;
  @NotEmpty
  private String referenceNumber;
}
