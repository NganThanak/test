package com.gl.csf.underwriting.common.model.underwriting;

import com.gl.csf.underwriting.common.model.document.Document;
import liquibase.util.StringUtils;
import lombok.Value;

import java.util.Set;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/10/2017.
 */
@Value
public class FieldCheckResult {
  String name;
  String description;
  String underwritingFieldId;
  String text;
  String comment;
  Set<Document> attachedDocuments;

  public boolean hasText(){
    return !StringUtils.isEmpty(text);
  }
}
