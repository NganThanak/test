package com.gl.csf.underwriting.api.application.ownerinfo.command;

import com.gl.csf.underwriting.common.model.owerinfo.PersonalInformationDTO;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/11/2017.
 */
@Value
public class UpdatePersonalInformationCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;
  PersonalInformationDTO personalInformationDTO;
}
