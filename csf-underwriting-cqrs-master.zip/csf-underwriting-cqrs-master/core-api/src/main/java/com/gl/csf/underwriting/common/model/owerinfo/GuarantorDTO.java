package com.gl.csf.underwriting.common.model.owerinfo;

import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.customer.Gender;
import com.gl.csf.underwriting.common.model.customer.Relationship;
import lombok.Data;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/12/2017.
 */
@Entity
@Data
public class GuarantorDTO {
  @Id
  private String id;
  private String applicationId;
  private String fullName;
  private Gender gender;
  private LocalDate dob;
  private String phoneNumber;
  private String email;
  private String nrcId;
  @Embedded
  private Relationship relationship;
  @Embedded
  private Address ownerAddress;
}
