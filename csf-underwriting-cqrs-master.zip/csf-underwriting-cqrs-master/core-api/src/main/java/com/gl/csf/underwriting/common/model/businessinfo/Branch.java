package com.gl.csf.underwriting.common.model.businessinfo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.gl.csf.underwriting.common.model.address.BusinessType;
import com.gl.csf.underwriting.common.model.address.District;
import com.gl.csf.underwriting.common.model.address.State;
import com.gl.csf.underwriting.common.model.address.Township;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.validator.constraints.NotEmpty;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.PositiveOrZero;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/8/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class Branch {

  @Id
  @Column(name = "branch_id")
  private String id;

  @NotEmpty
  @Column(name = "boss_branch_id")
  private String branchId;

  @NotEmpty
  private String applicationId;

  @NotEmpty
  private String branchName;

  @Embedded
  private BusinessType businessType;

  @Type(type = "text")
  private String businessTypeDescription;

  private String email;

  private Boolean isBoss = false;

  @NotNull
  @PositiveOrZero
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "rent_amount_currency"), @Column(name = "rent_amount")})
  private MonetaryAmount rentAmount;

  @NotEmpty
  private String phoneNumber;

  // TODO remove JsonProperty after BOSS api match with our model
  @JsonProperty("ADDRESS")
  @NotEmpty
  private String address;

  @NotNull
  @Embedded
  private State state;

  @NotNull
  @Embedded
  private District district;

  @NotNull
  @Embedded
  private Township township;

  @JsonProperty("LOCATION_OWNER")
  @Column(name = "location_owner")
  @Enumerated(EnumType.STRING)
  private LocationOwner locationOwner;

  // TODO remove JsonProperty after BOSS api match with our model
  @JsonProperty("OPEN_SINCE")
  private LocalDate openSince;

  @NotNull
  @Column(name = "branch_type")
  @Enumerated(EnumType.STRING)
  private BranchStatus branchStatus;

  // Branch status by B.O.S.S
  @Transient
  private String isActive;

  @NotNull
  @PositiveOrZero
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "revenue_currency"), @Column(name = "revenue")})
  private MonetaryAmount revenue;

  @NotNull
  @PositiveOrZero
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "expense_currency"), @Column(name = "expense")})
  private MonetaryAmount expense;

  @NotNull
  @PositiveOrZero
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "other_expense_currency"), @Column(name = "other_expense")})
  private MonetaryAmount otherExpense;

  @NotNull
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "margin_currency"), @Column(name = "margin")})
  private MonetaryAmount margin;

  @NotNull
  @PositiveOrZero
  private Integer numberOfStaff = 0;

  @NotNull
  @PositiveOrZero
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "staff_expense_currency"), @Column(name = "staff_expense")})
  private MonetaryAmount staffExpense;

  @NotNull
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "net_profit_currency"), @Column(name = "net_profit")})
  private MonetaryAmount netProfit;

  public static Branch create() {
    SecureRandom random = new SecureRandom();
    Branch branch = new Branch();
    branch.setId(UUID.randomUUID().toString());
    branch.setBranchId("BR-00" + new BigInteger(18, random).toString());
    return branch;
  }
}
