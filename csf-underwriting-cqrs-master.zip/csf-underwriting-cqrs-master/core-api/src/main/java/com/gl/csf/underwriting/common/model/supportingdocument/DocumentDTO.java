package com.gl.csf.underwriting.common.model.supportingdocument;


import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;

/**
 * 
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 21, 2017.
 */
@Data
@Entity
public class DocumentDTO {
  @Id
  private String id;
  @Column(name = "reference_id")
  private String applicationId;
  private LocalDateTime createdDate;
  private String uploadBy;
  private String attachment;
  private String comment;

  @Embedded
  private DocumentDescriptor descriptor;
}
