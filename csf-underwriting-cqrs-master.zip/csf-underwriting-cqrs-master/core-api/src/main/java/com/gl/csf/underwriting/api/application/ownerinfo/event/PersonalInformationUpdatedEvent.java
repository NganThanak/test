package com.gl.csf.underwriting.api.application.ownerinfo.event;

import com.gl.csf.underwriting.common.model.owerinfo.PersonalInformationDTO;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/11/2017.
 */
@Value
public class PersonalInformationUpdatedEvent {
  String id;
  PersonalInformationDTO personalInformationDTO;
  String username;
}
