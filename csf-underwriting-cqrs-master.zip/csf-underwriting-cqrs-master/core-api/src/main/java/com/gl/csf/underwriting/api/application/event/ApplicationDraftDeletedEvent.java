package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Value
public class ApplicationDraftDeletedEvent {
  String id;
}
