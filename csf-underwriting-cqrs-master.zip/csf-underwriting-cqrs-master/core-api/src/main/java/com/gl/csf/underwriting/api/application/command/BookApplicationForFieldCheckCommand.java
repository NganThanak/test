package com.gl.csf.underwriting.api.application.command;

import lombok.Data;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by jerome on 8/28/17.
 */
@Data
public class BookApplicationForFieldCheckCommand {

  @NotEmpty
  @TargetAggregateIdentifier
  private final String applicationId;

  public BookApplicationForFieldCheckCommand(String applicationId) {
    this.applicationId = applicationId;
  }
}
