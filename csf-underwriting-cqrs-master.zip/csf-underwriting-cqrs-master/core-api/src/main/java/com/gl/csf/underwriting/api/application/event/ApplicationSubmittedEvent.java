package com.gl.csf.underwriting.api.application.event;

import com.gl.csf.underwriting.common.model.application.Application;
import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import lombok.Value;

import java.time.LocalDateTime;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Value
public class ApplicationSubmittedEvent {
  String applicationId;
  Application application;
  LocalDateTime submittedDate;
  String username;
  ProductInformationDTO productInformationDTO;
}
