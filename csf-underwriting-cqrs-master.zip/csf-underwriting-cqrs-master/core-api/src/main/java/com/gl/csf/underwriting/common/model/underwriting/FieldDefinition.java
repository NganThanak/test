package com.gl.csf.underwriting.common.model.underwriting;

import lombok.Value;

/**
 * Created by p.ly on 9/27/2017.
 */
@Value
public class FieldDefinition {
  private String id;
  private String name;
  private String description;
  private boolean isMandatory;
  private boolean isTextRequired;
  private boolean isDocumentRequired;
}
