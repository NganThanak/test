package com.gl.csf.underwriting.api.application.event;

import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import java.util.Collection;
import java.util.Map;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/) Author: Kuylim Tith
 * (k.tith@gl-f.com) on 9/6/2017.
 */
@Value
public class UnderwritingInitializedEvent {

  String applicationId;
  String role;
  Map<String, FieldDefinition> underwritingFieldsDefinitions;
}
