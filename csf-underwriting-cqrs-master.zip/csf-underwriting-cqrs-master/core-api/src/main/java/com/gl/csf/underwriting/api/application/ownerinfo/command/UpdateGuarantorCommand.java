package com.gl.csf.underwriting.api.application.ownerinfo.command;

import com.gl.csf.underwriting.common.model.owerinfo.GuarantorDTO;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/12/2017.
 */
@Value
public class UpdateGuarantorCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;
  GuarantorDTO guarantorDTO;

  public UpdateGuarantorCommand(String applicationId, GuarantorDTO guarantorDTO) {
    this.applicationId = applicationId;
    this.guarantorDTO = guarantorDTO;
  }
}
