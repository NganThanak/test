package com.gl.csf.underwriting.api.application.event;

import java.time.LocalDateTime;
import lombok.Value;

/**
 * Created by jerome on 8/29/17.
 */
@Value
public class ApplicationBookedForUnderwritingEvent {
  String applicationId;
  String assigneeId;
  String role;
  LocalDateTime occurredOn = LocalDateTime.now();
}
