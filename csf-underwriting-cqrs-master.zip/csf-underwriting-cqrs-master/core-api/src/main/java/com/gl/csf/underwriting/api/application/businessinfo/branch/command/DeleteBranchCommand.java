package com.gl.csf.underwriting.api.application.businessinfo.branch.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/13/2017.
 */
@Value
public class DeleteBranchCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  private String id;
  private String branchId;
}
