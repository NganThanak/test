package com.gl.csf.underwriting.api.application.businessinfo.branch.event;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/13/2017.
 */
@Value
public class BranchDeletedEvent {
  String id;
  String branchId;
}
