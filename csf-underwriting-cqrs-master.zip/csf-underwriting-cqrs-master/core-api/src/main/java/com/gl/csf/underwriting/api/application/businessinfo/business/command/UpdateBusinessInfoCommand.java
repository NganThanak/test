package com.gl.csf.underwriting.api.application.businessinfo.business.command;

import com.gl.csf.underwriting.common.model.businessinfo.Business;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/11/2017.
 */
@Value
public class UpdateBusinessInfoCommand {

  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;

  @NotNull
  Business business;
}
