package com.gl.csf.underwriting.api.application.command;


import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

@Value
public class ApproveApplicationCommand {

  @TargetAggregateIdentifier
  private String applicationId;

}
