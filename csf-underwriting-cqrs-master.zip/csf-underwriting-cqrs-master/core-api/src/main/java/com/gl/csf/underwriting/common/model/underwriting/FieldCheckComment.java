package com.gl.csf.underwriting.common.model.underwriting;

import lombok.Data;

import javax.persistence.Column;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/28/2017.
 */
@Data
public class FieldCheckComment {
	@Column(name = "comment_field_id")
	private UUID id;

	@Column(name = "commented_by")
	private String name;

	@Column(name = "comment_date")
	private LocalDateTime date;

	@Column(name = "description")
	private String description;
}
