package com.gl.csf.underwriting.api.application.event;

import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import lombok.Value;

import java.util.Map;

@Value
public class FieldCheckRequestedEvent {
  private String fieldCheckId;
  private String applicationId;
  private Map<String, FieldDefinition> underwritingFields;
  private String underwriterId;
}
