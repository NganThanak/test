package com.gl.csf.underwriting.api.application.command;

import com.gl.csf.underwriting.common.model.application.Application;
import javax.validation.constraints.NotNull;
import lombok.Data;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
public class SubmitApplicationCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  private String id;
  @NotNull
  private Application application;

  private SubmitApplicationCommand() {

  }

  public SubmitApplicationCommand(String id, Application application) {
    this.id = id;
    this.application = application;
  }
}
