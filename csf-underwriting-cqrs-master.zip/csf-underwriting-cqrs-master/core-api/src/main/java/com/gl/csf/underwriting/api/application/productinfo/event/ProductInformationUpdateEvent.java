package com.gl.csf.underwriting.api.application.productinfo.event;

import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/14/2017.
 */
@Value
public class ProductInformationUpdateEvent {

  String id;
  ProductInformationDTO productInformation;
  String userName;

}
