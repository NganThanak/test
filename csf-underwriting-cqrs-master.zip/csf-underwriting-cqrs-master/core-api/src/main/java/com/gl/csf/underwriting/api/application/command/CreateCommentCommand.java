package com.gl.csf.underwriting.api.application.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 9/9/2017.
 */
@Value
public class CreateCommentCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;
  @NotEmpty
  String description;
}
