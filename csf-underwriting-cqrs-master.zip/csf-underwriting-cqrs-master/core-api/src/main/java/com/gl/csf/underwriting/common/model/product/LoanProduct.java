package com.gl.csf.underwriting.common.model.product;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
@Embeddable
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class LoanProduct {

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "loan_amount_currency"), @Column(name = "loan_amount")})
  private MonetaryAmount loanAmount;

  @Column(name = "term")
  private Integer term;
  
  @Column(name = "interest_rate")
  private Interest interestRate;

  @Column(name = "product_type")
  @Enumerated(EnumType.STRING)
  private ProductType productType;
}
