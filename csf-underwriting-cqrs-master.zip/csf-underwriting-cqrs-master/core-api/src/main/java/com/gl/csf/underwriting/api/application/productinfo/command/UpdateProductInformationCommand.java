package com.gl.csf.underwriting.api.application.productinfo.command;

import com.gl.csf.underwriting.common.model.productinfo.ProductInformationDTO;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/14/2017.
 */
@Value
public class UpdateProductInformationCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String id;
  ProductInformationDTO productInformation;
}
