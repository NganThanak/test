package com.gl.csf.underwriting.api.application.businessinfo.branch.command;

import com.gl.csf.underwriting.common.model.businessinfo.Branch;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/4/2017.
 */
@Value
public class AddBranchCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;

  @NotNull
  Branch branch;
}
