package com.gl.csf.underwriting.common.model.businessinfo;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/19/2017.
 */
public enum LocationOwner {
  RENT("Rent"), OWNER("Owner");
  private final String value;

  private LocationOwner(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
