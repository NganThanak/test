package com.gl.csf.underwriting.common.model.customer;

import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.bank.BankAccount;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.Data;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
@Embeddable
public class Customer {

  @Column(name = "username")
  private String username;

  @Column(name = "business_name")
  private String businessName;

  @Column(name = "business_id")
  private String businessId;

  @Column(name = "fullname")
  private String fullName;

  @Column(name = "gender")
  @Enumerated(EnumType.STRING)
  private Gender gender;

  @Column(name = "date_of_birth")
  private LocalDate dateOfBirth;

  @Column(name = "email")
  private String email;

  @Column(name = "phone_number")
  private String phoneNumber;
  @Embedded
  private Address address;
  @Embedded
  private BankAccount bankAccount;
}
