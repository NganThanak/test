package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/11/2017.
 */
@Value
public class CommentEditedEvent {
  private String applicationId;
  private String underwritingFieldId;
  private String commentId;
  private String content;
  private String username;
}
