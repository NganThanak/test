package com.gl.csf.underwriting.common.model.parameter;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/14/2017.
 */
public class Term implements Serializable {

  @NotNull
  private Integer value;

  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }
}
