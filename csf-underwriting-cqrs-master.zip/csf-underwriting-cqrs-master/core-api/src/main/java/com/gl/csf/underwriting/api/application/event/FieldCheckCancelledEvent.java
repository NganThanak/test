package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

@Value
public class FieldCheckCancelledEvent {

  private String applicationId;
  private String fieldCheckId;

}
