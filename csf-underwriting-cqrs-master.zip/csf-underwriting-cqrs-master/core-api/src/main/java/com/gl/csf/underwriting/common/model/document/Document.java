package com.gl.csf.underwriting.common.model.document;

import java.io.Serializable;
import java.util.Objects;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/10/2017.
 */
public class Document implements Serializable {
  private final String filename;
  private final DocumentDescriptor documentDescriptor;

  public Document(String filename, DocumentDescriptor documentDescriptor){
    this.filename = filename;
    this.documentDescriptor = documentDescriptor;
  }

  public String getFilename() {
    return filename;
  }

  public DocumentDescriptor getDocumentDescriptor() {
    return documentDescriptor;
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(documentDescriptor);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Document that = (Document) o;
    return Objects.equals(documentDescriptor, that.documentDescriptor);
  }
}
