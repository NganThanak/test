package com.gl.csf.underwriting.api.document.event;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/30/2017.
 */
@Value
public class DocumentRemovedEvent {
  String applicationId;

  DocumentDescriptor documentDescriptor;
}
