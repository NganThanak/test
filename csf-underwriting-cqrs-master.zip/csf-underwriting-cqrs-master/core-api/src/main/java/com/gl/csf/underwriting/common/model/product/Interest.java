package com.gl.csf.underwriting.common.model.product;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by b.chann on 2/5/2018.
 */
@Data
@Embeddable
public class Interest implements Serializable {

  @NotNull
  @Column(name = "interest_rate")
  @Digits(integer = 2, fraction = 1)
  @Min(value = 1, message = "Interest rate must be greater than 1.")
  private BigDecimal interestRate;
  private Boolean defaultValue;
  
  public boolean isDefaultValue() {
	return defaultValue;
  }

  public void setDefaultValue(boolean defaultValue) {
	this.defaultValue = defaultValue;
  }

  public BigDecimal getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(BigDecimal interestRate) {
    this.interestRate = interestRate;
  }
  
  @Override
  public String toString() {
    return interestRate.toString();
  }
  
  public static Interest create() {
    Interest interest = new Interest();
    interest.setInterestRate(BigDecimal.ZERO);
    interest.setDefaultValue(false);
    return interest;
  }
}
