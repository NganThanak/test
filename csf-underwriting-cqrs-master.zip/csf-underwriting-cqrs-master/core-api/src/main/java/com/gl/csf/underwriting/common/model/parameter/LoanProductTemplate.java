package com.gl.csf.underwriting.common.model.parameter;

import com.gl.csf.underwriting.common.model.product.Interest;
import com.gl.csf.underwriting.common.model.productinfo.PaymentFrequencyDTO;
import lombok.Data;

import javax.money.MonetaryAmount;
import java.io.Serializable;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 16/08/2017.
 */
@Data
public class LoanProductTemplate implements Serializable {
  private MonetaryAmount maximumLoanAmount;
  private MonetaryAmount minimumLoanAmount;
  private MonetaryAmount loanAmountStep;
  private Interest interest;
  private List<Term> terms;
  private List<PaymentFrequencyDTO> paymentFrequencies;
}
