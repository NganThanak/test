package com.gl.csf.underwriting.api.supportdocument.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/30/2017.
 */
@Value
public class RemoveSupportingDocumentCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;
  @NotEmpty
  String supportingDocumentId;
}