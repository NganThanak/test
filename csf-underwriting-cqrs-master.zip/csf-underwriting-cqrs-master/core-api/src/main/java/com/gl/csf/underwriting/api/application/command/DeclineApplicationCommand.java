package com.gl.csf.underwriting.api.application.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

@Value
public class DeclineApplicationCommand {

  @TargetAggregateIdentifier
  @NotEmpty
  String applicationId;
  String declineReason;
}
