package com.gl.csf.underwriting.api.application.event;

import java.time.LocalDateTime;
import lombok.Value;

@Value
public class ApplicationApprovedEvent {

  private String applicationId;
  private String underwriterId;
  private final LocalDateTime approvedOn = LocalDateTime.now();

}
