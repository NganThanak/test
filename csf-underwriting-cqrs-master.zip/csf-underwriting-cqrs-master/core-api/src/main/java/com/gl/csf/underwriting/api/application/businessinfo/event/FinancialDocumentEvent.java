package com.gl.csf.underwriting.api.application.businessinfo.event;

import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/26/2017.
 */
@Value
public class FinancialDocumentEvent {

  private String applicationId;
  private FinancialDocumentDTO financialDocumentDTO;
}
