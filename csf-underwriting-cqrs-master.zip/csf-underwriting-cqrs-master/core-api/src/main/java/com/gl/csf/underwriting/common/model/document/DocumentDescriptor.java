package com.gl.csf.underwriting.common.model.document;

import lombok.*;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Setter(AccessLevel.PRIVATE)
@Embeddable
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
public class DocumentDescriptor implements Serializable {

  private String documentId;
  private String uri;
  private String applicationId;

}
