package com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/13/2017.
 */
@Value
public class FinancialDocumentDeletedEvent {
  String applicationId;
  DocumentDescriptor documentDescriptor;
}
