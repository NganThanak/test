package com.gl.csf.underwriting.common.model.address;

import lombok.Data;

import javax.persistence.Embeddable;
import java.util.UUID;

@Data
@Embeddable
public class BusinessType {
    private UUID id;
    private String name;

    @Override
    public String toString() {
        return name;
    }
}
