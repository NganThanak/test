package com.gl.csf.underwriting.api.application.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by jerome on 8/28/17.
 */
@Value
public class StartUnderwritingCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;
}
