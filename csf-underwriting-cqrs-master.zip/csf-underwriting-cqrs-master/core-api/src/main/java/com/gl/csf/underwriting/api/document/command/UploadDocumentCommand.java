package com.gl.csf.underwriting.api.document.command;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/28/2017.
 */
@Value
public class UploadDocumentCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;

  @NotNull
  DocumentDescriptor documentDescriptor;
}
