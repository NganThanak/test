package com.gl.csf.underwriting.api.application.command;


import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 9/28/2017.
 */
@Value
public class SaveFieldCheckCommentCommand {
	@NotEmpty
	@TargetAggregateIdentifier
	private String applicationId;
	private String underwritingFieldId;
	@NotEmpty
	private String comment;
}
