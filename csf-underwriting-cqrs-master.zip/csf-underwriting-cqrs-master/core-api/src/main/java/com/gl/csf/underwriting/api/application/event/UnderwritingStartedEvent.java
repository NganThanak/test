package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/6/2017.
 */
@Value
public class UnderwritingStartedEvent {
  String applicationId;
}
