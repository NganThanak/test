package com.gl.csf.underwriting.common.model.bank;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/2/2017.
 */
public enum BankAccountType {
  BUSINESS("business"), PERSONAL("personal");
  private final String value;

  private BankAccountType(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
