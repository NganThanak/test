package com.gl.csf.underwriting.api.application.ownerinfo.event;

import com.gl.csf.underwriting.common.model.owerinfo.BankInformationDTO;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/12/2017.
 */
@Value
public class BankInformationUpdatedEvent {

  String id;
  String username;
  BankInformationDTO bankInformationDTO;

}
