package com.gl.csf.underwriting.api.offeramount.command;

import com.gl.csf.underwriting.common.model.offeramount.Offer;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/13/2017.
 */
@Value
public class MakeOfferCommand {

  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;

  @NotNull
  Offer offer;
}
