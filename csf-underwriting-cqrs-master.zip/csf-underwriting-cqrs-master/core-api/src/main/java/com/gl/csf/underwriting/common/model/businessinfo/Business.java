package com.gl.csf.underwriting.common.model.businessinfo;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/8/2017.
 */
@Data
@Entity
public class Business {
  @Id
  private String applicationId;

  private String businessId;

  @NotEmpty
  private String businessName;

  @Embedded
  private BranchDTO mainBranch;

  private Boolean isBoss;
}
