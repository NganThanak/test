package com.gl.csf.underwriting.common.model.businessinfo;

import com.gl.csf.underwriting.common.model.address.BusinessType;
import lombok.Data;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 11/15/2017.
 */
@Data
@Embeddable
public class BranchDTO {
	@Column(name = "main_branch_id")
	private String branchId;
	@Column(name = "main_branch_name")
	private String branchName;

  @Embedded
  private BusinessType businessType;

  @Type(type = "text")
  private String businessTypeDescription;

	public BranchDTO(){}

  public BranchDTO(String branchId, String branchName, BusinessType businessType, String businessTypeDescription) {
    this.branchId = branchId;
    this.branchName = branchName;
    this.businessType = businessType;
    this.businessTypeDescription = businessTypeDescription;
  }

  public BranchDTO(BusinessType businessType, String businessTypeDescription) {
    this.businessType = businessType;
    this.businessTypeDescription = businessTypeDescription;
  }

	@Override
	public String toString() {
		return branchName;
	}
}
