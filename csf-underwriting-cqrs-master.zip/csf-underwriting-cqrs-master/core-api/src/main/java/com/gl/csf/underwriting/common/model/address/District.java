package com.gl.csf.underwriting.common.model.address;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
@Embeddable
public class District {
  @Column(name = "district_id")
  private UUID id;

  @Column(name = "district_name")
  private String name;

  @Column(name = "district_burmese_name")
  private String burmeseName;

  @Override
  public String toString() {
    return name;
  }
}
