package com.gl.csf.underwriting.api.application.event;

import java.time.LocalDateTime;
import lombok.Value;

@Value
public class ApplicationRejectionRecommendedEvent {

  private String applicationId;
  private final LocalDateTime rejectionRecommendedOn = LocalDateTime.now();
  private String underwriterId;

}
