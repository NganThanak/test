package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

import java.time.LocalDateTime;

/**
 * Created by jerome on 8/29/17.
 */
@Value
public class ApplicationBookedForFieldCheckEvent {
  String applicationId;
  LocalDateTime occurredOn = LocalDateTime.now();
}
