package com.gl.csf.underwriting.api.application.command;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

@Value
public class AttachDocumentToUnderwritingFieldCommand {

  @TargetAggregateIdentifier
  private String applicationId;
  private String underwritingFieldId;
  private DocumentDescriptor documentDescriptor;
  private String fileName;

}
