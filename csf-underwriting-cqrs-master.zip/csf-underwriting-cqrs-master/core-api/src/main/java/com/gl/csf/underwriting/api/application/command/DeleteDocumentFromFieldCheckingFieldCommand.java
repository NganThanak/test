package com.gl.csf.underwriting.api.application.command;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/10/2017.
 */
@Value
public class DeleteDocumentFromFieldCheckingFieldCommand {
  @TargetAggregateIdentifier
  private String applicationId;
  private String underwritingFieldId;
  private DocumentDescriptor documentDescriptor;
}
