package com.gl.csf.underwriting.common.model.application;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
public enum ApplicationStatus {
  DRAFT, PENDING_UNDERWRITING, UNDERWRITING_IN_PROGRESS, DELETED, APPROVED, DECLINED, REJECTED, WAITING_FOR_FIELD_CHECK, FIELD_CHECK_IN_PROGRESS, WAITING_FOR_REVIEW, REVIEW_IN_PROGRESS

}
