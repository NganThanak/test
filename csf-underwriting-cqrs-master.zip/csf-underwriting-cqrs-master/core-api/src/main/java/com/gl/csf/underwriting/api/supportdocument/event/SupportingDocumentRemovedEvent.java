package com.gl.csf.underwriting.api.supportdocument.event;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/30/2017.
 */
@Value
public class SupportingDocumentRemovedEvent {
  String applicationId;
  String supportingDocumentId;
  String userName;
}