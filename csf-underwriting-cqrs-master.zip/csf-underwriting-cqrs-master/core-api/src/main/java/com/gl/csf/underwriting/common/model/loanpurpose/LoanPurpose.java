package com.gl.csf.underwriting.common.model.loanpurpose;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Created by p.ly on 12/12/2017.
 */
@Data
@Embeddable
public class LoanPurpose {

  @NotEmpty
  @Column(name = "purpose")
  private String purpose;

  @Override
  public String toString() {
    return purpose;
  }
}
