package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 9/9/2017.
 */
@Value
public class CommentCreatedEvent {
  String applicationId;
  String description;
  String username;
}
