package com.gl.csf.underwriting.common.model.businessinfo;

import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/13/2017.
 */
public enum BranchStatus implements Serializable{
  ACTIVE("Active"), INACTIVE("Inactive");
  private final String value;

  private BranchStatus(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
