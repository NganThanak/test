package com.gl.csf.underwriting.api.supportdocument.command;

import com.gl.csf.underwriting.common.model.supportingdocument.DocumentDTO;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/3/2017.
 */
@Value
public class SaveSupportingDocumentCommand {
	@NotEmpty
	@TargetAggregateIdentifier
	String applicationId;
	@NotNull
	DocumentDTO documentDTO;
}
