package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

@Value
public class UnderwritingFieldEditedEvent {

  private String applicationId;
  private String underwritingFieldId;
  private String content;
  private String username;

}
