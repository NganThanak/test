package com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event;

import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/28/2017.
 */
@Value
public class FinancialDocumentAddedEvent {
  private String applicationId;
  private FinancialDocumentDTO financialDocumentDTO;

  public FinancialDocumentAddedEvent(String applicationId, FinancialDocumentDTO financialDocumentDTO) {
    this.applicationId = applicationId;
    this.financialDocumentDTO = financialDocumentDTO;
  }
}