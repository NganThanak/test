package com.gl.csf.underwriting.common.model.owerinfo;

import com.gl.csf.underwriting.common.model.address.Address;
import com.gl.csf.underwriting.common.model.customer.Gender;
import lombok.Data;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/5/2017.
 */
@Entity
@Data
public class PersonalInformationDTO {
  @Id
  private String id;
  private String applicationId;
  private String fullName;
  private String fatherName;
  private Gender gender;
  private LocalDate dob;
  private String phoneNumber;
  private String additionalPhoneNumber1;
  private String additionalPhoneNumber2;
  private String email;
  private String nrcId;
  @Embedded
  private Address ownerAddress;
}
