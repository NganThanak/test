package com.gl.csf.underwriting.common.model.customer;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
public enum Gender {
  MALE("male"), FEMALE("female");
  private final String value;

  private Gender(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
