package com.gl.csf.underwriting.common.model.offeramount;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.validator.constraints.NotEmpty;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 10/13/2017.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class Offer {

  @Id
  private String id;
  private String applicationId;
  private String underwriter;

  private LocalDateTime ratedDate;

  @NotEmpty
  @Type(type = "text")
  private String offerReason;

  @NotNull
  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "offer_amount_currency"), @Column(name = "offer_amount")})
  private MonetaryAmount offerAmount;
}
