package com.gl.csf.underwriting.common.model.owerinfo;

import com.gl.csf.underwriting.common.model.bank.BankAccount;
import com.gl.csf.underwriting.common.model.bank.BankAccountType;
import lombok.Data;

import javax.persistence.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 8/31/2017.
 */
@Entity
@Data
public class BankInformationDTO {
  @Id
  private String id;
  private String applicationId;
  @Embedded
  private BankAccount bankAccount;
  @Enumerated(EnumType.STRING)
  private BankAccountType bankAccountType;
  private String description;
}

