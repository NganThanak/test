package com.gl.csf.underwriting.api.document;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/28/2017.
 */
@Entity
@Data
public class CreditScoreDocument {
  @Id
  @Column(name = "credit_score_documents_id")
  private String id;

  @NotEmpty
  private String fileName;

  @Embedded
  private DocumentDescriptor documentDescriptor;

  public CreditScoreDocument(String id, String fileName, DocumentDescriptor documentDescriptor){
    this.id = id;
    this.fileName = fileName;
    this.documentDescriptor = documentDescriptor;
  }

  public CreditScoreDocument(){}
}
