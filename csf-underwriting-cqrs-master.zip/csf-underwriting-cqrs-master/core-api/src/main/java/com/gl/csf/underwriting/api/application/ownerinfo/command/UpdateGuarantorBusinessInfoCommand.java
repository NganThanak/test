package com.gl.csf.underwriting.api.application.ownerinfo.command;

import com.gl.csf.underwriting.common.model.owerinfo.GuarantorBusinessInfoDTO;
import lombok.Data;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by p.ly on 11/21/2017.
 */
@Data
public class UpdateGuarantorBusinessInfoCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;
  GuarantorBusinessInfoDTO guarantorBusiness;

  public UpdateGuarantorBusinessInfoCommand(String applicationId, GuarantorBusinessInfoDTO guarantorBusiness) {
    this.applicationId = applicationId;
    this.guarantorBusiness = guarantorBusiness;
  }
}
