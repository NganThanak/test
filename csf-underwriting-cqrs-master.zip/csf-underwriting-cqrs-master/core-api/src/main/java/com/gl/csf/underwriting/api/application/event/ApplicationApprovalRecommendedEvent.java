package com.gl.csf.underwriting.api.application.event;

import java.time.LocalDateTime;
import lombok.Value;

@Value
public class ApplicationApprovalRecommendedEvent {

  private String applicationId;
  private final LocalDateTime approvalRecommendedOn = LocalDateTime.now();
  private String underwriterId;

}
