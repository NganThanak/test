package com.gl.csf.underwriting.common.model.owerinfo;

import com.gl.csf.underwriting.common.model.address.Address;
import lombok.Data;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by p.ly on 11/20/2017.
 */
@Entity
@Data
public class GuarantorBusinessInfoDTO {
  @Id
  private String id;
  private String applicationId;
  @Embedded
  private Address businessInfoAddress;
  private String businessInfoPhoneNumber;
}
