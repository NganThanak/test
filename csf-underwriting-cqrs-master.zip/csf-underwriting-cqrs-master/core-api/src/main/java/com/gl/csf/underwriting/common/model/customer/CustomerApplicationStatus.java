package com.gl.csf.underwriting.common.model.customer;

/**
 * Created by p.ly on 10/27/2017.
 */
public enum CustomerApplicationStatus {
  SAVED, APPLICATION_IN_PROGRESS, APPLICATION_DECLINED, APPLICATION_VALIDATED

}
