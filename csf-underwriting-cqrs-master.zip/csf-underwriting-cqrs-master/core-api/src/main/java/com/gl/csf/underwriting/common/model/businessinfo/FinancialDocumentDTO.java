package com.gl.csf.underwriting.common.model.businessinfo;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/26/2017.
 */
@Data
@Entity
public class FinancialDocumentDTO {
  @EmbeddedId
  private DocumentDescriptor descriptor;
  private String attachment;
  private String uploadBy;
  private LocalDateTime dateTime;
  private String comment;
}
