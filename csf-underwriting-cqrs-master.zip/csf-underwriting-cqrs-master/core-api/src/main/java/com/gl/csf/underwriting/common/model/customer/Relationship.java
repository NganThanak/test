package com.gl.csf.underwriting.common.model.customer;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/21/2017.
 */
@Data
@Embeddable
public class Relationship {
	@Column(name = "relationship_id")
	private UUID id;
	private String name;
	private String description;

	@Override
	public String toString() {
		return name;
	}
}
