package com.gl.csf.underwriting.api.application.businessinfo.financialdocument.event;

import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/4/2017.
 */
@Value
public class FinancialDocumentUpdatedEvent {
  private String applicationId;
  private FinancialDocumentDTO financialDocumentDTO;

  public FinancialDocumentUpdatedEvent(String applicationId, FinancialDocumentDTO financialDocumentDTO) {
    this.applicationId = applicationId;
    this.financialDocumentDTO = financialDocumentDTO;
  }
}
