package com.gl.csf.underwriting.api.application.event;

import java.time.LocalDateTime;
import lombok.Value;

@Value
public class ApplicationRejectedEvent {

  private String applicationId;
  private String underwriterId;
  private final LocalDateTime rejectedOn = LocalDateTime.now();

}
