package com.gl.csf.underwriting.api.application.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/11/2017.
 */
@Value
public class EditCommentCommand {
  @TargetAggregateIdentifier
  private String applicationId;
  private String underwritingFieldId;
  private String commentId;
  @NotEmpty
  private String content;
}
