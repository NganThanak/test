package com.gl.csf.underwriting.api.creditscoring.event;

import com.gl.csf.underwriting.api.document.CreditScoreDocument;
import lombok.Value;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/22/2017.
 */
@Value
public class ApplicationRatedEvent {
  String applicationId;
  String underwriter;
  String score;
  String reason;
  List<CreditScoreDocument> documents;
}
