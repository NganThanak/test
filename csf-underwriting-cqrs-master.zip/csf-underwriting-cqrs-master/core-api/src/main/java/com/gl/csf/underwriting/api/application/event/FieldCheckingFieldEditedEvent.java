package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 15/10/2017.
 */
@Value
public class FieldCheckingFieldEditedEvent {
  String applicationId;
  String underwritingFieldId;
  String content;
  String username;
}
