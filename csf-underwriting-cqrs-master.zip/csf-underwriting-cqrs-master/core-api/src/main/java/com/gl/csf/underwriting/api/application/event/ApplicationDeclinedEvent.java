package com.gl.csf.underwriting.api.application.event;

import lombok.Value;

@Value
public class ApplicationDeclinedEvent {
  private String applicationId;
  private String recordedBy;
  private String declineReason;
}
