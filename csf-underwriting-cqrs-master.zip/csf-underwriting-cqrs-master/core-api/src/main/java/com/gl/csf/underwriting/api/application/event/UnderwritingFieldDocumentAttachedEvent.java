package com.gl.csf.underwriting.api.application.event;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;

@Value
public class UnderwritingFieldDocumentAttachedEvent {
  private String applicationId;
  private String underwritingFieldId;
  private String fileName;
  private DocumentDescriptor documentDescriptor;
  private String username;
}
