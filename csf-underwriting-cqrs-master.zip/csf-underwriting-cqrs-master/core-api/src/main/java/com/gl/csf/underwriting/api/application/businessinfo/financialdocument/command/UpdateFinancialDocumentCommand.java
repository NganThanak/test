package com.gl.csf.underwriting.api.application.businessinfo.financialdocument.command;

import com.gl.csf.underwriting.common.model.businessinfo.FinancialDocumentDTO;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 10/4/2017.
 */
@Value
public class UpdateFinancialDocumentCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  String applicationId;

  @NotNull
  FinancialDocumentDTO financialDocumentDTO;

}
