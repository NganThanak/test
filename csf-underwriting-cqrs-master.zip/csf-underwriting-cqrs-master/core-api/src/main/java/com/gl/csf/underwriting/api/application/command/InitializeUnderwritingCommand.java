package com.gl.csf.underwriting.api.application.command;

import com.gl.csf.underwriting.common.model.underwriting.FieldDefinition;
import java.util.Collection;
import lombok.Data;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/) Author: Kuylim Tith
 * (k.tith@gl-f.com) on 9/6/2017.
 */
@Data
public class InitializeUnderwritingCommand {

  @NotEmpty
  @TargetAggregateIdentifier
  private final String applicationId;
  private final Collection<FieldDefinition> fieldDefinitions;

  public InitializeUnderwritingCommand(String applicationId,
      Collection<FieldDefinition> fieldDefinitions) {
    this.applicationId = applicationId;
    this.fieldDefinitions = fieldDefinitions;
  }
}
