package com.gl.csf.underwriting.api.application.event;

import com.gl.csf.underwriting.common.model.document.DocumentDescriptor;
import lombok.Value;

/**
 * Created by p.ly on 10/9/2017.
 */
@Value
public class UnderwritingFieldDocumentDeletedEvent {

  String applicationId;
  String underwritingFieldId;
  DocumentDescriptor documentDescriptor;
  String userName;

}
