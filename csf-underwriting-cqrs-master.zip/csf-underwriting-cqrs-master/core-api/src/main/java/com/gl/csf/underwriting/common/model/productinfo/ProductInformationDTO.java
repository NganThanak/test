package com.gl.csf.underwriting.common.model.productinfo;

import com.gl.csf.underwriting.common.model.loanpurpose.LoanPurpose;
import com.gl.csf.underwriting.common.model.product.Interest;
import com.gl.csf.underwriting.common.model.product.ProductType;
import lombok.Data;
import org.hibernate.annotations.*;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.validation.constraints.Min;
import java.util.Collection;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/14/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class ProductInformationDTO {
  @Id
  private String id;
  private String applicationId;
  private String referenceId;

  private ProductType loanType;
  private PaymentFrequencyDTO paymentFrequency;
  private Interest interest;
  @Min(0)
  private Integer term;

  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "loan_currency"), @Column(name = "loan_amount")})
  private MonetaryAmount loanAmount;

  // make snapshot this value for validation underwriter input next time
  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "maximum_loan_currency"), @Column(name = "maximum_loan_amount")})
  private MonetaryAmount maxLoanAmount;

  // make snapshot this value for validation underwriter input next time
  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "minimum_loan_currency"), @Column(name = "minimum_loan_amount")})
  private MonetaryAmount minLoanAmount;

  // make snapshot data from parameter to prevent override data when product change in parameter
  @ElementCollection(fetch = FetchType.EAGER)
  private List<PaymentFrequencyDTO> availablePaymentFrequency;

  // make snapshot data from parameter to prevent override data when product change in parameter
  @ElementCollection
  @LazyCollection(LazyCollectionOption.FALSE)
  @CollectionTable(name = "term", joinColumns = @JoinColumn(name = "id"))
  @Column(name = "available_term")
  private List<Integer> availableTerm;

  @ElementCollection
  @LazyCollection(LazyCollectionOption.FALSE)
  private Collection<LoanPurpose> loanPurposes;

}