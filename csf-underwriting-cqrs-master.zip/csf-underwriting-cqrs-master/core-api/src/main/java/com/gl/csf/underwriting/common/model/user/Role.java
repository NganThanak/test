package com.gl.csf.underwriting.common.model.user;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 19/08/2017.
 */
public enum Role {
  JUNIOR_UNDERWRITER("ROLE_JUNIOR_UNDERWRITER"), FIELD_CHECKER("ROLE_FIELD_CHECKER"), SENIOR_UNDERWRITER("ROLE_SENIOR_UNDERWRITER");

  private final String value;

  private Role(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return value;
  }
}
