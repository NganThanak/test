package com.gl.csf.underwriting.api.application.command;

import java.util.Collection;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

@Value
public class RequestFieldCheckCommand {

  @TargetAggregateIdentifier
  private String applicationId;
  private Collection<String> underwritingFieldIds;
}
