package com.gl.csf.underwriting.api.application.command;

import lombok.Data;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
public class DeleteApplicationDraftCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  private String id;
}
