package com.gl.csf.underwriting.api.application.businessinfo.business.event;

import com.gl.csf.underwriting.common.model.businessinfo.Business;
import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/11/2017.
 */
@Value
public class BusinessInfoUpdatedEvent {

  String applicationId;
  Business business;
  String userName;

}
