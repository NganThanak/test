package com.gl.csf.underwriting.common.model.productinfo;

import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 9/14/2017.
 */
@Embeddable
public class PaymentFrequencyDTO implements Serializable {
  private Integer value;
  private String description;

  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public String toString() {
    return description;
  }
}
