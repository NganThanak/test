package com.gl.csf.underwriting.common.model.address;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/09/2017.
 */
@Data
@Embeddable
public class State {
  @Column(name = "state_id")
  private UUID id;

  @Column(name = "state_name")
  private String name;

  @Column(name = "state_burmese_name")
  private String burmeseName;

  @Override
  public String toString() {
    return name;
  }
}
