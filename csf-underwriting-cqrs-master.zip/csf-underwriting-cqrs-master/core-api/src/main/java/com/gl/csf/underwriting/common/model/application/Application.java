package com.gl.csf.underwriting.common.model.application;

import com.gl.csf.underwriting.common.model.customer.Customer;
import com.gl.csf.underwriting.common.model.product.LoanProduct;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import lombok.Data;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
@Embeddable
public class Application {
  @Embedded
  private Customer applicant;
  @Embedded
  private LoanProduct loanProduct;
}
