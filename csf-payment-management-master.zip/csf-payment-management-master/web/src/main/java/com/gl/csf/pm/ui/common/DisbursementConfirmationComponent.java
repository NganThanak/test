package com.gl.csf.pm.ui.common;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Window;

@SpringComponent
@UIScope
public class DisbursementConfirmationComponent extends DisbursementConfirmationComponentDesign {

    private DisbursementConfirmationComponentListener listener;

    public interface DisbursementConfirmationComponentListener{
        void onClosed();
        void onNoButtonClicked();
        void onYesButtonClicked();
    }

    public DisbursementConfirmationComponent(){
        closeButton.addClickListener(e -> {
            if(listener != null)
                listener.onClosed();
        });
        noButton.addClickListener(e -> {
            if(listener != null)
                listener.onNoButtonClicked();
        });
        yesButton.addClickListener(e -> {
            if(listener != null)
                listener.onYesButtonClicked();
        });
    }

    public Window displayConfiguration() {
        Window window = new Window();
        window.center();
        window.removeAllCloseShortcuts();
        window.setResizable(false);
        window.setClosable(false);
        window.setModal(true);
        window.setWidth(600, Unit.PIXELS);
        return window;
    }

    public void setListener(DisbursementConfirmationComponentListener listener) {
        this.listener = listener;
    }
}
