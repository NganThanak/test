package com.gl.csf.pm.message;

public class PaymentHistoryUpdatedEvent {
}
