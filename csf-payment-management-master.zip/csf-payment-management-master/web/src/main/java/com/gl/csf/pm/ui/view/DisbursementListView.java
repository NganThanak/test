package com.gl.csf.pm.ui.view;

import com.gl.csf.pm.query.payment.paymentlist.PaymentSummaryEntry;
import com.gl.csf.pm.ui.disbursement.*;
import com.gl.csf.pm.ui.permission.Role;
import com.gl.csf.pm.ui.viewdeclaration.UIScopeAPViews;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.UI;
import org.springframework.security.access.annotation.Secured;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@UIScope
@SpringComponent
@SpringView(name = UIScopeAPViews.DISBURSEMENT)
@Secured(Role.ACCOUNTANT)
public class DisbursementListView extends DisbursementListViewDesign implements View {

  public DisbursementListView() {
    //TODO This line of code will be refactor later
    disbursementGrid.setDataProvider(createPaymentSummaryEntryDataProvider());

    disbursementGrid.addItemClickListener(clickEvent -> {
      if (clickEvent.getMouseEventDetails().isDoubleClick())
        UI.getCurrent().getNavigator().navigateTo(UIScopeAPViews.DISBURSEMENT_INFO);
    });
  }

  //TODO This line of code will be refactor later
  private ListDataProvider<PaymentSummaryEntry> createPaymentSummaryEntryDataProvider() {
    List<PaymentSummaryEntry> entries = new ArrayList<>();
     for (int i=0;i<4;i++){
      PaymentSummaryEntry entry = new PaymentSummaryEntry();
      entry.setId(UUID.randomUUID().toString());
      entry.setContractNo(i+"21929212u");
      entry.setBankName("ABA");
      entries.add(entry);
     }
    return new ListDataProvider<>(entries);
  }
}
