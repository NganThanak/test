package com.gl.csf.pm.ui.common;

import com.vaadin.ui.Label;
import com.vaadin.ui.Window;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 10/11/2017.
 */
public class PermissionRoleComponent extends PermissionRoleComponentDesign {

	public interface PermissionRoleComponentListener {
		void onClosed();
		void onLogoutButtonClicked();
	}

	private PermissionRoleComponentListener listener;

	public PermissionRoleComponent() {
		closeButton.addClickListener(e -> {
			if(listener != null)
				listener.onClosed();
		});
		logoutButton.addClickListener(e -> {
			if(listener != null)
				listener.onLogoutButtonClicked();
		});
	}
	
	public Window displayConfiguration() {
		Window window = new Window();
		window.center();
		window.removeAllCloseShortcuts();
		window.setResizable(false);
		window.setClosable(false);
		window.setModal(true);
		window.setWidth(600, Unit.PIXELS);
		return window;
	}

	public PermissionRoleComponentListener getListener() {
		return listener;
	}

	public void setListener(PermissionRoleComponentListener listener) {
		this.listener = listener;
	}
	
	public Label getConfirmationLabel(){
	  return confirmationMessage;
  }
}
