package com.gl.csf.pm.ui.view;

import com.gl.csf.pm.ui.common.PermissionRoleComponent;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Page;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Created by jerome on 8/15/17.
 */
@SpringComponent
@UIScope
public class AccessDeniedView extends CustomComponent implements View {
  /**
   * 
  */
  private static final long serialVersionUID = -3232388891263630770L;

  @Inject
  VaadinSecurity vaadinSecurity;
  
  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    
    if (!vaadinSecurity.isAuthenticated()) {
      Page.getCurrent()
              .setLocation("/sso/login?viewName=" + event.getViewName());
    } else {
      final PermissionRoleComponent permissionRoleComponent = new PermissionRoleComponent();

      permissionRoleComponent.getConfirmationLabel().setValue("Sorry, you don't have access to module paymentlist. Please logout and login with proper credential.");

      Window window = permissionRoleComponent.displayConfiguration();
      permissionRoleComponent.setListener(new PermissionRoleComponent.PermissionRoleComponentListener() {
        @Override
        public void onClosed() {window.close();}
        @Override
        public void onLogoutButtonClicked() {
          vaadinSecurity.logout();
        }
      });
      window.setContent(permissionRoleComponent);
      UI.getCurrent().addWindow(window);
    }
  }
}
