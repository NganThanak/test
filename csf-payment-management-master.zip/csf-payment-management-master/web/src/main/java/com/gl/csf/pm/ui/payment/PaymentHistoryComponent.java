package com.gl.csf.pm.ui.payment;

import com.gl.csf.pm.common.util.LocalDateTimeFormat;
import com.gl.csf.pm.common.util.MonetaryAmountRenderer;
import com.gl.csf.pm.common.util.excel.PaymentHistoryExcelBuilder;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 12/27/2017.
 */
@UIScope
@SpringComponent
public class PaymentHistoryComponent extends PaymentHistoryComponentDesign{
  private final PaymentHistoryRepository repository;
  private List<PaymentHistoryEntry> paymentHistoryEntries = new ArrayList<>();
  private final static String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private final static String PAYMENT_HISTORY_PATH = BASE_PATH + "/payment-history/download";
  private final static String INSTALLMENT_AMOUNT = "Installment amount";
  private final static String BANK_ACCOUNT = "Bank account";
  private String contractNo;
  private LocalDate dueDate;

  @Inject
  public PaymentHistoryComponent( PaymentHistoryRepository repository){
    this.repository = repository;

    setGridPaymentHistoryDataProvider();
    exportToExcelButton.addClickListener(clickEvent -> {
      if (!paymentHistoryEntries.isEmpty()) {
        PaymentHistoryExcelBuilder.setPaymentHistoryEntries(paymentHistoryEntries);
        PaymentHistoryExcelBuilder.setContractNo(contractNo);
        Page.getCurrent().open(PAYMENT_HISTORY_PATH, "_blank");
      }
    });

    paymentHistoryGrid.getColumn("totalAmount").setRenderer(new MonetaryAmountRenderer());
    paymentHistoryGrid.getColumn("paymentAmount").setRenderer(new MonetaryAmountRenderer());
    paymentHistoryGrid.getColumn("penaltyAmount").setRenderer(new MonetaryAmountRenderer());
    Grid.Column columnDueDate = paymentHistoryGrid.getColumn("dueDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());


    paymentHistoryGrid.addColumn(paymentHistoryEntry ->
      paymentHistoryEntry.getPaymentAmount().subtract(paymentHistoryEntry.getPenaltyAmount())).setRenderer(new MonetaryAmountRenderer()).setCaption(INSTALLMENT_AMOUNT);

    paymentHistoryGrid.addColumn(paymentHistoryEntry -> paymentHistoryEntry.getBankAccount().getBank().getName()).setCaption(BANK_ACCOUNT).setId("customerBankAccount");
    paymentHistoryGrid.setColumns("dueDate","totalAmount","paymentDate","customerBankAccount","bankTransactionReference","paymentAmount", "penaltyAmount");

    }

    public void setContractNoAndDueDate(String contractNo, LocalDate dueDate) {
      this.contractNo = contractNo;
      this.dueDate = dueDate;
    }

    private void setGridPaymentHistoryDataProvider() {
      paymentHistoryGrid.setDataProvider(new AbstractBackEndDataProvider<PaymentHistoryEntry, String>() {
        @Override
        protected Stream<PaymentHistoryEntry> fetchFromBackEnd(Query<PaymentHistoryEntry, String> query) {
        paymentHistoryEntries = repository.findByContractReferenceAndDueDate(contractNo,dueDate);
        return StreamSupport.stream(repository.findByContractReference(contractNo).spliterator(), true);
        }

        @Override
        protected int sizeInBackEnd(Query<PaymentHistoryEntry, String> query) {
            return Math.toIntExact(repository.countAllByContractReference(contractNo));
        }
      });
    }
}
