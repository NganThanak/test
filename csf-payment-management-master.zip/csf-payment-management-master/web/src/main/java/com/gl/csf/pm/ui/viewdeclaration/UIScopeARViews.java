package com.gl.csf.pm.ui.viewdeclaration;

public class UIScopeARViews {
	public static final String LISTS = "";
}
