package com.gl.csf.pm.ui.common.paymentsummary;

import com.gl.csf.pm.message.PaymentHistoryUpdatedEvent;
import com.gl.csf.pm.message.SessionScopeBus;
import com.gl.csf.pm.query.contract.util.CurrencyUtil;
import com.gl.csf.pm.query.headersummary.PaymentHeaderEntry;
import com.gl.csf.pm.query.headersummary.PaymentHeaderRepository;
import com.gl.csf.pm.query.payment.paymentdetail.PaymentDetailEntry;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import net.engio.mbassy.listener.Enveloped;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.subscription.MessageEnvelope;
import org.axonframework.commandhandling.gateway.CommandGateway;

import javax.inject.Inject;
import java.time.LocalDate;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/26/2017.
 */

@SpringComponent
@UIScope
public class PaymentHeaderComponent extends PaymentHeaderComponentDesign {
  
  private final PaymentHeaderRepository paymentHeaderRepository;
  public String paymentId;
  private CommandGateway commandGateway;
  private SessionScopeBus bus;
  private PaymentDetailEntry paymentDetailEntry;
  
  @Inject
  public PaymentHeaderComponent(PaymentHeaderRepository paymentHeaderRepository, CommandGateway commandGateway, SessionScopeBus bus) {
    this.paymentHeaderRepository = paymentHeaderRepository;
    this.commandGateway = commandGateway;
    this.bus = bus;
  }
  
  public void setPaymentId(String paymentId) {
    this.paymentId = paymentId;
    fetchData();
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }
  
  private void fetchData(){
    PaymentHeaderEntry paymentHeaderEntry = paymentHeaderRepository.findOne(paymentId);
    if(paymentHeaderEntry == null)
      throw new NullPointerException("PaymentHeaderEntry is null");

    contractNumberLabel.setValue(paymentHeaderEntry.getContractNumber());
    businessNameLabel.setValue(paymentHeaderEntry.getBusinessName());
    bankNameLabel.setValue(paymentHeaderEntry.getBankName() != null ? paymentHeaderEntry.getBankName().toString() : "-");
    bankAccountLabel.setValue(paymentHeaderEntry.getBankAccount() != null ? paymentHeaderEntry.getBankAccount().toString():"-");
    overdueDayLabel.setValue(String.valueOf(DAYS.between(paymentHeaderEntry.getDueDate(), LocalDate.now())));
    installmentAmountLabel.setValue( CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(paymentHeaderEntry.getInstallmentAmount()).toString());
    receivedAmountLabel.setValue( CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(paymentHeaderEntry.getReceiveAmount()).toString());
    paymentStatusLabel.setValue(paymentHeaderEntry.getPaymentStatus().name());
  }

  public void setPaymentDetailEntry(PaymentDetailEntry paymentDetailEntry){
    this.paymentDetailEntry = paymentDetailEntry;
  }

  @Handler
  @Enveloped(messages = {PaymentHistoryUpdatedEvent.class})
  public void handle(MessageEnvelope envelope) {
    fetchData();
  }
}


