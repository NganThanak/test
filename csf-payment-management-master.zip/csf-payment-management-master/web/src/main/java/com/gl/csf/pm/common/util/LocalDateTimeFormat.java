package com.gl.csf.pm.common.util;

import com.vaadin.ui.renderers.LocalDateRenderer;
import com.vaadin.ui.renderers.LocalDateTimeRenderer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by p.ly on 10/26/2017.
 */
public class LocalDateTimeFormat {

  public static LocalDateTimeRenderer createLocalDateTimeRenderer() {
    return new LocalDateTimeRenderer("dd-MM-yyyy");
  }
  
  public static LocalDateRenderer createLocalDateRenderer(){
    return new LocalDateRenderer("dd-MM-yyyy");
  }

  public static String formatLocalDate(LocalDate localDate){
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    return localDate.format(formatter);
  }
  
  public static DateTimeFormatter createDateTimeformatter() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy h:mm a");
    return formatter;
  }


}
