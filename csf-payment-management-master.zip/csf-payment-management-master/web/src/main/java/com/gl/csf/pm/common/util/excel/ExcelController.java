package com.gl.csf.pm.common.util.excel;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/18/2017.
 */
@Controller
@RequestMapping("/docs/export/")
public class ExcelController {
  @RequestMapping(value = "payment-history/download", method = RequestMethod.GET)
  public ModelAndView download(Map<String, Object> model) throws Exception {
    ModelAndView modelAndView = new ModelAndView(new PaymentHistoryExcelBuilder());

    return modelAndView;
  }

  @RequestMapping(value = "overall-payment/download", method = RequestMethod.GET)
  public ModelAndView downloadOverallPayment(Map<String, Object> model) throws Exception {
    ModelAndView modelAndView = new ModelAndView(new OverallPaymentExcelBuilder());

    return modelAndView;
  }
}
