package com.gl.csf.pm.ui.viewdeclaration;

/**
 * Created by p.ly on 11/8/2017.
 */
public class UIScopeAPViews {
  public static final String LISTS = "";
  public static final String PAYMENT = "paymentlist";
  public static final String DISBURSEMENT = "disbursement";
  public static final String DISBURSEMENT_INFO = "disbursementinfo";
}
