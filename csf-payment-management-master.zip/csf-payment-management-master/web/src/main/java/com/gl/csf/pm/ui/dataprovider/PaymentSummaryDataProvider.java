package com.gl.csf.pm.ui.dataprovider;

import com.gl.csf.pm.query.payment.paymentlist.PaymentSummaryEntry;
import com.gl.csf.pm.query.payment.paymentlist.PaymentSummaryRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;

import javax.inject.Inject;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/26/2017.
 */

@SpringComponent
public class PaymentSummaryDataProvider extends AbstractBackEndDataProvider<PaymentSummaryEntry, PaymentFilter>{
  
  private static final long serialVersionUID = 6663752771813910634L;
  private final PaymentSummaryRepository paymentSummaryRepository;
          
  @Inject
  public PaymentSummaryDataProvider(PaymentSummaryRepository paymentSummaryRepository) {
    this.paymentSummaryRepository = paymentSummaryRepository;
  }
  
  @Override
  protected Stream<PaymentSummaryEntry> fetchFromBackEnd(Query<PaymentSummaryEntry, PaymentFilter> query) {
    Optional<PaymentFilter> optionalFilter = query.getFilter();
  
    if(optionalFilter.isPresent()){
      PaymentFilter filter = optionalFilter.get();
      return paymentSummaryRepository.findAllByDueDateBetweenAndContractNoStartingWithAndBusinessNameStartingWithAndBankAccountStartingWithOrderByDueDateDesc(filter.getDueDateFrom(),filter.getDueDateTo(),filter.getContractNo(),filter.getBusinessName(),filter.getBankAccount()).parallelStream();
    } else {
      return Stream.empty();
    }
  }
  
  @Override
  protected int sizeInBackEnd(Query<PaymentSummaryEntry, PaymentFilter> query) {
    Optional<PaymentFilter> optionalFilter = query.getFilter();
    
    if(optionalFilter.isPresent()){
      PaymentFilter filter = optionalFilter.get();
      return paymentSummaryRepository.countAllByDueDateBetweenAndContractNoStartingWithAndBusinessNameStartingWithAndBankAccountStartingWith(filter.getDueDateFrom(),filter.getDueDateTo(),filter.getContractNo(),filter.getBusinessName(),filter.getBankAccount());
    } else {
      return 0;
    }
  }
}
