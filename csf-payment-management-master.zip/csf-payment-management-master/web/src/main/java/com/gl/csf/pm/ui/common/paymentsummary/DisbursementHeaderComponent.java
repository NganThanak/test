package com.gl.csf.pm.ui.common.paymentsummary;

import com.gl.csf.pm.ui.common.DisbursementConfirmationComponent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;

@SpringComponent
@UIScope
public class DisbursementHeaderComponent  extends DisbursementHeaderComponentDesign{

    public DisbursementHeaderComponent(){
        confirmButton.addClickListener(clickEvent -> {
            final DisbursementConfirmationComponent  disbursementConfirmationComponent= new DisbursementConfirmationComponent();
            Window window = disbursementConfirmationComponent.displayConfiguration();
            disbursementConfirmationComponent.setListener(new DisbursementConfirmationComponent.DisbursementConfirmationComponentListener() {
                @Override
                public void onClosed() {
                    window.close();
                }

                @Override
                public void onNoButtonClicked() {
                    window.close();
                }

                @Override
                public void onYesButtonClicked() {

                    window.close();
                }
            });
            window.setContent(disbursementConfirmationComponent);
            UI.getCurrent().addWindow(window);
        });
    }
}
