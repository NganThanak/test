package com.gl.csf.pm.common.util;

import com.vaadin.data.Converter;
import com.vaadin.data.Result;
import com.vaadin.data.ValueContext;
import org.javamoney.moneta.Money;
import org.springframework.util.StringUtils;

import javax.money.CurrencyUnit;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/08/2017.
 */
public class StringToMonetaryAmountConverter implements Converter<String, MonetaryAmount> {

  private final CurrencyUnit currencyUnit;

  public StringToMonetaryAmountConverter(CurrencyUnit currencyUnit) {
    this.currencyUnit = currencyUnit;
  }

  @Override
  public Result<MonetaryAmount> convertToModel(String presentation, ValueContext valueContext) {
    return Result.ok(Money.of(StringUtils.isEmpty(presentation) ? BigDecimal.ZERO : new BigDecimal(presentation.replace(",", "")), currencyUnit));
  }

  @Override
  public String convertToPresentation(MonetaryAmount model, ValueContext presentation) {
    NumberFormat formatter = new DecimalFormat("###,##0.00");
    return model == null ? "" :formatter.format(Double.parseDouble(model.getNumber().toString()));
  }
}
