package com.gl.csf.pm.ui.dataprovider;

import lombok.Value;

import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/6/2018.
 */
@Value
public class PaymentFilter {
  LocalDate dueDateFrom;
  LocalDate dueDateTo;
  String contractNo;
  String businessName;
  String bankAccount;
  
}
