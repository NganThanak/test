package com.gl.csf.pm.ui.payment;

import com.gl.csf.pm.common.util.LocalDateTimeFormat;
import com.gl.csf.pm.query.payment.paymentlist.PaymentSummaryEntry;
import com.gl.csf.pm.ui.dataprovider.PaymentFilter;
import com.gl.csf.pm.ui.dataprovider.PaymentSummaryDataProvider;
import com.gl.csf.pm.common.util.MonetaryAmountRenderer;
import com.gl.csf.pm.ui.viewdeclaration.UIScopeAPViews;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;
import com.vaadin.ui.UI;

import javax.inject.Inject;
import java.time.LocalDate;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * Created by p.ly on 12/26/2017.
 */
@SpringComponent
@UIScope
public class PaymentListComponent extends PaymentListComponentDesign{
  
  private static final long serialVersionUID = 136998192022361832L;
  private final ConfigurableFilterDataProvider<PaymentSummaryEntry, Void, PaymentFilter> configurableFilterDataProvider;
  
  @Inject
  PaymentListComponent(PaymentSummaryDataProvider paymentSummaryDataProvider){
    this.configurableFilterDataProvider = paymentSummaryDataProvider.withConfigurableFilter();
  
    fromDate.setValue(LocalDate.now().minusMonths(1).plusDays(1));
    toDate.setValue(LocalDate.now());
    
    fromDate.setRangeStart(LocalDate.now().minusMonths(1).plusDays(1));
    fromDate.setRangeEnd(LocalDate.now());
    toDate.setRangeStart(LocalDate.now().minusMonths(1));
    toDate.setRangeEnd(LocalDate.now());
    
    configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(),toDate.getValue(),contractNumberTextField.getValue(),businessNameTextField.getValue(),bankAccountNumberTextField.getValue()));
    //TODO this line of will be implement later
    paymentGrid.setDataProvider(configurableFilterDataProvider);

    paymentGrid.getColumn("dueAmount").setRenderer(new MonetaryAmountRenderer());
    Grid.Column columnDueDate = paymentGrid.getColumn("dueDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());
    paymentGrid.addColumn(paymentSummaryEntry -> DAYS.between( paymentSummaryEntry.getDueDate(),LocalDate.now())).setCaption("Overdue Days");

    paymentGrid.addItemClickListener(clickEvent -> {
      if (clickEvent.getMouseEventDetails().isDoubleClick()) {
        UI.getCurrent().getNavigator().navigateTo(UIScopeAPViews.PAYMENT + "/paymentid=" + clickEvent.getItem().getId() +"&duedate="+ clickEvent.getItem().getDueDate()+ "&contractno="+clickEvent.getItem().getContractNo());
      }
    });
  
    contractNumberTextField.addValueChangeListener(event -> {
      configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(),toDate.getValue(),contractNumberTextField.getValue(),businessNameTextField.getValue(),bankAccountNumberTextField.getValue()));
      configurableFilterDataProvider.refreshAll();
    });
    
    businessNameTextField.addValueChangeListener(event -> {
      configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(),toDate.getValue(),contractNumberTextField.getValue(),businessNameTextField.getValue(),bankAccountNumberTextField.getValue()));
      configurableFilterDataProvider.refreshAll();
    });
    
    bankAccountNumberTextField.addValueChangeListener(event -> {
      configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(),toDate.getValue(),contractNumberTextField.getValue(),businessNameTextField.getValue(),bankAccountNumberTextField.getValue()));
      configurableFilterDataProvider.refreshAll();
    });
    
    fromDate.addValueChangeListener(event -> {
      if(fromDate.getValue() != null || !fromDate.getValue().isBefore(LocalDate.now().minusDays(30)) || !fromDate.getValue().isAfter(LocalDate.now())){
        configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(),toDate.getValue(),contractNumberTextField.getValue(),businessNameTextField.getValue(),bankAccountNumberTextField.getValue()));
        configurableFilterDataProvider.refreshAll();
      }
    });
    
    toDate.addValueChangeListener(event -> {
      if(toDate.getValue() != null || !toDate.getValue().isBefore(LocalDate.now().minusDays(30)) || !toDate.getValue().isAfter(LocalDate.now())) {
        configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(), contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
        configurableFilterDataProvider.refreshAll();
      }
    });
  
    fromDate.addBlurListener(event -> {
      if(fromDate.getValue() == null || fromDate.getValue().isBefore(LocalDate.now().minusDays(30)) || fromDate.getValue().isAfter(LocalDate.now()))
        fromDate.setValue(LocalDate.now().minusDays(30));
    });
  
    toDate.addBlurListener(event -> {
      if(toDate.getValue() == null || toDate.getValue().isBefore(LocalDate.now().minusDays(30)) || toDate.getValue().isAfter(LocalDate.now()))
        toDate.setValue(LocalDate.now());
    });
  
    clearAllButton.addClickListener(event -> {
      clearCriteria();
    });
  }
  private void clearCriteria(){
    contractNumberTextField.clear();
    businessNameTextField.clear();
    bankAccountNumberTextField.clear();
    fromDate.setValue(LocalDate.now().minusDays(30));
    toDate.setValue(LocalDate.now());
  
    configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(),toDate.getValue(),contractNumberTextField.getValue(),businessNameTextField.getValue(),bankAccountNumberTextField.getValue()));
    configurableFilterDataProvider.refreshAll();
  }
}
