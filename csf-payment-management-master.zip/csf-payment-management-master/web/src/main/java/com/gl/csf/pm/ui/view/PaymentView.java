package com.gl.csf.pm.ui.view;

import com.gl.csf.pm.message.PaymentDetailUpdateEvent;
import com.gl.csf.pm.message.SessionScopeBus;
import com.gl.csf.pm.ui.viewdeclaration.UIScopeAPViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import net.engio.mbassy.listener.Enveloped;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.subscription.MessageEnvelope;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Map;

/**
 * Created by p.ly on 12/27/2017.
 */
@UIScope
@SpringComponent
@SpringView(name = UIScopeAPViews.PAYMENT)
public class PaymentView extends PaymentViewDesign implements View{
  
  private String paymentId;

  private String contractNo;
  private LocalDate duedate;
  private final SessionScopeBus bus;

  @Inject
  public PaymentView(SessionScopeBus bus) {
    this.bus = bus;
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    Map<String, String> parameterMap = event.getParameterMap();
    this.paymentId = parameterMap.getOrDefault("paymentid", null);
    this.duedate = LocalDate.parse(parameterMap.getOrDefault("duedate", null));
    this.contractNo = parameterMap.getOrDefault("contractno", null);

    paymentHeaderComponent.setPaymentId(paymentId);
    paymentDetailComponent.initialValue(contractNo, duedate);
    paymentDetailTabsheet.setSelectedTab(paymentDetailComponent);
    paymentDetailComponent.setPaymentId(paymentId);
    paymentHistoryComponent.setContractNoAndDueDate(contractNo, duedate);
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  @Handler
  @Enveloped(messages = {PaymentDetailUpdateEvent.class})
  public void handle(MessageEnvelope envelope) {
    paymentHeaderComponent.setPaymentDetailEntry(paymentDetailComponent.getPaymentDetailEntry());
  }
}
