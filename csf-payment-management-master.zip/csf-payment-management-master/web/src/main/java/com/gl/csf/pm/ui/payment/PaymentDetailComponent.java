package com.gl.csf.pm.ui.payment;

import com.gl.csf.pm.common.util.LocalDateTimeFormat;
import com.gl.csf.pm.message.PaymentHistorySaveEvent;
import com.gl.csf.pm.message.SessionScopeBus;
import com.gl.csf.pm.query.contract.util.PaymentReferenceService;
import com.gl.csf.pm.query.payment.paymentdetail.PaymentDetailEntry;
import com.gl.csf.pm.query.payment.paymentdetail.PaymentDetailRepository;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryRepository;
import com.gl.csf.pm.service.BankService;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import net.engio.mbassy.listener.Enveloped;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.subscription.MessageEnvelope;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.vaadin.spring.security.VaadinSecurity;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by p.ly on 12/27/2017.
 */
@SpringComponent
@UIScope
public class PaymentDetailComponent extends PaymentDetailComponentDesign {

  private String contractNo;
  private LocalDate dueDate;
  private final PaymentDetailRepository paymentDetailRepository;
  private final SessionScopeBus bus;
  private final CommandGateway commandGateway;
  private final PaymentReferenceService paymentReferenceService;
  private AddPaymentComponent addPaymentComponent;
  public String expectedPaymentId;
  private final PaymentHistoryRepository paymentHistoryRepository;
  private PaymentDetailEntry paymentDetailEntry;
  private final VaadinSecurity vaadinSecurity;
  private final BankService bankService;

  @Inject
  PaymentDetailComponent(PaymentDetailRepository paymentDetailRepository, SessionScopeBus bus, CommandGateway commandGateway,
                         PaymentReferenceService paymentReferenceService, PaymentHistoryRepository paymentHistoryRepository, VaadinSecurity vaadinSecurity, BankService bankService) {
    this.paymentDetailRepository = paymentDetailRepository;
    this.bus = bus;
    this.commandGateway = commandGateway;
    this.paymentReferenceService = paymentReferenceService;
    this.paymentHistoryRepository = paymentHistoryRepository;
    this.vaadinSecurity = vaadinSecurity;
    this.bankService = bankService;

    buttonAddPayment.addClickListener(event -> {
      gridLayout.removeAllComponents();

      paymentDetailEntry = paymentDetailRepository.findByContractReferenceAndDueDate(contractNo, dueDate);
      List<PaymentHistoryEntry> paymentHistories = paymentHistoryRepository.findByContractReferenceAndDueDate(contractNo, dueDate);

      setPaymentDetailComponent(paymentDetailEntry);
      setPaymentHistoryComponent(paymentHistories);
      addPaymentComponent = new AddPaymentComponent(paymentDetailEntry, paymentReferenceService, paymentDetailRepository,
              commandGateway,bus, vaadinSecurity, this.bankService);
    });
  }

  public void initialValue(String contractNo, LocalDate dueDate) {
    this.contractNo = contractNo;
    this.dueDate = dueDate;
    paymentDateLabel.setValue(LocalDateTimeFormat.formatLocalDate(dueDate));
    gridLayout.removeAllComponents();
    List<PaymentHistoryEntry> paymentHistories = paymentHistoryRepository.findByContractReferenceAndDueDate(contractNo, dueDate);
    paymentDetailEntry = paymentDetailRepository.findByContractReferenceAndDueDate(contractNo, dueDate);

    //set detail or history component
    if (paymentHistories.size() == 0)
      setPaymentDetailComponent(paymentDetailEntry);
    else
      setPaymentHistoryComponent(paymentHistories);
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  public void setPaymentId(String expectedPaymentId) {
    this.expectedPaymentId = expectedPaymentId;
    addPaymentComponent.setPaymentId(expectedPaymentId);
  }

  @Handler
  @Enveloped(messages = {PaymentHistorySaveEvent.class})
  public void handle(MessageEnvelope envelope) {
    gridLayout.removeAllComponents();
    setPaymentHistoryComponent(paymentHistoryRepository.findByContractReferenceAndDueDate(contractNo, dueDate));
  }


  private void setPaymentHistoryComponent(List<PaymentHistoryEntry> paymentHistories) {
    for (int i = paymentHistories.size(); i > 0; i--) {
      addPaymentComponent = new AddPaymentComponent(paymentHistories.get(i - 1), paymentDetailRepository, commandGateway, bankService);
      addPaymentComponent.disableComponent(false);
      addPaymentComponent.setStatusLabel(i);
      gridLayout.addComponent(addPaymentComponent);
    }
  }

  private void setPaymentDetailComponent(PaymentDetailEntry paymentDetailEntry) {
    if (paymentDetailEntry == null)
      throw new NullPointerException("Payment Detail Not Found");
    else {
      addPaymentComponent = new AddPaymentComponent(paymentDetailEntry, paymentReferenceService, paymentDetailRepository,
              commandGateway,bus,vaadinSecurity, bankService);
      addPaymentComponent.disableComponent(true);
      gridLayout.addComponent(addPaymentComponent);
      addPaymentComponent.cancelButton.addClickListener(event -> {
        if (gridLayout.getComponentCount() > 1) {
          gridLayout.removeAllComponents();
          setPaymentHistoryComponent(paymentHistoryRepository.findByContractReferenceAndDueDate(contractNo, dueDate));
        }
      });
    }
  }

  public PaymentDetailEntry getPaymentDetailEntry(){
    return addPaymentComponent.paymentDetailEntryBinder.getBean();
  }
}

