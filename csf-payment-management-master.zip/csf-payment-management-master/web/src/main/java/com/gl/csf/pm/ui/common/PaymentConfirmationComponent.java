package com.gl.csf.pm.ui.common;

import com.gl.csf.pm.query.contract.util.CurrencyUtil;
import com.gl.csf.pm.query.payment.paymentdetail.PaymentDetailEntry;
import com.vaadin.ui.Window;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/27/2017.
 */
public class PaymentConfirmationComponent extends PaymentConfirmationComponentDesign {
	
  private PaymentDetailEntry paymentDetailEntry;
  
  public interface PaymentConfirmationComponentListener{
    void onClosed();
    void onNoButtonClicked();
    void onYesButtonClicked();
  }
  
  private PaymentConfirmationComponentListener listener;
  
  public PaymentConfirmationComponent(PaymentDetailEntry paymentDetailEntry) {
      this.paymentDetailEntry = paymentDetailEntry;
      messageLabel.setValue("You received "+CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(paymentDetailEntry.getPaymentAmount())
              +" from "+paymentDetailEntry.getCustomerName()+".");
      closeButton.addClickListener(e -> {
          if(listener != null)
              listener.onClosed();
      });
      noButton.addClickListener(e -> {
          if(listener != null)
              listener.onNoButtonClicked();
      });
      yesButton.addClickListener(e -> {
          if(listener != null)
              listener.onYesButtonClicked();
      });
  }

public Window displayConfiguration() {
    Window window = new Window();
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth(600, Unit.PIXELS);
    return window;
  }
  
  public PaymentConfirmationComponentListener getListener() {
    return listener;
  }
  
  public void setListener(PaymentConfirmationComponentListener listener) {
    this.listener = listener;
  }
}
