package com.gl.csf.pm.common.util.excel;

import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxStreamingView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by p.ly on 1/10/2018.
 */
public class OverallPaymentExcelBuilder extends AbstractXlsxStreamingView {

  private static List<PaymentHistoryEntry> paymentHistoryEntries;


  @Override
  protected void buildExcelDocument(Map<String, Object> map, Workbook workbook, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
    String pattern = "yyyy-MMM-dd@hh-mm-ss aaa";
    SimpleDateFormat format = new SimpleDateFormat(pattern);
    String filename = "Overall-Payment-" + format.format(new Date());
    // change the file name
    httpServletResponse.setHeader("Content-Disposition", "attachment; filename=\"" + filename + ".xlsx\"");

    // create excel sheet
    Sheet sheet = workbook.createSheet("Payment history");

    // create header row
    Row header = sheet.createRow(1);
    header.createCell(0).setCellValue("Contract");
    header.createCell(1).setCellValue("Shop name");
    header.createCell(2).setCellValue("Due date");
    header.createCell(3).setCellValue("Due amount");
    header.createCell(4).setCellValue("Paid on");
    header.createCell(5).setCellValue("Bank name");
    header.createCell(6).setCellValue("Bank account");
    header.createCell(7).setCellValue("Bank transaction");
    header.createCell(8).setCellValue("Total received");
    header.createCell(9).setCellValue("Penalty Received");
    header.createCell(10).setCellValue("Installment Received");

    // create data row
    Row dataRow;
    for (int i = 2; i <= paymentHistoryEntries.size() + 1; i++) {
      dataRow = sheet.createRow(i);
      dataRow.createCell(0).setCellValue(paymentHistoryEntries.get(i - 2).getContractReference());
      dataRow.createCell(1).setCellValue(paymentHistoryEntries.get(i - 2).getBusinessName());
      dataRow.createCell(2).setCellValue(paymentHistoryEntries.get(i - 2).getDueDate().toString());
      dataRow.createCell(3).setCellValue(paymentHistoryEntries.get(i - 2).getTotalAmount().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()) ;
      dataRow.createCell(4).setCellValue(paymentHistoryEntries.get(i - 2).getPaymentDate().toString());
      dataRow.createCell(5).setCellValue(paymentHistoryEntries.get(i - 2).getBankAccount().getBank().getName());
      dataRow.createCell(6).setCellValue(paymentHistoryEntries.get(i - 2).getBankAccount().getAccountNumber());
      dataRow.createCell(7).setCellValue(paymentHistoryEntries.get(i - 2).getBankTransactionReference());
      dataRow.createCell(8).setCellValue(paymentHistoryEntries.get(i - 2).getPaymentAmount().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(9).setCellValue(paymentHistoryEntries.get(i - 2).getPenaltyAmount().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(10).setCellValue(paymentHistoryEntries.get(i - 2).getPaymentAmount().subtract(paymentHistoryEntries.get(i - 2).getPenaltyAmount()).getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
    }
  }

  public static void setPaymentHistoryEntries(List<PaymentHistoryEntry> paymentHistoryEntry) {
    paymentHistoryEntries = paymentHistoryEntry;
  }
}
