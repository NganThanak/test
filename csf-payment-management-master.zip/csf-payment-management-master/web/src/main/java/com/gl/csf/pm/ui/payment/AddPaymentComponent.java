package com.gl.csf.pm.ui.payment;

import com.gl.csf.pm.api.payment.command.ReceiveExpectedPaymentCommand;
import com.gl.csf.pm.common.util.NumeralFieldFormatterUtils;
import com.gl.csf.pm.common.util.StringToMonetaryAmountConverter;
import com.gl.csf.pm.message.PaymentHistorySaveEvent;
import com.gl.csf.pm.message.PaymentHistoryUpdatedEvent;
import com.gl.csf.pm.message.SessionScopeBus;
import com.gl.csf.pm.query.contract.util.CurrencyUtil;
import com.gl.csf.pm.query.contract.util.PaymentReferenceService;
import com.gl.csf.pm.query.payment.paymentdetail.PaymentDetailEntry;
import com.gl.csf.pm.query.payment.paymentdetail.PaymentDetailRepository;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import com.gl.csf.pm.service.BankService;
import com.gl.csf.pm.ui.common.PaymentConfirmationComponent;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import common.model.parameter.Bank;
import common.model.payment.PaymentMethod;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.javamoney.moneta.Money;
import org.vaadin.spring.security.VaadinSecurity;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.UUID;

/**
 * Created by p.ly on 12/27/2017.
 */
@SpringComponent
@UIScope
public class AddPaymentComponent extends AddPaymentComponentDesign{

  public Binder<PaymentDetailEntry> paymentDetailEntryBinder;
  public Binder<PaymentHistoryEntry> PaymentHistoryBinder = new BeanValidationBinder<>(PaymentHistoryEntry.class);
  private final PaymentDetailRepository paymentDetailRepository;
  private final CommandGateway commandGateway;
  private String expectedPaymentId;
  private final BankService bankService;

  AddPaymentComponent(PaymentDetailEntry paymentDetailEntry, PaymentReferenceService paymentReferenceService,
                      PaymentDetailRepository paymentDetailRepository, CommandGateway commandGateway, SessionScopeBus bus, VaadinSecurity vaadinSecurity, BankService bankService) {
    this.paymentDetailRepository = paymentDetailRepository;
    this.commandGateway = commandGateway;
    this.bankService = bankService;

    paymentDetailEntry.setPaymentDate(LocalDate.now());
    paymentDetailEntry.setPaymentAmount(paymentDetailEntry.getTotalAmount());

    ListDataProvider<Bank> bankListDataProvider = new ListDataProvider<>(bankService.getAllBanks());
    customerBankNameComboBox.setDataProvider(bankListDataProvider);

    paymentMethodComboBox.setDataProvider(new ListDataProvider<PaymentMethod>(Arrays.asList(PaymentMethod.values())));

    paymentDetailEntryBinder = createPaymentDetailBinder();
    paymentDetailEntryBinder.setBean(paymentDetailEntry);

    paymentDate.setDateFormat("dd/MM/yyyy");
    NumeralFieldFormatterUtils.formatNumeralTextField(paymentAmountTextField);
    NumeralFieldFormatterUtils.formatNumeralTextField(penaltyAmountTextField);
    paymentDetailEntryBinder.addStatusChangeListener(statusChangeEvent -> buttonConfirmReceive.setEnabled(statusChangeEvent.getBinder().isValid()));
    buttonConfirmReceive.addClickListener(event -> {
      final PaymentConfirmationComponent confirmationComponent = new PaymentConfirmationComponent(paymentDetailEntry);
      Window window = confirmationComponent.displayConfiguration();
      confirmationComponent.setListener(new PaymentConfirmationComponent.PaymentConfirmationComponentListener() {
        @Override
        public void onClosed() {
          window.close();
        }
      
        @Override
        public void onNoButtonClicked() {
          window.close();
        }
      
        @Override
        public void onYesButtonClicked() {
          PaymentDetailEntry entry = paymentDetailEntryBinder.getBean();
          commandGateway.send(new ReceiveExpectedPaymentCommand(UUID.randomUUID().toString(), entry.getPaymentAmount(),
                  entry.getId(),entry.getContractReference(),entry.getInstallmentNumber(),entry.getPaymentDate(),
                  entry.getBankTransactionReference(),paymentReferenceService.nextReference(entry.getContractReference()),
                  entry.getPenaltyAmount(),vaadinSecurity.getAuthentication().getName(), entry.getBankAccount()));
          Notification.show("Saved");
          bus.post(new PaymentHistorySaveEvent()).now();
          bus.post(new PaymentHistoryUpdatedEvent()).now();
          window.close();
        }
      });
      window.setContent(confirmationComponent);
      UI.getCurrent().addWindow(window);
    });
    paymentMethodComboBox.setSelectedItem(PaymentMethod.BANK_TRANSFER);
  }

  AddPaymentComponent(PaymentHistoryEntry paymentHistoryEntry, PaymentDetailRepository paymentDetailRepository, CommandGateway commandGateway, BankService bankService){
    this.paymentDetailRepository = paymentDetailRepository;
    this.commandGateway = commandGateway;
    this.bankService = bankService;

    PaymentHistoryBinder.setBean(paymentHistoryEntry);
    PaymentHistoryBinder.forField(contractReferenceTextField).bind("contractReference");
    PaymentHistoryBinder.forField(customerNameTextField).bind("customerName");
    PaymentHistoryBinder.forField(businessNameTextField).bind("businessName");
    PaymentHistoryBinder.forField(customerBankNameComboBox).bind("bankAccount.bank");
    PaymentHistoryBinder.forField(customerBankAccountTextField).bind("bankAccount.accountNumber");
    PaymentHistoryBinder.forField(vatAmountTextField).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("vatAmount");
    PaymentHistoryBinder.forField(totalAmountTextField).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("totalAmount");
    PaymentHistoryBinder.forField(paymentMethodComboBox).bind("paymentMethod");
    PaymentHistoryBinder.forField(paymentDate).bind("paymentDate");
    PaymentHistoryBinder.forField(bankTransactionReferenceTextField).bind("bankTransactionReference");
    PaymentHistoryBinder.forField(paymentAmountTextField).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("paymentAmount");
    PaymentHistoryBinder.forField(penaltyAmountTextField).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("penaltyAmount");
    if (!paymentMethodComboBox.getSelectedItem().isPresent())
      paymentMethodComboBox.setSelectedItem(PaymentMethod.BANK_TRANSFER);
  }

  public void disableComponent(boolean value){
    paymentDate.setEnabled(value);
    bankTransactionReferenceTextField.setEnabled(value);
    paymentAmountTextField.setEnabled(value);
    penaltyAmountTextField.setEnabled(value);
    cancelButton.setVisible(value);
    buttonConfirmReceive.setVisible(value);
    customerBankAccountTextField.setEnabled(value);
    customerBankNameComboBox.setEnabled(value);
  }

  private Binder<PaymentDetailEntry> createPaymentDetailBinder(){
    Binder<PaymentDetailEntry> result = new BeanValidationBinder<>(PaymentDetailEntry.class);
    
    result.forField(contractReferenceTextField).bind("contractReference");
    result.forField(customerNameTextField).bind("customerName");
    result.forField(businessNameTextField).bind("businessName");
    result.forField(customerBankNameComboBox).asRequired("this field can't be blank").bind("bankAccount.bank");
    result.forField(customerBankAccountTextField).asRequired("this field can't be blank").bind("bankAccount.accountNumber");
    result.forField(vatAmountTextField).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("vatAmount");
    result.forField(totalAmountTextField).withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("totalAmount");
    result.forField(paymentMethodComboBox).bind("paymentMethod");
    result.forField(paymentDate).asRequired("Please select payment date").bind("paymentDate");
    result.forField(bankTransactionReferenceTextField).asRequired("Please enter bank transaction reference").bind("bankTransactionReference");
    result.forField(paymentAmountTextField).asRequired("Please enter payment amount.").withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY)).bind("paymentAmount");
    result.forField(penaltyAmountTextField).asRequired("Penalty must be not null at lease 0.").withConverter(new StringToMonetaryAmountConverter(CurrencyUtil.MMK_CURRENCY))
            .withValidator(monetaryAmount -> monetaryAmount.isLessThanOrEqualTo(Money.of(new BigDecimal(paymentAmountTextField.getValue().replace(",","")),CurrencyUtil.MMK_CURRENCY)), "Penalty amount should not be higher than Payment Amount.")
            .bind("penaltyAmount");

    return result;
  }

  public void setStatusLabel(int paymentIndex){
    addPaymentTitle.setValue("Payment-"+paymentIndex);
    labelStatus.setValue("Received");

  }
  
  public void setPaymentId(String expectedPaymentId) {
    this.expectedPaymentId = expectedPaymentId;
  }
}
