package com.gl.csf.pm.ui.common;

import com.gl.csf.pm.ui.viewdeclaration.UIScopeAPViews;
import com.vaadin.server.ThemeResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.UI;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Created by p.ly on 12/26/2017.
 */
@SpringComponent
@UIScope
public class MainMenuBar extends MainMenuBarDesign{
  private final static String SPACE = "";

  @Inject
  public MainMenuBar(VaadinSecurity vaadinSecurity) {
    //set picture logo
    ThemeResource resource = new ThemeResource("images/logo.svg");
    logo.setSource(resource);
    logo.addClickListener(e -> UI.getCurrent().getNavigator().navigateTo(SPACE));

    MenuBar.MenuItem item = paymentMenu.addItem("Payment ", null);
    item.addItem("Disbursement", createNavigationCommand(UIScopeAPViews.DISBURSEMENT));
    item.addItem("Payment",  createNavigationCommand(UIScopeAPViews.LISTS));

    MenuBar.MenuItem logout = profileLoggedInMenu.addItem("Welcome, " + vaadinSecurity.getAuthentication().getName().toUpperCase(), null);
    logout.addItem("Log out",  menuItem -> vaadinSecurity.logout());
  }

  private MenuBar.Command createNavigationCommand(final String viewName) {
    return menuItem -> getUI().getNavigator().navigateTo(viewName);
  }
}
