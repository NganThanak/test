package com.gl.csf.pm.config.app;

import com.gl.csf.pm.query.contract.util.CurrencyUtil;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.javamoney.moneta.Money;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.money.MonetaryAmount;

/**
 * Created by p.ly on 1/2/2018.
 */
@Component
@Profile(value = {"default"})
public class DatabaseInitailizer implements CommandLineRunner {
  private final CommandGateway commandGateway;
  private static final MonetaryAmount MMK_AMOUNT = Money.of(200000, CurrencyUtil.MMK_CURRENCY);

  @Inject
  public DatabaseInitailizer(CommandGateway commandGateway) {
    this.commandGateway = commandGateway;
  }

  @Override
  public void run(String... args) throws Exception {
    for (int i = 0; i<10; i++){
      createMockPayment(i);
    }
  }

  private void createMockPayment(int index){

  }

}
