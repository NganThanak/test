package com.gl.csf.pm;

import com.gl.csf.pm.cm.integration.ExpectedPaymentCreatedMessagingChannel;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;

@SpringBootApplication
@EnableBinding(ExpectedPaymentCreatedMessagingChannel.class)
public class PaymentManagementApplication {

  public static void main(String[] args) {
    SpringApplication.run(PaymentManagementApplication.class, args);
  }
}
