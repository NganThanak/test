package com.gl.csf.pm.ui.dataprovider;

import com.gl.csf.pm.common.OffsetPageRequest;
import com.vaadin.data.provider.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.Arrays;

/**
 * Created by p.ly on 11/16/2017.
 */
public class DataProviderHelper {

  public static Pageable createPageable(Query<?, ?> query){
    return new OffsetPageRequest(query.getOffset(), query.getLimit(),
      new Sort(Sort.Direction.ASC, "dueDate"));
  }
}
