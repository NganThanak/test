package com.gl.csf.pm.ui.viewdisplay;

import com.gl.csf.pm.ui.common.MainMenuBar;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewDisplay;
import com.vaadin.spring.annotation.SpringViewDisplay;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.VerticalLayout;

import javax.inject.Inject;

/**
 * Created by p.ly on 11/8/2017.
 */

@SpringViewDisplay
public class MainViewDisplay extends CustomComponent implements ViewDisplay {

  /**
   * 
  */
  private static final long serialVersionUID = 2167991611127782568L;

  private final VerticalLayout content = new VerticalLayout();

  @Inject
  public MainViewDisplay(MainMenuBar mainMenuBar) {

    final VerticalLayout root = new VerticalLayout();
    root.setSpacing(false);
    root.setSizeFull();
    root.setMargin(false);

    root.addComponent(mainMenuBar);
    root.addComponent(content);
    setCompositionRoot(root);
  }

  @Override
  public void showView(View view) {
    content.removeAllComponents();
    content.setSpacing(false);
    content.setSizeFull();
    content.setMargin(false);
    content.addComponent((Component) view);
  }
}