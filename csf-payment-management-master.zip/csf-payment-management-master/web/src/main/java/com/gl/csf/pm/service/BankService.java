package com.gl.csf.pm.service;

import common.model.parameter.Bank;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 2/6/2018.
 */
@Service
public class BankService {

  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public BankService(@Value("${endpoints.rest.parameter.bank}") String baseUrl, RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  // TODO: Improve the performance by introducing the pagination here
  public List<Bank> getAllBanks() {
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
            new ParameterizedTypeReference<List<Bank>>(){}).getBody();
  }

  public Optional<Bank> getBankById(UUID bankId) {
    Objects.requireNonNull(bankId);
    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/" + bankId, HttpMethod.GET, null,
              new ParameterizedTypeReference<Bank>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
