package com.gl.csf.pm.ui.disbursement;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

/**
 * Created by p.ly on 1/13/2018.
 */
@SpringComponent
@UIScope
public class DisbursementRequestedComponent extends DisbursementRequestedComponentDesign{
}
