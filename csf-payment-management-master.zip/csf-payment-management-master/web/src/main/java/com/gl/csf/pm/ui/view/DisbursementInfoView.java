package com.gl.csf.pm.ui.view;

import com.gl.csf.pm.ui.permission.Role;
import com.gl.csf.pm.ui.viewdeclaration.UIScopeAPViews;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

/**
 * Created by p.ly on 1/13/2018.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeAPViews.DISBURSEMENT_INFO)
@Secured(Role.ACCOUNTANT)
public class DisbursementInfoView extends DisbursementInfoViewDesign implements View{
}
