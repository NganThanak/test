package com.gl.csf.pm.ui.view;

import com.gl.csf.pm.ui.permission.Role;
import com.gl.csf.pm.ui.viewdeclaration.UIScopeAPViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

/**
 * Created by p.ly on 12/26/2017.
 */
@UIScope
@SpringComponent
@SpringView(name = UIScopeAPViews.LISTS)
@Secured(Role.ACCOUNTANT)
public class PaymentListView extends PaymentListViewDesign implements View{

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    // set paymentListComponent as default tab
    paymentTabsheet.setSelectedTab(paymentListComponent);
    //reload overall payment
    overallPaymentComponent.updateOverallPayment();
  }

}
