package com.gl.csf.pm.ui.dataprovider;

import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import javax.inject.Inject;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Created by p.ly on 1/9/2018.
 */
@SpringComponent
public class OverallPaymentDataProvider extends AbstractBackEndDataProvider<PaymentHistoryEntry, PaymentFilter> {
  private final PaymentHistoryRepository repository;

  @Inject
  public OverallPaymentDataProvider(PaymentHistoryRepository repository) {
    this.repository = repository;
  }

  @Override
  protected Stream<PaymentHistoryEntry> fetchFromBackEnd(Query<PaymentHistoryEntry, PaymentFilter> query) {
    Optional<PaymentFilter> optionalFilter = query.getFilter();

    if (optionalFilter.isPresent()) {
      PaymentFilter filter = optionalFilter.get();
      return repository.findAllByPaymentDateBetweenAndContractReferenceStartingWithAndBusinessNameStartingWithAndBankAccount_AccountNumberStartingWith(filter.getDueDateFrom(), filter.getDueDateTo(), filter.getContractNo(), filter.getBusinessName(), filter.getBankAccount()).parallelStream();
    } else
      return Stream.empty();
  }

  @Override
  protected int sizeInBackEnd(Query<PaymentHistoryEntry, PaymentFilter> query) {
    Optional<PaymentFilter> optionalFilter = query.getFilter();

    if (optionalFilter.isPresent()) {
      PaymentFilter filter = optionalFilter.get();
      return repository.countAllByPaymentDateBetweenAndContractReferenceStartingWithAndBusinessNameStartingWithAndBankAccount_AccountNumberStartingWith(filter.getDueDateFrom(), filter.getDueDateTo(), filter.getContractNo(), filter.getBusinessName(), filter.getBankAccount());
    } else
      return 0;
  }
}
