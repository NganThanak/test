package com.gl.csf.pm.ui.payment;

import com.gl.csf.pm.common.util.MonetaryAmountRenderer;
import com.gl.csf.pm.common.util.excel.OverallPaymentExcelBuilder;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryRepository;
import com.gl.csf.pm.ui.dataprovider.OverallPaymentDataProvider;
import com.gl.csf.pm.ui.dataprovider.PaymentFilter;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by p.ly on 1/9/2018.
 */
@SpringComponent
@UIScope
public class OverallPaymentComponent extends OverallPaymentComponentDesign{

  private final ConfigurableFilterDataProvider<PaymentHistoryEntry, Void, PaymentFilter> configurableFilterDataProvider;
  private List<PaymentHistoryEntry> paymentHistoryEntries = new ArrayList<>();
  private final static String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private final static String Overall_PAYMENT_PATH = BASE_PATH + "/overall-payment/download";
  private final static String INSTALLMENT_AMOUNT = "Installment amount";
  private final static String BANK_NAME = "Bank name";
  private final static String BANK_ACCOUNT = "Bank account";
  private final PaymentHistoryRepository repository;

  @Inject
  public OverallPaymentComponent(OverallPaymentDataProvider dataProvider, PaymentHistoryRepository repository){
    this.configurableFilterDataProvider = dataProvider.withConfigurableFilter();
    this.repository = repository;
    //set current date
    fromDate.setValue(LocalDate.now());
    toDate.setValue(LocalDate.now());

    configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(),
      contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
    overallPaymentGrid.setDataProvider(configurableFilterDataProvider);

    exportToExcelButton.addClickListener(e->{
      if (!paymentHistoryEntries.isEmpty()) {
        OverallPaymentExcelBuilder.setPaymentHistoryEntries(paymentHistoryEntries);
        Page.getCurrent().open(Overall_PAYMENT_PATH, "_blank");
      }
    });

    //set render MMK to money amount for specific column
    overallPaymentGrid.getColumn("totalAmount").setRenderer(new MonetaryAmountRenderer());
    overallPaymentGrid.getColumn("paymentAmount").setRenderer(new MonetaryAmountRenderer());
    overallPaymentGrid.getColumn("penaltyAmount").setRenderer(new MonetaryAmountRenderer());

    overallPaymentGrid.addColumn(paymentHistoryEntry -> paymentHistoryEntry.getBankAccount().getBank().getName()).setCaption(BANK_NAME).setId("customerBankName");
    overallPaymentGrid.addColumn(paymentHistoryEntry -> paymentHistoryEntry.getBankAccount().getAccountNumber()).setCaption(BANK_ACCOUNT).setId("customerBankAccount");
    overallPaymentGrid.setColumns("contractReference","businessName","dueDate","totalAmount","paymentDate","customerBankName", "customerBankAccount","bankTransactionReference","paymentAmount","penaltyAmount");

    // generate installment amount
    overallPaymentGrid.addColumn(paymentHistoryEntry ->
      paymentHistoryEntry.getPaymentAmount().subtract(paymentHistoryEntry.getPenaltyAmount())).setRenderer(new MonetaryAmountRenderer()).setCaption(INSTALLMENT_AMOUNT);

    contractNumberTextField.addValueChangeListener(event -> {
      configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(),
        contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
      configurableFilterDataProvider.refreshAll();
      //get real time overall payment list
      paymentHistoryEntries.clear();
      paymentHistoryEntries = getPaymentHistoryEntries(fromDate.getValue(), toDate.getValue(),
        contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue());

    });

    businessNameTextField.addValueChangeListener(event -> {
      configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(),
        contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
      configurableFilterDataProvider.refreshAll();
      //get real time overall payment list
      paymentHistoryEntries.clear();
      paymentHistoryEntries = getPaymentHistoryEntries(fromDate.getValue(), toDate.getValue(),
        contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue());
    });

    bankAccountNumberTextField.addValueChangeListener(event -> {
      configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(),
        contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
      configurableFilterDataProvider.refreshAll();
      //get real time overall payment list
      paymentHistoryEntries.clear();
      paymentHistoryEntries = getPaymentHistoryEntries(fromDate.getValue(), toDate.getValue(),
        contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue());
    });

    fromDate.addValueChangeListener(event -> {
      if(fromDate.getValue() != null){
        configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(),
          contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
        configurableFilterDataProvider.refreshAll();
        //get real time overall payment list
        paymentHistoryEntries.clear();
        paymentHistoryEntries = getPaymentHistoryEntries(fromDate.getValue(), toDate.getValue(),
          contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue());
      }
    });

    toDate.addValueChangeListener(event -> {
      if(toDate.getValue() != null) {
        configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(),
          contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
        configurableFilterDataProvider.refreshAll();
        //get real time overall payment list
        paymentHistoryEntries.clear();
        paymentHistoryEntries = getPaymentHistoryEntries(fromDate.getValue(), toDate.getValue(),
          contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue());
      }
    });

    fromDate.addBlurListener(event -> {
      if(fromDate.getValue() == null)
        fromDate.setValue(LocalDate.now());
    });

    toDate.addBlurListener(event -> {
      if(toDate.getValue() == null)
        toDate.setValue(LocalDate.now());
    });

    clearAllButton.addClickListener(event -> {
      clearCriteria();
    });
  }

  private void clearCriteria(){
    contractNumberTextField.clear();
    businessNameTextField.clear();
    bankAccountNumberTextField.clear();
    fromDate.setValue(LocalDate.now());
    toDate.setValue(LocalDate.now());
    configurableFilterDataProvider.setFilter(new PaymentFilter(fromDate.getValue(), toDate.getValue(),
      contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue()));
    configurableFilterDataProvider.refreshAll();
  }

  private List<PaymentHistoryEntry> getPaymentHistoryEntries(LocalDate fromDate, LocalDate toDate, String contractNo, String businessName, String bankAccountNumber){
    return repository.findAllByPaymentDateBetweenAndContractReferenceStartingWithAndBusinessNameStartingWithAndBankAccount_AccountNumberStartingWith(fromDate, toDate, contractNo, businessName, bankAccountNumber);
  }

  public void updateOverallPayment(){
    // refresh data every enter into overall payment
    clearCriteria();

    //get real time overall payment list
    paymentHistoryEntries.clear();
    paymentHistoryEntries = getPaymentHistoryEntries(fromDate.getValue(), toDate.getValue(),
      contractNumberTextField.getValue(), businessNameTextField.getValue(), bankAccountNumberTextField.getValue());
  }
}
