package com.gl.csf.pm.ui.permission;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 10/6/2017.
 */
public class Role {
  public static final String ACCOUNTANT = "ROLE_ACCOUNTANT";
}
