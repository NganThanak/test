package com.gl.csf.pm.cm.integration;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/3/2018.
 */
public interface ExpectedPaymentCreatedMessagingChannel {
  String SUBSCRIBER = "expected-payment";

  @Input(SUBSCRIBER)
  SubscribableChannel subscriber();
}
