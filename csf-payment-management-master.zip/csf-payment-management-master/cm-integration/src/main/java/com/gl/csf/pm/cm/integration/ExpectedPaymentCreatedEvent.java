package com.gl.csf.pm.cm.integration;

import com.gl.csf.pm.cm.integration.model.ExpectedPaymentDTO;
import lombok.Data;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/3/2018.
 */
@Data
public class ExpectedPaymentCreatedEvent {
  private List<ExpectedPaymentDTO> expectedPayments;
}
