package com.gl.csf.pm.cm.integration;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
public interface PaymentAllocatedMessagingChannel {
  String SUBSCRIBER = "payment-allocated";

  @Input(SUBSCRIBER)
  SubscribableChannel subscriber();
}