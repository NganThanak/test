package com.gl.csf.pm.cm.integration.model;

import common.model.parameter.BankAccount;
import lombok.Data;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/3/2018.
 */
@Data
public class ExpectedPaymentDTO {
  private String id;
  private String contractNumber;
  int installmentNumber;
  private String businessName;
  private LocalDate dueDate;
  private MonetaryAmount dueAmount;
  private String bankName;
  private String bankAccount;
  private String customerName;
}
