package com.gl.csf.pm.cm.integration;

import com.gl.csf.pm.api.payment.command.MarkContractPaymentCompletedCommand;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Component
@EnableBinding(PaymentAllocatedMessagingChannel.class)
public class PaymentAllocatedEvenListener {
  private Logger logger = LoggerFactory.getLogger(PaymentAllocatedEvenListener.class);

  @Inject
  private CommandGateway commandGateway;

  @StreamListener(target = PaymentAllocatedMessagingChannel.SUBSCRIBER)
  public void onReceived(PaymentAllocatedEvent event){
    commandGateway.send(new MarkContractPaymentCompletedCommand(event.getPaymentId(), event.getAmount(), event.getPenaltyAmount()));
  }
}
