package com.gl.csf.pm.query.contract.util;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import javax.inject.Inject;
import java.util.Calendar;

@Service
public class YearlySequenceHandler {


  private final JdbcTemplate jdbcTemplate;

  @Inject
  public YearlySequenceHandler(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  public long nextValue() {

    final String currentSequenceName = String
        .format("received_payment_sequence_%tY", Calendar.getInstance());
    jdbcTemplate.execute(
        "CREATE SEQUENCE IF NOT EXISTS " + currentSequenceName + " INCREMENT BY 1 START WITH 1");
    return jdbcTemplate
        .queryForObject("select nextval('" + currentSequenceName + "')",
            Long.class);

  }


}
