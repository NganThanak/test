package com.gl.csf.pm.query.payment.paymentdetail;

import com.gl.csf.pm.api.payment.event.ExpectedPaymentReceivedEvent;
import com.gl.csf.pm.api.payment.event.PaymentReceivedEvent;
import com.gl.csf.pm.cm.integration.ExpectedPaymentCreatedEvent;
import com.gl.csf.pm.cm.integration.ExpectedPaymentCreatedMessagingChannel;
import com.gl.csf.pm.cm.integration.model.ExpectedPaymentDTO;
import com.gl.csf.pm.query.contract.util.PaymentReferenceService;
import com.gl.csf.pm.query.contract.util.CurrencyUtil;
import com.gl.csf.pm.query.contract.util.MoneyUtils;
import common.model.parameter.Bank;
import common.model.parameter.BankAccount;
import common.model.payment.PaymentStatus;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by p.ly on 1/4/2018.
 */
@Component
public class PaymentDetailEventListener {
  private final PaymentDetailRepository repository;
  private final PaymentReferenceService paymentReferenceService;
  
  @Inject
  PaymentDetailEventListener(PaymentDetailRepository repository, PaymentReferenceService paymentReferenceService) {
    this.repository = repository;
    this.paymentReferenceService = paymentReferenceService;
  }
  
  @StreamListener(target = ExpectedPaymentCreatedMessagingChannel.SUBSCRIBER)
  public void onReceived(ExpectedPaymentCreatedEvent event) {
    
    for (ExpectedPaymentDTO expectedPaymentDTO : event.getExpectedPayments()) {
      PaymentDetailEntry entry = new PaymentDetailEntry();
      BankAccount bankAccount = new BankAccount();
      Bank bank = new Bank();
      bank.setName(expectedPaymentDTO.getBankName());
      bankAccount.setAccountNumber(expectedPaymentDTO.getBankAccount());
      bankAccount.setBank(bank);
      entry.setId(expectedPaymentDTO.getId());
      entry.setInstallmentNumber(expectedPaymentDTO.getInstallmentNumber());
      entry.setContractReference(expectedPaymentDTO.getContractNumber());
      entry.setCustomerName(expectedPaymentDTO.getCustomerName());
      entry.setBusinessName(expectedPaymentDTO.getBusinessName());
      entry.setBankAccount(bankAccount);
      entry.setTotalAmount(expectedPaymentDTO.getDueAmount());
      entry.setPaymentStatus(PaymentStatus.UNPAID);
      entry.setInstallmentNumber(expectedPaymentDTO.getInstallmentNumber());
      entry.setDueDate(expectedPaymentDTO.getDueDate());
      
      repository.save(entry);
    }
  }
  
  @EventHandler
  public void on(ExpectedPaymentReceivedEvent event) {
    checkPaymentPartalOrOver(event);
  }
  
  @EventHandler
  public void on(PaymentReceivedEvent event) {
    // TODO
  }
  
  private void checkPaymentPartalOrOver(ExpectedPaymentReceivedEvent event) {
    
    List<PaymentStatus> statuses = new ArrayList<>();
    statuses.add(PaymentStatus.UNPAID);
    statuses.add(PaymentStatus.PARTIAL);
    List<PaymentDetailEntry> detailEntry = repository.findByContractReferenceAndPaymentStatusInOrderByDueDate(event.getContractNumber(), statuses);
    MonetaryAmount receiveAmount = event.getAmount();
    for (int i = 0; i < detailEntry.size(); i++) {
      receiveAmount = receiveAmount.subtract(detailEntry.get(i).getTotalAmount());
      if (receiveAmount.isGreaterThan(MoneyUtils.ZERO_VALUE)) {
        detailEntry.get(i).setPaymentStatus(PaymentStatus.OVER_PAY);
        repository.save(detailEntry.get(i));
      } else if (receiveAmount.isEqualTo(MoneyUtils.ZERO_VALUE)) {
        detailEntry.get(i).setPaymentStatus(PaymentStatus.FULL);
        repository.save(detailEntry.get(i));
        break;
      } else if (receiveAmount.isLessThan(MoneyUtils.ZERO_VALUE)) {
        detailEntry.get(i).setPaymentStatus(PaymentStatus.PARTIAL);
        repository.save(detailEntry.get(i));
        break;
      }
    }
    
  }
}
