package com.gl.csf.pm.query.payment.paymentlist;

import com.gl.csf.pm.api.payment.event.ExpectedPaymentReceivedEvent;
import com.gl.csf.pm.api.payment.event.PaymentReceivedEvent;
import com.gl.csf.pm.cm.integration.ExpectedPaymentCreatedEvent;
import com.gl.csf.pm.cm.integration.ExpectedPaymentCreatedMessagingChannel;
import com.gl.csf.pm.cm.integration.model.ExpectedPaymentDTO;
import com.gl.csf.pm.query.headersummary.PaymentHeaderEntry;
import com.gl.csf.pm.query.headersummary.PaymentHeaderRepository;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryRepository;
import common.model.payment.PaymentStatus;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import javax.money.MonetaryAmount;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/27/2017.
 */
@Component
public class PaymentSummaryEventListener {
  private final PaymentSummaryRepository paymentSummaryRepository;
  private final PaymentHeaderRepository paymentHeaderRepository;
  private final PaymentHistoryRepository paymentHistoryRepository;
  
  public PaymentSummaryEventListener(PaymentSummaryRepository paymentSummaryRepository, PaymentHeaderRepository paymentHeaderRepository,
                                     PaymentHistoryRepository paymentHistoryRepository) {
    this.paymentSummaryRepository = paymentSummaryRepository;
    this.paymentHeaderRepository = paymentHeaderRepository;
    this.paymentHistoryRepository = paymentHistoryRepository;
  }

  @StreamListener(target = ExpectedPaymentCreatedMessagingChannel.SUBSCRIBER)
  public void onReceived(ExpectedPaymentCreatedEvent event){

    for(ExpectedPaymentDTO expectedPaymentDTO : event.getExpectedPayments()) {
      PaymentSummaryEntry entry = new PaymentSummaryEntry();
      entry.setId(expectedPaymentDTO.getId());
      entry.setInstallmentNumber(expectedPaymentDTO.getInstallmentNumber());
      entry.setContractNo(expectedPaymentDTO.getContractNumber());
      entry.setBusinessName(expectedPaymentDTO.getBusinessName());
      entry.setDueDate(expectedPaymentDTO.getDueDate());
      entry.setDueAmount(expectedPaymentDTO.getDueAmount());
      entry.setBankName(expectedPaymentDTO.getBankName());
      entry.setBankAccount(expectedPaymentDTO.getBankAccount());
      entry.setCustomerName(expectedPaymentDTO.getCustomerName());
      entry.setPaymentStatus(PaymentStatus.UNPAID);

      paymentSummaryRepository.save(entry);
    }
  }

  @EventHandler
  public void on (ExpectedPaymentReceivedEvent event){
    PaymentSummaryEntry entry = paymentSummaryRepository.findOne(event.getExpectedPaymentId());
    PaymentHeaderEntry paymentHeaderEntry = paymentHeaderRepository.findOne(event.getExpectedPaymentId());
    PaymentStatus paymentStatus = null;

    MonetaryAmount totalPaymentAmount = event.getAmount();
    List<PaymentHistoryEntry> paymentHistoryEntries = paymentHistoryRepository.findByContractReferenceAndDueDate(event.getContractNumber(),entry.getDueDate());
    if(!paymentHistoryEntries.isEmpty()){
      for (PaymentHistoryEntry paymentHistoryEntry: paymentHistoryEntries){
        totalPaymentAmount = totalPaymentAmount.add(paymentHistoryEntry.getPaymentAmount());
      }
    }

    if (paymentHeaderEntry.getInstallmentAmount().isEqualTo(totalPaymentAmount)) {
      paymentStatus = PaymentStatus.FULL;
    } else if (paymentHeaderEntry.getInstallmentAmount().isLessThan(totalPaymentAmount)) {
      paymentStatus = PaymentStatus.OVER_PAY;
    } else if (paymentHeaderEntry.getInstallmentAmount().isGreaterThan(totalPaymentAmount))
      paymentStatus = PaymentStatus.PARTIAL;

    entry.setPaymentStatus(paymentStatus);
    paymentSummaryRepository.save(entry);
  }

  @EventHandler
  public void on (PaymentReceivedEvent event){
    // TODO
  }
}
