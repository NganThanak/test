package com.gl.csf.pm.query.payment.paymenthistory;

import common.model.parameter.BankAccount;
import common.model.payment.PaymentMethod;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;
import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class PaymentHistoryEntry {

    @Id
    private String id;
    private int installmentNumber;
    private String paymentNo;

    @Column(name = "contract_reference")
    private String contractReference;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "business_name")
    private String businessName;

    private BankAccount bankAccount;

    @Positive
    @Type(type = "Money")
    @Columns(columns = {@Column(name = "vat_currency"), @Column(name = "vat_amount")})
    private MonetaryAmount vatAmount;
    
    @Type(type = "Money")
    @Columns(columns = {@Column(name = "total_currency"), @Column(name = "total_amount")})
    private MonetaryAmount totalAmount;

    @Column(name = "payment_method")
    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod;

    @Column(name = "payment_date")
    private LocalDate paymentDate;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name = "bank_transaction_reference")
    private String bankTransactionReference;

    @Positive
    @Type(type = "Money")
    @Columns(columns = {@Column(name = "payment_currency"), @Column(name = "payment_amount")})
    private MonetaryAmount paymentAmount;
    
    @Type(type = "Money")
    @Columns(columns = {@Column(name = "penalty_currency"), @Column(name = "penalty_amount")})
    private MonetaryAmount penaltyAmount;

    private String ReceivedBy;
    private LocalDateTime actionDate;
}