package com.gl.csf.pm.query.contract.util;

import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 17/11/2017.
 */
@Service
public class PaymentReferenceService {

  private final Supplier<Long> sequenceValueProvider;

  @Inject
  public PaymentReferenceService(YearlySequenceHandler yearlySequenceHandler) {
    this(() -> yearlySequenceHandler.nextValue());
  }

  protected PaymentReferenceService(Supplier<Long> sequenceValueProvider) {
    Objects.requireNonNull(sequenceValueProvider);
    this.sequenceValueProvider = sequenceValueProvider;
  }

  public String nextReference(String contractNumber) {
    contractNumber = contractNumber.substring(3,contractNumber.length());
    return contractNumber.concat(
        generateNextContractNumber(sequenceValueProvider.get()));
  }

  private String generateNextContractNumber(long sequenceValue) {

    final String contractNumberWithoutCheckDigits = String
        .format("%04d", sequenceValue);
    long checkDigits =
        (98 - ((Long.parseUnsignedLong(contractNumberWithoutCheckDigits) * 100) % 97)) % 97;

    return contractNumberWithoutCheckDigits;

  }
}
