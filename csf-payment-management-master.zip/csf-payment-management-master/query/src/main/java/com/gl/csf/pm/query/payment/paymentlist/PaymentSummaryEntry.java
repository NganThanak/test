package com.gl.csf.pm.query.payment.paymentlist;

import common.model.payment.PaymentStatus;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/26/2017.
 */

@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class PaymentSummaryEntry {
  @Id
  private String id;
  
  private String contractNo;
  
  @Column(name = "business_name")
  private String businessName;
  
  @Column(name = "due_date")
  private LocalDate dueDate;
  
  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "amount_currency"), @Column(name = "due_amount")})
  private MonetaryAmount dueAmount;
  
  @Column(name = "bank_name")
  private String bankName;
  
  @Column(name = "bank_account")
  private String bankAccount;
  
  @Column(name = "customer_name")
  private String customerName;
  
  @Column(name = "payment_status")
  @Enumerated(EnumType.STRING)
  private PaymentStatus paymentStatus;
  private int installmentNumber;
}
