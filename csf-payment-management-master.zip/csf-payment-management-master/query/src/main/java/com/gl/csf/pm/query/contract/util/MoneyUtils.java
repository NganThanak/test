package com.gl.csf.pm.query.contract.util;

import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 1/13/2018.
 */
public class MoneyUtils {
  public static final MonetaryAmount ZERO_VALUE = Money.of(0.00, CurrencyUtil.MMK_CURRENCY);
}
