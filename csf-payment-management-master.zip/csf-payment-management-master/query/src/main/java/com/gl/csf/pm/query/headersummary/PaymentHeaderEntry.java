package com.gl.csf.pm.query.headersummary;

import common.model.payment.PaymentStatus;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/28/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class PaymentHeaderEntry  implements Serializable {
  @Id
  private String id;
  private String contractNumber;
  private String businessName;
  private String bankName;
  private String bankAccount;
  private LocalDate dueDate;
  
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "installment_amount_currency"), @Column(name = "installment_amount")})
  private MonetaryAmount installmentAmount;
  
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "receive_amount_currency"), @Column(name = "receive_amount")})
  private MonetaryAmount receiveAmount;
  
  @Enumerated(EnumType.STRING)
  private PaymentStatus paymentStatus;
}
