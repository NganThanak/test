package com.gl.csf.pm.query.headersummary;

import com.gl.csf.pm.api.payment.event.ExpectedPaymentReceivedEvent;
import com.gl.csf.pm.cm.integration.ExpectedPaymentCreatedEvent;
import com.gl.csf.pm.cm.integration.ExpectedPaymentCreatedMessagingChannel;
import com.gl.csf.pm.cm.integration.model.ExpectedPaymentDTO;
import com.gl.csf.pm.query.contract.util.CurrencyUtil;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryEntry;
import com.gl.csf.pm.query.payment.paymenthistory.PaymentHistoryRepository;
import common.model.payment.PaymentStatus;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/28/2017.
 */
@Component
public class PaymentHeaderEventListener {
  private final PaymentHeaderRepository repository;
  private final PaymentHistoryRepository paymentHistoryRepository;
  private static final MonetaryAmount MMK_DefaultAMOUNT = Money.of(0, CurrencyUtil.MMK_CURRENCY);
  @Inject
  public PaymentHeaderEventListener(PaymentHeaderRepository repository, PaymentHistoryRepository paymentHistoryRepository) {
    this.repository = repository;
    this.paymentHistoryRepository = paymentHistoryRepository;
  }

  @StreamListener(target = ExpectedPaymentCreatedMessagingChannel.SUBSCRIBER)
  public void onReceived(ExpectedPaymentCreatedEvent event){

    for(ExpectedPaymentDTO expectedPaymentDTO : event.getExpectedPayments()) {
      PaymentHeaderEntry entry = new PaymentHeaderEntry();
      entry.setId(expectedPaymentDTO.getId());
      entry.setContractNumber(expectedPaymentDTO.getContractNumber());
      entry.setBusinessName(expectedPaymentDTO.getBusinessName());
      entry.setBankName(expectedPaymentDTO.getBankName());
      entry.setBankAccount(expectedPaymentDTO.getBankAccount());
      entry.setInstallmentAmount(expectedPaymentDTO.getDueAmount());
      entry.setReceiveAmount(MMK_DefaultAMOUNT);
      entry.setDueDate(expectedPaymentDTO.getDueDate());
      entry.setPaymentStatus(PaymentStatus.UNPAID);

      repository.save(entry);
    }
  }

  @EventHandler
  public void on(ExpectedPaymentReceivedEvent event){
    PaymentStatus paymentStatus = null;
    PaymentHeaderEntry entry = repository.findOne(event.getExpectedPaymentId());

    MonetaryAmount totalPaymentAmount = event.getAmount();
    List<PaymentHistoryEntry> paymentHistoryEntries = paymentHistoryRepository.findByContractReferenceAndDueDate(event.getContractNumber(),entry.getDueDate());
    int size = paymentHistoryEntries.size();
    paymentHistoryEntries.remove(size-1);
    if(!paymentHistoryEntries.isEmpty()){
      for (PaymentHistoryEntry paymentHistoryEntry: paymentHistoryEntries){
        totalPaymentAmount = totalPaymentAmount.add(paymentHistoryEntry.getPaymentAmount());
      }
    }

    if (entry.getInstallmentAmount().isEqualTo(totalPaymentAmount)) {
      paymentStatus = PaymentStatus.FULL;
    } else if (entry.getInstallmentAmount().isLessThan(totalPaymentAmount)) {
      paymentStatus = PaymentStatus.OVER_PAY;
    } else if (entry.getInstallmentAmount().isGreaterThan(totalPaymentAmount))
      paymentStatus = PaymentStatus.PARTIAL;

    entry.setPaymentStatus(paymentStatus);
    entry.setReceiveAmount(totalPaymentAmount);
    repository.save(entry);
  }
}
