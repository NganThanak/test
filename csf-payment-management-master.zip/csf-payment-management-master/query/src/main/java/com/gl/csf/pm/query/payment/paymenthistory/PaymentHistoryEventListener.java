package com.gl.csf.pm.query.payment.paymenthistory;

import com.gl.csf.pm.api.payment.event.ExpectedPaymentReceivedEvent;
import com.gl.csf.pm.api.payment.event.PaymentReceivedEvent;
import com.gl.csf.pm.query.contract.util.MoneyUtils;
import com.gl.csf.pm.query.headersummary.PaymentHeaderEntry;
import com.gl.csf.pm.query.headersummary.PaymentHeaderRepository;
import com.gl.csf.pm.query.payment.paymentlist.PaymentSummaryEntry;
import com.gl.csf.pm.query.payment.paymentlist.PaymentSummaryRepository;
import common.model.parameter.Bank;
import common.model.parameter.BankAccount;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.UUID;

@Component
public class PaymentHistoryEventListener {
    private final PaymentHistoryRepository repository;
    private final PaymentHeaderRepository paymentHeaderRepository;
    private final PaymentSummaryRepository paymentSummaryRepository;

    @Inject
    public PaymentHistoryEventListener(PaymentHistoryRepository repository, PaymentHeaderRepository paymentHeaderRepository,
                                       PaymentSummaryRepository paymentSummaryRepository) {
        this.repository = repository;
        this.paymentHeaderRepository = paymentHeaderRepository;
        this.paymentSummaryRepository = paymentSummaryRepository;
    }

    @EventHandler
    public void on(ExpectedPaymentReceivedEvent event){
        PaymentHistoryEntry entry = new PaymentHistoryEntry();
        PaymentHeaderEntry paymentHeaderEntry = paymentHeaderRepository.findOne(event.getExpectedPaymentId());
        PaymentSummaryEntry paymentSummaryEntry = paymentSummaryRepository.findOne(event.getExpectedPaymentId());

        BankAccount bankAccount = new BankAccount();
        Bank bank = new Bank();
        bank.setName(event.getBankAccount().getBank().getName());
        bankAccount.setAccountNumber(event.getBankAccount().getAccountNumber());
        bankAccount.setBank(bank);

        entry.setId(UUID.randomUUID().toString());
        entry.setTotalAmount(paymentHeaderEntry.getInstallmentAmount());
        entry.setPenaltyAmount(event.getPenaltyAmount() != null ? event.getPenaltyAmount() : MoneyUtils.ZERO_VALUE);
        entry.setPaymentAmount(event.getAmount() != null ? event.getAmount() : MoneyUtils.ZERO_VALUE);
        entry.setPaymentDate(event.getPaymentDate());
        entry.setCustomerName(paymentSummaryEntry.getCustomerName());
        entry.setBankTransactionReference(event.getBankTransaction());
        entry.setDueDate(paymentSummaryEntry.getDueDate());
        entry.setBusinessName(paymentSummaryEntry.getBusinessName());
        entry.setBankAccount(bankAccount);
        entry.setContractReference(event.getContractNumber());
        entry.setPaymentNo(event.getPaymentReference());
        entry.setActionDate(LocalDateTime.now());
        entry.setReceivedBy(event.getReceivedBy());
        repository.save(entry);
    }

    @EventHandler
    public void on (PaymentReceivedEvent event){
        // TODO
    }

}