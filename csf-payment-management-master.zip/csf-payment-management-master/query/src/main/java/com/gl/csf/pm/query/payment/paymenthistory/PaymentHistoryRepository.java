package com.gl.csf.pm.query.payment.paymenthistory;

import org.springframework.data.repository.PagingAndSortingRepository;
import java.time.LocalDate;
import java.util.List;

public interface PaymentHistoryRepository extends PagingAndSortingRepository<PaymentHistoryEntry, String> {
  List<PaymentHistoryEntry> findByContractReference(String ContractReference);
  List<PaymentHistoryEntry> findByContractReferenceAndDueDate(String ContractReference, LocalDate dueDate);
  Integer countAllByContractReference(String ContractReference);

  List<PaymentHistoryEntry> findAllByPaymentDateBetweenAndContractReferenceStartingWithAndBusinessNameStartingWithAndBankAccount_AccountNumberStartingWith(
          LocalDate localDateFrom, LocalDate localDateTo, String contractNo, String businessName, String bankAccount);

  int countAllByPaymentDateBetweenAndContractReferenceStartingWithAndBusinessNameStartingWithAndBankAccount_AccountNumberStartingWith(
    LocalDate localDateFrom, LocalDate localDateTo,String contractNo, String businessName, String bankAccount);
}