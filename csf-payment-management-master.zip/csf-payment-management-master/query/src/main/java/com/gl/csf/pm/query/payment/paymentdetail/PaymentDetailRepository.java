package com.gl.csf.pm.query.payment.paymentdetail;


import common.model.payment.PaymentStatus;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.time.LocalDate;
import java.util.List;

/**
 * Created by p.ly on 1/4/2018.
 */
public interface PaymentDetailRepository extends PagingAndSortingRepository<PaymentDetailEntry,String>{
  PaymentDetailEntry findByContractReferenceAndDueDate(String ContractReference, LocalDate localDate);
  List<PaymentDetailEntry> findByContractReferenceAndPaymentStatusInOrderByDueDate(String ContractReference, List<PaymentStatus> paymentStatuses);
}
