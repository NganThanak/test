package com.gl.csf.pm.query.payment.paymentlist;

import org.springframework.data.repository.PagingAndSortingRepository;

import java.time.LocalDate;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/27/2017.
 */
public interface PaymentSummaryRepository extends PagingAndSortingRepository<PaymentSummaryEntry, String> {
  List<PaymentSummaryEntry> findAllByDueDateBetweenAndContractNoStartingWithAndBusinessNameStartingWithAndBankAccountStartingWithOrderByDueDateDesc(LocalDate localDateFrom, LocalDate localDateTo,String contractNo, String businessName, String bankAccount);
  int countAllByDueDateBetweenAndContractNoStartingWithAndBusinessNameStartingWithAndBankAccountStartingWith(LocalDate localDateFrom, LocalDate localDateTo,String contractNo, String businessName, String bankAccount);
}
