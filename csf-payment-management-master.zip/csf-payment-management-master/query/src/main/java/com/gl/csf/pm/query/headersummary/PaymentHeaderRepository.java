package com.gl.csf.pm.query.headersummary;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 12/28/2017.
 */
public interface PaymentHeaderRepository extends JpaRepository<PaymentHeaderEntry, String> {
    PaymentHeaderEntry findByContractNumber(String contractNumber);
}
