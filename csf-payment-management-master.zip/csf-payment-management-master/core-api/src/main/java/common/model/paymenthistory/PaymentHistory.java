package common.model.paymenthistory;

import common.model.payment.PaymentMethod;
import lombok.Value;
import javax.money.MonetaryAmount;
import java.time.LocalDate;

@Value
public class PaymentHistory {

    String contractReference;
    String customerName;
    String businessName;
    String customerBankName;
    String customerBankAccount;
    MonetaryAmount vatAmount;
    MonetaryAmount totalAmount;
    PaymentMethod paymentMethod;
    LocalDate dueDate;
    LocalDate paymentDate;
    String bankTransactionReference;
    MonetaryAmount paymentAmount;
    MonetaryAmount penaltyAmount;

}
