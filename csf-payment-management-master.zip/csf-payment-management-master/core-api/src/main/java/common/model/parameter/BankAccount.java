package common.model.parameter;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 5, 2017.
 */
@Data
@Embeddable
public class BankAccount implements Serializable {
  @Embedded
  private Bank bank;
  private String accountName;
  private String accountNumber;

  public BankAccount() {
  }

  public BankAccount(Bank bank, String accountName, String accountNumber) {
    this.bank = bank;
    this.accountName = accountName;
    this.accountNumber = accountNumber;
  }
}
