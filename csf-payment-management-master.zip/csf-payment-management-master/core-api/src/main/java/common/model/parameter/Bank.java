package common.model.parameter;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.UUID;

/**
 * Created by p.ly on 2/6/2018.
 */
@Data
@Embeddable
public class Bank implements Serializable {
  @Column(name = "bank_id")
  private String id;
  @Column(name = "bank_name")
  private String name;
  @Column(name = "bank_burmeseName")
  private String burmeseName;

  public Bank() {
  }

  public Bank(String id, String name, String burmeseName) {
    this.id = id;
    this.name = name;
    this.burmeseName = burmeseName;
  }

  @Override
  public String toString() {
    return name;
  }
}
