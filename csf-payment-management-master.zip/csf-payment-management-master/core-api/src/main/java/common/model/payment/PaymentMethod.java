package common.model.payment;

/**
 * Created by p.ly on 1/4/2018.
 */
public enum PaymentMethod {
  BANK_TRANSFER;
}
