package common.model.payment;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/26/2017.
 */
public enum PaymentStatus {
  UNPAID, FULL, PARTIAL, OVER_PAY;
}
