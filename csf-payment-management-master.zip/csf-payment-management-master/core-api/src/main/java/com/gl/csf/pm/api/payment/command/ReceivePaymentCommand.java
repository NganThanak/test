package com.gl.csf.pm.api.payment.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

import javax.money.MonetaryAmount;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/12/2018.
 */
@Value
public class ReceivePaymentCommand {
  @TargetAggregateIdentifier
  String paymentId;
  @NotNull
  MonetaryAmount amount;
  @NotNull
  String contractNumber;
  @NotNull
  int installmentNumber;
  @NotNull
  LocalDate paymentDate;
  @NotNull
  String paymentReference;
  @NotNull
  String bankTransaction;
  MonetaryAmount penaltyAmount;
}
