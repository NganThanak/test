package com.gl.csf.pm.api.payment.event;

import common.model.parameter.BankAccount;
import lombok.Value;
import org.axonframework.serialization.Revision;
import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/11/2018.
 */
@Value
@Revision("1.0")
public class ExpectedPaymentReceivedEvent {
  String paymentId;
  LocalDate receivedOn;
  String expectedPaymentId;
  String contractNumber;
  int installmentNumber;
  MonetaryAmount amount;
  LocalDate paymentDate;
  String bankTransaction;
  MonetaryAmount penaltyAmount;
  String paymentReference;
  String receivedBy;
  BankAccount bankAccount;
}
