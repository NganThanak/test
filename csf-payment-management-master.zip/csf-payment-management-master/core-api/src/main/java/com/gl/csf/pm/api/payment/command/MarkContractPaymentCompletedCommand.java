package com.gl.csf.pm.api.payment.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

import javax.money.MonetaryAmount;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Value
public class MarkContractPaymentCompletedCommand {
  @TargetAggregateIdentifier
  String paymentId;
  MonetaryAmount amount;
  MonetaryAmount penaltyAmount;
}
