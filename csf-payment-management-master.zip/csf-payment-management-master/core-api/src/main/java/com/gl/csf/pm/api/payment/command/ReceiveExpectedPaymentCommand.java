package com.gl.csf.pm.api.payment.command;

import common.model.parameter.BankAccount;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

import javax.money.MonetaryAmount;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/11/2018.
 */
@Value
public class ReceiveExpectedPaymentCommand {
  @TargetAggregateIdentifier
  String paymentId;
  @NotNull
  MonetaryAmount amount;
  @NotNull
  String expectedPaymentId;
  @NotNull
  String contractNumber;
  @NotNull
  int installmentNumber;
  @NotNull
  LocalDate paymentDate;
  @NotNull
  String bankTransaction;
  @NotNull
  String paymentReference;
  MonetaryAmount penaltyAmount;
  String receivedBy;
  BankAccount bankAccount;
}
