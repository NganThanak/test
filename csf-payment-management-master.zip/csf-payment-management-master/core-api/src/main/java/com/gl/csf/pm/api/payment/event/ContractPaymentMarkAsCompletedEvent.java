package com.gl.csf.pm.api.payment.event;

import lombok.Value;
import org.axonframework.serialization.Revision;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Value
@Revision("1.0")
public class ContractPaymentMarkAsCompletedEvent {
  String paymentId;
  MonetaryAmount amount;
  MonetaryAmount penaltyAmount;
}
