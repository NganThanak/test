package com.gl.csf.pm.payment;

import com.gl.csf.pm.api.payment.command.MarkContractPaymentCompletedCommand;
import com.gl.csf.pm.api.payment.command.ReceiveExpectedPaymentCommand;
import com.gl.csf.pm.api.payment.command.ReceivePaymentCommand;
import com.gl.csf.pm.api.payment.event.ContractPaymentMarkAsCompletedEvent;
import com.gl.csf.pm.api.payment.event.ExpectedPaymentReceivedEvent;
import com.gl.csf.pm.api.payment.event.PaymentReceivedEvent;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.AggregateIdentifier;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.spring.stereotype.Aggregate;

import java.time.LocalDate;

import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/) Author: Kuylim Tith
 * (k.tith@gl-f.com) on 1/5/2018.
 */
@Aggregate
public class ContractPayment {

  @AggregateIdentifier
  private String paymentId;

  public ContractPayment(){}

  @CommandHandler
  public ContractPayment(ReceiveExpectedPaymentCommand command) {
    apply(new ExpectedPaymentReceivedEvent(command.getPaymentId(), LocalDate.now(),
            command.getExpectedPaymentId(), command.getContractNumber(), command.getInstallmentNumber(), command.getAmount(), command.getPaymentDate(),
            command.getBankTransaction(), command.getPenaltyAmount(), command.getPaymentReference(),command.getReceivedBy(), command.getBankAccount()));
  }

  @CommandHandler
  public ContractPayment(ReceivePaymentCommand command){
    apply(new PaymentReceivedEvent(command.getPaymentId(), LocalDate.now(), command.getContractNumber(), command.getInstallmentNumber(), command.getAmount(),
            command.getPaymentDate(),command.getPaymentReference() , command.getBankTransaction(), command.getPenaltyAmount()));
  }

  @CommandHandler
  public void markContractPaymentAllocate(MarkContractPaymentCompletedCommand command){
    apply(new ContractPaymentMarkAsCompletedEvent(command.getPaymentId(), command.getAmount(), command.getPenaltyAmount()));
  }

  @EventSourcingHandler
  private void on(ExpectedPaymentReceivedEvent event) {
    this.paymentId = event.getPaymentId();
  }

  @EventSourcingHandler
  private void on(PaymentReceivedEvent event){
    this.paymentId = event.getPaymentId();
  }

  @EventSourcingHandler
  private void on(ContractPaymentMarkAsCompletedEvent event){
    this.paymentId = event.getPaymentId();
  }
}
