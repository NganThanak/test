package com.gl.csf.pm.payment;

import com.gl.csf.pm.api.payment.event.ContractPaymentMarkAsCompletedEvent;
import com.gl.csf.pm.api.payment.event.ExpectedPaymentReceivedEvent;
import com.gl.csf.pm.api.payment.event.PaymentReceivedEvent;
import lombok.Data;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.eventhandling.saga.EndSaga;
import org.axonframework.eventhandling.saga.SagaEventHandler;
import org.axonframework.eventhandling.saga.StartSaga;
import org.axonframework.spring.stereotype.Saga;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.integration.support.MessageBuilder;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/12/2018.
 */
@Saga
public class ContractPaymentManagementSaga {

  @Inject
  private transient CommandGateway commandGateway;
  @Inject
  private transient Source messagingChannel;

  private String paymentId;
  private MonetaryAmount amount;
  private MonetaryAmount penaltyAmount;

  @StartSaga
  @SagaEventHandler(associationProperty = "paymentId")
  public void on(ExpectedPaymentReceivedEvent event) {
    this.paymentId = event.getPaymentId();
    this.amount = event.getAmount();
    this.penaltyAmount = event.getPenaltyAmount();

    messagingChannel.output().send(MessageBuilder
            .withPayload(new ContractExpectedPaymentReceivedEvent(event.getPaymentId(), event.getReceivedOn(), event.getExpectedPaymentId(),
                             event.getContractNumber(), event.getInstallmentNumber(), event.getAmount(), event.getPaymentDate(),
                    event.getPaymentReference() ,event.getBankTransaction(), event.getPenaltyAmount())).build());
  }

  @StartSaga
  @SagaEventHandler(associationProperty = "paymentId")
  public void on(PaymentReceivedEvent event) {
    this.paymentId = event.getPaymentId();
    this.amount = event.getAmount();
    this.penaltyAmount = event.getPenaltyAmount();

    messagingChannel.output().send(MessageBuilder
            .withPayload(new ContractPaymentReceivedEvent(event.getPaymentId(), event.getReceivedOn(),
                    event.getContractNumber(), event.getInstallmentNumber(), event.getAmount(), event.getPaymentDate(),
                    event.getPaymentReference() ,event.getBankTransaction(), event.getPenaltyAmount())).build());
  }

  @SagaEventHandler(associationProperty = "paymentId")
  @EndSaga
  public void on(ContractPaymentMarkAsCompletedEvent event){
    this.paymentId = event.getPaymentId();
    this.amount = event.getAmount();
    this.penaltyAmount = event.getPenaltyAmount();
  }

  @Data
  class ContractPaymentReceivedEvent {
    String paymentId;
    LocalDate receivedOn;
    String contractNumber;
    int installmentNumber;
    MonetaryAmount amount;
    LocalDate paymentDate;
    String paymentReference;

    String bankTransaction;
    MonetaryAmount penaltyAmount;

    public ContractPaymentReceivedEvent(String paymentId, LocalDate receivedOn, String contractNumber, int installmentNumber, MonetaryAmount amount,
                                        LocalDate paymentDate, String paymentReference, String bankTransaction, MonetaryAmount penaltyAmount) {
      this.paymentId = paymentId;
      this.receivedOn = receivedOn;
      this.contractNumber = contractNumber;
      this.installmentNumber = installmentNumber;
      this.amount = amount;
      this.paymentDate = paymentDate;
      this.paymentReference = paymentReference;
      this.bankTransaction = bankTransaction;
      this.penaltyAmount = penaltyAmount;
    }

    public ContractPaymentReceivedEvent() {
    }
  }

  @Data
  class ContractExpectedPaymentReceivedEvent extends ContractPaymentReceivedEvent {
    String expectedPaymentId;
    public ContractExpectedPaymentReceivedEvent(String paymentId, LocalDate receivedOn, String expectedPaymentId, String contractNumber, int installmentNumber, MonetaryAmount amount,
                                                LocalDate paymentDate, String paymentReference,  String bankTransaction, MonetaryAmount penaltyAmount){

      this.paymentId = paymentId;
      this.receivedOn = receivedOn;
      this.expectedPaymentId = expectedPaymentId;
      this.contractNumber = contractNumber;
      this.installmentNumber = installmentNumber;
      this.amount = amount;
      this.paymentDate = paymentDate;
      this.paymentReference = paymentReference;
      this.bankTransaction = bankTransaction;
      this.penaltyAmount = penaltyAmount;
    }
    public ContractExpectedPaymentReceivedEvent(){}
  }
}
