# contract-management


CQRS Spring-boot based application with the following configuration :

- Spring Boot 1.5.8
- Vaadin 8.1.6
- Axon 3.0.6
- Minio 3.0.7
- Hibernate 5.2.12
- MBassador 1.3.1
- Jackson object mapper configuration
- Spring cloud stream RabbitMQ
- Jersey 2.25.1
- Actuator endpoints
- Docker and gitflow configurations
- Liquibase ready (disabled for now, check application.properties)


