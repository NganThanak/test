package com.gl.csf.cm.core.contract;

import com.gl.csf.cm.api.contract.command.*;
import com.gl.csf.cm.api.contract.event.*;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.common.model.product.StaffLoanProduct;
import com.gl.csf.cm.api.contract.event.ApplicationSubmittedEvent;
import com.gl.csf.financeapi.utils.FinanceUtils;
import liquibase.util.StringUtils;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.AggregateIdentifier;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.messaging.annotation.MetaDataValue;
import org.axonframework.spring.stereotype.Aggregate;

import java.time.LocalDate;

import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/13/2017.
 */
@Aggregate
public class Contract {

  @AggregateIdentifier
  private String id;
  private String contractNumber;
  private ContractStatus contractStatus;
  private LoanProduct loanProduct;

  private Contract() {
  }

  public LoanProduct getLoanProduct() {
    return loanProduct;
  }

  @CommandHandler
  public Contract(CreateContractCommand command, @MetaDataValue("username") String username) {
    if (StringUtils.isEmpty(command.getContractNumber()))
      throw new IllegalArgumentException("Contract number must not be null");

    apply(new ContractCreatedEvent(command.getId(), command.getApplicationId(), command.getContractNumber(), command.getLoanProduct(),
            command.getLesseePersonalInformation(), command.getLesseeBusiness(), command.getLesseeBankAccountInformation(),
            command.getGuarantorPersonalInformation(), command.getGuarantorBusiness(), LocalDate.now(), command.getStaff(), command.getStaffLoanProduct(), username));
  }
  
  @CommandHandler
  public Contract(SubmitApplicationCommand command, @MetaDataValue("username") String username){
    apply(new ApplicationSubmittedEvent(command.getId(),command.getApplicationId(),command.getContractNumber(),
            command.getApplication().getStaff(),command.getApplication().getStaffLoanProduct(), username));
  }

  @CommandHandler
  public void updateContractNumber(UpdateContractNumberCommand command) {
    apply(new ContractNumberUpdatedEvent(command.getId(), command.getContractNumber()));
  }

  void activateStandardLoanContract(ActivateStandardLoanContractCommand command, LocalDate firstDueDate, String username){
    if (contractStatus != ContractStatus.CONTRACT_PENDING)
      throw new IllegalStateException("Contract status isn't in the state to be activated");

    apply(new StandardLoanContractActivatedEvent(command.getId(), contractNumber, command.getContractDate(),
            firstDueDate, loanProduct.getTerm(), loanProduct.getInterestRate(),
            loanProduct.getPaymentFrequency(), loanProduct.getLoanAmount(), LocalDate.now(), username));
  }

  void activateRevolvingLoanContract(ActivateRevolvingLoanContractCommand command, LocalDate firstDueDate, @MetaDataValue("username") String username){
    if (contractStatus != ContractStatus.CONTRACT_PENDING)
      throw new IllegalStateException("Contract status isn't in the state to be activated");

    apply(new RevolvingLoanContractActivatedEvent(command.getId(), contractNumber, command.getContractDate(),
            firstDueDate, loanProduct.getTerm(), loanProduct.getInterestRate(),
            loanProduct.getPaymentFrequency(), loanProduct.getLoanAmount(), LocalDate.now(), username, command.getFirstWithdrawalAmount()));
  }

  void activateStaffLoanContract(ActivateStaffLoanContractCommand command, LocalDate firstDueDate, @MetaDataValue("username") String username){
    if (contractStatus != ContractStatus.CONTRACT_PENDING)
      throw new IllegalStateException("Contract status isn't in the state to be activated");

    apply(new StaffLoanContractActivatedEvent(command.getId(), contractNumber, command.getContractDate(),
            firstDueDate, loanProduct.getTerm(), loanProduct.getInterestRate(),
            loanProduct.getPaymentFrequency(), loanProduct.getLoanAmount(), LocalDate.now(), username));
  }

  @CommandHandler
  public void allocatePayment(AllocatePaymentCommand command) {
    if (contractStatus != ContractStatus.CONTRACT_ACTIVATED)
      throw new IllegalStateException("Contract status isn't in the state to be allocated payment information!");
    if (PaymentStatus.FULL.equals(command.getPaymentStatus()))
      apply(new PaymentFullyAllocatedEvent(command.getId(), command.getPaymentId(), LocalDate.now(), command.getExpectedPaymentId(),
              command.getContractNumber(), command.getInstallmentNumber(), command.getAmount(), command.getPaymentDate(),
              command.getPaymentReference(), command.getBankTransaction(), command.getPenaltyAmount()));
    if (PaymentStatus.PARTIAL.equals(command.getPaymentStatus()))
      apply(new PaymentPartiallyAllocatedEvent(command.getId(), command.getPaymentId(), LocalDate.now(), command.getExpectedPaymentId(),
              command.getContractNumber(), command.getInstallmentNumber(), command.getAmount(), command.getPaymentDate(),
              command.getPaymentReference(), command.getBankTransaction(), command.getPenaltyAmount()));
  }

  @EventSourcingHandler
  private void on(ContractCreatedEvent event) {
    this.id = event.getId();
    this.contractStatus = ContractStatus.CONTRACT_PENDING;
    this.contractNumber = event.getContractNumber();
    com.gl.csf.cm.common.model.product.LoanProduct loanProduct = event.getLoanProduct();
    this.loanProduct = new LoanProduct(loanProduct.getProductType(), loanProduct.getTerm(), loanProduct.getInterestRate(),
            loanProduct.getPaymentFrequency() == null ? null : loanProduct.getPaymentFrequency().getValue(), loanProduct.getLoanAmount());
  }
  
  @EventSourcingHandler
  private void on(ApplicationSubmittedEvent event) {
    this.id = event.getId();
    this.contractStatus = ContractStatus.CONTRACT_PENDING;
    this.contractNumber = event.getContractNumber();
    StaffLoanProduct loanProduct = event.getStaffLoanProduct();
    this.loanProduct = new LoanProduct(loanProduct.getProductType(), loanProduct.getTerm(), loanProduct.getInterestRate(),
            loanProduct.getPaymentFrequency() == null ? null : loanProduct.getPaymentFrequency().getValue(), loanProduct.getLoanAmount());
  }

  @EventSourcingHandler
  private void on(ContractActivatedEvent event) {
    this.contractStatus = ContractStatus.CONTRACT_ACTIVATED;
    this.loanProduct.activate();
  }

  @EventSourcingHandler
  private void on(PendingContractCancelledEvent event) {
    this.contractStatus = ContractStatus.PENDING_CANCEL;
  }

  @EventSourcingHandler
  private void on(ContractCancellationRejectedEvent event) {
    this.contractStatus = ContractStatus.CONTRACT_PENDING;
  }
  
  @EventSourcingHandler
  private void on(PendingStaffLoanContractCancelledEvent event) {
    this.contractStatus = ContractStatus.PENDING_CANCEL;
  }
  
  @EventSourcingHandler
  private void on(StaffLoanContractCancellationRejectedEvent event) {
    this.contractStatus = ContractStatus.CONTRACT_PENDING;
  }

  @CommandHandler
  public void on(CancelPendingContractCommand command, @MetaDataValue("username") String username) {
    if (contractStatus != ContractStatus.CONTRACT_PENDING)
      throw new IllegalStateException("This contract can't cancel because contract status is not pending.");
    apply(new PendingContractCancelledEvent(command.getId(), command.getCancelReason(), username, command.getContractStatus()));
  }

  @CommandHandler
  public void on(CancelContractCommand command, @MetaDataValue("username") String username) {
    if (contractStatus.equals(ContractStatus.CONTRACT_PENDING) || contractStatus.equals(ContractStatus.PENDING_CANCEL)) {
      apply(new ContractCancelledEvent(command.getId(), command.getCancelReason(), username, command.getContractStatus()));
    } else {
      throw new IllegalStateException("This contract can't cancel because contract status is not pending.");
    }
  }

  @CommandHandler
  public void on(CancelContractActivatedCommand command, @MetaDataValue("username") String username) {
    apply(new ContractActivatedCancelledEvent(command.getId(), command.getCancelReason(), username, command.getContractStatus()));
  }

  @CommandHandler
  public void on(RejectCancellationContractCommand command, @MetaDataValue("username") String username) {
    if (contractStatus != ContractStatus.PENDING_CANCEL)
      throw new IllegalStateException("This contract can't reject cancellation because contract status is not pending cancel.");
    apply(new ContractCancellationRejectedEvent(command.getId(), username, command.getContractStatus()));
  }
  
  @CommandHandler
  public void on(CancelStaffLoanContractCommand command, @MetaDataValue("username") String username) {
    if (contractStatus.equals(ContractStatus.CONTRACT_PENDING) || contractStatus.equals(ContractStatus.PENDING_CANCEL)) {
      apply(new StaffLoanContractCancelledEvent(command.getId(), command.getCancelReason(), username, command.getContractStatus()));
    } else {
      throw new IllegalStateException("This contract can't cancel because contract status is not pending.");
    }
  }
  
  @CommandHandler
  public void on(CancelPendingStaffLoanContractCommand command, @MetaDataValue("username") String username) {
    if (contractStatus != ContractStatus.CONTRACT_PENDING)
      throw new IllegalStateException("This contract can't cancel because contract status is not pending.");
    apply(new PendingStaffLoanContractCancelledEvent(command.getId(), command.getCancelReason(), username, command.getContractStatus()));
  }
  
  @CommandHandler
  public void on(RejectCancellationStaffLoanContractCommand command, @MetaDataValue("username") String username) {
    if (contractStatus != ContractStatus.PENDING_CANCEL)
      throw new IllegalStateException("This contract can't reject cancellation because contract status is not pending cancel.");
    apply(new StaffLoanContractCancellationRejectedEvent(command.getId(), username, command.getContractStatus()));
  }
  
}