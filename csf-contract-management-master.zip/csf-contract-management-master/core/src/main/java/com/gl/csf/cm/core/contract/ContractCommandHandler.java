package com.gl.csf.cm.core.contract;

import com.gl.csf.cm.api.contract.command.ActivateRevolvingLoanContractCommand;
import com.gl.csf.cm.api.contract.command.ActivateStaffLoanContractCommand;
import com.gl.csf.cm.api.contract.command.ActivateStandardLoanContractCommand;
import com.gl.csf.cm.common.model.payment.DueDateCalculationPeriod;
import com.gl.csf.cm.service.DueDateCalculationPeriodService;
import com.gl.csf.financeapi.utils.FinanceUtils;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.Aggregate;
import org.axonframework.commandhandling.model.Repository;
import org.axonframework.messaging.annotation.MetaDataValue;

import java.time.LocalDate;
import java.util.Comparator;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 06/02/2018.
 */
public class ContractCommandHandler {
  private final Repository<Contract> repository;
  private final DueDateCalculationPeriodService service;

  public ContractCommandHandler(Repository<Contract> repository, DueDateCalculationPeriodService service) {
    this.repository = repository;
    this.service = service;
  }

  @CommandHandler
  public void activateStandardLoanContract(ActivateStandardLoanContractCommand command, @MetaDataValue("username") String username) {
    Aggregate<Contract> contractAggregate = repository.load(command.getId());
    contractAggregate.execute(contract->{
      contract.getLoanProduct().checkIsValid();
      LocalDate firstDueDate = FinanceUtils.getFirstDueDate(command.getContractDate(), contract.getLoanProduct().getPaymentFrequency());
      contract.activateStandardLoanContract(command, firstDueDate, username);
    });
  }

  @CommandHandler
  public void activateRevolvingLoanContract(ActivateRevolvingLoanContractCommand command, @MetaDataValue("username") String username) {
    Aggregate<Contract> contractAggregate = repository.load(command.getId());
    contractAggregate.execute(contract->{
      contract.getLoanProduct().checkIsValid();
      LocalDate firstDueDate = FinanceUtils.getFirstDueDate(command.getContractDate(), contract.getLoanProduct().getPaymentFrequency());
      contract.activateRevolvingLoanContract(command, firstDueDate, username);
    });
  }

  @CommandHandler
  public void activateStaffLoanContract(ActivateStaffLoanContractCommand command, @MetaDataValue("username") String username) {
    Aggregate<Contract> contractAggregate = repository.load(command.getId());
    contractAggregate.execute(contract->{
      contract.getLoanProduct().checkIsValid();

      int dueDatePeriod = service.getAllDueDateCalculationPeriod().stream().filter(
              p -> (LocalDate.now().isAfter(p.getEffectiveDate()) || LocalDate.now().isEqual(p.getEffectiveDate()))
                      && !LocalDate.now().isBefore(p.getEffectiveDate()))
              .sorted(Comparator.comparing(DueDateCalculationPeriod::getEffectiveDate).reversed())
              .map(DueDateCalculationPeriod::getDays).findFirst().orElseThrow(() -> new IllegalArgumentException("Couldn't find due date period"));

      LocalDate firstDueDate = FinanceUtils.getFirstDueDateForStaffLoan(command.getContractDate(), dueDatePeriod);

      contract.activateStaffLoanContract(command, firstDueDate, username);
    });
  }
}
