package com.gl.csf.cm.core.contract;

import com.gl.csf.cm.common.model.product.ProductType;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 23/11/2017.
 */
class LoanProduct {
  public enum Status {
    PENDING,
    ACTIVE
  }

  private ProductType loanType;
  private int term;
  private BigDecimal interestRate;
  private Integer paymentFrequency;
  private MonetaryAmount loanAmount;
  private Status status;

  LoanProduct(ProductType loanType, int term, BigDecimal interestRate,
              Integer paymentFrequency, MonetaryAmount loanAmount){
    this.loanType = loanType;
    this.term = term;
    this.interestRate = interestRate;
    this.paymentFrequency = paymentFrequency;
    this.loanAmount = loanAmount;
    this.status = Status.PENDING;
  }

  void checkIsValid(){
    if(status == Status.ACTIVE)
      throw new IllegalStateException("Loan product is already active");
    if(term <= 0)
      throw new IllegalStateException("Term must be > 0");
    if(interestRate == null || interestRate.compareTo(BigDecimal.ZERO) <= 0)
      throw new IllegalStateException("Interest rate must be > 0");
    if(paymentFrequency == null)
      throw new IllegalStateException("Payment frequency can't be empty");
    if(12 % paymentFrequency != 0)
      throw new IllegalStateException("Payment frequency must be divisible by number of month in a year");
    if(term % (12/paymentFrequency) != 0)
      throw new IllegalStateException("term: " + term + " must be multiple of paymentinformation period: " + (12/paymentFrequency));
  }

  void activate(){
    this.status = Status.ACTIVE;
  }

  ProductType getLoanType() {
    return loanType;
  }

  public int getTerm() {
    return term;
  }

  BigDecimal getInterestRate() {
    return interestRate;
  }

  int getPaymentFrequency() {
    return paymentFrequency;
  }

  MonetaryAmount getLoanAmount() {
    return loanAmount;
  }
}
