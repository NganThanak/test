package com.gl.csf.cm.uw.integration.model;

import com.gl.csf.cm.uw.integration.model.common.Address;
import com.gl.csf.cm.uw.integration.model.common.Gender;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
public class PersonalInformationDTO implements Serializable {
  private String id;
  private String applicationId;
  private String fullName;
  private String fatherName;
  private Gender gender;
  private LocalDate dob;
  private String phoneNumber;
  private String additionalPhoneNumber1;
  private String additionalPhoneNumber2;
  private String email;
  private String nrcId;
  private Address ownerAddress;
}
