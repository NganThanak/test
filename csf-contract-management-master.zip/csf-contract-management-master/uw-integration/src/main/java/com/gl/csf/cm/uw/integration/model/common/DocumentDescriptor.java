package com.gl.csf.cm.uw.integration.model.common;

import lombok.*;

import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Setter(AccessLevel.PRIVATE)
@Embeddable
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode
public class DocumentDescriptor implements Serializable {
  private String documentId;
  private String uri;
  private String applicationId;
}
