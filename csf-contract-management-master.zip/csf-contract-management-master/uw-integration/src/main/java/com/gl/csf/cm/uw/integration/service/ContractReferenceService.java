package com.gl.csf.cm.uw.integration.service;

import java.time.LocalDate;
import java.util.Objects;
import java.util.function.Supplier;
import javax.inject.Inject;
import org.springframework.stereotype.Service;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 17/11/2017.
 */
@Service
public class ContractReferenceService {

  private final Supplier<Long> sequenceValueProvider;

  @Inject
  public ContractReferenceService(YearlySequenceHandler yearlySequenceHandler) {
    this(() -> yearlySequenceHandler.nextValue());
  }

  protected ContractReferenceService(Supplier<Long> sequenceValueProvider) {
    Objects.requireNonNull(sequenceValueProvider);
    this.sequenceValueProvider = sequenceValueProvider;
  }

  public String nextReference() {
    return "CV-".concat(
        generateNextContractNumber(sequenceValueProvider.get()));
  }
  
  private String generateNextContractNumber(long sequenceValue) {

    final String contractNumberWithoutCheckDigits = String
        .format("%ty%06d", LocalDate.now(), sequenceValue);
    long checkDigits =
        (98 - ((Long.parseUnsignedLong(contractNumberWithoutCheckDigits) * 100) % 97)) % 97;

    return contractNumberWithoutCheckDigits.concat(String.format("%02d", checkDigits));

  }
  
  public Long getCheckTwoDigits(){
    final String contractNumberWithoutCheckDigits = String
            .format("%ty%06d", LocalDate.now(), sequenceValueProvider.get());
    return ((98 - ((Long.parseUnsignedLong(contractNumberWithoutCheckDigits) * 100) % 97)) % 97);
  }
}
