package com.gl.csf.cm.uw.integration.model;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
public enum ProductType {
  STANDARD_LOAN("Standard Loan"), REVOLVING_LOAN("Revolving Loan");

  private final String value;
  ProductType(final String value) {
    this.value = value;
  }
  public String getValue() {
    return value;
  }
}
