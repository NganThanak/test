package com.gl.csf.cm.uw.integration;

import com.gl.csf.cm.uw.integration.model.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
class ApplicationApprovedEvent implements Serializable {
  private String applicationId;
  private PersonalInformationDTO personalInformation;
  private BankInformationDTO bankInformation;
  private GuarantorDTO guarantorInformation;
  private GuarantorBusinessInfoDTO guarantorBusinessInformation;
  private Business businessInformation;
  private List<Branch> branches;
  private FinancialStatementDTO financialStatement;
  private List<FinancialDocumentDTO> financialDocuments;
  private ProductInformationDTO productionInformation;
}
