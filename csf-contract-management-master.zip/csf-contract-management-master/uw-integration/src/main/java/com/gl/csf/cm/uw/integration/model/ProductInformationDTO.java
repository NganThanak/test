package com.gl.csf.cm.uw.integration.model;

import com.gl.csf.cm.uw.integration.model.common.Interest;
import lombok.Data;

import javax.money.MonetaryAmount;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
public class ProductInformationDTO implements Serializable {
  private String applicationId;
  private ProductType loanType;
  private PaymentFrequencyDTO paymentFrequency;
  private Interest interest;
  private Integer term;
  private MonetaryAmount loanAmount;
  private MonetaryAmount maxLoanAmount;
  private MonetaryAmount minLoanAmount;
  private String reasonForRequest;
}
