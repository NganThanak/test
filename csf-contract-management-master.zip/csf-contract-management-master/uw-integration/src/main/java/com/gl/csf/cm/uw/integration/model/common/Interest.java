package com.gl.csf.cm.uw.integration.model.common;

import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by b.chann on 2/5/2018.
 */
@Data
public class Interest implements Serializable {

  private BigDecimal interestRate;
  private Boolean defaultValue;

  @Override
  public String toString() {
    return interestRate.toString();
  }
}
