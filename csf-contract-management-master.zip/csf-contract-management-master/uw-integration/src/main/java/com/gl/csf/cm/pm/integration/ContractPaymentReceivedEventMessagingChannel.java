package com.gl.csf.cm.pm.integration;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/11/2018.
 */
public interface ContractPaymentReceivedEventMessagingChannel {
  String SUBSCRIBER = "payment-receive";

  @Input(SUBSCRIBER)
  SubscribableChannel subscriber();
}
