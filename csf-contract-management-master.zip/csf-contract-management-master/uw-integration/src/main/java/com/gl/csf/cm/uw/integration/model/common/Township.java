package com.gl.csf.cm.uw.integration.model.common;

import lombok.Data;

import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
public class Township implements Serializable {
  private String id;
  private String name;
  private String burmeseName;
}
