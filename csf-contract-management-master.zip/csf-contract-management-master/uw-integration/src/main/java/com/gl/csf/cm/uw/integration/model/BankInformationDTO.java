package com.gl.csf.cm.uw.integration.model;

import com.gl.csf.cm.uw.integration.model.common.BankAccount;
import com.gl.csf.cm.uw.integration.model.common.BankAccountType;
import lombok.Data;

import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
public class BankInformationDTO implements Serializable {
  private String id;
  private String applicationId;
  private BankAccount bankAccount;
  private BankAccountType bankAccountType;
  private String description;
}
