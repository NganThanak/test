package com.gl.csf.cm.uw.integration.model.common;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
public enum LocationOwner {
  RENT("Rent"), OWNER("Owner");
  private final String value;

  private LocationOwner(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
