package com.gl.csf.cm.pm.integration;

import com.gl.csf.cm.api.contract.command.AllocatePaymentCommand;
import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryEntry;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryRepository;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleEntry;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleRepository;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/11/2018.
 */
@Component
@EnableBinding(ContractPaymentReceivedEventMessagingChannel.class)
public class ContractPaymentReceivedEventListener {

  private Logger logger = LoggerFactory.getLogger(ContractPaymentReceivedEventListener.class);

  @Inject
  private CommandGateway commandGateway;
  @Inject
  private ContractSummaryRepository contractSummaryRepository;
  @Inject
  private ContractScheduleRepository contractScheduleRepository;

  @StreamListener(target = ContractPaymentReceivedEventMessagingChannel.SUBSCRIBER)
  public void onRecieved(ContractPaymentReceivedEvent event){
    Optional<ContractSummaryEntry> contractSummaryEntry = contractSummaryRepository.findByContractNumber(event.getContractNumber());
    if(contractSummaryEntry.isPresent()){
      logger.info("Receive payment id : " + event.getPaymentId());
      Optional<ContractScheduleEntry> contractScheduleEntry = contractScheduleRepository.
              findByContractNumberAndInstallmentNumber(event.getContractNumber(), event.getInstallmentNumber());

      if(contractScheduleEntry.isPresent()){
        if(event.getAmount().subtract(contractScheduleEntry.get().getScheduleInstallmentAmount()).isZero()){
          commandGateway.send(new AllocatePaymentCommand(contractSummaryEntry.get().getId(), event.getPaymentId(), LocalDate.now(), event.getExpectedPaymentId(),
                  event.getContractNumber(), event.getInstallmentNumber(), event.getAmount(), event.getPaymentDate(),
                  event.getPaymentReference(), event.getBankTransaction(), event.getPenaltyAmount(), PaymentStatus.FULL));
        }
        else{
          commandGateway.send(new AllocatePaymentCommand(contractSummaryEntry.get().getId(), event.getPaymentId(), LocalDate.now(), event.getExpectedPaymentId(),
                  event.getContractNumber(), event.getInstallmentNumber(), event.getAmount(), event.getPaymentDate(),
                  event.getPaymentReference(), event.getBankTransaction(), event.getPenaltyAmount(), PaymentStatus.PARTIAL));
        }
      }
      else {
        // TODO fire event not found contract
        logger.info("This contract not found " + event.getContractNumber());
      }
    }
  }
}
