package com.gl.csf.cm.uw.integration.service;

import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved.
 * (http://www.grouplease.co.th/) Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on
 * 17/11/2017.
 */
@Service
public class StaffLoanContractReferenceService {

  private final Supplier<Long> sequenceValueProvider;

  @Inject
  public StaffLoanContractReferenceService(YearlySequenceHandler yearlySequenceHandler) {
    this(() -> yearlySequenceHandler.nextStaffLoanValue());
  }

  protected StaffLoanContractReferenceService(Supplier<Long> sequenceValueProvider) {
    Objects.requireNonNull(sequenceValueProvider);
    this.sequenceValueProvider = sequenceValueProvider;
  }

  public String nextReference() {
    return "SL-".concat(
        generateNextContractNumber(sequenceValueProvider.get()));
  }
  
  private String generateNextContractNumber(long sequenceValue) {

    final String contractNumberWithoutCheckDigits = String
        .format("%ty%06d", LocalDate.now(), sequenceValue);
    long checkDigits =
        (98 - ((Long.parseUnsignedLong(contractNumberWithoutCheckDigits) * 100) % 97)) % 97;

    return contractNumberWithoutCheckDigits.concat(String.format("%02d", checkDigits));

  }
  
  public Long getCheckTwoDigits(){
    final String contractNumberWithoutCheckDigits = String
            .format("%ty%06d", LocalDate.now(), sequenceValueProvider.get());
    return ((98 - ((Long.parseUnsignedLong(contractNumberWithoutCheckDigits) * 100) % 97)) % 97);
  }
}
