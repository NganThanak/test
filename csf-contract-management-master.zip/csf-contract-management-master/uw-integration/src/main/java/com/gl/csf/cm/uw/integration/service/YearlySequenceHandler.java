package com.gl.csf.cm.uw.integration.service;


import java.util.Calendar;
import javax.inject.Inject;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class YearlySequenceHandler {


  private final JdbcTemplate jdbcTemplate;

  @Inject
  public YearlySequenceHandler(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  public long nextValue() {

    final String currentSequenceName = String
        .format("contract_sequence_%tY", Calendar.getInstance());
    jdbcTemplate.execute(
        "CREATE SEQUENCE IF NOT EXISTS " + currentSequenceName + " INCREMENT BY 1 START WITH 1");
    return jdbcTemplate
        .queryForObject("select nextval('" + currentSequenceName + "')",
            Long.class);
  }
  
  public long nextStaffLoanValue() {
    
    final String currentSequenceName = String
            .format("contract_staff_loan_sequence_%tY", Calendar.getInstance());
    jdbcTemplate.execute(
            "CREATE SEQUENCE IF NOT EXISTS " + currentSequenceName + " INCREMENT BY 1 START WITH 1");
    return jdbcTemplate
            .queryForObject("select nextval('" + currentSequenceName + "')",
                    Long.class);
  }
}
