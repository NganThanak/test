package com.gl.csf.cm.pm.integration;

import lombok.Data;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/11/2018.
 */
@Data
public class ContractPaymentReceivedEvent {
  private String paymentId;
  private LocalDate receivedOn;
  private String expectedPaymentId;
  private String contractNumber;
  private int installmentNumber;
  private MonetaryAmount amount;
  private LocalDate paymentDate;
  private String paymentReference;
  private String bankTransaction;
  MonetaryAmount penaltyAmount;
}
