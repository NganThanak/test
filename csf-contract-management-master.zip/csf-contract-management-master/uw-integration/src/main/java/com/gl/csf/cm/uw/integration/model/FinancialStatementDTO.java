package com.gl.csf.cm.uw.integration.model;

import lombok.Data;

import javax.money.MonetaryAmount;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
public class FinancialStatementDTO implements Serializable {
  private String applicationId;
  private Integer totalBranch;
  private MonetaryAmount revenue;
  private MonetaryAmount expense;
  private MonetaryAmount margin;
  private Integer numberOfStaff;
  private MonetaryAmount staffExpense;
  private MonetaryAmount netProfit;
  private MonetaryAmount totalRent;
  private MonetaryAmount otherExpense;
  private MonetaryAmount financialRatio;
  private MonetaryAmount installment;
  private MonetaryAmount financialRatioLow;
}
