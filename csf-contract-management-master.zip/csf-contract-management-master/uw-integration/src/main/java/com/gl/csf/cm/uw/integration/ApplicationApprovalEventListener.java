package com.gl.csf.cm.uw.integration;

import com.gl.csf.cm.api.contract.command.CreateContractCommand;
import com.gl.csf.cm.common.model.Gender;
import com.gl.csf.cm.common.model.address.Address;
import com.gl.csf.cm.common.model.address.District;
import com.gl.csf.cm.common.model.address.State;
import com.gl.csf.cm.common.model.address.Township;
import com.gl.csf.cm.common.model.bank.Bank;
import com.gl.csf.cm.common.model.bank.BankAccount;
import com.gl.csf.cm.common.model.bank.BankAccountType;
import com.gl.csf.cm.common.model.guarantor.GuarantorBusiness;
import com.gl.csf.cm.common.model.guarantor.GuarantorPersonalInformation;
import com.gl.csf.cm.common.model.guarantor.Relationship;
import com.gl.csf.cm.common.model.lessee.*;
import com.gl.csf.cm.common.model.lessee.Branch;
import com.gl.csf.cm.common.model.product.LoanProduct;
import com.gl.csf.cm.common.model.product.PaymentFrequency;
import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.common.model.product.StaffLoanProduct;
import com.gl.csf.cm.query.contract.application.ContractApplicationEntry;
import com.gl.csf.cm.query.contract.application.ContractApplicationRepository;
import com.gl.csf.cm.uw.integration.model.*;
import com.gl.csf.cm.uw.integration.model.common.Interest;
import com.gl.csf.cm.uw.integration.service.ContractReferenceService;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.inject.Inject;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Component
public class ApplicationApprovalEventListener {
  private Logger logger = LoggerFactory.getLogger(ApplicationApprovalEventListener.class);

  private final CommandGateway commandGateway;
  private final ContractReferenceService contractReferenceService;
  private final ContractApplicationRepository contractApplicationRepository;

  @Inject
  private ApplicationApprovalEventListener(CommandGateway commandGateway, ContractReferenceService contractReferenceService, ContractApplicationRepository contractApplicationRepository){
    this.commandGateway = commandGateway;
    this.contractReferenceService = contractReferenceService;
    this.contractApplicationRepository = contractApplicationRepository;
  }

  @StreamListener(target = ApplicationApprovalMessagingChannel.SUBSCRIBER)
  protected void onReceived(ApplicationApprovedEvent event) {
    logger.info("Received event for application id: " + event.getApplicationId());

    Optional<ContractApplicationEntry> optionalContractApplicationEntry = contractApplicationRepository.findByApplicationId(event.getApplicationId());

    if(optionalContractApplicationEntry.isPresent()){
      ContractApplicationEntry contractApplicationEntry = optionalContractApplicationEntry.get();
      logger.error("Application id: " + contractApplicationEntry.getApplicationId() +
              " has been used to create contract: " + contractApplicationEntry.getContractNumber() +
              " on: " + contractApplicationEntry.getCreatedDate());
      return;
    }

    LoanProduct loanProduct = new LoanProduct(convert(event.getProductionInformation().getLoanType()),
            event.getProductionInformation().getLoanAmount(), event.getProductionInformation().getTerm(),
      event.getProductionInformation().getInterest().getInterestRate(), convert(event.getProductionInformation().getPaymentFrequency()), event.getProductionInformation().getReasonForRequest());

    LesseePersonalInformation lesseePersonalInformation = new LesseePersonalInformation(event.getPersonalInformation().getFullName(),
            event.getPersonalInformation().getFatherName(), convert(event.getPersonalInformation().getGender()),
            event.getPersonalInformation().getDob(), event.getPersonalInformation().getPhoneNumber(),
            event.getPersonalInformation().getAdditionalPhoneNumber1(), event.getPersonalInformation().getAdditionalPhoneNumber2(), event.getPersonalInformation().getEmail(),
            event.getPersonalInformation().getNrcId(), convert(event.getPersonalInformation().getOwnerAddress()));

    Business uwBusiness = event.getBusinessInformation();
    FinancialStatementDTO uwFinancialStatement = event.getFinancialStatement();

    LesseeBusiness lesseeBusiness = new LesseeBusiness(uwBusiness.getBusinessName(),
            uwBusiness.getMainBranch() != null ? uwBusiness.getMainBranch().getBranchId() : null,
            uwBusiness.getMainBranch() != null ? uwBusiness.getMainBranch().getBranchName() : null,
            uwBusiness.getIsBoss(),
            uwBusiness.getBusinessId(), uwFinancialStatement.getTotalBranch(), uwFinancialStatement.getRevenue(), uwFinancialStatement.getExpense(),
            uwFinancialStatement.getMargin(), uwFinancialStatement.getNumberOfStaff(), uwFinancialStatement.getStaffExpense(), uwFinancialStatement.getNetProfit(),
            uwFinancialStatement.getTotalRent(), uwFinancialStatement.getOtherExpense(), uwFinancialStatement.getFinancialRatio(), uwFinancialStatement.getInstallment(),
            uwFinancialStatement.getFinancialRatioLow(),
            convertBranches(event.getBranches()), convertFinancialDocuments(event.getFinancialDocuments()));

    LesseeBankAccountInformation lesseeBankAccountInformation = new LesseeBankAccountInformation(
            convert(event.getBankInformation().getBankAccount()), convert(event.getBankInformation().getBankAccountType()),
            event.getBankInformation().getDescription());

    GuarantorPersonalInformation guarantorPersonalInformation = null;
    GuarantorBusiness guarantorBusiness = null;

    GuarantorDTO guarantorDTO = event.getGuarantorInformation();

    if(guarantorDTO != null) {
      guarantorPersonalInformation = new GuarantorPersonalInformation(guarantorDTO.getFullName(),
              convert(guarantorDTO.getGender()), guarantorDTO.getDob(), guarantorDTO.getPhoneNumber(), guarantorDTO.getEmail(),
              guarantorDTO.getNrcId(), convert(guarantorDTO.getRelationship()), convert(guarantorDTO.getOwnerAddress()));
    }

    GuarantorBusinessInfoDTO guarantorBusinessInformation = event.getGuarantorBusinessInformation();
    if(guarantorBusinessInformation != null){
      guarantorBusiness = new GuarantorBusiness(guarantorBusinessInformation.getBusinessInfoPhoneNumber(), convert(guarantorBusinessInformation.getBusinessInfoAddress()));
    }

    CreateContractCommand createContractCommand = new CreateContractCommand(UUID.randomUUID().toString(),
        contractReferenceService.nextReference(), event.getApplicationId(), loanProduct,
        lesseePersonalInformation, lesseeBusiness,
            lesseeBankAccountInformation, guarantorPersonalInformation, guarantorBusiness, new Staff(), new StaffLoanProduct());

    commandGateway.send(createContractCommand);
    logger.info("Sent the Create contract command for an application id: " + event.getApplicationId());
  }

  private Relationship convert(com.gl.csf.cm.uw.integration.model.common.Relationship uwRelationship){
    if(uwRelationship == null)
      return null;

    Relationship relationship = new Relationship();

    relationship.setId(uwRelationship.getId());
    relationship.setName(uwRelationship.getName());
    relationship.setDescription(uwRelationship.getDescription());

    return relationship;
  }

  private BankAccountType convert(com.gl.csf.cm.uw.integration.model.common.BankAccountType uwBankAccountType){
    if(uwBankAccountType == null)
      return null;

    switch (uwBankAccountType){
      case BUSINESS:
        return BankAccountType.BUSINESS;
      case PERSONAL:
        return BankAccountType.PERSONAL;
      default:
        throw new IllegalArgumentException("Not found Bank account type: " + uwBankAccountType);
    }
  }

  private BankAccount convert(com.gl.csf.cm.uw.integration.model.common.BankAccount uwBankAccount){
    if(uwBankAccount == null)
      return null;

    BankAccount bankAccount = new BankAccount();
    bankAccount.setAccountName(uwBankAccount.getAccountName());
    bankAccount.setAccountNumber(uwBankAccount.getAccountNumber());
    bankAccount.setBank(convert(uwBankAccount.getBank()));
    return bankAccount;
  }

  private Bank convert(com.gl.csf.cm.uw.integration.model.common.Bank uwBank){
    if(uwBank == null)
      return null;

    Bank bank = new Bank();
    bank.setId(uwBank.getId());
    bank.setName(uwBank.getName());
    bank.setBurmeseName(uwBank.getBurmeseName());
    return bank;
  }

  private List<FinancialDocument> convertFinancialDocuments(List<FinancialDocumentDTO> uwFinancialDocuments){
    List<FinancialDocument> financialDocuments = new ArrayList<>();

    for(com.gl.csf.cm.uw.integration.model.FinancialDocumentDTO uwFinancialDocument : uwFinancialDocuments){
      FinancialDocument financialDocument = new FinancialDocument();
      financialDocument.setBucketId(uwFinancialDocument.getDescriptor().getApplicationId());
      financialDocument.setDocumentId(uwFinancialDocument.getDescriptor().getDocumentId());
      financialDocument.setAttachment(uwFinancialDocument.getAttachment());
      financialDocument.setUploadBy(uwFinancialDocument.getUploadBy());
      financialDocument.setDateTime(uwFinancialDocument.getDateTime());
      financialDocument.setComment(uwFinancialDocument.getComment());
      financialDocuments.add(financialDocument);
    }

    return financialDocuments;
  }

  private List<Branch> convertBranches(List<com.gl.csf.cm.uw.integration.model.Branch> uwBranches){
    List<Branch> branches = new ArrayList<>();

    for(com.gl.csf.cm.uw.integration.model.Branch uwBranch : uwBranches){
      Branch branch = new Branch();

      branch.setBranchId(uwBranch.getBranchId());
      branch.setBranchName(uwBranch.getBranchName());
      branch.setEmail(uwBranch.getEmail());
      branch.setIsBoss(uwBranch.getIsBoss());
      branch.setRentAmount(uwBranch.getRentAmount());
      branch.setPhoneNumber(uwBranch.getPhoneNumber());
      branch.setAddress(uwBranch.getAddress());
      branch.setState(new State(uwBranch.getState().getId(), uwBranch.getState().getName(), uwBranch.getState().getBurmeseName()));
      branch.setDistrict(new District(uwBranch.getDistrict().getId(), uwBranch.getDistrict().getName(), uwBranch.getDistrict().getBurmeseName()));
      branch.setTownship(new Township(uwBranch.getTownship().getId(), uwBranch.getTownship().getName(), uwBranch.getTownship().getBurmeseName()));
      branch.setLocationOwner(convert(uwBranch.getLocationOwner()));
      branch.setOpenSince(uwBranch.getOpenSince());
      branch.setBranchStatus(convert(uwBranch.getBranchStatus()));

      branch.setRevenue(uwBranch.getRevenue());
      branch.setExpense(uwBranch.getExpense());
      branch.setOtherExpense(uwBranch.getOtherExpense());
      branch.setMargin(uwBranch.getMargin());
      branch.setNumberOfStaff(uwBranch.getNumberOfStaff());
      branch.setStaffExpense(uwBranch.getStaffExpense());
      branch.setNetProfit(uwBranch.getNetProfit());

      branches.add(branch);
    }

    return branches;
  }

  private BranchStatus convert(com.gl.csf.cm.uw.integration.model.common.BranchStatus uwBranchStatus){
    if(uwBranchStatus == null)
      return null;

    switch (uwBranchStatus){
      case ACTIVE:
        return BranchStatus.ACTIVE;
      case INACTIVE:
        return BranchStatus.INACTIVE;
      default:
        throw new IllegalArgumentException("Not found branch status: " + uwBranchStatus);
    }
  }

  private LocationOwner convert(com.gl.csf.cm.uw.integration.model.common.LocationOwner uwLocationOwner){
    if(uwLocationOwner == null)
      return null;

    switch (uwLocationOwner){
      case RENT:
        return LocationOwner.RENT;
      case OWNER:
        return LocationOwner.OWNER;
      default:
        throw new IllegalArgumentException("Not found location owner: " + uwLocationOwner);
    }
  }

  private Address convert(com.gl.csf.cm.uw.integration.model.common.Address uwAddress){
    if(uwAddress == null)
      return null;

    State state = null;
    if(uwAddress.getState() != null) {
      state = new State(uwAddress.getState().getId(), uwAddress.getState().getName(), uwAddress.getState().getBurmeseName());
    }

    District district = null;
    if(uwAddress.getDistrict() != null) {
      district = new District(uwAddress.getDistrict().getId(), uwAddress.getDistrict().getName(), uwAddress.getDistrict().getBurmeseName());
    }

    Township township = null;

    if(uwAddress.getTownship() != null) {
      township = new Township(uwAddress.getTownship().getId(), uwAddress.getTownship().getName(), uwAddress.getTownship().getBurmeseName());
    }

    return new Address(uwAddress.getText(), state, district, township);
  }

  private Gender convert(com.gl.csf.cm.uw.integration.model.common.Gender uwGender){
    if(uwGender == null)
      return null;

    switch (uwGender){
      case MALE:
        return Gender.MALE;
      case FEMALE:
        return Gender.FEMALE;
      default:
        throw new IllegalArgumentException("Not found gender: " + uwGender);
    }
  }

  private ProductType convert(com.gl.csf.cm.uw.integration.model.ProductType uwProductType){
    if(uwProductType == null)
      return null;

    switch (uwProductType){
      case STANDARD_LOAN:
        return ProductType.STANDARD_LOAN;
      case REVOLVING_LOAN:
        return ProductType.REVOLVING_LOAN;
      default:
        throw new IllegalArgumentException("Not found product type: " + uwProductType);
    }
  }

  private PaymentFrequency convert(PaymentFrequencyDTO uwPaymentFrequency){
    if(uwPaymentFrequency == null)
      return null;

    PaymentFrequency paymentFrequency = new PaymentFrequency();
    paymentFrequency.setDescription(uwPaymentFrequency.getDescription());
    paymentFrequency.setValue(uwPaymentFrequency.getValue());
    return paymentFrequency;
  }
}
