package com.gl.csf.cm.uw.integration;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
public interface ApplicationApprovalMessagingChannel {
  String SUBSCRIBER = "application-approval";

  @Input(SUBSCRIBER)
  SubscribableChannel subscriber();
}
