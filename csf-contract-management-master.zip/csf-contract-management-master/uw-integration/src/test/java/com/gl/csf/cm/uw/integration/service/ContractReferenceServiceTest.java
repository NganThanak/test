package com.gl.csf.cm.uw.integration.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

public class ContractReferenceServiceTest {

  @Test
  public void testGetReferenceNumber() throws Exception {
    ContractReferenceService contractReferenceService = new ContractReferenceService(() -> 1L);
    assertThat(contractReferenceService.nextReference()).isEqualTo("CV-1700000176");

  }

}