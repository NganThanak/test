package com.gl.csf.cm.common.model.lessee;

import lombok.Value;

import javax.money.MonetaryAmount;
import java.io.Serializable;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Value
public class LesseeBusiness implements Serializable {
  private String businessName;
  private String mainBranchId;
  private String mainBranchName;
  private Boolean isBoss;
  private String businessId;

  // Financial statement
  private Integer totalBranch;
  private MonetaryAmount revenue;
  private MonetaryAmount expense;
  private MonetaryAmount margin;
  private Integer numberOfStaff;
  private MonetaryAmount staffExpense;
  private MonetaryAmount netProfit;
  private MonetaryAmount totalRent;
  private MonetaryAmount otherExpense;
  private MonetaryAmount financialRatio;
  private MonetaryAmount installment;
  private MonetaryAmount financialRatioLow;

  private List<Branch> branches;
  private List<FinancialDocument> financialDocuments;
}
