package com.gl.csf.cm.common.model.contract;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
public enum ContractStatus {
  CONTRACT_PENDING, CONTRACT_ACTIVATED, PENDING_CANCEL, CONTRACT_CANCELLED, CLOSED, CONTRACT_DECLINED, CONTRACT_REJECTED;


}
