package com.gl.csf.cm.api.contract.command;

import com.gl.csf.cm.common.model.guarantor.GuarantorBusiness;
import com.gl.csf.cm.common.model.guarantor.GuarantorPersonalInformation;
import com.gl.csf.cm.common.model.lessee.LesseeBankAccountInformation;
import com.gl.csf.cm.common.model.lessee.LesseeBusiness;
import com.gl.csf.cm.common.model.lessee.LesseePersonalInformation;
import com.gl.csf.cm.common.model.lessee.Staff;
import com.gl.csf.cm.common.model.product.LoanProduct;
import com.gl.csf.cm.common.model.product.StaffLoanProduct;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/13/2017.
 */
@Value
public class CreateContractCommand implements Serializable {
  @TargetAggregateIdentifier
  String id;
  @NotEmpty
  String contractNumber;
  @NotEmpty
  String applicationId;
  @NotNull
  LoanProduct loanProduct;
  @NotNull
  LesseePersonalInformation lesseePersonalInformation;
  @NotNull
  LesseeBusiness lesseeBusiness;
  @NotNull
  LesseeBankAccountInformation lesseeBankAccountInformation;

  GuarantorPersonalInformation guarantorPersonalInformation;
  GuarantorBusiness guarantorBusiness;
  Staff staff;
  StaffLoanProduct staffLoanProduct;
}
