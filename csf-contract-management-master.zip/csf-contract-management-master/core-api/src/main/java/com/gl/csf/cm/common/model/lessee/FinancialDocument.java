package com.gl.csf.cm.common.model.lessee;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
public class FinancialDocument implements Serializable {
  private String bucketId;
  private String documentId;

  private String attachment;
  private String uploadBy;
  private LocalDateTime dateTime;
  private String comment;
}
