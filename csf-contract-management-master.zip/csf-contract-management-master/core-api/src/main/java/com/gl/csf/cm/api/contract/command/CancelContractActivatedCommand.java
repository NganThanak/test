package com.gl.csf.cm.api.contract.command;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: chann bora
 */
@Value
public class CancelContractActivatedCommand implements Serializable {
  @TargetAggregateIdentifier
  String id;
  
  @NotNull
  String cancelReason;
  ContractStatus contractStatus;
}
