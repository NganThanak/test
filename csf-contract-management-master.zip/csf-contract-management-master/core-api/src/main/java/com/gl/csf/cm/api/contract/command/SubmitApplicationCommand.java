package com.gl.csf.cm.api.contract.command;

import com.gl.csf.cm.common.model.application.StaffLoanApplications;
import lombok.Data;
import org.axonframework.commandhandling.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
public class SubmitApplicationCommand {
  @NotEmpty
  @TargetAggregateIdentifier
  private String id;
  @NotNull
  private StaffLoanApplications application;
  private String applicationId;
  private String contractNumber;
  
  private SubmitApplicationCommand() {
  
  }
  
  public SubmitApplicationCommand(String id, StaffLoanApplications application,String applicationId, String contractNumber) {
    this.id = id;
    this.application = application;
    this.applicationId = applicationId;
    this.contractNumber = contractNumber;
  }
}
