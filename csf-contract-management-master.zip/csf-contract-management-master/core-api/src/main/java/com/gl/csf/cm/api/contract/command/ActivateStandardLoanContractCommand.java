package com.gl.csf.cm.api.contract.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/11/2017.
 */
@Value
public class ActivateStandardLoanContractCommand implements Serializable {
  @TargetAggregateIdentifier
  String id;
  @NotNull
  LocalDate contractDate;
}
