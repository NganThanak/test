package com.gl.csf.cm.common.model.application;

import com.gl.csf.cm.common.model.lessee.Staff;
import com.gl.csf.cm.common.model.product.StaffLoanProduct;
import lombok.Data;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Data
@Embeddable
public class StaffLoanApplications {
  @Embedded
  private Staff staff;
  @Embedded
  private StaffLoanProduct staffLoanProduct;
  
  public StaffLoanApplications() {
  }
}
