package com.gl.csf.cm.common.model.lessee;

import com.gl.csf.cm.common.model.bank.BankAccount;
import com.gl.csf.cm.common.model.bank.BankAccountType;
import lombok.Value;

import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Value
public class LesseeBankAccountInformation implements Serializable {
  private BankAccount bankAccount;
  private BankAccountType bankAccountType;
  private String description;
}
