package com.gl.csf.cm.service;

import com.gl.csf.cm.common.model.payment.DueDateCalculationPeriod;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 2/1/2018.
 */
@Service
public class DueDateCalculationPeriodService{
  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public DueDateCalculationPeriodService(@Value("${endpoints.rest.parameter.duedatecalculationperiod}") String baseUrl, RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  public List<DueDateCalculationPeriod> getAllDueDateCalculationPeriod(){
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
      new ParameterizedTypeReference<List<DueDateCalculationPeriod>>(){}).getBody();
  }

  public Optional<DueDateCalculationPeriod> getDueDateCalculationPeriodById(UUID stateId){
    Objects.requireNonNull(stateId);

    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/" + stateId, HttpMethod.GET, null,
        new ParameterizedTypeReference<DueDateCalculationPeriod>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
