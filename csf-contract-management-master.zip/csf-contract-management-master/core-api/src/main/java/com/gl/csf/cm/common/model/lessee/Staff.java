package com.gl.csf.cm.common.model.lessee;

import com.gl.csf.cm.common.model.Gender;
import com.gl.csf.cm.common.model.address.Address;
import com.gl.csf.cm.common.model.bank.BankAccount;
import lombok.Data;
import org.hibernate.annotations.*;
import org.hibernate.validator.constraints.NotEmpty;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Pisith Ly (p.ly@gl-f.com) on Aug 5, 2017.
 */
@Embeddable
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class Staff implements Serializable {

  private String fullName;
  private String nrcID;
  private Gender gender;
  private String fatherName;
  private LocalDate dateOfBirth;
  private String position;
  
  @Embedded
  private Company company;
  private String phoneNumber;
  private String email;
  @Embedded
  private Address address;
  
  @Embedded
  private BankAccount bankAccount;
  
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "monthly_salary_currency"), @Column(name = "monthly_salary")})
  private MonetaryAmount monthlySalary;
  
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "annual_salary_currency"), @Column(name = "annual_salary")})
  private MonetaryAmount annualSalary;

  @ElementCollection
  @LazyCollection(LazyCollectionOption.FALSE)
  private Collection<StaffLoanPurpose> staffLoanPurposes;

  private String otherLoanPurpose;
  
  public Staff(String fullName, String nrcID, Gender gender, String fatherName, LocalDate dateOfBirth, String position, Company company, String phoneNumber, String email, Address address, BankAccount bankAccount, MonetaryAmount monthlySalary, MonetaryAmount annualSalary, Collection<StaffLoanPurpose> staffLoanPurposes, String otherLoanPurpose) {
    this.fullName = fullName;
    this.nrcID = nrcID;
    this.gender = gender;
    this.fatherName = fatherName;
    this.dateOfBirth = dateOfBirth;
    this.position = position;
    this.company = company;
    this.phoneNumber = phoneNumber;
    this.email = email;
    this.address = address;
    this.bankAccount = bankAccount;
    this.monthlySalary = monthlySalary;
    this.annualSalary = annualSalary;
    this.staffLoanPurposes = staffLoanPurposes;
    this.otherLoanPurpose = otherLoanPurpose;
  }
  
  public Staff() {
  }
}

