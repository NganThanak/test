package com.gl.csf.cm.common.model.payment;

import lombok.Data;

import java.time.LocalDate;

/**
 * Created by p.ly on 2/1/2018.
 */
@Data
public class DueDateCalculationPeriod {

  private String id;
  private int days;
  private LocalDate effectiveDate;

  @Override
  public String toString() {
    return String.valueOf(days);
  }
}

