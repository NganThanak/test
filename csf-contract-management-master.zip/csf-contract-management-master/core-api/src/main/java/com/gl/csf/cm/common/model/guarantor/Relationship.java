package com.gl.csf.cm.common.model.guarantor;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Embeddable
public class Relationship implements Serializable {
  @Column(name = "relationship_id")
  private String id;
  @Column(name = "relationship_name")
  private String name;
  @Column(name = "relationship_description")
  private String description;

  @Override
  public String toString() {
    return name;
  }
}
