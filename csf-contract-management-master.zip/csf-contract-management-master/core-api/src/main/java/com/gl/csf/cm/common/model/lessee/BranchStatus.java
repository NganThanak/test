package com.gl.csf.cm.common.model.lessee;

import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
public enum BranchStatus implements Serializable {
  ACTIVE("Active"), INACTIVE("Inactive");
  private final String value;

  private BranchStatus(final String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
