package com.gl.csf.cm.common.model.product;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by p.ly on 1/20/2018.
 */
@Data
@Embeddable
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class StaffLoanProduct implements Serializable {

  private ProductType productType;
  
  @NotNull
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "loan_amount_currency"), @Column(name = "loan_amount_salary")})
  private MonetaryAmount loanAmount;
  @NotNull
  private Integer term;

  @NotNull
  @Embedded
  private PaymentFrequency paymentFrequency;
  @Digits(integer = 2, fraction = 1)
  private BigDecimal interestRate;

  public StaffLoanProduct(ProductType productType, MonetaryAmount loanAmount, Integer term, PaymentFrequency paymentFrequency, BigDecimal interestRate) {
    this.productType = productType;
    this.loanAmount = loanAmount;
    this.term = term;
    this.paymentFrequency = paymentFrequency;
    this.interestRate = interestRate;
  }

  public StaffLoanProduct(){

  }
}
