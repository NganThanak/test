package com.gl.csf.cm.common.model.payment;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
public enum PaymentStatus {
  UNPAID, FULL, PARTIAL, OVER_PAY;
}
