package com.gl.csf.cm.common.model.contract;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/16/2017.
 */
public enum WriteOffStatus {
  PENDING_WRITE_OFF, WRITE_OFF, NONE
}
