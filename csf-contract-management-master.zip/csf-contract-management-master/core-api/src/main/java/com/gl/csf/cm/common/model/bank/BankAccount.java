package com.gl.csf.cm.common.model.bank;

import lombok.Data;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Embeddable
public class BankAccount implements Serializable {
  @Embedded
  private Bank bank;
  private String accountName;
  private String accountNumber;
  
  public BankAccount() {
  }
  
  public BankAccount(Bank bank, String accountName, String accountNumber) {
    this.bank = bank;
    this.accountName = accountName;
    this.accountNumber = accountNumber;
  }
}
