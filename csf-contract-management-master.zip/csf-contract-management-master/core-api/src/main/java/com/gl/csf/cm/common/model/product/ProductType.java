package com.gl.csf.cm.common.model.product;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
public enum ProductType {
  STANDARD_LOAN("Standard Loan"), REVOLVING_LOAN("Revolving Loan"), STAFF_LOAN("Staff Loan");

  private final String value;
  
  private ProductType(final String value) {
    this.value = value;
  }
  public String getValue() {
    return value;
  }

}
