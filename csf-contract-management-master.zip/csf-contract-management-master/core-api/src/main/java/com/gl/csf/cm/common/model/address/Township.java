package com.gl.csf.cm.common.model.address;

import lombok.Data;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Embeddable
public class Township implements Serializable {
  @Column(name = "township_id")
  private String id;
  @Column(name = "township_name")
  private String name;
  @Column(name = "township_burmeseName")
  private String burmeseName;

  public Township(String id, String name, String burmeseName) {
    this.id = id;
    this.name = name;
    this.burmeseName = burmeseName;
  }

  public Township() {
  }

  @Override
  public String toString() {
    return name;
  }
}
