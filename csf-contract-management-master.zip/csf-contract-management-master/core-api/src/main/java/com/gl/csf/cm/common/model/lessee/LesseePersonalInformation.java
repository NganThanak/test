package com.gl.csf.cm.common.model.lessee;

import com.gl.csf.cm.common.model.Gender;
import com.gl.csf.cm.common.model.address.Address;
import lombok.Value;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Value
public class LesseePersonalInformation implements Serializable {
  private String fullName;
  private String fatherName;
  private Gender gender;
  private LocalDate dob;
  private String phoneNumber;
  private String additionalPhoneNumber1;
  private String additionalPhoneNumber2;
  private String email;
  private String nrcId;
  private Address ownerAddress;
}
