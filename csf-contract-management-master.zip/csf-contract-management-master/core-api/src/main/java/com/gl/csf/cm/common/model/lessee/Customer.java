package com.gl.csf.cm.common.model.lessee;

import com.gl.csf.cm.common.model.Gender;
import com.gl.csf.cm.common.model.address.Address;
import com.gl.csf.cm.common.model.bank.BankAccount;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 8/15/2017.
 */
@Data
@Embeddable
public class Customer {

  @Column(name = "username")
  private String username;

  @Column(name = "business_name")
  private String businessName;

  @Column(name = "business_id")
  private String businessId;

  @Column(name = "fullname")
  private String fullName;

  @Column(name = "gender")
  @Enumerated(EnumType.STRING)
  private Gender gender;

  @Column(name = "date_of_birth")
  private LocalDate dateOfBirth;

  @Column(name = "email")
  private String email;

  @Column(name = "phone_number")
  private String phoneNumber;
  @Embedded
  private Address address;
  @Embedded
  private BankAccount bankAccount;
}
