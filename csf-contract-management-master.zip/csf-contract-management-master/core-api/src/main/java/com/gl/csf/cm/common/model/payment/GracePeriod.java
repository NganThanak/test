package com.gl.csf.cm.common.model.payment;

import lombok.Data;

import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/17/2018.
 */
@Data
public class GracePeriod {
  private String id;
  private int days;
  private LocalDate effectiveDate;

  @Override
  public String toString() {
    return String.valueOf(days);
  }
}
