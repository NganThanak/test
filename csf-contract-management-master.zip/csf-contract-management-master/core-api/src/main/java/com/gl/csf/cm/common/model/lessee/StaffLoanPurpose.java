package com.gl.csf.cm.common.model.lessee;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.UUID;

/**
 * Created by p.ly on 1/19/2018.
 */
@Embeddable
@Data
public class StaffLoanPurpose implements Serializable {
  @NotNull
  @Column(name = "staff_loan_purpose_id")
  private UUID id;
  @NotEmpty
  private String purpose;

  public StaffLoanPurpose(UUID id, String purpose) {
    this.id = id;
    this.purpose = purpose;
  }

  public StaffLoanPurpose() {
  }

  @Override
  public String toString() {
    return purpose;
  }
}
