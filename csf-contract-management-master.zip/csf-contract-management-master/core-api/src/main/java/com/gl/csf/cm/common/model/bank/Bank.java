package com.gl.csf.cm.common.model.bank;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Embeddable
public class Bank implements Serializable {
  @Column(name = "bank_id")
  private String id;
  @Column(name = "bank_name")
  private String name;
  @Column(name = "bank_burmeseName")
  private String burmeseName;
  
  public Bank() {
  }
  
  public Bank(String id, String name, String burmeseName) {
    this.id = id;
    this.name = name;
    this.burmeseName = burmeseName;
  }
  
  @Override
  public String toString() {
    return name;
  }
}
