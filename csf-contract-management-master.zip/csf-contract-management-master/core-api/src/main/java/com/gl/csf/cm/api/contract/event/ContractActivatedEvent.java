package com.gl.csf.cm.api.contract.event;

import lombok.Getter;

import javax.money.MonetaryAmount;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/11/2017.
 */
@Getter
public class ContractActivatedEvent implements Serializable {
  private String id;
  private String contractNumber;
  private LocalDate contractDate;
  private LocalDate firstDueDate;

  private int term;
  private BigDecimal interestRate;
  private int paymentFrequency;
  private MonetaryAmount loanAmount;

  private LocalDate activatedDate;
  private String activatedBy;

  ContractActivatedEvent(String id, String contractNumber, LocalDate contractDate, LocalDate firstDueDate,
                         int term, BigDecimal interestRate, int paymentFrequency, MonetaryAmount loanAmount,
                         LocalDate activatedDate, String activatedBy) {
    this.id = id;
    this.contractNumber = contractNumber;
    this.contractDate = contractDate;
    this.firstDueDate = firstDueDate;
    this.term = term;
    this.interestRate = interestRate;
    this.paymentFrequency = paymentFrequency;
    this.loanAmount = loanAmount;
    this.activatedDate = activatedDate;
    this.activatedBy = activatedBy;
  }
}
