package com.gl.csf.cm.api.contract.event;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import lombok.Value;

import java.io.Serializable;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/13/2017.
 */
@Value
public class ContractCancelledEvent implements Serializable {
  String id;
  String cancelReason;
  String updatedBy;
  ContractStatus contractStatus;
}
