package com.gl.csf.cm.common.model.product;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Embeddable
public class PaymentFrequency implements Serializable {
  @Column(name = "payment_frequency_id")
  private String id;
  @Column(name = "payment_frequency_value")
  private Integer value;
  @Column(name = "payment_frequency_description")
  private String description;

  @Override
  public String toString() {
    return description;
  }
}
