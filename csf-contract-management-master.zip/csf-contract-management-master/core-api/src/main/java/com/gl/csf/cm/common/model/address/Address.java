package com.gl.csf.cm.common.model.address;

import lombok.Data;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Embeddable
public class Address implements Serializable {
  private String text;
  @Embedded
  private State state;
  @Embedded
  private District district;
  @Embedded
  private Township township;

  public Address(){
  }
  
  public Address(String text, State state, District district, Township township){
    this.text = text;
    this.state = state;
    this.district = district;
    this.township = township;
  }
}