package com.gl.csf.cm.common.model.product;

import lombok.Value;

import javax.money.MonetaryAmount;
import javax.validation.constraints.Digits;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Value
public class LoanProduct implements Serializable {
  private ProductType productType;
  private MonetaryAmount loanAmount;
  private Integer term;
  @Digits(integer = 2, fraction = 1)
  private BigDecimal interestRate;
  private PaymentFrequency paymentFrequency;
  private String reasonForRequest;
}
