package com.gl.csf.cm.api.contract.event;

import com.gl.csf.cm.common.model.guarantor.GuarantorBusiness;
import com.gl.csf.cm.common.model.guarantor.GuarantorPersonalInformation;
import com.gl.csf.cm.common.model.lessee.LesseeBankAccountInformation;
import com.gl.csf.cm.common.model.lessee.LesseeBusiness;
import com.gl.csf.cm.common.model.lessee.LesseePersonalInformation;
import com.gl.csf.cm.common.model.lessee.Staff;
import com.gl.csf.cm.common.model.product.LoanProduct;
import com.gl.csf.cm.common.model.product.StaffLoanProduct;
import lombok.Value;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/13/2017.
 */
@Value
public class ContractCreatedEvent implements Serializable {
  String id;
  String applicationId;
  String contractNumber;
  LoanProduct loanProduct;
  LesseePersonalInformation lesseePersonalInformation;
  LesseeBusiness lesseeBusiness;
  LesseeBankAccountInformation lesseeBankAccountInformation;
  GuarantorPersonalInformation guarantorPersonalInformation;
  GuarantorBusiness guarantorBusiness;
  LocalDate createdDate;
  Staff staff;
  StaffLoanProduct staffLoanProduct;
  String createdBy;
}
