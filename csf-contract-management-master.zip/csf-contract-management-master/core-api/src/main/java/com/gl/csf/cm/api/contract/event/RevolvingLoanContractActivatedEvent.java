package com.gl.csf.cm.api.contract.event;

import javax.money.MonetaryAmount;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/11/2017.
 */
public class RevolvingLoanContractActivatedEvent extends ContractActivatedEvent implements Serializable {

  private final MonetaryAmount firstWithdrawalAmount;

  public RevolvingLoanContractActivatedEvent(String id, String contractNumber, LocalDate contractDate, LocalDate firstDueDate, int term, BigDecimal interestRate,
                                      int paymentFrequency, MonetaryAmount loanAmount, LocalDate activatedDate, String activatedBy, MonetaryAmount firstWithdrawalAmount) {
    super(id, contractNumber, contractDate, firstDueDate, term, interestRate, paymentFrequency, loanAmount, activatedDate, activatedBy);
    this.firstWithdrawalAmount = firstWithdrawalAmount;
  }


  public MonetaryAmount getFirstWithdrawalAmount() {
    return firstWithdrawalAmount;
  }
}
