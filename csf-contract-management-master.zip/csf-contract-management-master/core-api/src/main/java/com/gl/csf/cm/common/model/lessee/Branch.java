package com.gl.csf.cm.common.model.lessee;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.gl.csf.cm.common.model.address.District;
import com.gl.csf.cm.common.model.address.State;
import com.gl.csf.cm.common.model.address.Township;
import lombok.Data;

import javax.money.MonetaryAmount;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
public class Branch implements Serializable {

  private String branchId;
  private String branchName;
  private String email;
  private Boolean isBoss;
  private MonetaryAmount rentAmount;

  private String phoneNumber;
  @JsonProperty("ADDRESS")
  private String address;
  private State state;
  private District district;
  private Township township;

  @JsonProperty("LOCATION_OWNER")
  private LocationOwner locationOwner;

  @JsonProperty("OPEN_SINCE")
  private LocalDate openSince;

  private BranchStatus branchStatus;

  private MonetaryAmount revenue;
  private MonetaryAmount expense;
  private MonetaryAmount otherExpense;
  private MonetaryAmount margin;
  private Integer numberOfStaff;
  private MonetaryAmount staffExpense;
  private MonetaryAmount netProfit;
}
