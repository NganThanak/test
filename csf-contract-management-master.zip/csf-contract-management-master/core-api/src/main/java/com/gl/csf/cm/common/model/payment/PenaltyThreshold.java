package com.gl.csf.cm.common.model.payment;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/30/2018.
 */
@Data
public class PenaltyThreshold implements Serializable {
  private String id;
  private double threshold;
  private LocalDate effectiveDate;
}
