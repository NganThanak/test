package com.gl.csf.cm.common.model.payment;

import lombok.Data;

import javax.persistence.Column;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Created by p.ly on 1/16/2018.
 */
@Data
public class PenaltyCalculationPeriod implements Serializable{

  private String id;
  private int days;
  private LocalDate effectiveDate;

  @Override
  public String toString() {
    return String.valueOf(days);
  }
}
