package com.gl.csf.cm.api.contract.event;

import lombok.Value;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/3/2018.
 */
@Value
public class ContractNumberUpdatedEvent {
  String id;
  private String contractNumber;
}
