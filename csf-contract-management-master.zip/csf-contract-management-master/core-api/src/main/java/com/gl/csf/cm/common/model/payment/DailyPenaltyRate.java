package com.gl.csf.cm.common.model.payment;

import lombok.Data;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/17/2018.
 */
@Data
public class DailyPenaltyRate {
  private String id;
  private MonetaryAmount rate;
  private LocalDate effectiveDate;

  @Override
  public String toString() {
    return rate.getNumber().toString();
  }
}
