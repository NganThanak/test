package com.gl.csf.cm.common.model.contract;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/16/2017.
 */
public enum RescheduleStatus {
  RESCHEDULE_IN_PROGRESS, PENDING_RESCHEDULE_APPROVAL, RESCHEDULE_REQUEST_APPROVED, RESCHEDULE_REQUEST_REJECTED,
  RESCHEDULE_ACTIVATED, PENDING_RESCHEDULE_CANCELLED, RESCHEDULE_CANCELLED, NONE
}
