package com.gl.csf.cm.config;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
public interface MultiOutputSource {
  String OUTPUT_ALLOCATION_PAYMENT = "output-allocation-payment";

  @Output(OUTPUT_ALLOCATION_PAYMENT)
  MessageChannel outputAllocationPayment();
}
