package com.gl.csf.cm.common.model.lessee;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.UUID;

/**
 * Created by p.ly on 1/20/2018.
 */
@Data
@Embeddable
public class Company implements Serializable {
  @Column(name = "company_id")
  private String id;
  private String company;
  
  @Override
  public String toString() {
    return company;
  }
  
  public Company(){
  
  }
  
  public Company(String id, String company) {
    this.id = id;
    this.company = company;
  }
}
