package com.gl.csf.cm.common.model.address;

import lombok.Data;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */

@Data
@Embeddable
public class District implements Serializable {
  @Column(name = "district_id")
  private String id;
  @Column(name = "district_name")
  private String name;
  @Column(name = "district_burmeseName")
  private String burmeseName;

  public District(String id, String name, String burmeseName) {
    this.id = id;
    this.name = name;
    this.burmeseName = burmeseName;
  }

  public District() {
  }

  @Override
  public String toString() {
    return name;
  }
}
