package com.gl.csf.cm.api.contract.command;

import lombok.Value;
import org.axonframework.commandhandling.TargetAggregateIdentifier;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/3/2018.
 */
@Value
public class UpdateContractNumberCommand {
  @TargetAggregateIdentifier
  String id;
  
  private String contractNumber;
}
