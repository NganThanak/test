package com.gl.csf.cm.ui.view;

import com.gl.csf.cm.ui.common.PermissionRoleComponent;
import com.gl.csf.cm.ui.permission.Role;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Page;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Created by jerome on 8/15/17.
 */
@SpringComponent
@UIScope
public class AccessDeniedView extends CustomComponent implements View {
  @Inject
  VaadinSecurity vaadinSecurity;
  
  String staff = "Unknown";

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    if (!vaadinSecurity.isAuthenticated()) {
      Page.getCurrent()
              .setLocation("/sso/login?viewName=" + event.getViewName());
    } else {
      final PermissionRoleComponent permissionRoleComponent = new PermissionRoleComponent();
      vaadinSecurity.getAuthentication().getAuthorities().forEach(e-> {
        if (e.getAuthority().equals(Role.ADMINISTRATOR)) {
          staff = "Paramter staff";
        } else if (e.getAuthority().equals(Role.CUSTOMER)) {
          staff = "Customer";
        } else {
          staff = "UW staff";
        }
      });
      permissionRoleComponent.confirmationMessage.setValue("Sorry, you don't have access to module Contract Management as '"+ staff +"'.Please logout and login with proper credential.");
      Window window = permissionRoleComponent.displayConfiguration();
      permissionRoleComponent.setListener(new PermissionRoleComponent.PermissionRoleComponentListener() {
        @Override
        public void onClosed() {window.close();}
        @Override
        public void onLogoutButtonClicked() {
          vaadinSecurity.logout();
        }
      });
      window.setContent(permissionRoleComponent);
      UI.getCurrent().addWindow(window);
    }
  }
}
