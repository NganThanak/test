package com.gl.csf.cm.ui.report;

import com.gl.csf.cm.query.contract.accounting.ContractInterestRealizationAttributeEntry;
import com.gl.csf.cm.query.contract.accounting.ContractInterestRealizationAttributeRepository;
import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationEntry;
import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationRepository;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import java.util.List;
import java.util.Optional;

/**
 * Created by p.ly on 11/21/2017.
 */
@SpringComponent
@UIScope
public class InterestReportByContractComponent extends InterestReportByContractComponentDesign{
  private final ContractPeriodInterestRealizationRepository repository;
  private final ContractInterestRealizationAttributeRepository attributeRepository;
  public InterestReportByContractComponent(ContractPeriodInterestRealizationRepository repository, ContractInterestRealizationAttributeRepository attributeRepository) {
    this.repository = repository;
    this.attributeRepository = attributeRepository;

    searchButton.addClickListener(e->{
      List<ContractPeriodInterestRealizationEntry> interestRealizationEntries = repository.findAllByContractNumber(contractNumberTextField.getValue());
      Optional<ContractInterestRealizationAttributeEntry> entryOptional = attributeRepository.findByContractNumber(contractNumberTextField.getValue());
      reportItemLayout.removeAllComponents();

      if(!interestRealizationEntries.isEmpty() && entryOptional.isPresent())
        reportItemLayout.addComponent(new InterestReportByContractItemComponent(contractNumberTextField.getValue(), interestRealizationEntries, entryOptional.get()));
    });

    clearReportItem();
  }

  public void clearReportItem(){
    reportItemLayout.removeAllComponents();
    contractNumberTextField.clear();
  }
}
