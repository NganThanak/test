package com.gl.csf.cm.resource;

import com.gl.csf.cm.api.contract.command.SubmitApplicationCommand;
import com.gl.csf.cm.common.model.application.StaffLoanApplications;
import com.gl.csf.cm.uw.integration.service.ContractReferenceService;
import com.gl.csf.cm.uw.integration.service.StaffLoanContractReferenceService;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/20/2018.
 */
@Component
@Path("")
public class ApplicationResource {
  private CommandGateway commandGateway;
  private final StaffLoanContractReferenceService contractReferenceService;
  @Inject
  public ApplicationResource(CommandGateway commandGateway, StaffLoanContractReferenceService contractReferenceService) {
    this.commandGateway = commandGateway;
    this.contractReferenceService = contractReferenceService;
  }
  
  @POST
  @Path("/applications/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes("application/x-command.SubmitApplicationCommand+json")
  public Response submitApplication(@PathParam("id") String id, StaffLoanApplications staffLoanApplications){
    String nextReferenceNumber = contractReferenceService.nextReference();
    SubmitApplicationCommand submitApplicationCommand = new SubmitApplicationCommand(id,staffLoanApplications,UUID.randomUUID().toString(),nextReferenceNumber);
    commandGateway.send(submitApplicationCommand);
    
    return Response.noContent().build();
  }
}
