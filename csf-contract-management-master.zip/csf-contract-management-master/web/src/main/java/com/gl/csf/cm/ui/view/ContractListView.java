package com.gl.csf.cm.ui.view;

import com.gl.csf.cm.ui.permission.Role;
import com.gl.csf.cm.ui.viewdeclaration.UIScopeContractViews;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;
import org.vaadin.spring.security.VaadinSecurity;
import javax.inject.Inject;

/**
 * Created by p.ly on 1/22/2018.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeContractViews.CONTRACT_LIST)
@Secured({Role.SL_MANAGER, Role.SL_STAFF, Role.OPERATION_STAFF, Role.OPERATION_MANAGER})
public class ContractListView extends ContractListViewDesign implements View{

  private VaadinSecurity vaadinSecurity;

  @Inject
  public ContractListView(VaadinSecurity vaadinSecurity) {
    this.vaadinSecurity = vaadinSecurity;

    contractTab.getTab(contractListTabsheet).setVisible(vaadinSecurity.hasAnyAuthority(Role.OPERATION_MANAGER, Role.OPERATION_STAFF));
    contractTab.getTab(staffloanContractListTabsheet).setVisible(vaadinSecurity.hasAnyAuthority(Role.SL_STAFF, Role.SL_MANAGER));
  }
}
