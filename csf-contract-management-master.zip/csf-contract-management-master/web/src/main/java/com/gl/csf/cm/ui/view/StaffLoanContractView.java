package com.gl.csf.cm.ui.view;

import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.ui.component.contract.businessinfo.StaffLoanBusinessInfoComponent;
import com.gl.csf.cm.ui.component.contract.loaninformation.StaffLoanInfoComponent;
import com.gl.csf.cm.ui.component.contract.ownerinfo.StaffLoanPersonalInfoComponent;
import com.gl.csf.cm.ui.permission.Role;
import com.gl.csf.cm.ui.viewdeclaration.UIScopeContractViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;
import javax.inject.Inject;
import java.util.Map;

/**
 * Created by p.ly on 1/23/2018.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeContractViews.STAFF_LOAN)
@Secured({Role.SL_MANAGER,Role.SL_STAFF})
public class StaffLoanContractView extends StaffLoanContractViewDesign implements View{
  
  private String contractId;
  private String contractNo;
  private final SessionScopeBus bus;
  private final StaffLoanPersonalInfoComponent staffLoanPersonalInfoComponent;
  private final StaffLoanBusinessInfoComponent staffLoanBusinessInfoComponent;
  private final StaffLoanInfoComponent staffLoanInfoComponent;
  private final static String CONTRACT_INFORMATION = "Owner information";
  private final static String CONTRACT_FINANCIAL_INFORMATION = "Financial information";
  private final static String CONTRACT_STAFFLOAN_INFORMATION = "Loan information";

  @Inject
  public StaffLoanContractView(SessionScopeBus bus, StaffLoanPersonalInfoComponent staffLoanPersonalInfoComponent,
                               StaffLoanBusinessInfoComponent staffLoanBusinessInfoComponent, StaffLoanInfoComponent staffLoanInfoComponent) {
    this.bus = bus;
    this.staffLoanPersonalInfoComponent = staffLoanPersonalInfoComponent;
    this.staffLoanBusinessInfoComponent = staffLoanBusinessInfoComponent;
    this.staffLoanInfoComponent = staffLoanInfoComponent;

    contractTab.addTab(staffLoanPersonalInfoComponent, CONTRACT_INFORMATION);
    contractTab.addTab(staffLoanBusinessInfoComponent, CONTRACT_FINANCIAL_INFORMATION);
    contractTab.addTab(staffLoanInfoComponent, CONTRACT_STAFFLOAN_INFORMATION);
  }
  
  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {

    Map<String, String> parameterMap = event.getParameterMap();
    this.contractId = parameterMap.getOrDefault("contractid", null);
    this.contractNo = parameterMap.getOrDefault("contractno", null);

    staffLoanPersonalInfoComponent.setContractId(this.contractId);
    staffLoanBusinessInfoComponent.setContractId(this.contractId);
    staffLoanInfoComponent.setContractId(this.contractId);

    contractTab.setSelectedTab(staffLoanPersonalInfoComponent);
    setContractIdByEventBus(this.contractId, this.contractNo);
  }
  
  public void setContractIdByEventBus(String contractId, String contractNo) {
    bus.post(new ContractSelectedEvent(contractId,contractNo)).now();
  }
}
