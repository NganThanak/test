package com.gl.csf.cm.ui.report;

import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.query.contract.accounting.PortfolioPeriodInterestRealizationEntry;
import com.gl.csf.cm.query.contract.accounting.PortfolioPeriodInterestRealizationRepository;
import com.gl.csf.cm.ui.permission.Role;
import com.gl.csf.cm.ui.util.ProductTypeUtil;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import javax.inject.Inject;

import org.vaadin.spring.security.VaadinSecurity;

import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.YEARS;

/**
 * Created by p.ly on 11/21/2017.
 */
@SpringComponent
@UIScope
public class InterestSummaryReportComponent extends InterestSummaryReportComponentDesign {
  
  /**
	 * 
	 */
  private static final long serialVersionUID = 4316812017292280978L;

  private String loanType = "All";
  private List<ProductType> productTypes = new ArrayList<>();
  
  @Inject
  public InterestSummaryReportComponent(PortfolioPeriodInterestRealizationRepository repository, VaadinSecurity vaadinSecurity) {
    if (vaadinSecurity.hasAnyAuthority(Role.OPERATION_MANAGER, Role.OPERATION_STAFF)) {
    	productTypes.addAll(ProductTypeUtil.getBySMERole());
    }
    if (vaadinSecurity.hasAnyAuthority(Role.SL_STAFF, Role.SL_MANAGER)) {
    	productTypes.addAll(ProductTypeUtil.getByStaffLoanRole());
    }    
    loanTypeComboBox.setDataProvider(new ListDataProvider<ProductType>(productTypes));
    searchButton.setEnabled(false);
    Binder<PortfolioPeriodInterestRealizationEntry> filterBinder = filterBinder();
    filterBinder.addStatusChangeListener(event -> searchButton.setEnabled(event.getBinder().isValid()));
    
    dateFromDateField.setDateFormat("MM-yyyy");
    dateToDateField.setDateFormat("MM-yyyy");
    
    dateFromDateField.addValueChangeListener(event -> {
      dateToDateField.clear();
    });
    
    loanTypeComboBox.addValueChangeListener(event -> {
      if (event.getSource().getOptionalValue().isPresent())
        loanType = event.getValue().toString();
      else
        loanType = "All";
    });
    
    clearAllButton.addClickListener(clickEvent -> {
      filterBinder.setBean(new PortfolioPeriodInterestRealizationEntry());
      loanTypeComboBox.setSelectedItem(null);
      reportItemList.removeAllComponents();
    });
    
    searchButton.addClickListener(event -> {
      reportItemList.removeAllComponents();
      List<PortfolioPeriodInterestRealizationEntry> periodInterestRealizationEntryList = new ArrayList<>();
      
      if (loanType.equalsIgnoreCase("All")) {
        List<PortfolioPeriodInterestRealizationEntry> entryList = repository.findAllByEndOfMonthDateBetween(dateFromDateField.getValue().with(TemporalAdjusters.lastDayOfMonth()), dateToDateField.getValue().with(TemporalAdjusters.lastDayOfMonth()));
        if (!entryList.isEmpty() && vaadinSecurity.hasAnyAuthority(Role.OPERATION_MANAGER, Role.OPERATION_STAFF)) {
        	periodInterestRealizationEntryList.addAll(entryList.stream()
        		.filter(ProductTypeUtil::isSMEProduct)
        		.collect(Collectors.toList()));
        }
        if (!entryList.isEmpty() && vaadinSecurity.hasAnyAuthority(Role.SL_STAFF, Role.SL_MANAGER)) {
        	periodInterestRealizationEntryList.addAll(entryList.stream()
            		.filter(ProductTypeUtil::isStaffLoanProduct)
            		.collect(Collectors.toList()));
        }
      }
      else {
        periodInterestRealizationEntryList = repository.findAllByLoanTypeAndEndOfMonthDateBetween(loanTypeComboBox.getSelectedItem().get(), dateFromDateField.getValue(), dateToDateField.getValue());
      }
      if (!periodInterestRealizationEntryList.isEmpty()) {
        reportItemList.addComponent(new InterestSummaryReportItemComponent(periodInterestRealizationEntryList, dateFromDateField.getValue(), dateToDateField.getValue(), loanType));
      }
      
    });
  }
  
  private Binder<PortfolioPeriodInterestRealizationEntry> filterBinder() {
    Binder<PortfolioPeriodInterestRealizationEntry> result = new BeanValidationBinder<>(PortfolioPeriodInterestRealizationEntry.class);
    result.forField(dateFromDateField).asRequired("From date is required.").bind("endOfMonthDate");
    result.forField(dateToDateField).asRequired("To date is required.").withValidator(todate -> todate.compareTo(dateFromDateField.getValue()) > 0, "To date must be greater than From date").withValidator(d -> YEARS.between(dateFromDateField.getValue(), d) < 2, "From to To date must between 2 years").bind("endOfMonthDate");
    return result;
  }
}