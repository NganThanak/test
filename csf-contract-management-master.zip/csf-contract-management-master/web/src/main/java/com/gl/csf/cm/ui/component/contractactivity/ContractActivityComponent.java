package com.gl.csf.cm.ui.component.contractactivity;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

/**
 * Created by p.ly on 11/8/2017.
 */
@SpringComponent
@UIScope
public class ContractActivityComponent extends ContractActivityComponentDesign{
}
