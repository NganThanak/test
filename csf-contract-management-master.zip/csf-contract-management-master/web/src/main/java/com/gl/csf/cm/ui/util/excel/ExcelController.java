package com.gl.csf.cm.ui.util.excel;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 9/18/2017.
 */
@Controller
@RequestMapping("/docs/export/")
public class ExcelController {
  @RequestMapping(value = "payment-simulation/download", method = RequestMethod.GET)
  public ModelAndView download(Map<String, Object> model) throws Exception {
    ModelAndView modelAndView = new ModelAndView(new PaymentScheduleExcelBuilder());

    return modelAndView;
  }

  @RequestMapping(value = "report/accounting-closing-report/download", method = RequestMethod.GET)
  public ModelAndView downloadAccountingClosingReport(Map<String, Object> model) throws Exception {
    ModelAndView modelAndView = new ModelAndView(new AccountClosingReportExcelBuilder(AccountClosingReportExcelBuilder.contractPeriodInterestRealizationEntrys.size() + 10 ));

    return modelAndView;
  }

  @RequestMapping(value = "report/contract-interest-realization-attribute/download", method = RequestMethod.GET)
  public ModelAndView downloadInterestRealizationAttribute(Map<String, Object> model) throws Exception {
    ModelAndView modelAndView = new ModelAndView(new ContractInterestRealizationAttributeExcelBuilder());

    return modelAndView;
  }
  
  @RequestMapping(value = "interest-summary-report/download", method = RequestMethod.GET)
  public ModelAndView downloadReport(Map<String, Object> model) throws Exception {
    ModelAndView modelAndView = new ModelAndView(new InterestSummaryReportExcelBuilder());
    
    return modelAndView;
  }
}
