package com.gl.csf.cm.message;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.VaadinSessionScope;
import net.engio.mbassy.bus.MBassador;
import net.engio.mbassy.bus.publication.SyncAsyncPostCommand;

import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/11/2017.
 */
@SpringComponent
@VaadinSessionScope
public class SessionScopeBus <T> implements Serializable {
  private final transient MBassador<T> bus;

  public SessionScopeBus(){
    this.bus = new MBassador<>();
  }

  public MBassador<T> getBus() {
    return bus;
  }

  public SyncAsyncPostCommand<T> post(T message){
    return bus.post(message);
  }

  public void subscribe(Object listener){
    bus.subscribe(listener);
  }

  public boolean unsubscribe(Object listener){
    return bus.unsubscribe(listener);
  }
}
