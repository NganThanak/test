package com.gl.csf.cm.ui.component.contract.ownerinfo;

import com.gl.csf.cm.common.model.address.State;
import com.gl.csf.cm.service.StateService;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/7/2017.
 */
@SpringComponent
@UIScope
public class PersonalInfoComponent extends PersonalInfoComponentDesign {
  private final StateService stateService;
  
  @Inject
  public PersonalInfoComponent(StateService stateService){
    this.stateService = stateService;
    enableAndDisablePersonalComponent(false);
    enableAndDisableBankInfoComponent(false);
  
    ListDataProvider<State> stateListDataProvider = new ListDataProvider<>(stateService.getAllStates());
    comboBoxState.setDataProvider(stateListDataProvider);
  }
  
  private void enableAndDisableBankInfoComponent(boolean value) {
    textFieldBankHolderName.setEnabled(value);
    comboBoxBankName.setEnabled(value);
    textFieldBankNumber.setEnabled(value);
    radioButtonBankAccountType.setEnabled(value);
    textFieldDescription.setEnabled(value);
  }
  
  public void enableAndDisablePersonalComponent(boolean value){
    textFieldFullName.setEnabled(value);
    comboBoxGender.setEnabled(value);
    dateFieldDOB.setEnabled(value);
    textFieldPhoneNumber.setEnabled(value);
    textFieldEmail.setEnabled(value);
    textFieldOwnerAddress.setEnabled(value);
    comboBoxDistrict.setEnabled(value);
    comboBoxTownship.setEnabled(value);
    textFieldFatherName.setEnabled(value);
    comboBoxState.setEnabled(value);
    textFieldNRCID.setEnabled(value);
  }
  
}
