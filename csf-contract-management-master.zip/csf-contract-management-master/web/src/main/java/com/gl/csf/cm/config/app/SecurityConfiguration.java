package com.gl.csf.cm.config.app;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 11/15/2017.
 */
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.inject.Inject;
import com.gl.csf.cm.config.Authenticated;
import com.gl.csf.cm.config.Authenticated.With;

import com.gl.csf.cm.config.Authenticated;
import org.keycloak.adapters.KeycloakConfigResolver;
import org.keycloak.adapters.KeycloakDeployment;
import org.keycloak.adapters.KeycloakDeploymentBuilder;
import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.keycloak.adapters.springboot.KeycloakSpringBootProperties;
import org.keycloak.adapters.springsecurity.KeycloakConfiguration;
import org.keycloak.adapters.springsecurity.authentication.KeycloakAuthenticationProvider;
import org.keycloak.adapters.springsecurity.client.KeycloakClientRequestFactory;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.keycloak.adapters.springsecurity.config.KeycloakWebSecurityConfigurerAdapter;
import org.keycloak.adapters.springsecurity.filter.KeycloakAuthenticationProcessingFilter;
import org.keycloak.adapters.springsecurity.filter.KeycloakPreAuthActionsFilter;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.core.authority.mapping.SimpleAuthorityMapper;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.web.client.RestTemplate;
import org.vaadin.spring.security.annotation.EnableVaadinSharedSecurity;
import org.vaadin.spring.security.config.VaadinSharedSecurityConfiguration;
import org.vaadin.spring.security.shared.VaadinLogoutHandler;
import org.vaadin.spring.security.shared.VaadinRedirectLogoutHandler;
import org.vaadin.spring.security.web.VaadinRedirectStrategy;

import javax.inject.Inject;
import java.util.Arrays;

@KeycloakConfiguration
@EnableVaadinSharedSecurity
@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true, proxyTargetClass = true)
public class SecurityConfiguration extends KeycloakWebSecurityConfigurerAdapter {
  
  @Inject
  ObjectMapper objectMapper;
  
  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    KeycloakAuthenticationProvider keycloakAuthenticationProvider = keycloakAuthenticationProvider();
    final SimpleAuthorityMapper grantedAuthoritiesMapper = new SimpleAuthorityMapper();
    grantedAuthoritiesMapper.setConvertToUpperCase(true);
    keycloakAuthenticationProvider.setGrantedAuthoritiesMapper(grantedAuthoritiesMapper);
    auth.authenticationProvider(keycloakAuthenticationProvider);
  }
  
  @Override
  protected void configure(HttpSecurity http) throws Exception {
    super.configure(http);
    http.httpBasic().disable();
    http.formLogin().disable();
    http.anonymous().disable();
    http.csrf().disable();
    http.headers()
            .frameOptions().sameOrigin().and()
            .authorizeRequests()
            .antMatchers("/vaadinServlet/UIDL/**").permitAll()
            .antMatchers("/vaadinServlet/HEARTBEAT/**").permitAll()
            .antMatchers("/h2-console/**").permitAll()
            .antMatchers("/api/**").authenticated()
            .anyRequest().authenticated();
  }
  
  @Override
  public void configure(WebSecurity web) throws Exception {
    web.ignoring().antMatchers("/VAADIN/**");
  }
  
  @Bean
  public KeycloakConfigResolver KeycloakConfigResolver() {
    return new KeycloakSpringBootConfigResolver();
  }
  
  @Bean
  @Override
  protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
    return new RegisterSessionAuthenticationStrategy(buildSessionRegistry());
  }
  
  @Bean
  protected SessionRegistry buildSessionRegistry() {
    return new SessionRegistryImpl();
  }
  
  
  @Bean(name = VaadinSharedSecurityConfiguration.VAADIN_LOGOUT_HANDLER_BEAN)
  VaadinLogoutHandler vaadinLogoutHandler(VaadinRedirectStrategy vaadinRedirectStrategy) {
    VaadinRedirectLogoutHandler handler = new VaadinRedirectLogoutHandler(
            vaadinRedirectStrategy);
    handler.setLogoutUrl("/sso/logout");
    return handler;
  }
  
  @Bean
  public FilterRegistrationBean keycloakAuthenticationProcessingFilterRegistrationBean(
          KeycloakAuthenticationProcessingFilter filter) {
    FilterRegistrationBean registrationBean = new FilterRegistrationBean(filter);
    registrationBean.setEnabled(false);
    return registrationBean;
  }
  
  @Bean
  public FilterRegistrationBean keycloakPreAuthActionsFilterRegistrationBean(
          KeycloakPreAuthActionsFilter filter) {
    FilterRegistrationBean registrationBean = new FilterRegistrationBean(filter);
    registrationBean.setEnabled(false);
    return registrationBean;
  }
  
  @Bean
  @Inject
  @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
  @Authenticated(With.USER_CREDENTIALS)
  public KeycloakRestTemplate userCredentialsRestTemplate(
          KeycloakClientRequestFactory keycloakClientRequestFactory) {
    final KeycloakRestTemplate keycloakRestTemplate = new KeycloakRestTemplate(
            keycloakClientRequestFactory);
    keycloakRestTemplate.getMessageConverters().add(0, mappingJacksonHttpMessageConverter());
    return keycloakRestTemplate;
  }
  
  @Bean
  @Inject
  @Authenticated(With.CLIENT_CREDENTIALS)
  @Primary
  public RestTemplate clientCredentialsRestTemplate(
          KeycloakSpringBootProperties keycloakSpringBootProperties) {
    final OAuth2RestTemplate oAuth2RestTemplate = new OAuth2RestTemplate(
            clientCredentialsResourceDetails(
                    KeycloakDeploymentBuilder.build(keycloakSpringBootProperties)),
            new DefaultOAuth2ClientContext());
    oAuth2RestTemplate.getMessageConverters().add(0, mappingJacksonHttpMessageConverter());
    return oAuth2RestTemplate;
    
    
  }
  
  private ClientCredentialsResourceDetails clientCredentialsResourceDetails(
          KeycloakDeployment keycloakDeployment) {
    
    ClientCredentialsResourceDetails clientCredentialsResourceDetails = new ClientCredentialsResourceDetails();
    clientCredentialsResourceDetails.setAccessTokenUri(keycloakDeployment.getTokenUrl());
    clientCredentialsResourceDetails.setAuthenticationScheme(AuthenticationScheme.header);
    clientCredentialsResourceDetails.setClientId(keycloakDeployment.getResourceName());
    clientCredentialsResourceDetails
            .setClientSecret(keycloakDeployment.getResourceCredentials().get("secret").toString());
    clientCredentialsResourceDetails.setScope(Arrays.asList(keycloakDeployment.getScope()));
    
    return clientCredentialsResourceDetails;
  }
  
  
  @Bean
  public MappingJackson2HttpMessageConverter mappingJacksonHttpMessageConverter() {
    MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    converter.setObjectMapper(objectMapper);
    return converter;
  }
}
