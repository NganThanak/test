package com.gl.csf.cm.ui.component.contract.ownerinfo;

import com.gl.csf.cm.common.model.bank.BankAccountType;
import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.guarantor.GuarantorBusinessEntry;
import com.gl.csf.cm.query.contract.guarantor.GuarantorBusinessRepository;
import com.gl.csf.cm.query.contract.guarantor.GuarantorPersonalInformationEntry;
import com.gl.csf.cm.query.contract.guarantor.GuarantorPersonalInformationRepository;
import com.gl.csf.cm.query.contract.lessee.LesseeBankAccountInformationEntry;
import com.gl.csf.cm.query.contract.lessee.LesseeBankAccountInformationRepository;
import com.gl.csf.cm.query.contract.lessee.LesseePersonalInformationEntry;
import com.gl.csf.cm.query.contract.lessee.LesseePersonalInformationRepository;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Arrays;

import static java.time.temporal.ChronoUnit.YEARS;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/7/2017.
 */
@Listener
@SpringComponent
@UIScope
public class OwnerInfoComponent extends OwnerInfoComponentDesign {
  private final SessionScopeBus bus;
  private final GuarantorPersonalInformationRepository guarantorPersonalInformationRepository;
  private final GuarantorBusinessRepository guarantorBusinessRepository;

  private final Binder<GuarantorPersonalInformationEntry> guarantorPersonalInformationBinder;
  private final Binder<GuarantorBusinessEntry> guarantorBusinessBinder;

  private final LesseePersonalInformationRepository lesseePersonalInformationRepository;
  private final LesseeBankAccountInformationRepository lesseeBankAccountInformationRepository;

  private final Binder<LesseePersonalInformationEntry> lesseePersonalInformationBinder;
  private final Binder<LesseeBankAccountInformationEntry> lesseeBankAccountInformationBinder;

  private String contractId;

  @Inject
  public OwnerInfoComponent(SessionScopeBus bus, LesseePersonalInformationRepository lesseePersonalInformationRepository, LesseeBankAccountInformationRepository lesseeBankAccountInformationRepository,
                            GuarantorPersonalInformationRepository guarantorPersonalInformationRepository, GuarantorBusinessRepository guarantorBusinessRepository){
    this.bus = bus;
    this.lesseePersonalInformationRepository = lesseePersonalInformationRepository;
    this.lesseeBankAccountInformationRepository = lesseeBankAccountInformationRepository;
    
    this.guarantorPersonalInformationRepository = guarantorPersonalInformationRepository;
    this.guarantorBusinessRepository = guarantorBusinessRepository;
    
    this.lesseePersonalInformationBinder = createLesseePersonalInformationBinder();
    this.lesseeBankAccountInformationBinder = createLesseeBankAccountInformationBinder();

    this.guarantorPersonalInformationBinder = createGuarantorPersonalInformationBinder();
    this.guarantorBusinessBinder = createGuarantorBusinessBinder();
    
    this.personalInfoComponent.radioButtonBankAccountType.setDataProvider(new ListDataProvider<>(Arrays.asList(BankAccountType.values())));

  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }
  
  private Binder<LesseePersonalInformationEntry> createLesseePersonalInformationBinder(){
    Binder<LesseePersonalInformationEntry> result = new BeanValidationBinder<>(LesseePersonalInformationEntry.class);
    result.forField(personalInfoComponent.textFieldFullName).asRequired("Full name").bind("fullName");
    result.forField(personalInfoComponent.comboBoxGender).asRequired("Gender").bind("gender");
    result.forField(personalInfoComponent.dateFieldDOB).withValidator(dob -> YEARS.between(dob, LocalDate.now()) >= 18, "Age must be greater than 18.")
            .asRequired("Age must be greater than 18.").bind("dob");
    result.forField(personalInfoComponent.textFieldPhoneNumber).asRequired("Phone number").bind("phoneNumber");
    result.forField(personalInfoComponent.additionalPhoneNumberTextField1).bind("additionalPhoneNumber1");
    result.forField(personalInfoComponent.additionalPhoneNumberTextField2).bind("additionalPhoneNumber2");
    result.forField(personalInfoComponent.textFieldOwnerAddress).asRequired("Owner address").bind("ownerAddress.text");
    result.forField(personalInfoComponent.textFieldFatherName).bind("fatherName");
    result.forField(personalInfoComponent.textFieldNRCID).asRequired("National ID").bind("nrcId");
    result.forField(personalInfoComponent.comboBoxState).asRequired("State").bind("ownerAddress.state");
    result.bind(personalInfoComponent.textFieldEmail,"email");
    result.forField(personalInfoComponent.comboBoxDistrict).asRequired("District").bind("ownerAddress.district");
    result.forField(personalInfoComponent.comboBoxTownship).asRequired("Township").bind("ownerAddress.township");
    return result;
  }
  
  private Binder<LesseeBankAccountInformationEntry> createLesseeBankAccountInformationBinder(){
    Binder<LesseeBankAccountInformationEntry> result = new BeanValidationBinder<>(LesseeBankAccountInformationEntry.class);
    result.forField(personalInfoComponent.textFieldBankHolderName).asRequired("Account name").bind("bankAccount.accountName");
    result.forField(personalInfoComponent.comboBoxBankName).asRequired("Bank name").bind("bankAccount.bank");
    result.forField(personalInfoComponent.textFieldBankNumber).asRequired("Bank number").bind("bankAccount.accountNumber");
    result.forField(personalInfoComponent.radioButtonBankAccountType).asRequired("Account type").bind("bankAccountType");
    result.bind(personalInfoComponent.textFieldDescription,"description");
    return result;
  }

  private Binder<GuarantorPersonalInformationEntry> createGuarantorPersonalInformationBinder(){
    Binder<GuarantorPersonalInformationEntry> result = new BeanValidationBinder<>(GuarantorPersonalInformationEntry.class);
    result.forField(guarantorComponent.textFieldFullName).bind("fullName");
    result.forField(guarantorComponent.comboBoxGender).bind("gender");
    result.forField(guarantorComponent.dateFieldDOB).withValidator(dob -> YEARS.between(dob, LocalDate.now()) >= 18, "Age must be greater than 18.").bind("dob");
    result.forField(guarantorComponent.textFieldPhoneNumber).bind("phoneNumber");
    result.forField(guarantorComponent.textFieldNRCID).bind("nrcId");
    result.bind(guarantorComponent.textFieldEmail,"email");
    result.forField(guarantorComponent.comboBoxRelationship).bind("relationship");
    result.forField(guarantorComponent.textFieldOwnerAddress).bind("address.text");
    result.forField(guarantorComponent.comboBoxState).bind("address.state");
    result.forField(guarantorComponent.comboBoxDistrict).bind("address.district");
    result.forField(guarantorComponent.comboBoxTownship).bind("address.township");
    return result;
  }

  private Binder<GuarantorBusinessEntry> createGuarantorBusinessBinder(){
    Binder<GuarantorBusinessEntry> result = new BeanValidationBinder<>(GuarantorBusinessEntry.class);
    result.forField(guarantorComponent.textFieldPhoneNumberBusiness).bind("phoneNumber");
    result.forField(guarantorComponent.textFieldOwnerAddressBusiness).bind("address.text");
    result.forField(guarantorComponent.comboBoxStateBusiness).bind("address.state");
    result.forField(guarantorComponent.comboBoxDistrictBusiness).bind("address.district");
    result.forField(guarantorComponent.comboBoxTownshipBusiness).bind("address.township");
    return result;
  }

  private void fetchData(){
    lesseePersonalInformationBinder.setBean(lesseePersonalInformationRepository.findOne(contractId));
    lesseeBankAccountInformationBinder.setBean(lesseeBankAccountInformationRepository.findOne(contractId));

    guarantorPersonalInformationBinder.setBean(guarantorPersonalInformationRepository.findOne(contractId));
    guarantorBusinessBinder.setBean(guarantorBusinessRepository.findOne(contractId));
  }

  @Handler
  private void handle(ContractSelectedEvent event){
    this.contractId = event.getContractId();
    //set personalInfoComponent as default tab
    ownerInfoTabSheet.setSelectedTab(personalInfoComponent);
    fetchData();
  }
}
