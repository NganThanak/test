package com.gl.csf.cm.ui.report;

import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.query.contract.accounting.PortfolioPeriodInterestRealizationEntry;
import com.gl.csf.cm.ui.util.excel.InterestSummaryReportExcelBuilder;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import java.time.LocalDate;
import java.util.List;
/**
 * Created by p.ly on 11/21/2017.
 */

public class InterestSummaryReportItemComponent extends InterestSummaryReportItemComponentDesign{
  private static final String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private static final String INTEREST_SUMMARY_REPORT_PATH = BASE_PATH + "/interest-summary-report/download";
  
  public InterestSummaryReportItemComponent(List<PortfolioPeriodInterestRealizationEntry> value, LocalDate dateFromDateField, LocalDate dateToDateField, String loanTypeValue) {
    dateFrom.setValue(LocalDateTimeFormat.formatLocalDate(dateFromDateField));
    dateTo.setValue(LocalDateTimeFormat.formatLocalDate(dateToDateField));
    loanType.setValue(loanTypeValue);
    
    buttonDownload.addClickListener(event -> {
      InterestSummaryReportExcelBuilder.setInstallment(value, dateFromDateField, dateToDateField);
      InterestSummaryReportExcelBuilder.setLoanType(loanTypeValue);
      Page.getCurrent().open(INTEREST_SUMMARY_REPORT_PATH, "_blank");
    });
  }
}
