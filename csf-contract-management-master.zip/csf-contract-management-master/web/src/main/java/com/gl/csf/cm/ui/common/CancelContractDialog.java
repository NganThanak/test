package com.gl.csf.cm.ui.common;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.vaadin.ui.Window;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/16/2017.
 */
public class CancelContractDialog extends CancelContractDialogDesign {
  public interface ConfirmationComponentListener{
    void onClosed();
    void onRejectButtonClicked();
    void onCancellationButtonClicked();
  }
  
  private ConfirmationComponentListener listener;
  
  public CancelContractDialog() {
    closeButton.addClickListener(e -> {
      if(listener != null)
        listener.onClosed();
    });
    cancellationButton.addClickListener(e -> {
      if(listener != null)
        listener.onCancellationButtonClicked();
    });
    
    rejectButton.addClickListener(e -> {
      if(listener != null)
        listener.onRejectButtonClicked();
    });

    reasonText.addValueChangeListener(e-> {
      cancellationButton.setEnabled((!reasonText.getValue().isEmpty() || !reasonLabel.getValue().isEmpty()) && cancelLabel.getValue() != null);
    });
  }
  
  public Window displayConfiguration() {
    Window window = new Window();
    window.center();
    window.removeAllCloseShortcuts();
    window.setResizable(false);
    window.setClosable(false);
    window.setModal(true);
    window.setWidth(600, Unit.PIXELS);
    return window;
  }
  
  public ConfirmationComponentListener getListener() {
    return listener;
  }
  
  public void setListener(ConfirmationComponentListener listener) {
    this.listener = listener;
  }
  
  public String getCancelReason(){return reasonText.getValue();}

  public void setCancelTypeLabel(String cancelType){
    if(cancelType.equals(ContractStatus.CONTRACT_PENDING.toString())){
      rejectButton.setEnabled(false);
      cancellationButton.setEnabled(false);
    }
    else{
      cancellationButton.setEnabled(true);
      rejectButton.setEnabled(true);
      cancelLabel.setValue(cancelType.equals(ContractStatus.CONTRACT_REJECTED.toString()) ? "Reject" : "Decline");
    }
  }
  
  public void setReasonLabel(String reason){
    reasonLabel.setValue(reason);
  }
  
  public ContractStatus getContractStatus(){
    if(cancelLabel.getValue().equals("CONTRACT_DECLINED"))
      return ContractStatus.CONTRACT_DECLINED;
    else if (cancelLabel.getValue().equals("CONTRACT_REJECTED"))
      return ContractStatus.CONTRACT_REJECTED;
    return null;
  }
}
