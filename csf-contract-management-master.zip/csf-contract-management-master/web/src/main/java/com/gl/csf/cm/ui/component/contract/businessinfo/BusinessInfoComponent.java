package com.gl.csf.cm.ui.component.contract.businessinfo;

import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.config.storage.MinioConfiguration;
import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.lessee.business.*;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.service.DocumentService;
import com.gl.csf.cm.ui.util.StringToMonetaryConverter;
import com.gl.csf.cm.uw.integration.model.common.DocumentDescriptor;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;
import com.vaadin.ui.themes.ValoTheme;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.*;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/7/2017.
 */
@Listener
@SpringComponent
@UIScope
public class BusinessInfoComponent extends BusinessInfoComponentDesign {
  private final SessionScopeBus bus;
  private final Binder<LesseeBusinessEntry> lesseeBusinessEntryBinder = new BeanValidationBinder<>(LesseeBusinessEntry.class);
  private final LesseeBusinessRepository lesseeBusinessRepository;
  private final Binder<FinancialStatementEntry> financialStatementEntryBinder = new BeanValidationBinder<>(FinancialStatementEntry.class);
  private final FinancialStatementRepository financialStatementRepository;
  private final Accordion branchAccordion = new Accordion();
  private final List<MainBranch> possibleMainBranches = new ArrayList<>();
  private final BranchRepository branchRepository;
  private final FinancialDocumentRepository financialDocumentRepository;
  private final DocumentService documentService;
  private String contractId;
  private Set<String> imageType = new HashSet<>(Arrays.asList("JPG", "PNG", "JPEG"));
  private Logger logger = LoggerFactory.getLogger(BusinessInfoComponent.class);
  private final MinioConfiguration minioConfiguration;

  @Inject
  public BusinessInfoComponent(SessionScopeBus bus, LesseeBusinessRepository lesseeBusinessRepository, FinancialStatementRepository financialStatementRepository,
                               BranchRepository branchRepository, FinancialDocumentRepository financialDocumentRepository, DocumentService documentService, MinioConfiguration minioConfiguration){
    this.bus = bus;
    this.lesseeBusinessRepository = lesseeBusinessRepository;
    this.financialStatementRepository = financialStatementRepository;
    this.branchRepository = branchRepository;
    this.financialDocumentRepository = financialDocumentRepository;
    this.documentService = documentService;
    this.minioConfiguration = minioConfiguration;
    // TODO: Temporary disable the graph
    //saleChart.addComponent(new SalesHistoryLineGraph());
    initializeBinder(lesseeBusinessEntryBinder, financialStatementEntryBinder);

    gridFinancialDocument.addComponentColumn(financialDocument->{
      CssLayout cssLayout = new CssLayout();
      String fileExtension = FilenameUtils.getExtension(financialDocument.getAttachment());
      if (imageType.contains(fileExtension.toUpperCase())) {
        Button previewButton = new Button();
        previewButton.setIcon(VaadinIcons.EYE);
        previewButton.setStyleName(ValoTheme.BUTTON_LINK);
        previewButton.addClickListener(event -> {
          try {
            StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
              try {
                return this.documentService.downloadDocument(new DocumentDescriptor(financialDocument.getDocumentDescriptor().getDocumentId(), this.minioConfiguration.getEndpoint(),
                        financialDocument.getDocumentDescriptor().getBucketId()));
              } catch (Exception e) {
                logger.error("error when download financial document", e);
                throw new RuntimeException(e);
              }
            }, financialDocument.getAttachment());
            Window window = new Window();
            window.center();
            window.setResizable(true);
            window.setContent(new Image(financialDocument.getAttachment(), streamResource));
            UI.getCurrent().addWindow(window);
          } catch (Exception e) {
            logger.error("error when download financial document", e);
            throw new RuntimeException(e);
          }
        });
        cssLayout.addComponent(previewButton);
      }

      Button downloadButton = new Button("");
      downloadButton.setIcon(VaadinIcons.DOWNLOAD);
      downloadButton.setStyleName(ValoTheme.BUTTON_LINK);
      try {
        StreamResource streamResource = new StreamResource((StreamResource.StreamSource) () -> {
          try {
            return documentService.downloadDocument(new DocumentDescriptor(financialDocument.getDocumentDescriptor().getDocumentId(),
                    minioConfiguration.getEndpoint(), financialDocument.getDocumentDescriptor().getBucketId()));
          } catch (Exception e) {
            logger.error("error when download financial document", e);
            throw new RuntimeException(e);
          }
        }, financialDocument.getAttachment());

        FileDownloader fileDownloader = new FileDownloader(streamResource);
        fileDownloader.extend(downloadButton);
      } catch (Exception e) {
        logger.error("error when download financial document", e);
        throw new RuntimeException(e);
      }
      cssLayout.addComponent(downloadButton);

      return cssLayout;
    });
    Grid.Column columnDueDate = gridFinancialDocument.getColumn("dateTime");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  private void initializeBinder(Binder<LesseeBusinessEntry> businessEntryBinder, Binder<FinancialStatementEntry> financialStatementEntryBinder){
    businessEntryBinder.forField(businessNameTextField).bind("businessName");
    businessEntryBinder.forField(mainBranchComboBox).bind("mainBranch");

    financialStatementEntryBinder.forField(totalBranchTextField)
            .withConverter(new StringToIntegerConverter("Must be integer")).bind("totalBranch");
    financialStatementEntryBinder.forField(revenueTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("revenue");
    financialStatementEntryBinder.forField(expenseTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("expense");
    financialStatementEntryBinder.forField(marginTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("margin");
    financialStatementEntryBinder.forField(numberOfStaffTextField)
            .withConverter(new StringToIntegerConverter("Must be integer")).bind("numberOfStaff");
    financialStatementEntryBinder.forField(staffExpenseTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("staffExpense");
    financialStatementEntryBinder.forField(netProfitTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("netProfit");
    financialStatementEntryBinder.forField(totalRentAmountTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("totalRent");
    financialStatementEntryBinder.forField(otherExpenseTextfield)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("otherExpense");
    financialStatementEntryBinder.forField(financialRatioTextfield)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("financialRatio");
    financialStatementEntryBinder.forField(financialRatioLowTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("financialRatioLow");

    branchVerticlLayout.addComponent(branchAccordion);
  }

  private void setGridFinancialDataProvider(String contractId) {
    gridFinancialDocument.setDataProvider(new AbstractBackEndDataProvider<FinancialDocumentEntry, String>() {
      @Override
      protected Stream<FinancialDocumentEntry> fetchFromBackEnd(Query<FinancialDocumentEntry, String > query) {
        return financialDocumentRepository.findAllByContractId(contractId).parallelStream();
      }

      @Override
      protected int sizeInBackEnd(Query<FinancialDocumentEntry, String> query) {
        return financialDocumentRepository.countByContractId(contractId);
      }
    });
  }

  private void fetchData(){
    branchAccordion.removeAllComponents();
    possibleMainBranches.clear();
    for (BranchEntry branch : branchRepository.findAllByContractId(contractId)) {
      possibleMainBranches.add(new MainBranch(branch.getId(), branch.getBranchName()));
      BranchDetailComponent branchDetailComponent = new BranchDetailComponent();
      branchDetailComponent.bind(branch);
      branchAccordion.addTab(branchDetailComponent).setCaption(branch.getBranchName());
      
    }
    mainBranchComboBox.setItems(possibleMainBranches);

    lesseeBusinessEntryBinder.setBean(lesseeBusinessRepository.findOne(contractId));
    FinancialStatementEntry financialStatementEntry = financialStatementRepository.findOne(contractId);
    financialStatementEntryBinder.setBean(financialStatementEntry);
    setGridFinancialDataProvider(contractId);
  }

  @Handler
  private void handle(ContractSelectedEvent event){
    this.contractId = event.getContractId();
    fetchData();
  }
}
