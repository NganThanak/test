package com.gl.csf.cm.ui.component.contract.loaninformation;

import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;
import com.vaadin.ui.components.grid.ItemClickListener;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 11/22/2017.
 */
@Listener
@SpringComponent
@UIScope
public class LoanInfoComponent extends LoanInfoComponentDesign {

  private final SessionScopeBus bus;

  @Inject
  public LoanInfoComponent(SessionScopeBus bus) {
    this.bus = bus;

    loanInformationComponent.setVisible(true);
    loanInformationDetailComponent.setVisible(false);

    loanInformationComponent.loanInformationGrid.addItemClickListener((ItemClickListener<LoanProductEntry>) itemClick -> {
      if(itemClick.getMouseEventDetails().isDoubleClick()){
        loanInformationComponent.setVisible(false);
        loanInformationDetailComponent.setVisible(true);
        loanInformationDetailComponent.setLoanProduct(itemClick.getItem());
      }
    });
  
    Grid.Column columnDueDate = loanInformationComponent.loanInformationGrid.getColumn("initiatedDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());

    loanInformationDetailComponent.backToListButton.addClickListener((Button.ClickListener) clickEvent -> {
      loanInformationComponent.setVisible(true);
      loanInformationDetailComponent.setVisible(false);
    });
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  @Handler
  private void handle(ContractSelectedEvent event){
    loanInformationComponent.setVisible(true);
    loanInformationDetailComponent.setVisible(false);
  }
}
