package com.gl.csf.cm.ui.util;

import java.util.Arrays;
import java.util.List;

import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationEntry;
import com.gl.csf.cm.query.contract.accounting.PortfolioPeriodInterestRealizationEntry;

public class ProductTypeUtil {
	
	public static List<ProductType> getBySMERole() {
		return Arrays.asList(ProductType.STANDARD_LOAN, ProductType.REVOLVING_LOAN);
	}

	public static List<ProductType> getByStaffLoanRole() {
		return Arrays.asList(ProductType.STAFF_LOAN);
	}

	public static boolean isSMEProduct(PortfolioPeriodInterestRealizationEntry entry) {
		return Arrays.asList(ProductType.STANDARD_LOAN, ProductType.REVOLVING_LOAN).contains(entry.getLoanType());
	}
	
	public static boolean isStaffLoanProduct(PortfolioPeriodInterestRealizationEntry entry) {
		return ProductType.STAFF_LOAN.equals(entry.getLoanType());
	}
	
	public static boolean isSMEProduct(ContractPeriodInterestRealizationEntry entry) {
		return Arrays.asList(ProductType.STANDARD_LOAN, ProductType.REVOLVING_LOAN).contains(entry.getProductType());
	}
	
	public static boolean isStaffLoanProduct(ContractPeriodInterestRealizationEntry entry) {
		return ProductType.STAFF_LOAN.equals(entry.getProductType());
	}
}