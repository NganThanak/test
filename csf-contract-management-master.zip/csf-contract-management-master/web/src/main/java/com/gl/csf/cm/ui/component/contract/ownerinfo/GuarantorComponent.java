package com.gl.csf.cm.ui.component.contract.ownerinfo;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/7/2017.
 */
@SpringComponent
@UIScope
public class GuarantorComponent extends GuarantorComponentDesign {

  public GuarantorComponent(){
    buttonSave.setVisible(false);
    buttonEdit.setVisible(false);
    enableAndDisableComponent(false);
    buttonSaveBusinessInfo.setVisible(false);
    enableAndDisableBusinessInfoComponent(false);

    buttonEdit.addClickListener(e->{
      if(buttonEdit.getCaption().equalsIgnoreCase("Edit")){
        buttonSave.setVisible(true);
        buttonEdit.setCaption("Cancel");
        enableAndDisableComponent(true);
      }else if(buttonEdit.getCaption().equalsIgnoreCase("Cancel")) {
        buttonEdit.setCaption("Edit");
        buttonSave.setVisible(false);
        enableAndDisableComponent(false);
      }
    });

    buttonSave.addClickListener(event -> {
      buttonSave.setVisible(false);
      buttonEdit.setCaption("Edit");
      enableAndDisableComponent(false);
    });

    buttonEditBusinessInfo.setVisible(false);
    buttonEditBusinessInfo.addClickListener(e->{
      if(buttonEditBusinessInfo.getCaption().equalsIgnoreCase("Edit")){
        buttonSaveBusinessInfo.setVisible(true);
        buttonEditBusinessInfo.setCaption("Cancel");
        enableAndDisableBusinessInfoComponent(true);
      }else if(buttonEditBusinessInfo.getCaption().equalsIgnoreCase("Cancel")) {
        buttonEditBusinessInfo.setCaption("Edit");
        buttonSaveBusinessInfo.setVisible(false);
        enableAndDisableBusinessInfoComponent(false);
      }
    });

    buttonSaveBusinessInfo.addClickListener(event -> {
      buttonSaveBusinessInfo.setVisible(false);
      buttonEditBusinessInfo.setCaption("Edit");
      enableAndDisableBusinessInfoComponent(false);
    });
  }

  private void enableAndDisableComponent(boolean value){
    textFieldNRCID.setEnabled(value);
    textFieldFullName.setEnabled(value);
    comboBoxGender.setEnabled(value);
    dateFieldDOB.setEnabled(value);
    textFieldPhoneNumber.setEnabled(value);
    textFieldEmail.setEnabled(value);
    textFieldOwnerAddress.setEnabled(value);
    comboBoxDistrict.setEnabled(value);
    comboBoxTownship.setEnabled(value);
    comboBoxState.setEnabled(value);
    comboBoxRelationship.setEnabled(value);
  }

  private void enableAndDisableBusinessInfoComponent(boolean value){
    textFieldOwnerAddressBusiness.setEnabled(value);
    comboBoxDistrictBusiness.setEnabled(value);
    comboBoxTownshipBusiness.setEnabled(value);
    comboBoxStateBusiness.setEnabled(value);
    textFieldPhoneNumberBusiness.setEnabled(value);
  }
}
