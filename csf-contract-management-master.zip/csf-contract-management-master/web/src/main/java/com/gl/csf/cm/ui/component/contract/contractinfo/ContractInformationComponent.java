package com.gl.csf.cm.ui.component.contract.contractinfo;

import com.gl.csf.cm.ui.permission.Role;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

/**
 * Created by p.ly on 11/8/2017.
 */
@SpringComponent
@UIScope
public class ContractInformationComponent extends ContractInformationComponentDesign{

  public ContractInformationComponent(){

  }

}
