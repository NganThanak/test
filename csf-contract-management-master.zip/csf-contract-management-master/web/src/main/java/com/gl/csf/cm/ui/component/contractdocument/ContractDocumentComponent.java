package com.gl.csf.cm.ui.component.contractdocument;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

/**
 * Created by p.ly on 11/8/2017.
 */
@SpringComponent
@UIScope
public class ContractDocumentComponent extends ContractDocumentComponentDesign{

}
