package com.gl.csf.cm.ui.report;

import com.gl.csf.cm.query.contract.accounting.ContractInterestRealizationAttributeEntry;
import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationEntry;
import com.gl.csf.cm.ui.util.excel.ContractInterestRealizationAttributeExcelBuilder;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import java.util.List;

/**
 * Created by p.ly on 11/21/2017.
 */
@SpringComponent
@UIScope
public class InterestReportByContractItemComponent extends InterestReportByContractItemComponentDesign{

  private static final String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private static final String PAYMENT_SIMULATION_PATH = BASE_PATH + "/report/contract-interest-realization-attribute/download";

  public InterestReportByContractItemComponent(String contractNumber, List<ContractPeriodInterestRealizationEntry> interestRealizationEntries, ContractInterestRealizationAttributeEntry attributeEntry) {
    contractNumberTextField.setValue(contractNumber);

    downloadButton.addClickListener(e->{
      ContractInterestRealizationAttributeExcelBuilder.setInterestRealizationEntries(interestRealizationEntries);
      ContractInterestRealizationAttributeExcelBuilder.setAttributeEntry(attributeEntry);
      Page.getCurrent().open(PAYMENT_SIMULATION_PATH, "_blank");
    });
  }
}
