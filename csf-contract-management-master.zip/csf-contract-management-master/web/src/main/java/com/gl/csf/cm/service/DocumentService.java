package com.gl.csf.cm.service;

import com.gl.csf.cm.config.storage.MinioConfiguration;
import com.gl.csf.cm.uw.integration.model.common.DocumentDescriptor;
import io.minio.MinioClient;
import io.minio.errors.*;
import org.springframework.stereotype.Component;
import org.xmlpull.v1.XmlPullParserException;

import javax.inject.Inject;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by jerome on 9/18/17.
 */
@Component
public class DocumentService {

  private final MinioClient minioClient;

  @Inject
  public DocumentService(MinioConfiguration minioConfiguration) throws Exception {

    this.minioClient = new MinioClient(minioConfiguration.getEndpoint(),
            minioConfiguration.getAccessKey(), minioConfiguration.getSecretKey());

  }

  public DocumentDescriptor uploadDocument(String fileName, String applicationId, InputStream inputStream,

                                           String contentType) throws IOException, InvalidKeyException, NoSuchAlgorithmException,
          InsufficientDataException, InvalidArgumentException, InternalException, NoResponseException, InvalidBucketNameException,
          XmlPullParserException, ErrorResponseException, RegionConflictException {

    Objects.requireNonNull(applicationId);

    if (!minioClient.bucketExists(applicationId)) {
      minioClient.makeBucket(applicationId);
    }

    String[] extension = fileName.split("\\.");


    final String objectName = UUID.randomUUID().toString() + "." + extension[1];
    minioClient.putObject(applicationId,
            objectName,
            inputStream, inputStream.available(), contentType);
    return new DocumentDescriptor(objectName, minioClient.getObjectUrl(applicationId, objectName),
            applicationId);
  }

  public InputStream downloadDocument(DocumentDescriptor descriptor)
          throws Exception {
    return minioClient.getObject(descriptor.getApplicationId(), descriptor.getDocumentId());
  }

  public void deleteDocument(DocumentDescriptor documentDescriptor) throws Exception {
    minioClient
            .removeObject(documentDescriptor.getApplicationId(), documentDescriptor.getDocumentId());
  }

  public Stream<DocumentDescriptor> listDocuments(String applicationId) throws Exception {

    return StreamSupport.stream(minioClient.listObjects(applicationId).spliterator(), false)
            .map(itemResult -> {
              try {
                return new DocumentDescriptor(
                        itemResult.get().objectName(),
                        minioClient.getObjectUrl(applicationId, itemResult.get().objectName()),
                        applicationId);
              } catch (Exception e) {
                throw new RuntimeException(e);
              }
            });

  }

  void deleteAllDocuments(String applicationId, boolean keepBucket) throws Exception {

    if (!minioClient.bucketExists(applicationId)) {
      return;
    }
    minioClient.listObjects(applicationId).forEach(itemResult -> {
      try {
        minioClient.removeObject(applicationId, itemResult.get().objectName());
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    });
    if (!keepBucket) {
      minioClient.removeBucket(applicationId);
    }
  }
}
