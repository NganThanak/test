package com.gl.csf.cm.ui.viewdeclaration;

/**
 * Created by p.ly on 11/8/2017.
 */
public class UIScopeContractViews {

  public static final String CONTRACT_LIST = "";
  public static final String CONTRACT ="contract";
  public static final String SALES_HISTORY = "saleshistory";
  public static final String PAYMENT = "paymentinformation";
  public static final String LOAN_INFORMATION_LIST = "loaninformations";
  public static final String LOAN_INFORMATION_DETAIL = "loaninformationdetail";
  public static final String REPORT = "report";
  public static final String STAFF_LOAN = "staffloan";

}
