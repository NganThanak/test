package com.gl.csf.cm.ui.common.contract.applicationsummary;

import com.gl.csf.cm.api.contract.command.*;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.exception.InvalidContractDayException;
import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.contractcancel.ContractCancelEntry;
import com.gl.csf.cm.query.contract.contractcancel.ContractCancelRepository;
import com.gl.csf.cm.query.contract.contractheader.ContractHeaderEntry;
import com.gl.csf.cm.query.contract.contractheader.ContractHeaderRepository;
import com.gl.csf.cm.query.contract.contractsummary.ContractStaffLoanSummaryEntry;
import com.gl.csf.cm.query.contract.contractsummary.ContractStaffLoanSummaryRepository;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryEntry;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryRepository;
import com.gl.csf.cm.service.ContractService;
import com.gl.csf.cm.ui.common.CancelContractDialog;
import com.gl.csf.cm.ui.common.ConfirmationComponent;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.ui.component.contract.activation.ActivateContractComponentListener;
import com.gl.csf.cm.ui.component.contract.activation.ActivateRevolvingLoanComponent;
import com.gl.csf.cm.ui.component.contract.activation.ActivateStandardLoanComponent;
import com.gl.csf.cm.ui.permission.Role;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.vaadin.spring.security.VaadinSecurity;
import javax.inject.Inject;
import java.util.Optional;

/**
 * Created by p.ly on 11/8/2017.
 */
@Listener
@SpringComponent
@UIScope
public class ContractHeaderComponent extends ContractHeaderComponentDesign {

  private final SessionScopeBus bus;
  private final ContractHeaderRepository contractHeaderRepository;
  private final ContractSummaryRepository contractSummaryRepository;
  private final ContractCancelRepository contractCancelRepository;
  private final ContractStaffLoanSummaryRepository contractStaffLoanSummaryRepository;
  private final ContractService contractService;
  private final VaadinSecurity vaadinSecurity;
  private String contractId;
  private final static String FULL_NAME = "Full Name";
  private final static String BUSINESS_NAME = "Business Name";
  private static String PREFIX_CONTRACT_No = "";
  @Inject
  public ContractHeaderComponent(SessionScopeBus bus, ContractHeaderRepository contractHeaderRepository,
                                 CommandGateway commandGateway, ContractSummaryRepository contractSummaryRepository,
                                 ContractCancelRepository contractCancelRepository, ContractStaffLoanSummaryRepository contractStaffLoanSummaryRepository,
                                 ContractService contractService, VaadinSecurity vaadinSecurity){
    this.bus = bus;
    this.contractHeaderRepository = contractHeaderRepository;
    this.contractSummaryRepository = contractSummaryRepository;
    this.contractCancelRepository = contractCancelRepository;
    this.contractStaffLoanSummaryRepository = contractStaffLoanSummaryRepository;
    this.contractService = contractService;
    this.vaadinSecurity = vaadinSecurity;

    buttonActivate.addClickListener(e-> {
      Window popupWindow;
      // check permission for each user
      if (PREFIX_CONTRACT_No.equalsIgnoreCase("SL")) {
        ContractStaffLoanSummaryEntry contractStaffLoanSummaryEntry = contractStaffLoanSummaryRepository.findOne(contractId);

        ActivateStandardLoanComponent activateStandardLoanComponent = new ActivateStandardLoanComponent();
        popupWindow = activateStandardLoanComponent.displayConfiguration();
        activateStandardLoanComponent.setListener(new ActivateContractComponentListener() {
          @Override
          public void onClosed() {
            popupWindow.close();
          }

          @Override
          public void onCancelButtonClicked() {
            popupWindow.close();
          }

          @Override
          public void onConfirmButtonClicked() {
            try {
              ActivateStaffLoanContractCommand activateStaffLoanContractCommand = new ActivateStaffLoanContractCommand(contractStaffLoanSummaryEntry.getId(), activateStandardLoanComponent.getContractDate());
              ContractHeaderComponent.this.contractService.activateStaffLoanContract(activateStaffLoanContractCommand);
              fetchData();
              popupWindow.close();
            } catch (InvalidContractDayException | RuntimeException e) {
              Notification.show("Activating contract", e.getMessage(), Notification.Type.ERROR_MESSAGE);
            }
          }
        });
        popupWindow.setContent(activateStandardLoanComponent);

      } else {
        ContractSummaryEntry contractSummaryEntry = contractSummaryRepository.findOne(contractId);
        if(contractSummaryEntry.getLoanType().equals(ProductType.STANDARD_LOAN)||contractSummaryEntry.getLoanType().equals(ProductType.STANDARD_LOAN)){
          ActivateStandardLoanComponent activateStandardLoanComponent = new ActivateStandardLoanComponent();
          popupWindow = activateStandardLoanComponent.displayConfiguration();
          activateStandardLoanComponent.setListener(new ActivateContractComponentListener() {
            @Override
            public void onClosed() {
              popupWindow.close();
            }

            @Override
            public void onCancelButtonClicked() {
              popupWindow.close();
            }

            @Override
            public void onConfirmButtonClicked() {
              try {
                ActivateStandardLoanContractCommand activateStandardLoanContractCommand = new ActivateStandardLoanContractCommand(contractSummaryEntry.getId(), activateStandardLoanComponent.getContractDate());
                ContractHeaderComponent.this.contractService.activateStandardLoanContract(activateStandardLoanContractCommand);
                fetchData();
                popupWindow.close();
              } catch (InvalidContractDayException | RuntimeException e) {
                Notification.show("Activating contract", e.getMessage(), Notification.Type.ERROR_MESSAGE);
              }
            }
          });

          popupWindow.setContent(activateStandardLoanComponent);
        }else {
          ActivateRevolvingLoanComponent activateRevolvingLoanComponent = new ActivateRevolvingLoanComponent();
          popupWindow = activateRevolvingLoanComponent.displayConfiguration();

          activateRevolvingLoanComponent.setListener(new ActivateContractComponentListener() {
            @Override
            public void onClosed() {
              popupWindow.close();
            }

            @Override
            public void onCancelButtonClicked() {
              popupWindow.close();
            }

            @Override
            public void onConfirmButtonClicked() {
              ActivateRevolvingLoanContractCommand activateRevolvingLoanContractCommand = new ActivateRevolvingLoanContractCommand(contractSummaryEntry.getId(),
                activateRevolvingLoanComponent.getContractDate(), activateRevolvingLoanComponent.getFirstWithdrawalAmount());
              try {
                contractService.activateRevolvingLoanContract(activateRevolvingLoanContractCommand);
                fetchData();
                popupWindow.close();
              } catch (InvalidContractDayException e) {
                Notification.show("Activating Contract", e.getMessage(), Notification.Type.ERROR_MESSAGE);
              }
            }
          });
          popupWindow.setContent(activateRevolvingLoanComponent);
        }
      }
      UI.getCurrent().addWindow(popupWindow);
    });
  
    cancelContractButton.addClickListener(e -> {
      // check permission for each user
      if (PREFIX_CONTRACT_No.equalsIgnoreCase("SL")) {
        ContractStaffLoanSummaryEntry contractStaffLoanSummaryEntry = contractStaffLoanSummaryRepository.findOne(contractId);
          if (contractStaffLoanSummaryEntry.getContractStatus().equals(ContractStatus.CONTRACT_PENDING)){
            final ConfirmationComponent confirmationComponent = new ConfirmationComponent();
            Window window = confirmationComponent.displayConfiguration();
            confirmationComponent.setListener(new ConfirmationComponent.ConfirmationComponentListener() {
              @Override
              public void onClosed() {
                window.close();
              }
    
              @Override
              public void onNoButtonClicked() {
                window.close();
              }
    
              @Override
              public void onYesButtonClicked(){
                try {
                  if(vaadinSecurity.hasAuthority(Role.SL_MANAGER))
                    commandGateway.sendAndWait(new CancelStaffLoanContractCommand(contractId, confirmationComponent.getCancelReason(), confirmationComponent.getContractStatus()));
                  else
                    commandGateway.sendAndWait(new CancelPendingStaffLoanContractCommand(contractId, confirmationComponent.getCancelReason(), confirmationComponent.getContractStatus()));
                  fetchData();
                  window.close();
                } catch (IllegalStateException e1) {
                  Notification.show("Error can't cancel this contract", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
                }
              }
            });
            window.setContent(confirmationComponent);
            UI.getCurrent().addWindow(window);
          }
        else if(vaadinSecurity.hasAuthority(Role.SL_MANAGER) && contractStaffLoanSummaryEntry.getContractStatus().equals(ContractStatus.PENDING_CANCEL)){
          final CancelContractDialog confirmationComponent = new CancelContractDialog();
          Optional<ContractCancelEntry> contractCancelEntry = contractCancelRepository.findByContractID(contractId);
          if(contractCancelEntry.isPresent()){
            confirmationComponent.setReasonLabel(contractCancelEntry.get().getCancelledReasonStaff());
            confirmationComponent.setCancelTypeLabel(contractCancelEntry.get().getContractStatus().toString());
          }
          Window window = confirmationComponent.displayConfiguration();
          confirmationComponent.setListener(new CancelContractDialog.ConfirmationComponentListener() {
            @Override
            public void onClosed() {
              window.close();
            }
      
            @Override
            public void onRejectButtonClicked() {
              try {
                commandGateway.sendAndWait(new RejectCancellationStaffLoanContractCommand(contractId, ContractStatus.CONTRACT_PENDING));
                fetchData();
                window.close();
              } catch (IllegalStateException e1) {
                Notification.show("Error can't cancel this contract", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
              }
            }
      
            @Override
            public void onCancellationButtonClicked() {
              try {
                commandGateway.sendAndWait(new CancelStaffLoanContractCommand(contractId, confirmationComponent.getCancelReason(), contractCancelEntry.get().getContractStatus()));
                fetchData();
                window.close();
              } catch (IllegalStateException e1) {
                Notification.show("Error can't cancel this contract", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
              }
            }
          });
          window.setContent(confirmationComponent);
          UI.getCurrent().addWindow(window);
        }
      } else{ // cancel contract of SME Loan
        ContractSummaryEntry contractSummaryEntry = contractSummaryRepository.findOne(contractId);
        if (contractSummaryEntry.getContractStatus().equals(ContractStatus.CONTRACT_PENDING)){
          final ConfirmationComponent confirmationComponent = new ConfirmationComponent();
          Window window = confirmationComponent.displayConfiguration();
          confirmationComponent.setListener(new ConfirmationComponent.ConfirmationComponentListener() {
            @Override
            public void onClosed() {
              window.close();
            }

            @Override
            public void onNoButtonClicked() {
              window.close();
            }

            @Override
            public void onYesButtonClicked() {
              try {
                if(vaadinSecurity.hasAuthority(Role.OPERATION_MANAGER))
                  commandGateway.sendAndWait(new CancelContractCommand(contractId, confirmationComponent.getCancelReason(), confirmationComponent.getContractStatus()));
                else
                  commandGateway.sendAndWait(new CancelPendingContractCommand(contractId, confirmationComponent.getCancelReason(), confirmationComponent.getContractStatus()));
                fetchData();
                window.close();
              } catch (IllegalStateException e1) {
                Notification.show("Error can't cancel this contract", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
              }
            }
          });
          window.setContent(confirmationComponent);
          UI.getCurrent().addWindow(window);
        }
        else if(vaadinSecurity.hasAuthority(Role.OPERATION_MANAGER) && contractSummaryEntry.getContractStatus().equals(ContractStatus.PENDING_CANCEL)){
          final CancelContractDialog confirmationComponent = new CancelContractDialog();
          Optional<ContractCancelEntry> contractCancelEntry = contractCancelRepository.findByContractID(contractId);
          if(contractCancelEntry.isPresent()){
            confirmationComponent.setReasonLabel(contractCancelEntry.get().getCancelledReasonStaff());
            confirmationComponent.setCancelTypeLabel(contractCancelEntry.get().getContractStatus().toString());
          }
          Window window = confirmationComponent.displayConfiguration();
          confirmationComponent.setListener(new CancelContractDialog.ConfirmationComponentListener() {
            @Override
            public void onClosed() {
              window.close();
            }

            @Override
            public void onRejectButtonClicked() {
              try {
                commandGateway.sendAndWait(new RejectCancellationContractCommand(contractId, ContractStatus.CONTRACT_PENDING));
                fetchData();
                window.close();
              } catch (IllegalStateException e1) {
                Notification.show("Error can't cancel this contract", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
              }
            }

            @Override
            public void onCancellationButtonClicked() {
              try {
                commandGateway.sendAndWait(new CancelContractCommand(contractId, confirmationComponent.getCancelReason(), contractCancelEntry.get().getContractStatus()));
                fetchData();
                window.close();
              } catch (IllegalStateException e1) {
                Notification.show("Error can't cancel this contract", e1.getLocalizedMessage(), Notification.Type.ERROR_MESSAGE);
              }
            }
          });
          window.setContent(confirmationComponent);
          UI.getCurrent().addWindow(window);
        }
      }
    });
  }
  
  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  private void fetchData(){
    ContractHeaderEntry contractHeaderEntry = contractHeaderRepository.findOne(contractId);
    contractNumberLabel.setValue(contractHeaderEntry.getContractNumber());
    contractDateLabel.setValue(contractHeaderEntry.getContractDate() != null ? LocalDateTimeFormat.formatLocalDate(contractHeaderEntry.getContractDate()) : "-");
    contractStatusLabel.setValue(contractHeaderEntry.getContractStatus() != null ? contractHeaderEntry.getContractStatus().toString():"-");
    loanAmountLabel.setValue( CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(contractHeaderEntry.getLoanAmount()).toString());
    termLabel.setValue(contractHeaderEntry.getTerm().toString());
    businessNameLabel.setValue(contractHeaderEntry.getBusinessName());
    contractStatusLabel.setValue(contractHeaderEntry.getContractStatus() != null ? contractHeaderEntry.getContractStatus().toString() : "-");
    if(contractHeaderEntry.getContractStatus().equals(ContractStatus.CONTRACT_PENDING)){
      cancelContractButton.setEnabled(true);
      buttonActivate.setEnabled(true);
    }else if(contractHeaderEntry.getContractStatus().equals(ContractStatus.PENDING_CANCEL) && (vaadinSecurity.hasAuthority(Role.OPERATION_MANAGER) || vaadinSecurity.hasAuthority(Role.SL_MANAGER))){
      cancelContractButton.setEnabled(true);
      buttonActivate.setEnabled(false);
    }
    else{
      cancelContractButton.setEnabled(false);
      buttonActivate.setEnabled(false);
    }
  }

  @Handler
  public void handle(ContractSelectedEvent event){
    this.contractId = event.getContractId();
    //split contract no to know which is SME and Staff Loan
    String[] prefix = event.getContractNo().split("-");
    PREFIX_CONTRACT_No = prefix[0];

    if(PREFIX_CONTRACT_No.equalsIgnoreCase("SL"))
      labelName.setValue(FULL_NAME);
    else
      labelName.setValue(BUSINESS_NAME);

    fetchData();
  }
}
