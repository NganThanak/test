package com.gl.csf.cm;

import com.gl.csf.cm.uw.integration.ApplicationApprovalMessagingChannel;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;

@SpringBootApplication
@EnableBinding(ApplicationApprovalMessagingChannel.class)
public class ContractManagementApplication {

  public static void main(String[] args) {
    SpringApplication.run(ContractManagementApplication.class, args);
  }
}
