package com.gl.csf.cm.ui.component.contract.activation;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/11/2017.
 */
public interface ActivateContractComponentListener {
  void onClosed();
  void onCancelButtonClicked();
  void onConfirmButtonClicked();
}
