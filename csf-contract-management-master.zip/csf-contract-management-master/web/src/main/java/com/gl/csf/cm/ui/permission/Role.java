package com.gl.csf.cm.ui.permission;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 11/15/2017.
 */
public class Role {
  public static final String OPERATION_STAFF = "ROLE_OPERATION_STAFF";
  public static final String OPERATION_MANAGER = "ROLE_OPERATION_MANAGER";
  public static final String ADMINISTRATOR = "ROLE_ADMINISTRATOR";
  public static final String CUSTOMER = "ROLE_CUSTOMER";
  public static final String SL_STAFF = "ROLE_SL_STAFF";
  public static final String SL_MANAGER = "ROLE_SL_MANAGER";
}
