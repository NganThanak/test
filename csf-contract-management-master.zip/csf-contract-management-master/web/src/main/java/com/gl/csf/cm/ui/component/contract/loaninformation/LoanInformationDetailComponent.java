package com.gl.csf.cm.ui.component.contract.loaninformation;

import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryEntry;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryRepository;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.gl.csf.cm.ui.util.StringToMonetaryConverter;
import com.gl.csf.cm.ui.util.excel.PaymentScheduleExcelBuilder;
import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToBigDecimalConverter;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/8/2017.
 */
@UIScope
@SpringComponent
public class LoanInformationDetailComponent extends LoanInformationDetailComponentDesign {
  private static final String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private static final String PAYMENT_SIMULATION_PATH = BASE_PATH + "/payment-simulation/download";
  private static final Set<Integer> prohibitedDates = new HashSet<>(Arrays.asList(29, 30, 31));
  private static ContractSummaryRepository contractSummaryRepository;

  private final Grid<Installment> paymentGrid = new Grid<>();
  private final Binder<LoanProductEntry> loanProductEntryBinder;

  public LoanInformationDetailComponent(ContractSummaryRepository contractSummaryRepository){
    this.contractSummaryRepository = contractSummaryRepository;
    loanProductEntryBinder = createUpdateProductInformationBinder();
    gridLayout.addComponent(paymentGrid);
    paymentGrid.setWidth(100, Unit.PERCENTAGE);

    buttonExportToExcel.addClickListener(clickEvent -> {
      PaymentScheduleExcelBuilder.setInstallment(generatePaymentSchedule(loanProductEntryBinder.getBean()));
      PaymentScheduleExcelBuilder.setLoanType(loanProductEntryBinder.getBean().getLoanType().getValue());
      PaymentScheduleExcelBuilder.setCustomer(loanProductEntryBinder.getBean().getId());
      Page.getCurrent().open(PAYMENT_SIMULATION_PATH, "_blank");
    });

    initPaymentGridColumn();
  }

  private static ListDataProvider<Installment> createInstallmentDataProvider(LoanProductEntry loanProductEntry) {
    return new ListDataProvider<>(generatePaymentSchedule(loanProductEntry));
  }

  private void initPaymentGridColumn(){
    paymentGrid.addColumn(Installment::getInstallmentNumber).setCaption("Period");
    paymentGrid.addColumn(installment -> installment.getAmount().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Installment");
    paymentGrid.addColumn(installment -> installment.getPrincipal().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Principal");
    paymentGrid.addColumn(installment -> installment.getInterest().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Interest");
    paymentGrid.addColumn(installment -> installment.getEndBalance().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Remaining Balance");
  }

  private Binder<LoanProductEntry> createUpdateProductInformationBinder() {
    Binder<LoanProductEntry> result = new BeanValidationBinder<>(LoanProductEntry.class);
    result.bind(textFieldID, "id");
    result.forField(comboBoxTerm).asRequired("Term").bind("term");
    result.forField(comboBoxLoanType).asRequired("Loan type").bind("loanType");
    result.forField(textFieldLoanAmount).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("loanAmount");

    result.forField(comboBoxPaymentFrequency).asRequired("Payment frequency").bind("paymentFrequency");
    result.forField(textFieldInterestRate).withConverter(new StringToBigDecimalConverter("Must be number")).bind("interestRate");
    result.forField(textAreaReasonForRequest).asRequired("Please put the reason").bind("reasonForRequest");
    return result;
  }

  void setLoanProduct(LoanProductEntry loanProduct){
    loanProductEntryBinder.setBean(loanProduct);
    paymentGrid.setDataProvider(createInstallmentDataProvider(loanProductEntryBinder.getBean()));
  }

  private static List<Installment> generatePaymentSchedule(LoanProductEntry productInformation){
    if(productInformation.getLoanAmount() == null || productInformation.getTerm() == null || productInformation.getPaymentFrequency() == null || productInformation.getInterestRate() == null)
      return new ArrayList<>();
    ContractSummaryEntry contractSummaryEntry = contractSummaryRepository.findOne(productInformation.getContractId());
    
    LocalDate dueDate = LocalDate.now();
    if(contractSummaryEntry.getDueDate() == null) {
      if (prohibitedDates.contains(LocalDate.now().getDayOfMonth()))
        dueDate = LocalDate.now().plusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
    }else {
      dueDate = contractSummaryEntry.getDueDate();
    }
    
    LoanParameter param = LoanParameterBuilder.createBuilder().numberOfCompoundingPeriods(productInformation.getPaymentFrequency().getValue())
      .loanAmount(productInformation.getLoanAmount())
      .loanTerm(productInformation.getTerm().doubleValue() / 12.0)
      .nominalInterestRate((productInformation.getInterestRate().doubleValue() * 12) / 100)
      .dueDate(dueDate)
      .scale(10)
      .build();

    return new SimpleAmortization().generatePaymentSchedule(param);
  }
}
