package com.gl.csf.cm.ui.component.contract.loaninformation;

import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.gl.csf.cm.query.contract.product.LoanProductRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;

import javax.inject.Inject;
import java.util.stream.Stream;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/7/2017.
 */
@Listener
@SpringComponent
@UIScope
public class LoanInformationComponent extends LoanInformationComponentDesign{

  private final SessionScopeBus bus;
  private final ConfigurableFilterDataProvider<LoanProductEntry, Void, String> configurableFilterDataProvider;

  @Inject
  public LoanInformationComponent(SessionScopeBus bus, LoanProductRepository repository) {
    this.bus = bus;

    configurableFilterDataProvider = (new AbstractBackEndDataProvider<LoanProductEntry, String>() {
      @Override
      protected Stream<LoanProductEntry> fetchFromBackEnd(Query<LoanProductEntry, String> query) {
        if(query.getFilter().isPresent()){
          return repository.findAllByContractId(query.getFilter().get()).parallelStream();
        } else {
          return Stream.empty();
        }
      }

      @Override
      protected int sizeInBackEnd(Query<LoanProductEntry, String> query) {
        if(query.getFilter().isPresent()){
          return repository.countAllByContractId(query.getFilter().get());
        } else {
          return 0;
        }
      }
    }).withConfigurableFilter();
    loanInformationGrid.setDataProvider(configurableFilterDataProvider);
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  @Handler
  private void handle(ContractSelectedEvent event){
    configurableFilterDataProvider.setFilter(event.getContractId());
  }
}
