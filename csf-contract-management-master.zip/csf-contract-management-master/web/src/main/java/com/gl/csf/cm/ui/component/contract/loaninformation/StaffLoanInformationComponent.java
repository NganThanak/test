package com.gl.csf.cm.ui.component.contract.loaninformation;

import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.gl.csf.cm.query.contract.product.StaffLoanProductEntry;
import com.gl.csf.cm.query.contract.product.StaffLoanProductRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;

import javax.inject.Inject;
import java.util.stream.Stream;

/**
 * Created by p.ly on 1/24/2018.
 */
@SpringComponent
@UIScope
public class StaffLoanInformationComponent extends StaffLoanInformationComponentDesign{

  private String contractId;
  private final ConfigurableFilterDataProvider<StaffLoanProductEntry, Void, String> configurableFilterDataProvider;
  private final StaffLoanProductRepository repository;

  @Inject
  public StaffLoanInformationComponent(StaffLoanProductRepository repository) {

    this.repository = repository;
    // init staff loan information grid that filter by contract id
    configurableFilterDataProvider = (new AbstractBackEndDataProvider<StaffLoanProductEntry, String>() {
      @Override
      protected Stream<StaffLoanProductEntry> fetchFromBackEnd(Query<StaffLoanProductEntry, String> query) {
        if(query.getFilter().isPresent()){
          return repository.findAllByContractId(query.getFilter().get()).parallelStream();
        } else {
          return Stream.empty();
        }
      }

      @Override
      protected int sizeInBackEnd(Query<StaffLoanProductEntry, String> query) {
        if(query.getFilter().isPresent()){
          return repository.countAllByContractId(query.getFilter().get());
        } else {
          return 0;
        }
      }
    }).withConfigurableFilter();
    loanInformationGrid.setDataProvider(configurableFilterDataProvider);
    Grid.Column columnDueDate = loanInformationGrid.getColumn("initiatedDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());
  }

  public void setContractId(String contractId){
    this.contractId = contractId;
    configurableFilterDataProvider.setFilter(contractId);
    loanInformationGrid.getDataProvider().refreshAll();
  }
}
