package com.gl.csf.cm.config.app;

import com.gl.csf.cm.api.contract.command.CreateContractCommand;
import com.gl.csf.cm.api.contract.command.SubmitApplicationCommand;
import com.gl.csf.cm.common.model.Gender;
import com.gl.csf.cm.common.model.address.Address;
import com.gl.csf.cm.common.model.address.District;
import com.gl.csf.cm.common.model.address.State;
import com.gl.csf.cm.common.model.address.Township;
import com.gl.csf.cm.common.model.application.StaffLoanApplications;
import com.gl.csf.cm.common.model.bank.Bank;
import com.gl.csf.cm.common.model.bank.BankAccount;
import com.gl.csf.cm.common.model.bank.BankAccountType;
import com.gl.csf.cm.common.model.guarantor.GuarantorBusiness;
import com.gl.csf.cm.common.model.guarantor.GuarantorPersonalInformation;
import com.gl.csf.cm.common.model.lessee.*;
import com.gl.csf.cm.common.model.product.LoanProduct;
import com.gl.csf.cm.common.model.product.PaymentFrequency;
import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.common.model.product.StaffLoanProduct;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.uw.integration.service.ContractReferenceService;
import com.gl.csf.cm.uw.integration.service.StaffLoanContractReferenceService;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.javamoney.moneta.Money;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/13/2017.
 */
@Component
@Profile(value = {"default"})
public class DatabaseInitializer implements CommandLineRunner {
  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);
  private final CommandGateway commandGateway;
  private final ContractReferenceService contractReferenceService;
  private final StaffLoanContractReferenceService staffLoanContractReferenceService;

  @Inject
  public DatabaseInitializer(CommandGateway commandGateway, ContractReferenceService contractReferenceService, StaffLoanContractReferenceService staffLoanContractReferenceService) {
    this.commandGateway = commandGateway;
    this.contractReferenceService = contractReferenceService;
    this.staffLoanContractReferenceService = staffLoanContractReferenceService;
  }

  @Override
  public void run(String... strings) throws Exception{
    Random random = new Random();
    for(int i = 0; i < 15; i++){
      UUID id = UUID.randomUUID();
      createMockContract(id.toString(), ProductType.STANDARD_LOAN, random);
    }
    
    for(int i = 0; i < 10; i++){
      UUID id = UUID.randomUUID();
      createMockContract(id.toString(), ProductType.REVOLVING_LOAN, random);
    }
    
    for(int i = 0; i<5; i++){
      UUID id = UUID.randomUUID();
      createStaffLoanData(id.toString(),ProductType.STAFF_LOAN);
    }
  }
  private void createStaffLoanData(String id, ProductType productType){
    List<StaffLoanPurpose>staffLoanPurposes = new ArrayList<>();
    staffLoanPurposes.add(new StaffLoanPurpose(UUID.randomUUID(), "I want to buy house"));
    staffLoanPurposes.add(new StaffLoanPurpose(UUID.randomUUID(), "I want to buy new car"));
    staffLoanPurposes.add(new StaffLoanPurpose(UUID.randomUUID(), "I want to buy new motor"));
    PaymentFrequency paymentFrequency = new PaymentFrequency();
    paymentFrequency.setValue(12);
    paymentFrequency.setDescription("Monthly");
    
    Staff staff = new Staff("Jhon",
            "123124124",
            Gender.MALE,
            "Doe",
            LocalDate.now().minusYears(20),
            "Developer",
            new Company(UUID.randomUUID().toString(),"GLF"),
            "023-45334442",
            "test@gmail.com",
            new Address("my address",
                    new State(UUID.randomUUID().toString(),"test state", "test state bur"),
                    new District(UUID.randomUUID().toString(),"test district", "test district bur"),
                    new Township(UUID.randomUUID().toString(),"test township", "test township bur")),
            new BankAccount(
                    new Bank("123", "AYA", "AYA Burmese"), "Test Account", "Test account Number"),
            Money.of(15000000, CurrencyUtil.MMK_CURRENCY),
            Money.of(15000000, CurrencyUtil.MMK_CURRENCY),staffLoanPurposes, "other loanpurpus");
    StaffLoanProduct staffLoanProduct = new StaffLoanProduct(productType, Money.of(14000000, CurrencyUtil.MMK_CURRENCY), 12, paymentFrequency, new BigDecimal("1.3").setScale(1, BigDecimal.ROUND_HALF_UP));
    String applicationId = UUID.randomUUID().toString();
    String contractNumber = staffLoanContractReferenceService.nextReference();
    
    StaffLoanApplications staffLoanApplications = new StaffLoanApplications();
    staffLoanApplications.setStaff(staff);
    staffLoanApplications.setStaffLoanProduct(staffLoanProduct);
    SubmitApplicationCommand submitApplicationCommand = new SubmitApplicationCommand(id,staffLoanApplications,applicationId,contractNumber);
  
    commandGateway.send(submitApplicationCommand);
  }

  
  /*
  private void cancelActivatedContract() {
	try {
      commandGateway.sendAndWait(new CancelContractActivatedCommand("d00db4d9-7056-47be-95b6-9ba5234bc37a", "Users want to cancel Activated Contract having contract number CV-1800000386", ContractStatus.CONTRACT_CANCELLED));
    }catch (AggregateNotFoundException e1) {
      System.out.println("Error : " + e1.getMessage());
    } 
  }
  
  private void updataContractNumbers() {
	  Map<String, String> items = new HashMap<>();
	    items.put("dcd0057e-b435-4ba6-876c-2cb6d37a04ca", "CV-1800000289");
	    items.put("d00db4d9-7056-47be-95b6-9ba5234bc37a", "CV-1800000386");
	    items.put("6c61b227-693b-4b70-9cd6-b4ec272ca56b", "CV-1800000483");
	    items.put("5d2bd525-cd35-4626-b6f5-1706efe5fb27", "CV-18000005" + contractReferenceService.getCheckTwoDigits());
	  
	    items.forEach((k,v)->{
	      try {
	        commandGateway.sendAndWait(new UpdateContractNumberCommand(k, v));
	      }
	        catch (AggregateNotFoundException e1) {
	        System.out.println("Error : " + e1.getMessage());
	      }      
	    });
  }*/

  private void createMockContract(String id, ProductType productType, Random random) {
    PaymentFrequency paymentFrequency = new PaymentFrequency();

    int paymentFrequencyValue = 0;
    switch (paymentFrequencyValue){
      case 0:
        paymentFrequency.setValue(12);
        paymentFrequency.setDescription("Monthly");
        break;
      case 1:
        paymentFrequency.setValue(4);
        paymentFrequency.setDescription("Quarterly");
        break;
      case 2:
        paymentFrequency.setValue(1);
        paymentFrequency.setDescription("Yearly");
        break;
    }

    LoanProduct loanProduct = new LoanProduct(productType, Money.of(15000000, CurrencyUtil.MMK_CURRENCY), 12,
            new BigDecimal("2.3").setScale(1, BigDecimal.ROUND_HALF_UP), paymentFrequency, "Extend business");

    StaffLoanProduct staffLoanProduct = new StaffLoanProduct(productType, Money.of(15000000, CurrencyUtil.MMK_CURRENCY), 12, paymentFrequency, new BigDecimal("2.3").setScale(1, BigDecimal.ROUND_HALF_UP));

    LesseePersonalInformation lesseePersonalInformation = new LesseePersonalInformation("Jhon", "Doe", Gender.MALE,
            LocalDate.now().minusYears(20), "087-87787878", "098-34232324", "023-45334442", "test@gmail.com", "123124124", new Address("my address",
      new State(UUID.randomUUID().toString(),"test state", "test state bur"),
      new District(UUID.randomUUID().toString(),"test district", "test district bur"),
      new Township(UUID.randomUUID().toString(),"test township", "test township bur")));

    List<StaffLoanPurpose>staffLoanPurposes = new ArrayList<>();
    staffLoanPurposes.add(new StaffLoanPurpose(UUID.randomUUID(), "I want to buy house"));
    staffLoanPurposes.add(new StaffLoanPurpose(UUID.randomUUID(), "I want to buy new car"));
    staffLoanPurposes.add(new StaffLoanPurpose(UUID.randomUUID(), "I want to buy new motor"));

    Staff staff = new Staff("Jhon",
            "123124124",
            Gender.MALE,
            "Doe",
            LocalDate.now().minusYears(20),
            "Developer",
            new Company(UUID.randomUUID().toString(),"GLF"),
            "023-45334442",
            "test@gmail.com",
            new Address("my address",
            new State(UUID.randomUUID().toString(),"test state", "test state bur"),
            new District(UUID.randomUUID().toString(),"test district", "test district bur"),
            new Township(UUID.randomUUID().toString(),"test township", "test township bur")),
            new BankAccount(
                    new Bank("123", "AYA", "AYA Burmese"), "Test Account", "Test account Number"),
            Money.of(15000000, CurrencyUtil.MMK_CURRENCY),
            Money.of(15000000, CurrencyUtil.MMK_CURRENCY),staffLoanPurposes, "other loanpurpus");

    List<Branch> branches = new ArrayList<>();
    Branch branch = new Branch();
    branch.setAddress("Address Branch 1");
    branch.setBranchName("Branch 1");
    branch.setBranchId(UUID.randomUUID().toString());
    branch.setNumberOfStaff(12);

    Branch branch1 = new Branch();
    branch1.setBranchId("11124124124");
    branch1.setAddress("Address Branch 2");
    branch1.setBranchName("Branch 2");
    branch1.setBranchId(UUID.randomUUID().toString());
    branch1.setNumberOfStaff(12);

    branches.add(branch);
    branches.add(branch1);

    FinancialDocument financialDocument = new FinancialDocument();
    financialDocument.setDocumentId("doc0011");
    financialDocument.setBucketId("buck0001");
    financialDocument.setAttachment("att.doc");
    financialDocument.setUploadBy("System");
    financialDocument.setComment("comment 1");
    financialDocument.setDateTime(LocalDateTime.now());

    LesseeBusiness lesseeBusiness = new LesseeBusiness("Test Business", branch1.getBranchId(), branch1.getBranchName(), false, "BizId 01",
            branches.size(), MMK_ZERO, MMK_ZERO, MMK_ZERO, 24, MMK_ZERO, MMK_ZERO, MMK_ZERO, MMK_ZERO,
            MMK_ZERO, MMK_ZERO, MMK_ZERO, branches, Collections.singletonList(financialDocument));

    LesseeBankAccountInformation lesseeBankAccountInformation = new LesseeBankAccountInformation(new BankAccount(
            new Bank("123", "AYA", "AYA Burmese"), "Test Account", "Test account Number"),
            BankAccountType.PERSONAL, "Test Bank Account");

    GuarantorPersonalInformation guarantorPersonalInformation = new GuarantorPersonalInformation("Pisith Ly",
            Gender.MALE, null, "087436283", "p.ly@gl-f.coom", null, null, new Address("my address",
      new State(UUID.randomUUID().toString(),"test state", "test state bur"),
      new District(UUID.randomUUID().toString(),"test district", "test district bur"),
      new Township(UUID.randomUUID().toString(),"test township", "test township bur")));

    GuarantorBusiness guarantorBusiness = new GuarantorBusiness("02323232", new Address("my address",
      new State(UUID.randomUUID().toString(),"test state", "test state bur"),
      new District(UUID.randomUUID().toString(),"test district", "test district bur"),
      new Township(UUID.randomUUID().toString(),"test township", "test township bur")));
  
    String nextReferenceNumber;
    if(productType.equals(ProductType.STAFF_LOAN))
      nextReferenceNumber = staffLoanContractReferenceService.nextReference();
    else
      nextReferenceNumber = contractReferenceService.nextReference();
    
    CreateContractCommand createContractCommand = new CreateContractCommand(id,
            nextReferenceNumber, UUID.randomUUID().toString(), loanProduct,
            lesseePersonalInformation, lesseeBusiness,
            lesseeBankAccountInformation, guarantorPersonalInformation, guarantorBusiness, staff, staffLoanProduct);

    commandGateway.send(createContractCommand);
  }
}
