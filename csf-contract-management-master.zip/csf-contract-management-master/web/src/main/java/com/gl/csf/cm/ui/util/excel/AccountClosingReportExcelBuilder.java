package com.gl.csf.cm.ui.util.excel;

import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationEntry;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/23/2017.
 */
public class AccountClosingReportExcelBuilder extends CustomAbstractXlsxStreamingView {
  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);

  public static List<ContractPeriodInterestRealizationEntry> contractPeriodInterestRealizationEntrys;
  private static String closingReportFrom;
  private static String closingReportTo;
  private static String productLoanType;

  public AccountClosingReportExcelBuilder(int maxAccessWindowSize) {
    super(maxAccessWindowSize);
  }

  private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM, YYYY");

  private Map<LocalDate, List<ContractPeriodInterestRealizationEntry>> groupContractByMonth;

  @Override
  protected void buildExcelDocument(Map<String, Object> map, Workbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {

    String filename = "Account-Closing-Report-From-" + closingReportFrom + "-To-" + closingReportTo;
    // change the file name
    response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + ".xlsx\"");

    // create excel sheet
    Sheet sheet = workbook.createSheet("Accounting closing report");
    sheet.setDefaultColumnWidth(20);

    sheet.addMergedRegion(new CellRangeAddress(
            1,
            1,
            0,
            4
    ));

    // set title
    Row title = sheet.createRow(1);
    title.createCell(0).setCellValue("Accounting report - Account closing report");

    // from date to date
    Row period = sheet.createRow(3);

    period.createCell(0).setCellValue("From ");
    period.createCell(1).setCellValue(closingReportFrom);

    period.createCell(3).setCellValue("To ");
    period.createCell(4).setCellValue(closingReportTo);

    // loan type
    Row loanType = sheet.createRow(5);

    loanType.createCell(0).setCellValue("Loan :");
    loanType.createCell(1).setCellValue(productLoanType);

    // loop map to set header
    Row monthHeader = sheet.createRow(7);

    // set up header
    Row header = sheet.createRow(8);
    header.createCell(0).setCellValue("Contract");

    int monthCellIndex = 1;
    int mergeRange = 1;
    int headerIndex = 1;

    for (Map.Entry<LocalDate, List<ContractPeriodInterestRealizationEntry>> entry : groupContractByMonth().entrySet()) {
      sheet.addMergedRegion(new CellRangeAddress(
              7,
              7,
              monthCellIndex,
              (mergeRange + 1)
      ));
      monthHeader.createCell((monthCellIndex)).setCellValue(entry.getKey().format(formatter));
      monthCellIndex += 2;
      mergeRange += 2;


      header.createCell(headerIndex).setCellValue("Interest end of month");
      header.createCell((headerIndex + 1)).setCellValue("Principal end of month");

      headerIndex += 2;
    }

    Row dataRow;
    int dataIndex = 9;

    // render available contract number
    for (Map.Entry<String, String> contractNumber : renderContractNumberList().entrySet()) {
      dataRow = sheet.createRow(dataIndex);
      dataRow.createCell(0).setCellValue(contractNumber.getKey());
      dataIndex++;
    }

    Row totalAmountRow = sheet.createRow((dataIndex + 1));
    totalAmountRow.createCell(0).setCellValue("Total amount");

    Row totalNumberOfContractRow = sheet.createRow((dataIndex + 2));
    totalNumberOfContractRow.createCell(0).setCellValue("Total no. of contract");


    dataIndex = 9;
    int interestEndOfMonthIndex = 1;
    int principleEndOfMonthIndex = 2;

    int numberContractInterest = 0;
    int numberContractPrinciple = 0;

    MonetaryAmount totalAmountInterestEndOfMonth = Money.of(0, CurrencyUtil.MMK_CURRENCY);
    MonetaryAmount totalAmountPrincipleEndOfMonth = Money.of(0, CurrencyUtil.MMK_CURRENCY);
    
    dataRow = sheet.getRow(dataIndex);		

    // group months
    for (Map.Entry<LocalDate, List<ContractPeriodInterestRealizationEntry>> entry : groupContractByMonth().entrySet()) {
      // list of contracts in month
      for (ContractPeriodInterestRealizationEntry contractPeriodInterestRealizationEntry : entry.getValue()) {
        // loop to check data match to contract number
        for (Map.Entry<String, String> contractNumber : renderContractNumberList().entrySet()) {
          if (contractNumber.getKey().equals(contractPeriodInterestRealizationEntry.getContractNumber())) {
            dataRow = sheet.getRow(dataIndex);

            dataRow.createCell(interestEndOfMonthIndex).setCellValue(contractPeriodInterestRealizationEntry.getInterestEndOfMonth()
                    .getNumber().numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
            dataRow.createCell(principleEndOfMonthIndex).setCellValue(contractPeriodInterestRealizationEntry.getPrincipalEndOfMonth()
                    .getNumber().numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());

            dataIndex++;
          } else
            dataIndex++;
        }
        // calculate total
        totalAmountInterestEndOfMonth = totalAmountInterestEndOfMonth.add(contractPeriodInterestRealizationEntry.getInterestEndOfMonth());
        totalAmountPrincipleEndOfMonth = totalAmountPrincipleEndOfMonth.add(contractPeriodInterestRealizationEntry.getPrincipalEndOfMonth());

        // count not empty cell
        if (contractPeriodInterestRealizationEntry.getInterestEndOfMonth().isPositive())
          ++numberContractInterest;
        if (contractPeriodInterestRealizationEntry.getPrincipalEndOfMonth().isPositive())
          ++numberContractPrinciple;

        dataIndex = 9;
      }

      totalAmountRow.createCell(interestEndOfMonthIndex).setCellValue(totalAmountInterestEndOfMonth.getNumber()
              .numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      totalAmountRow.createCell(principleEndOfMonthIndex).setCellValue(totalAmountPrincipleEndOfMonth.getNumber()
              .numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());

      totalNumberOfContractRow.createCell(interestEndOfMonthIndex).setCellValue(numberContractInterest);
      totalNumberOfContractRow.createCell(principleEndOfMonthIndex).setCellValue(numberContractPrinciple);

      // reset for next month
      numberContractInterest = 0;
      numberContractPrinciple = 0;

      totalAmountInterestEndOfMonth = Money.of(0, CurrencyUtil.MMK_CURRENCY);
      totalAmountPrincipleEndOfMonth = Money.of(0, CurrencyUtil.MMK_CURRENCY);

      interestEndOfMonthIndex += 2;
      principleEndOfMonthIndex += 2;
    }
  }

  private Map<LocalDate, List<ContractPeriodInterestRealizationEntry>> groupContractByMonth() {

    groupContractByMonth = contractPeriodInterestRealizationEntrys.stream()
            .collect(Collectors.groupingBy(ContractPeriodInterestRealizationEntry::getEndOfMonthDate));

    groupContractByMonth = new TreeMap<>(groupContractByMonth);

    return groupContractByMonth;
  }

  private Map<String, String> renderContractNumberList() {
    Map<String, String> contractNumberList = new TreeMap<>();


    for (ContractPeriodInterestRealizationEntry contractPeriodInterestRealizationEntry : contractPeriodInterestRealizationEntrys) {
      contractNumberList.put(contractPeriodInterestRealizationEntry.getContractNumber(), contractPeriodInterestRealizationEntry.getContractId());
    }

    return contractNumberList;
  }

  public static void setContractPeriodInterestRealizationEntrys(List<ContractPeriodInterestRealizationEntry> contractPeriodInterestRealizationEntryList) {
    Map<LocalDate, List<ContractPeriodInterestRealizationEntry>> resultMap = new HashMap<>();
	Map<LocalDate, Map<String, List<ContractPeriodInterestRealizationEntry>>> entryByEndOfMonthAndContractNumber = 
			contractPeriodInterestRealizationEntryList.stream().collect(Collectors.groupingBy(ContractPeriodInterestRealizationEntry::getEndOfMonthDate, 
			Collectors.groupingBy(ContractPeriodInterestRealizationEntry::getContractNumber)));
	entryByEndOfMonthAndContractNumber.forEach((eom, mapp)-> {
		List<ContractPeriodInterestRealizationEntry> results = new ArrayList<>();
		mapp.forEach((contract, entryList) -> {
			if (entryList.size() == 1) {
				results.add(entryList.get(0));
			} else {
				ContractPeriodInterestRealizationEntry result = new ContractPeriodInterestRealizationEntry();
				result.setDueDate(entryList.get(0).getDueDate());
				result.setContractId(entryList.get(0).getContractId());
				result.setContractNumber(entryList.get(0).getContractNumber());
				result.setEndOfMonthDate(eom);
				result.setId(entryList.get(0).getId());
				result.setProductType(entryList.get(0).getProductType());			
				MonetaryAmount installment = MMK_ZERO;
				MonetaryAmount interest = MMK_ZERO;
				MonetaryAmount interestEndOfMonth = MMK_ZERO;
				Integer p = Integer.valueOf(0);
				MonetaryAmount principal = MMK_ZERO;
				MonetaryAmount principalEndOfMonth = MMK_ZERO;
				MonetaryAmount remainingBalanceEndOfMonth = MMK_ZERO;
				MonetaryAmount remainingPrincipalBalance = MMK_ZERO;
				MonetaryAmount sumOfAccruedInterestEndOfMonth = MMK_ZERO;
				MonetaryAmount sumOfAccruedPrincipalEndOfMonth = MMK_ZERO;
				for(ContractPeriodInterestRealizationEntry entry: entryList) {
					installment = installment.add(entry.getInstallment());
					interest = interest.add(entry.getInstallment());
					interestEndOfMonth = interestEndOfMonth.add(entry.getInterestEndOfMonth());
					p += entry.getPeriod();
					principal = principal.add(entry.getPrincipal());
					principalEndOfMonth = principalEndOfMonth.add(entry.getPrincipalEndOfMonth());
					remainingBalanceEndOfMonth = remainingBalanceEndOfMonth.add(entry.getRemainingBalanceEndOfMonth());
					remainingPrincipalBalance = remainingPrincipalBalance.add(entry.getRemainingPrincipalBalance());
					sumOfAccruedInterestEndOfMonth = sumOfAccruedInterestEndOfMonth.add(entry.getSumOfAccruedInterestEndOfMonth());
					sumOfAccruedPrincipalEndOfMonth = sumOfAccruedPrincipalEndOfMonth.add(entry.getSumOfAccruedPrincipalEndOfMonth());
				}			
				result.setInstallment(installment);
				result.setInterest(interest);
				result.setInterestEndOfMonth(interestEndOfMonth);
				result.setPeriod(p);
				result.setPrincipal(principal);
				result.setPrincipalEndOfMonth(principalEndOfMonth);
				result.setRemainingBalanceEndOfMonth(remainingBalanceEndOfMonth);
				result.setRemainingPrincipalBalance(remainingPrincipalBalance);
				result.setSumOfAccruedInterestEndOfMonth(sumOfAccruedInterestEndOfMonth);
				result.setSumOfAccruedPrincipalEndOfMonth(sumOfAccruedPrincipalEndOfMonth);			
				results.add(result);
			}
		});
		resultMap.put(eom, results);
	});
	
	List<ContractPeriodInterestRealizationEntry> results = new ArrayList<>();
	
	resultMap.forEach((eom, resultList) -> {
		results.addAll(resultList);
	});
	contractPeriodInterestRealizationEntrys = results;
    
  }

  public static void setClosingReportFrom(String reportFrom) {
    closingReportFrom = reportFrom;
  }

  public static void setClosingReportTo(String reportTo) {
    closingReportTo = reportTo;
  }

  public static void setProductLoanType(String type) {
    productLoanType = type;
  }
}
