package com.gl.csf.cm.ui.component.paymentInformation;

import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.query.paymentinformation.penalty.PenaltyEntry;
import com.gl.csf.cm.query.paymentinformation.penalty.PenaltyRepository;
import com.gl.csf.cm.query.paymentinformation.penalty.endofcontract.EndOfContractPenaltyEntry;
import com.gl.csf.cm.query.paymentinformation.penalty.endofcontract.EndOfContractPenaltyRepository;
import com.gl.csf.cm.query.paymentinformation.penalty.history.PenaltyHistoryEntry;
import com.gl.csf.cm.query.paymentinformation.penalty.history.PenaltyHistoryRepository;
import com.gl.csf.cm.query.paymentinformation.penalty.summary.PenaltySummary;
import com.gl.csf.cm.query.paymentinformation.penalty.summary.PenaltySummaryRepository;
import com.gl.csf.cm.query.service.PenaltyOverdueDayService;
import com.gl.csf.cm.ui.util.MonetaryAmountRenderer;
import com.vaadin.data.TreeData;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.data.provider.TreeDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Component;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TreeGrid;
import com.vaadin.ui.components.grid.FooterRow;
import net.engio.mbassy.listener.Handler;
import org.javamoney.moneta.Money;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by p.ly on 12/2/2017.
 */
@SpringComponent
@UIScope
public class PenaltyComponent extends PenaltyComponentDesign {

  private static final String EMPTY = "";
  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);

  private final PenaltyRepository penaltyRepository;
  private final SessionScopeBus bus;
  private final PenaltyOverdueDayService penaltyOverdueDayService;
  private final EndOfContractPenaltyRepository endOfContractPenaltyRepository;
  private final PenaltyHistoryRepository penaltyHistoryRepository;
  private final PenaltySummaryRepository penaltySummaryRepository;
  private String contractNo;
  private MonetaryAmount totalPenaltyAmount = MMK_ZERO;
  private MonetaryAmount totalReceivePenaltyAmount = MMK_ZERO;
  private MonetaryAmount totalPenaltyAmountAllocation = MMK_ZERO;

  private MonetaryAmount monthlyPenaltyBalance = MMK_ZERO;
  private MonetaryAmount totalMonthlyPenaltyAmount = MMK_ZERO;
  private MonetaryAmount totalMonthlyPenaltyPaymentAmount = MMK_ZERO;
  private MonetaryAmount endOfContractPenaltyBalance = MMK_ZERO;

  private TreeGrid<PenaltyEntry> treeGrid = new TreeGrid<>();
  private List<PenaltyEntry> items;

  @Inject
  PenaltyComponent(PenaltyRepository penaltyRepository, SessionScopeBus bus,
                   PenaltyOverdueDayService penaltyOverdueDayService, EndOfContractPenaltyRepository endOfContractPenaltyRepository,
                   PenaltyHistoryRepository penaltyHistoryRepository, PenaltySummaryRepository penaltySummaryRepository) {
    this.bus = bus;
    this.penaltyRepository = penaltyRepository;
    this.penaltyOverdueDayService = penaltyOverdueDayService;
    this.endOfContractPenaltyRepository = endOfContractPenaltyRepository;
    this.penaltyHistoryRepository = penaltyHistoryRepository;
    this.penaltySummaryRepository = penaltySummaryRepository;

    treeGrid.setStyleName("payment-information-tree-grid");
  }

  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
    fetchData();
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  @Handler
  public void handle(ContractSelectedEvent event) {
    this.contractNo = event.getContractNo();
    treeGrid.removeAllColumns();
    penaltyTreeGrid.addComponent(generateTreeGrid(this.contractNo));
    fetchData();
  }

  private Component generateTreeGrid(String contractNumber) {
    TreeData<PenaltyEntry> data = new TreeData<>();

    List<PenaltyEntry> tmpPenaltyEntries = penaltyRepository.findAllByContractNumberAndDueDateBeforeAndPaymentStatusIsNot(contractNumber, LocalDate.now(), PaymentStatus.FULL);
    List<PenaltyEntry> penaltyEntries = new ArrayList<>();

    for (PenaltyEntry penaltyEntry : tmpPenaltyEntries) {

      penaltyEntry = penaltyOverdueDayService.calculateOverdueDays(penaltyEntry, "", "", MMK_ZERO, MMK_ZERO, null);
      totalReceivePenaltyAmount = penaltyEntry.getReceivePenaltyAmount().add(totalReceivePenaltyAmount);
      totalPenaltyAmount = penaltyEntry.getPenaltyAmount().add(totalPenaltyAmount);
      totalPenaltyAmountAllocation = penaltyEntry.getAllocatePenaltyAmount().add(totalPenaltyAmountAllocation);

      totalMonthlyPenaltyAmount = totalMonthlyPenaltyAmount.add(penaltyEntry.getPenaltyAmount());
      totalMonthlyPenaltyPaymentAmount = totalMonthlyPenaltyPaymentAmount.add(penaltyEntry.getAllocatePenaltyAmount());

      monthlyPenaltyBalance = totalMonthlyPenaltyAmount.subtract(totalMonthlyPenaltyPaymentAmount);
      penaltyEntries.add(penaltyEntry);
    }

    constructTreeGrid();
    items = penaltyEntries;
    if (!items.isEmpty()) {
      for (PenaltyEntry entry : items) {
        if (!penaltyHistoryRepository.findByContractNumberAndInstallmentNumber(entry.getContractNumber(),
                entry.getInstallmentNumber()).isEmpty()) {
          List<PenaltyHistoryEntry> subItems = penaltyHistoryRepository.findByContractNumberAndInstallmentNumber(entry.getContractNumber(),
                  entry.getInstallmentNumber());
          entry.setSubItems(convertPenaltyHistoryEntryToPenaltyEntry(subItems));
        }
        data.addItem(null, entry);
        data.addItems(entry, entry.getSubItems());
      }
    }
    TreeDataProvider<PenaltyEntry> dataProvider = new TreeDataProvider<>(data);
    treeGrid.setDataProvider(dataProvider);
    dataProvider.refreshAll();

    return treeGrid;
  }

  public List<PenaltyEntry> convertPenaltyHistoryEntryToPenaltyEntry(List<PenaltyHistoryEntry> subItems) {
    List<PenaltyEntry> penaltyEntries = new ArrayList<>();
    for (PenaltyHistoryEntry history : subItems) {
      PenaltyEntry penaltyEntry = new PenaltyEntry();
      penaltyEntry.setPaymentDate(history.getPaymentDate());
      penaltyEntry.setPaymentStatus(history.getPaymentStatus());
      penaltyEntry.setReceivePenaltyAmount(history.getReceivePenaltyAmount());
      penaltyEntry.setPaymentReference(history.getPaymentReference());
      penaltyEntry.setBankTransaction(history.getBankTransaction());
      penaltyEntry.setAllocatePenaltyAmount(history.getAllocatePenaltyAmount());
      penaltyEntry.setPenaltyAmount(MMK_ZERO);
      penaltyEntry.setOverdueDays(0);
      penaltyEntry.setContractNumber(history.getContractNumber());
      penaltyEntry.setInstallmentNumber(history.getInstallmentNumber());
      penaltyEntry.setId(history.getId());

      penaltyEntries.add(penaltyEntry);

    }
    return penaltyEntries;
  }

  private void constructTreeGrid() {
    treeGrid.setWidth(100.f, Unit.PERCENTAGE);

    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getInstallmentNumber()).setCaption("Installment No.").setId("installmentNumber");
    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getOverdueDays() == 0 ? EMPTY : penaltyEntry.getOverdueDays()).setCaption("Overdue Days").setId("overdueDays");
    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getPenaltyAmount())
            .setCaption("Penalty Amount").setId("penaltyAmount").setRenderer(new MonetaryAmountRenderer());
    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getPaymentStatus()).setCaption("Payment Status").setId("paymentStatus");
    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getPaymentDate()).setCaption("Payment Date").setId("paymentDate");
    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getBankTransaction()).setCaption("Bank Transaction").setId("bankTransaction");
    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getReceivePenaltyAmount().isEqualTo(MMK_ZERO) ? null : penaltyEntry.getReceivePenaltyAmount())
            .setCaption("Receive Penalty Amount").setId("receivePenaltyAmount").setRenderer(new MonetaryAmountRenderer());
    treeGrid.addColumn(penaltyEntry -> penaltyEntry.getAllocatePenaltyAmount().isEqualTo(MMK_ZERO) ? null : penaltyEntry.getAllocatePenaltyAmount())
            .setCaption("Penalty Amount Allocation").setId("penaltyAmountAllocation").setRenderer(new MonetaryAmountRenderer());
  
    Grid.Column columnDueDate = treeGrid.getColumn("paymentDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());
    
    FooterRow footer = treeGrid.appendFooterRow();
    footer.join("installmentNumber", "overdueDays").setText("Total");

    footer.getCell("penaltyAmount").setText(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(totalPenaltyAmount).toString());
    footer.getCell("receivePenaltyAmount").setText(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(totalReceivePenaltyAmount).toString());
    footer.getCell("penaltyAmountAllocation").setText(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(totalPenaltyAmountAllocation).toString());
    if (treeGrid.getFooterRowCount() > 1)
      treeGrid.removeFooterRow(0);

  }

  private void fetchData() {
    List<EndOfContractPenaltyEntry> endOfContractPenaltyEntries = endOfContractPenaltyRepository.findByContractNumber(contractNo);
    ListDataProvider<EndOfContractPenaltyEntry> endOfContractPenaltyEntryListDataProvider = new ListDataProvider<>(endOfContractPenaltyEntries);

    gridEndOfContractPenalty.setDataProvider(endOfContractPenaltyEntryListDataProvider);
    endOfContractPenaltyEntryListDataProvider.refreshAll();

    gridEndOfContractPenalty.getColumn("penaltyAmount").setRenderer(new MonetaryAmountRenderer());
    gridEndOfContractPenalty.getColumn("paymentAmount").setRenderer(new MonetaryAmountRenderer());
    gridEndOfContractPenalty.getColumn("paymentAllocation").setRenderer(new MonetaryAmountRenderer());
    
    Grid.Column columnDueDate = gridEndOfContractPenalty.getColumn("paymentDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());

    Optional<PenaltySummary> optionalPenaltySummary = penaltySummaryRepository.findByContractNumber(contractNo);
    PenaltySummary penaltySummary;

    if (optionalPenaltySummary.isPresent()) {
      penaltySummary = optionalPenaltySummary.get();
      endOfContractPenaltyBalance = penaltySummary.getEndOfContractPenaltyBalanceAmount();
    }

    monthlyPenaltyBalanceLabel.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(monthlyPenaltyBalance).toString());
    endOfContractPenaltyBalanceLabel.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(endOfContractPenaltyBalance).toString());
  }
}
