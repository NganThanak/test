package com.gl.csf.cm.mocktreegrid;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by p.ly on 12/8/2017.
 */
public class MockPaymentSchedule {
  private String installmentNo;
  private String installmentAmount;
  private String paymentReference;
  private String paymentAmount;
  private String paymentDate;
  private List<MockPaymentSchedule> subItems = new ArrayList<>();
  public MockPaymentSchedule(String installmentNo, String installmentAmount, String paymentReference, String paymentAmount, String paymentDate) {
    this.installmentNo = installmentNo;
    this.installmentAmount = installmentAmount;
    this.paymentReference = paymentReference;
    this.paymentAmount = paymentAmount;
    this.paymentDate = paymentDate;
  }

  public String getInstallmentNo() {
    return installmentNo;
  }

  public void setInstallmentNo(String installmentNo) {
    this.installmentNo = installmentNo;
  }

  public String getInstallmentAmount() {
    return installmentAmount;
  }

  public void setInstallmentAmount(String installmentAmount) {
    this.installmentAmount = installmentAmount;
  }

  public String getPaymentReference() {
    return paymentReference;
  }

  public void setPaymentReference(String paymentReference) {
    this.paymentReference = paymentReference;
  }

  public String getPaymentAmount() {
    return paymentAmount;
  }

  public void setPaymentAmount(String paymentAmount) {
    this.paymentAmount = paymentAmount;
  }

  public String getPaymentDate() {
    return paymentDate;
  }

  public void setPaymentDate(String paymentDate) {
    this.paymentDate = paymentDate;
  }

  public List<MockPaymentSchedule> getSubItems() {
    return subItems;
  }

  public void setSubItems(List<MockPaymentSchedule> subItems) {
    this.subItems = subItems;
  }
}
