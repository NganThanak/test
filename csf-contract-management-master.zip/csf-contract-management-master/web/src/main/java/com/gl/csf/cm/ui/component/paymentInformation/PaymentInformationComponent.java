package com.gl.csf.cm.ui.component.paymentInformation;

import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.query.paymentinformation.paymentschedule.PaymentScheduleEntry;
import com.gl.csf.cm.query.paymentinformation.paymentschedule.PaymentScheduleHistory;
import com.gl.csf.cm.query.paymentinformation.paymentschedule.PaymentScheduleHistoryRepository;
import com.gl.csf.cm.query.paymentinformation.paymentschedule.PaymentScheduleRepository;
import com.gl.csf.cm.ui.util.MonetaryAmountRenderer;
import com.vaadin.data.TreeData;
import com.vaadin.data.provider.TreeDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Component;
import com.vaadin.ui.TreeGrid;
import com.vaadin.ui.components.grid.FooterRow;
import org.javamoney.moneta.Money;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by p.ly on 11/8/2017.
 */
@SpringComponent
@UIScope
public class PaymentInformationComponent extends PaymentInformationComponentDesign{
  private static final String EMPTY = "";
  private static final String ALIGN_CENTER = "v-align-center";
  private static final String ALIGN_RIGHT = "v-align-right";
  private TreeGrid<PaymentScheduleEntry> treeGrid = new TreeGrid<>();
  private final PaymentScheduleRepository paymentScheduleRepository;
  private final PaymentScheduleHistoryRepository paymentScheduleHistoryRepository;
  private String contractNumber;
  List<PaymentScheduleEntry> items;
  private FooterRow footer = treeGrid.appendFooterRow();

  @Inject
  PaymentInformationComponent(PaymentScheduleRepository paymentScheduleRepository, PaymentScheduleHistoryRepository paymentScheduleHistoryRepository){

    this.paymentScheduleRepository = paymentScheduleRepository;
    this.paymentScheduleHistoryRepository = paymentScheduleHistoryRepository;
    treeGrid.setStyleName("payment-information-tree-grid");
  }

  private Component generateTreeGrid(String contractNumber){
    TreeData<PaymentScheduleEntry> data = new TreeData<>();
    MonetaryAmount totalAmount = Money.of(0, CurrencyUtil.MMK_CURRENCY);
    MonetaryAmount totalAllocationAmount = Money.of(0, CurrencyUtil.MMK_CURRENCY);
    constructTreeGrid();
    items = paymentScheduleRepository.findAllByContractNumberOrderByInstallmentNumber(contractNumber);
    if (!items.isEmpty()){
        for (PaymentScheduleEntry entry:items){
          if(!paymentScheduleHistoryRepository.findAllByContractNumberAndInstallmentNumber(entry.getContractNumber(),
                  entry.getInstallmentNumber()).isEmpty()){
            List<PaymentScheduleHistory> subItems = paymentScheduleHistoryRepository.findAllByContractNumberAndInstallmentNumber(entry.getContractNumber(),
                    entry.getInstallmentNumber());
            entry.setSubItems(convertScheduleHistoryToEntry(subItems));

            for(PaymentScheduleHistory paymentScheduleHistory : subItems){
              if(paymentScheduleHistory.getPaymentAmount()!= null)
                totalAmount = totalAmount.add(paymentScheduleHistory.getPaymentAmount());
              if(paymentScheduleHistory.getAmountAllocation() != null)
                totalAllocationAmount = totalAllocationAmount.add(paymentScheduleHistory.getAmountAllocation());
            }
          }
          data.addItem(null, entry);
          data.addItems(entry, entry.getSubItems());
        }
    }

    TreeDataProvider<PaymentScheduleEntry>  dataProvider = new TreeDataProvider<>(data);
    treeGrid.setDataProvider(dataProvider);
    dataProvider.refreshAll();

    DecimalFormat formatter = new DecimalFormat("#,###.00");
    footer.join("installmentNo", "amount", "bankTransaction").setText("Total");
    footer.getCell("paymentAmount").setText(formatter.format(totalAmount.getNumber()));
    footer.getCell("amountAllocation").setText(formatter.format(totalAllocationAmount.getNumber()));
    return treeGrid;
  }

  public List<PaymentScheduleEntry> convertScheduleHistoryToEntry( List<PaymentScheduleHistory> subItems){
    List<PaymentScheduleEntry> paymentScheduleEntries = new ArrayList<>();
      for (PaymentScheduleHistory history: subItems){
        PaymentScheduleEntry paymentScheduleEntry = new PaymentScheduleEntry();
        paymentScheduleEntry.setContractNumber(history.getContractNumber());
        paymentScheduleEntry.setInstallmentAmount(history.getInstallmentAmount());
        paymentScheduleEntry.setInstallmentNumber(history.getInstallmentNumber());
        paymentScheduleEntry.setPaymentDate(history.getPaymentDate());
        paymentScheduleEntry.setAmountAllocation(history.getAmountAllocation());
        paymentScheduleEntry.setBankTransaction(history.getBankTransaction());
        paymentScheduleEntry.setPaymentAmount(history.getPaymentAmount());
        paymentScheduleEntry.setPaymentReference(history.getPaymentReference());
        paymentScheduleEntries.add(paymentScheduleEntry);
    }
    return paymentScheduleEntries;
  }

  private void constructTreeGrid() {
    treeGrid.setWidth(100.f, Unit.PERCENTAGE);
    treeGrid.addColumn(item -> item.getInstallmentNumber() == null ? EMPTY : item.getInstallmentNumber()).setId("installmentNo").setCaption("Installment No.")
            .setStyleGenerator(item -> ALIGN_RIGHT);

    treeGrid.addColumn(item -> item.getInstallmentAmount() != null? item.getInstallmentAmount() : EMPTY).setId("amount")
            .setCaption("Installment Amount").setStyleGenerator(item -> ALIGN_RIGHT).setRenderer(new MonetaryAmountRenderer());

    treeGrid.addColumn(item -> item.getBankTransaction()).setId("bankTransaction").setCaption("Bank Transaction").setStyleGenerator(item -> ALIGN_CENTER);

    treeGrid.addColumn(item -> item.getPaymentAmount()).setId("paymentAmount")
            .setCaption("Payment Amount").setStyleGenerator(item -> ALIGN_RIGHT).setRenderer(new MonetaryAmountRenderer());

    treeGrid.addColumn(item -> item.getAmountAllocation()!= null? item.getAmountAllocation() : EMPTY)
            .setCaption("Amount Allocation").setStyleGenerator(item -> ALIGN_RIGHT).setRenderer(new MonetaryAmountRenderer()).setId("amountAllocation");

    treeGrid.addColumn(item -> item.getPaymentDate() != null ? item.getPaymentDate() : EMPTY).setId("paymentDate").setCaption("Payment Date");

  }

  public void setContractNumber(String contractNumber){
    this.contractNumber = contractNumber;
    treeGrid.removeAllColumns();
    paymentGridLayout.addComponent(generateTreeGrid(contractNumber));
  
    PaymentScheduleHistory scheduleHistory = paymentScheduleHistoryRepository.findFirstByContractNumberOrderByLastPaymentDateDesc(contractNumber);
    String lastPaymentDate = scheduleHistory != null && scheduleHistory.getPaymentDate() != null ? "Payment update at " + LocalDateTimeFormat.formatLocalDate(scheduleHistory.getPaymentDate()) : "No payment date updated";
    paymentDate.setValue(lastPaymentDate);
  }


}
