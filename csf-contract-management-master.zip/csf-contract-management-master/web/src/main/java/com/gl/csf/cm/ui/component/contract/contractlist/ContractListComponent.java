package com.gl.csf.cm.ui.component.contract.contractlist;

import com.gl.csf.cm.api.contract.command.ActivateRevolvingLoanContractCommand;
import com.gl.csf.cm.api.contract.command.ActivateStandardLoanContractCommand;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.exception.InvalidContractDayException;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryEntry;
import com.gl.csf.cm.service.ContractService;
import com.gl.csf.cm.ui.component.contract.activation.ActivateContractComponentListener;
import com.gl.csf.cm.ui.component.contract.activation.ActivateRevolvingLoanComponent;
import com.gl.csf.cm.ui.component.contract.activation.ActivateStandardLoanComponent;
import com.gl.csf.cm.ui.dataprovider.ContractSummaryDataProvider;
import com.gl.csf.cm.ui.util.MonetaryAmountRenderer;
import com.gl.csf.cm.ui.viewdeclaration.UIScopeContractViews;
import com.vaadin.data.ValueProvider;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;

/**
 * Created by p.ly on 1/22/2018.
 */
@SpringComponent
@UIScope
public class ContractListComponent extends ContractListComponentDesign{
  private static final long serialVersionUID = 136998192022361832L;
  private final ConfigurableFilterDataProvider<ContractSummaryEntry, Void, ContractSummaryEntry> configurableFilterDataProvider;
  ContractSummaryEntry filterContractSummaryEntry;

  public ContractListComponent(ContractSummaryDataProvider contractSummaryDataProvider, ContractService contractService) {

      this.configurableFilterDataProvider = contractSummaryDataProvider.withConfigurableFilter();

      filterContractSummaryEntry = new ContractSummaryEntry();
      configurableFilterDataProvider.setFilter(filterContractSummaryEntry);

      contractGrid.setDataProvider(configurableFilterDataProvider);
      Grid.Column columnDueDate = contractGrid.getColumn("dueDate");
      columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());
      contractStatusComboBox.setDataProvider(new ListDataProvider<ContractStatus>(Arrays.asList(ContractStatus.values())));

      contractNumberTextField.addValueChangeListener(event -> {
        filterContractSummaryEntry.setContractNumber(contractNumberTextField.getValue());
        configurableFilterDataProvider.refreshAll();
      });

      businessNameTextField.addValueChangeListener(event -> {
        filterContractSummaryEntry.setBusinessName(businessNameTextField.getValue());
        configurableFilterDataProvider.refreshAll();
      });

      contractStatusComboBox.addValueChangeListener(event -> {
        if (event.getSource().getOptionalValue().isPresent()) {
          filterContractSummaryEntry.setContractStatus(event.getValue());
          configurableFilterDataProvider.refreshAll();
        }else{
          filterContractSummaryEntry.setContractStatus(null);
          configurableFilterDataProvider.refreshAll();
        }
      });

      clearAllButton.addClickListener(e->{
        clearCriteria();
      });

      contractGrid.addItemClickListener(clickEvent -> {
        if (clickEvent.getMouseEventDetails().isDoubleClick()) {
          UI.getCurrent().getNavigator().navigateTo(UIScopeContractViews.CONTRACT + "/contractid=" + clickEvent.getItem().getId()
            +"&contractno="+clickEvent.getItem().getContractNumber());
        }
      });

      contractGrid.getColumn("loanAmount").setRenderer(new MonetaryAmountRenderer());
      contractGrid.addColumn(contractSummaryEntry -> getPaymentAlertStatus(contractSummaryEntry.getDueDate())).setCaption("Payment alert").setId("paymentAlert");
      contractGrid.addColumn(contractSummaryEntry -> getOverDueDay(contractSummaryEntry.getDueDate())).setCaption("Overdue day").setId("overdueDate");
      contractGrid.addComponentColumn(createActivateColumn(contractService)).setCaption("Action").setId("action");
      contractGrid.setColumnOrder("contractNumber","contractStatus", "loanType", "loanAmount", "businessName", "term", "dueDate","paymentAlert", "overdueDate", "action", "rescheduleStatus", "writeoffStatus");
      contractGrid.setStyleGenerator(item -> {
        if (ContractStatus.CONTRACT_ACTIVATED.equals(item.getContractStatus())) {
          return "contract_activated";
        } else if (ContractStatus.CONTRACT_PENDING.equals(item.getContractStatus())) {
          return "contract_pending";
        } else if (ContractStatus.CLOSED.equals(item.getContractStatus())) {
          return "contract_closed";
        } else if (ContractStatus.CONTRACT_CANCELLED.equals(item.getContractStatus())) {
          return "contract_canceled";
        } else {
          return null;
        }
      });
    }

    private ValueProvider<ContractSummaryEntry, Button> createActivateColumn(ContractService contractService) {
      return contractSummaryEntry -> {

        if(contractSummaryEntry.getContractStatus() != ContractStatus.CONTRACT_PENDING){
          return null;
        }

        Button buttonActivate = new Button("Activate");
        buttonActivate.addStyleName("btn-activate borderless");
        buttonActivate.setWidth(110,Unit.PIXELS);
        buttonActivate.setHeight(30,Unit.PIXELS);

        buttonActivate.addClickListener(event -> {
          Window popupWindow;

          if (contractSummaryEntry.getLoanType().equals(ProductType.STANDARD_LOAN)) {
            ActivateStandardLoanComponent activateStandardLoanComponent = new ActivateStandardLoanComponent();
            popupWindow = activateStandardLoanComponent.displayConfiguration();

            activateStandardLoanComponent.setListener(new ActivateContractComponentListener() {
              @Override
              public void onClosed() {
                popupWindow.close();
              }

              @Override
              public void onCancelButtonClicked() {
                popupWindow.close();
              }

              @Override
              public void onConfirmButtonClicked() {
                try {
                  ActivateStandardLoanContractCommand activateStandardLoanContractCommand = new ActivateStandardLoanContractCommand(contractSummaryEntry.getId(), activateStandardLoanComponent.getContractDate());
                  contractService.activateStandardLoanContract(activateStandardLoanContractCommand);
                  configurableFilterDataProvider.refreshAll();
                  buttonActivate.setVisible(false);
                  popupWindow.close();
                } catch (InvalidContractDayException | RuntimeException e) {
                  Notification.show("Activating contract", e.getMessage(), Notification.Type.ERROR_MESSAGE);
                }
              }
            });

            popupWindow.setContent(activateStandardLoanComponent);
          } else {
            ActivateRevolvingLoanComponent activateRevolvingLoanComponent = new ActivateRevolvingLoanComponent();
            popupWindow = activateRevolvingLoanComponent.displayConfiguration();

            activateRevolvingLoanComponent.setListener(new ActivateContractComponentListener() {
              @Override
              public void onClosed() {
                popupWindow.close();
              }

              @Override
              public void onCancelButtonClicked() {
                popupWindow.close();
              }

              @Override
              public void onConfirmButtonClicked() {
                ActivateRevolvingLoanContractCommand activateRevolvingLoanContractCommand = new ActivateRevolvingLoanContractCommand(contractSummaryEntry.getId(),
                  activateRevolvingLoanComponent.getContractDate(), activateRevolvingLoanComponent.getFirstWithdrawalAmount());

                try {
                  contractService.activateRevolvingLoanContract(activateRevolvingLoanContractCommand);
                  configurableFilterDataProvider.refreshAll();
                  buttonActivate.setVisible(false);
                  popupWindow.close();
                } catch (InvalidContractDayException e) {
                  Notification.show("Activating Contract", e.getMessage(), Notification.Type.ERROR_MESSAGE);
                }
              }
            });
            popupWindow.setContent(activateRevolvingLoanComponent);
          }

          UI.getCurrent().addWindow(popupWindow);
        });

        return buttonActivate;
      };
    }

  private void clearCriteria(){
    contractNumberTextField.clear();
    businessNameTextField.clear();
    contractStatusComboBox.clear();
    filterContractSummaryEntry.setBusinessName(null);
    filterContractSummaryEntry.setContractNumber(null);
    filterContractSummaryEntry.setContractStatus(null);
    configurableFilterDataProvider.refreshAll();
  }

  private String getPaymentAlertStatus(LocalDate dueDate){
    if(dueDate == null)
      return "";

    int untilPaymentDay = Math.toIntExact(ChronoUnit.DAYS.between(LocalDate.now(), dueDate));
    if(untilPaymentDay > 7){
      return "";
    } else if (untilPaymentDay > 3 && untilPaymentDay <= 7) {
      return "-7d";
    } else if (untilPaymentDay > 0 && untilPaymentDay <= 3){
      return "-3d";
    } else if (untilPaymentDay == 0){
      return "dd";
    } else {
      return "ovd";
    }
  }

  private String getOverDueDay(LocalDate dueDate){
    if(dueDate == null)
      return "";
    int overdueDay = Math.toIntExact(ChronoUnit.DAYS.between(dueDate, LocalDate.now()));
    return overdueDay < 0 ? "" : overdueDay + "";
  }
}

