package com.gl.csf.cm.ui.view;

import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.ui.component.contract.contractinfo.ContractInformationComponent;
import com.gl.csf.cm.ui.component.paymentInformation.PaymentComponent;
import com.gl.csf.cm.ui.permission.Role;
import com.gl.csf.cm.ui.viewdeclaration.UIScopeContractViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;
import java.util.Map;


/**
 * Created by p.ly on 11/8/2017.
 */
@UIScope
@SpringComponent
@SpringView(name = UIScopeContractViews.CONTRACT)
@Secured({Role.OPERATION_STAFF, Role.OPERATION_MANAGER,Role.SL_MANAGER,Role.SL_STAFF})
public class ContractView extends ContractViewDesign implements View {

  private String contractId;
  private String contractNo;
  private final SessionScopeBus bus;
  private final static String CONTRACT_INFORMATION = "Contract information";
  private final static String PAYMENT_INFORMATION = "Payment information";
  private final ContractInformationComponent contractInformationComponent;
  private final PaymentComponent paymentComponent;

  public ContractView(SessionScopeBus bus, ContractInformationComponent contractInformationComponent, PaymentComponent paymentComponent) {
    this.bus = bus;
    this.contractInformationComponent = contractInformationComponent;
    this.paymentComponent = paymentComponent;
    contractTab.addSelectedTabChangeListener(e-> paymentComponent.reload());

    contractTab.addTab(contractInformationComponent,CONTRACT_INFORMATION);
    contractTab.addTab(paymentComponent,PAYMENT_INFORMATION);
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    Map<String, String> parameterMap = event.getParameterMap();
    this.contractId = parameterMap.getOrDefault("contractid", null);
    this.contractNo = parameterMap.getOrDefault("contractno", null);
    //reset tab for contract view
    contractTab.setSelectedTab(contractInformationComponent);
    paymentComponent.setContractNo(contractNo);
    contractInformationComponent.setDefaultTab();

    setContractIdByEventBus(this.contractId, this.contractNo);
  }

  public void setContractIdByEventBus(String contractId, String contractNo) {
    bus.post(new ContractSelectedEvent(contractId,contractNo)).now();
  }

}