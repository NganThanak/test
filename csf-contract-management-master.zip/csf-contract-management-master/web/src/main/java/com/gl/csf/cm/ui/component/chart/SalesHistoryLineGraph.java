package com.gl.csf.cm.ui.component.chart;

import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.model.*;
import com.vaadin.ui.Component;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kismong San (k.san@gl-f.com) on 8/18/2017.
 */
public class SalesHistoryLineGraph extends AbstractVaadinChart {

  @Override
  public String getDescription() {
    return "Basic Line With Data Labels";
  }

  @Override
  protected Component getChart() {
    Chart chart = new Chart();
    chart.setHeight("450px");
    chart.setWidth("100%");

    Configuration configuration = chart.getConfiguration();
    configuration.getChart().setType(ChartType.LINE);
    configuration.getChart().setMarginRight(130);
    configuration.getChart().setMarginBottom(25);

    configuration.getTitle().setText("");
    configuration.getSubTitle().setText("");

    configuration.getxAxis().setCategories("January", "February", "March");

    YAxis yAxis = configuration.getyAxis();
    yAxis.setMin(-5d);
    yAxis.setTitle(new AxisTitle("Currency ($) "));
    yAxis.getTitle().setAlign(VerticalAlign.MIDDLE);

    configuration
            .getTooltip()
            .setFormatter(
                    "'<b>Currency</b>: USD<br/><b>'+ this.series.name +'</b>" +
                            "<br/>'+this.x +': '+ this.y +'K<br/><a href=#>See more detail</a>'");

    PlotOptionsLine plotOptions = new PlotOptionsLine();
    plotOptions.getDataLabels().setEnabled(true);
    configuration.setPlotOptions(plotOptions);

    Legend legend = configuration.getLegend();
    legend.setLayout(LayoutDirection.VERTICAL);
    legend.setAlign(HorizontalAlign.RIGHT);
    legend.setVerticalAlign(VerticalAlign.TOP);
    legend.setX(-10d);
    legend.setY(100d);
    legend.setBorderWidth(0);

    ListSeries ls = new ListSeries();
    ls.setName("Branch C");
    ls.setData(7.0, 6.9, 9.5);
    configuration.addSeries(ls);
    ls = new ListSeries();
    ls.setName("Branch B");
    ls.setData(-0.2, 0.8, 5.7);
    configuration.addSeries(ls);
    ls = new ListSeries();
    ls.setName("Branch A");
    ls.setData(-0.9, 0.6, 3.5);
    configuration.addSeries(ls);


    chart.drawChart(configuration);
    return chart;
  }

}