package com.gl.csf.cm.ui.component.contract.loaninformation;

import com.gl.csf.cm.common.model.lessee.StaffLoanPurpose;
import com.gl.csf.cm.query.contract.contractsummary.ContractStaffLoanSummaryEntry;
import com.gl.csf.cm.query.contract.contractsummary.ContractStaffLoanSummaryRepository;
import com.gl.csf.cm.query.contract.product.StaffLoanProductEntry;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.ui.util.StringToMonetaryConverter;
import com.gl.csf.cm.ui.util.excel.PaymentScheduleExcelBuilder;
import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToBigDecimalConverter;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

/**
 * Created by p.ly on 1/25/2018.
 */
@SpringComponent
@UIScope
public class StaffLoanInformationDetailComponent extends StaffLoanInformationDetailComponentDesign{

  private final Grid<Installment> paymentGrid = new Grid<>();
  private final Binder<StaffLoanProductEntry> loanProductEntryBinder;
  private static ContractStaffLoanSummaryRepository contractStaffLoanSummaryRepository;
  private static final String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private static final String PAYMENT_SIMULATION_PATH = BASE_PATH + "/payment-simulation/download";

  private static final Set<Integer> prohibitedDates = new HashSet<>(Arrays.asList(29, 30, 31));

  public StaffLoanInformationDetailComponent(ContractStaffLoanSummaryRepository contractStaffLoanSummaryRepository) {
    this.contractStaffLoanSummaryRepository = contractStaffLoanSummaryRepository;
    loanProductEntryBinder = createUpdateProductInformationBinder();
    gridLayout.addComponent(paymentGrid);
    paymentGrid.setWidth(100, Unit.PERCENTAGE);
  
    buttonExportToExcel.addClickListener(clickEvent -> {
      PaymentScheduleExcelBuilder.setInstallment(generatePaymentSchedule(loanProductEntryBinder.getBean()));
      PaymentScheduleExcelBuilder.setLoanType(loanProductEntryBinder.getBean().getLoanType().getValue());
      PaymentScheduleExcelBuilder.setCustomer(loanProductEntryBinder.getBean().getId());
      Page.getCurrent().open(PAYMENT_SIMULATION_PATH, "_blank");
    });

    initPaymentGridColumn();
  }

  void setLoanProduct(StaffLoanProductEntry staffLoanProductEntry){
    loanProductEntryBinder.setBean(staffLoanProductEntry);
    paymentGrid.setDataProvider(createInstallmentDataProvider(loanProductEntryBinder.getBean()));
    loanPurposeItemLayout.removeAllComponents();
    staffLoanProductEntry.getStaffLoanPurposes().forEach(staffLoanPurpose -> loanPurposeItemLayout.addComponent(createLoanPurposeItemComponent(staffLoanPurpose)));
  }

  private static ListDataProvider<Installment> createInstallmentDataProvider(StaffLoanProductEntry loanProductEntry) {
    return new ListDataProvider<>(generatePaymentSchedule(loanProductEntry));
  }

  private Binder<StaffLoanProductEntry> createUpdateProductInformationBinder() {
    Binder<StaffLoanProductEntry> result = new BeanValidationBinder<>(StaffLoanProductEntry.class);
    result.bind(textFieldID, "id");
    result.forField(comboBoxTerm).asRequired("Term").bind("term");
    result.forField(comboBoxLoanType).asRequired("Loan type").bind("loanType");
    result.forField(textFieldLoanAmount).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("loanAmount");

    result.forField(comboBoxPaymentFrequency).asRequired("Payment frequency").bind("paymentFrequency");
    result.forField(textFieldInterestRate).withConverter(new StringToBigDecimalConverter("Must be number")).bind("interestRate");
    return result;
  }

  private static List<Installment> generatePaymentSchedule(StaffLoanProductEntry productInformation){
    if(productInformation.getLoanAmount() == null || productInformation.getTerm() == null || productInformation.getPaymentFrequency() == null || productInformation.getInterestRate() == null)
      return new ArrayList<>();
    ContractStaffLoanSummaryEntry contractSummaryEntry = contractStaffLoanSummaryRepository.findOne(productInformation.getContractId());

    LocalDate dueDate = LocalDate.now();
    if(contractSummaryEntry.getDueDate() == null) {
      if (prohibitedDates.contains(LocalDate.now().getDayOfMonth()))
        dueDate = LocalDate.now().plusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
    }else {
      dueDate = contractSummaryEntry.getDueDate();
    }

    LoanParameter param = LoanParameterBuilder.createBuilder().numberOfCompoundingPeriods(productInformation.getPaymentFrequency().getValue())
      .loanAmount(productInformation.getLoanAmount())
      .loanTerm(productInformation.getTerm().doubleValue() / 12.0)
      .nominalInterestRate((productInformation.getInterestRate().doubleValue() * 12) / 100)
      .dueDate(dueDate)
      .scale(10)
      .dueDateMode(LoanParameter.DueDateMode.END_OF_MONTH)
      .build();

    return new SimpleAmortization().generatePaymentSchedule(param);
  }

  private void initPaymentGridColumn(){
    paymentGrid.addColumn(Installment::getInstallmentNumber).setCaption("Period");
    paymentGrid.addColumn(installment -> installment.getAmount().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Installment");
    paymentGrid.addColumn(installment -> installment.getPrincipal().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Principal");
    paymentGrid.addColumn(installment -> installment.getInterest().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Interest");
    paymentGrid.addColumn(installment -> installment.getEndBalance().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()).setCaption("Remaining Balance");

  }

  private Component createLoanPurposeItemComponent(StaffLoanPurpose loanPurpose) {
    CssLayout loanPurposeItem = new CssLayout();
    loanPurposeItem.setWidth(100, Unit.PERCENTAGE);
    loanPurposeItem.setHeight(50, Unit.PIXELS);
    loanPurposeItem.setStyleName("loan-purpose-item-layout");

    Label purposeLabel = new Label();
    purposeLabel.setStyleName("loan-purpose-item-label");
    purposeLabel.setValue(loanPurpose.getPurpose());

    Button deletePurposeItem = new Button();
    deletePurposeItem.setIcon(VaadinIcons.TRASH);
    deletePurposeItem.setStyleName("loan-purpose-item-delete-button borderless");
    deletePurposeItem.setId("deleteIcon");
    deletePurposeItem.setEnabled(false);
    //TODO will be refactor
    deletePurposeItem.addClickListener(event -> {
      loanPurposeItemLayout.removeComponent(loanPurposeItem);

    });

    loanPurposeItem.addComponent(purposeLabel);
    loanPurposeItem.addComponent(deletePurposeItem);
    return loanPurposeItem;
  }
}
