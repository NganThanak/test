package com.gl.csf.cm.ui.dataprovider;

import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.query.contract.contractsummary.ContractStaffLoanSummaryEntry;
import com.gl.csf.cm.query.contract.contractsummary.ContractStaffLoanSummaryRepository;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryRepository;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.vaadin.spring.annotation.SpringComponent;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Pageable;

import javax.inject.Inject;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created by p.ly on 11/15/2017.
 */
@SpringComponent
public class ContractStaffLoanSummaryDataProvider extends AbstractBackEndDataProvider<ContractStaffLoanSummaryEntry, ContractStaffLoanSummaryEntry> {
  /**
  *
  */
  private static final long serialVersionUID = 6663752771813910634L;
  
  private final ContractStaffLoanSummaryRepository repository;
  
  private static final ExampleMatcher exampleMatcher = ExampleMatcher.matching()
    .withMatcher("contractNumber", match -> match.contains().ignoreCase())
    .withMatcher("contract_status", match -> match.contains().ignoreCase())
    .withMatcher("businessName", match->match.contains().ignoreCase())
    .withMatcher("loanType", match-> match.equals(ProductType.STAFF_LOAN))
    .withIgnorePaths("reschedule_status", "writeoff_status", "reference_number", "loan_type", "loan_amount", "term", "dueDate", "paymentAlert", "overdueDay");

  @Inject
  public ContractStaffLoanSummaryDataProvider(ContractStaffLoanSummaryRepository repository){
    this.repository = repository;
  }

  @Override
  protected Stream<ContractStaffLoanSummaryEntry> fetchFromBackEnd(Query<ContractStaffLoanSummaryEntry, ContractStaffLoanSummaryEntry> query) {
    Optional<ContractStaffLoanSummaryEntry> filter = query.getFilter();
    Pageable pageable = DataProviderHelper.createPageable(query);

    return filter.map(contractSummaryEntry ->
            StreamSupport.stream(repository.findAll(Example.of(contractSummaryEntry, exampleMatcher), pageable).spliterator(), true))
            .orElseGet(Stream::empty);
  }

  @Override
  protected int sizeInBackEnd(Query<ContractStaffLoanSummaryEntry, ContractStaffLoanSummaryEntry> query) {
    Optional<ContractStaffLoanSummaryEntry> filter = query.getFilter();
    return filter.map(contractSummaryEntry -> Math.toIntExact(repository.count(Example.of(contractSummaryEntry, exampleMatcher))))
            .orElse(0);
  }
}
