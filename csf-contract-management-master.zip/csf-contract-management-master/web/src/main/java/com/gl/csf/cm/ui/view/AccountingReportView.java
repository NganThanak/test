package com.gl.csf.cm.ui.view;

import com.gl.csf.cm.ui.permission.Role;
import com.gl.csf.cm.ui.viewdeclaration.UIScopeContractViews;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.annotation.UIScope;
import org.springframework.security.access.annotation.Secured;

import javax.inject.Inject;

/**
 * Created by p.ly on 11/21/2017.
 */
@SpringComponent
@UIScope
@SpringView(name = UIScopeContractViews.REPORT)
@Secured({Role.OPERATION_STAFF, Role.OPERATION_MANAGER,Role.SL_MANAGER,Role.SL_STAFF})
public class AccountingReportView extends AccountingReportViewDesign implements View{

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
    interestReportByContractComponent.clearReportItem();
  }
}
