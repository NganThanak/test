package com.gl.csf.cm.ui.report;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationEntry;
import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationRepository;
import com.gl.csf.cm.query.contract.contractcancel.ContractCancelRepository;
import com.gl.csf.cm.ui.permission.Role;
import com.gl.csf.cm.ui.util.ProductTypeUtil;
import com.gl.csf.cm.ui.util.excel.AccountClosingReportExcelBuilder;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.vaadin.spring.security.VaadinSecurity;

import static java.time.temporal.ChronoUnit.YEARS;


/**
 * Created by p.ly on 11/21/2017.
 */
@SpringComponent
@UIScope
public class AccountingClosingReportComponent extends AccountingClosingReportComponentDesign{

  /**
	 * 
	 */
  private static final long serialVersionUID = 712659258843637057L;
  
  private final Binder<ContractPeriodInterestRealizationEntry> filterBinder;
  private String loanType = "All";
  private List<ProductType> productTypes = new ArrayList<>();

  public AccountingClosingReportComponent(ContractPeriodInterestRealizationRepository repository, VaadinSecurity vaadinSecurity, ContractCancelRepository contractCancelRepository) {
    searchButton.setEnabled(false);
    
    if (vaadinSecurity.hasAnyAuthority(Role.OPERATION_MANAGER, Role.OPERATION_STAFF)) {
    	productTypes.addAll(ProductTypeUtil.getBySMERole());
    }
    if (vaadinSecurity.hasAnyAuthority(Role.SL_STAFF, Role.SL_MANAGER)) {
    	productTypes.addAll(ProductTypeUtil.getByStaffLoanRole());
    }    
    loantypeComboBox.setDataProvider(new ListDataProvider<ProductType>(productTypes));
    
    filterBinder = filterBinder();
    filterBinder.addStatusChangeListener(event -> searchButton.setEnabled(event.getBinder().isValid()));

    searchButton.setEnabled(false);
    reportItemLayout.setHeight(600, Unit.PERCENTAGE);
    loantypeComboBox.addValueChangeListener(event -> {
      if (event.getSource().getOptionalValue().isPresent())
        loanType = event.getValue().toString();
      else
        loanType= "All";
    });

    clearallButton.addClickListener(clickEvent -> {
      filterBinder.setBean(new ContractPeriodInterestRealizationEntry());
      loantypeComboBox.setSelectedItem(null);
      reportItemLayout.removeAllComponents();
    });
    fromDate.setDateFormat("MM/yyyy");
    toDate.setDateFormat("MM/yyyy");
    fromDate.addValueChangeListener(event->{
      toDate.clear();
    });

    searchButton.addClickListener(clickEvent -> {
      reportItemLayout.removeAllComponents();
      List<ContractPeriodInterestRealizationEntry> contractPeriodInterestRealizationGroupByDate = new ArrayList<>();
      if (loanType.equalsIgnoreCase("All")){
    	List<ContractPeriodInterestRealizationEntry> entryList = repository.findAllByEndOfMonthDateBetween(fromDate.getValue().with(TemporalAdjusters.lastDayOfMonth()), toDate.getValue().with(TemporalAdjusters.lastDayOfMonth()));
        if (!entryList.isEmpty() && vaadinSecurity.hasAnyAuthority(Role.OPERATION_MANAGER, Role.OPERATION_STAFF)) {
        	contractPeriodInterestRealizationGroupByDate.addAll(entryList.stream()
        		.filter(ProductTypeUtil::isSMEProduct)
        		.collect(Collectors.toList()));
        }
        if (!entryList.isEmpty() && !entryList.isEmpty() && vaadinSecurity.hasAnyAuthority(Role.SL_STAFF, Role.SL_MANAGER)) {
        	contractPeriodInterestRealizationGroupByDate.addAll(entryList.stream()
            		.filter(ProductTypeUtil::isStaffLoanProduct)
            		.collect(Collectors.toList()));
        }
      } else{
        contractPeriodInterestRealizationGroupByDate = repository.findAllByEndOfMonthDateBetweenAndProductType(fromDate.getValue().with(TemporalAdjusters.lastDayOfMonth()), toDate.getValue().with(TemporalAdjusters.lastDayOfMonth()),
                loantypeComboBox.getSelectedItem().get());
      }

      if(!contractPeriodInterestRealizationGroupByDate.isEmpty()) {
    	contractPeriodInterestRealizationGroupByDate = contractPeriodInterestRealizationGroupByDate.stream()
    			.filter(record -> !contractCancelRepository.findByContractIDAndContractStatus(record.getContractId(), ContractStatus.CONTRACT_CANCELLED).isPresent())
    			.collect(Collectors.toList());
    	AccountClosingReportExcelBuilder.setContractPeriodInterestRealizationEntrys(contractPeriodInterestRealizationGroupByDate);
        AccountClosingReportExcelBuilder.setClosingReportFrom(fromDate.getValue().toString());
        AccountClosingReportExcelBuilder.setClosingReportTo(toDate.getValue().toString());
        AccountClosingReportExcelBuilder.setProductLoanType(loanType);
        reportItemLayout.addComponent(new AccountingClosingReportItemComponent(fromDate.getValue(), toDate.getValue(), loanType));
      }
    });
  }

  private Binder<ContractPeriodInterestRealizationEntry>  filterBinder(){
    Binder<ContractPeriodInterestRealizationEntry> result = new BeanValidationBinder<>(ContractPeriodInterestRealizationEntry.class);
    result.forField(fromDate).asRequired("From date").bind("endOfMonthDate");
    result.forField(toDate).asRequired("To date is required.").withValidator(todate -> todate.compareTo(fromDate.getValue()) > 0, "To date must be greater than From date").withValidator(d -> YEARS.between(fromDate.getValue(), d) < 2, "From to To date must between 2 years").bind("dueDate");
    return result;
  }
}
