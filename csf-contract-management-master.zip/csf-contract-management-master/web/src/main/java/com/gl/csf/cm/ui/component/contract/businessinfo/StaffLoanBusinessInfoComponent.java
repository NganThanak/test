package com.gl.csf.cm.ui.component.contract.businessinfo;

import com.gl.csf.cm.query.contract.staff.StaffFinancialStatementEntry;
import com.gl.csf.cm.query.contract.staff.StaffFinancialStatementRepository;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.ui.util.StringToMonetaryConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToBigDecimalConverter;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

/**
 * Created by p.ly on 1/24/2018.
 */
@SpringComponent
@UIScope
public class StaffLoanBusinessInfoComponent extends StaffLoanBusinessInfoComponentDesign{
  private final Binder<StaffFinancialStatementEntry> financialStatementEntryBinder;
  private final StaffFinancialStatementRepository staffFinancialStatementRepository;
  private String contractId;
  public StaffLoanBusinessInfoComponent(StaffFinancialStatementRepository staffFinancialStatementRepository) {
    this.staffFinancialStatementRepository = staffFinancialStatementRepository;
    this.financialStatementEntryBinder = createLesseeBankAccountInformationBinder();
  }
  private Binder<StaffFinancialStatementEntry> createLesseeBankAccountInformationBinder(){
    Binder<StaffFinancialStatementEntry> result = new BeanValidationBinder<>(StaffFinancialStatementEntry.class);
    result.forField(monthlySalaryTextField).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("monthlySalary");
    result.forField(annualSalaryTextField).withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY)).bind("annualSalary");
    result.forField(financialRatioTextField).withConverter(new StringToBigDecimalConverter("Must be number")).bind("financialRatio");
    return result;
  }
  
  private void fetchData() {
    financialStatementEntryBinder.setBean(staffFinancialStatementRepository.findOne(contractId));
  }
  
  public void setContractId(String contractId){
    this.contractId = contractId;
    fetchData();
  }
}
