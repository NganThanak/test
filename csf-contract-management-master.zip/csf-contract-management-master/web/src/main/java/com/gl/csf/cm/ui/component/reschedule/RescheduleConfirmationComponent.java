package com.gl.csf.cm.ui.component.reschedule;

import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/8/2017.
 */
@UIScope
@SpringComponent
public class RescheduleConfirmationComponent extends RescheduleConfirmationComponentDesign{

}
