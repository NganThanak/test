package com.gl.csf.cm.ui.component.contract.activation;

import com.vaadin.ui.Window;

import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 11/16/2017.
 */
public class ActivateStandardLoanComponent extends ActivateStandardLoanComponentDesign {

	private ActivateContractComponentListener listener;

	public ActivateStandardLoanComponent() {
		closeButton.addClickListener(e -> {
			if(listener != null)
				listener.onClosed();
		});
		buttonCancel.addClickListener(e -> {
			if(listener != null)
				listener.onCancelButtonClicked();
		});
		buttonConfirm.addClickListener(e -> {
			if(listener != null)
				listener.onConfirmButtonClicked();
		});

		buttonConfirm.setEnabled(false);
		contractDate.addValueChangeListener(e-> buttonConfirm.setEnabled(e.getValue() != null));
	}

	public ActivateContractComponentListener getListener() {
		return listener;
	}

	public void setListener(ActivateContractComponentListener listener) {
		this.listener = listener;
	}

	public Window displayConfiguration() {
		Window window = new Window();
		window.center();
		window.removeAllCloseShortcuts();
		window.setResizable(false);
		window.setClosable(false);
		window.setModal(true);
		window.setWidth(600, Unit.PIXELS);
		return window;
	}

	public LocalDate getContractDate(){
		return contractDate.getValue();
	}
}
