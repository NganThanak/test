package com.gl.csf.cm.ui.component.contract.loaninformation;

import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.product.StaffLoanProductEntry;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Button;
import com.vaadin.ui.components.grid.ItemClickListener;
import net.engio.mbassy.listener.Handler;
import net.engio.mbassy.listener.Listener;

import javax.inject.Inject;

/**
 * Created by p.ly on 1/24/2018.
 */
@UIScope
@SpringComponent
@Listener
public class StaffLoanInfoComponent extends StaffLoanInfoComponentDesign{

  private String contractId;
  private final SessionScopeBus bus;

  @Inject
  StaffLoanInfoComponent(SessionScopeBus bus) {
    this.bus = bus;

    staffLoanInformationComponent.setVisible(true);
    staffloanInformationDetailComponent.setVisible(false);

    staffLoanInformationComponent.loanInformationGrid.addItemClickListener((ItemClickListener<StaffLoanProductEntry>) itemClick -> {
      if(itemClick.getMouseEventDetails().isDoubleClick()){
        staffLoanInformationComponent.setVisible(false);
        staffloanInformationDetailComponent.setVisible(true);
        staffloanInformationDetailComponent.setLoanProduct(itemClick.getItem());
      }
    });

    staffloanInformationDetailComponent.backToListButton.addClickListener((Button.ClickListener) clickEvent -> {
      staffLoanInformationComponent.setVisible(true);
      staffloanInformationDetailComponent.setVisible(false);
    });
  }

  public void setContractId(String contractId){
    this.contractId = contractId;
    staffLoanInformationComponent.setContractId(contractId);
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  @Handler
  public void handle(ContractSelectedEvent event){
    staffLoanInformationComponent.setVisible(true);
    staffloanInformationDetailComponent.setVisible(false);
  }
}
