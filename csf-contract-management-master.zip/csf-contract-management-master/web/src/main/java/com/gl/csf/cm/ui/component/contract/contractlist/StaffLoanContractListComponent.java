package com.gl.csf.cm.ui.component.contract.contractlist;

import com.gl.csf.cm.api.contract.command.ActivateStaffLoanContractCommand;
import com.gl.csf.cm.api.contract.command.ActivateStandardLoanContractCommand;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.exception.InvalidContractDayException;
import com.gl.csf.cm.query.contract.contractsummary.ContractStaffLoanSummaryEntry;
import com.gl.csf.cm.service.ContractService;
import com.gl.csf.cm.ui.component.contract.activation.ActivateContractComponentListener;
import com.gl.csf.cm.ui.component.contract.activation.ActivateStandardLoanComponent;
import com.gl.csf.cm.ui.dataprovider.ContractStaffLoanSummaryDataProvider;
import com.gl.csf.cm.ui.util.MonetaryAmountRenderer;
import com.gl.csf.cm.ui.viewdeclaration.UIScopeContractViews;
import com.vaadin.data.ValueProvider;
import com.vaadin.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.data.provider.ListDataProvider;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.*;

import java.util.Arrays;

/**
 * Created by p.ly on 1/22/2018.
 */
@SpringComponent
@UIScope
public class StaffLoanContractListComponent extends StaffLoanContractListComponentDesign{
  private static final long serialVersionUID = 136998192022361832L;
  private final ConfigurableFilterDataProvider<ContractStaffLoanSummaryEntry, Void, ContractStaffLoanSummaryEntry> configurableFilterDataProvider;
  ContractStaffLoanSummaryEntry filterContractSummaryEntry;
  private final static String ACTION = "Action";

  public StaffLoanContractListComponent(ContractStaffLoanSummaryDataProvider contractSummaryDataProvider,ContractService contractService) {
    this.configurableFilterDataProvider = contractSummaryDataProvider.withConfigurableFilter();
    filterContractSummaryEntry = new ContractStaffLoanSummaryEntry();
    configurableFilterDataProvider.setFilter(filterContractSummaryEntry);
    contractGrid.setDataProvider(configurableFilterDataProvider);
    contractStatusComboBox.setDataProvider(new ListDataProvider<ContractStatus>(Arrays.asList(ContractStatus.values())));
  
    contractNumberTextField.addValueChangeListener(event -> {
      filterContractSummaryEntry.setContractNumber(contractNumberTextField.getValue());
      configurableFilterDataProvider.refreshAll();
    });
  
    staffFullNameTextField.addValueChangeListener(event -> {
      filterContractSummaryEntry.setStaffName(staffFullNameTextField.getValue());
      configurableFilterDataProvider.refreshAll();
    });
  
    contractStatusComboBox.addValueChangeListener(event -> {
      if (event.getSource().getOptionalValue().isPresent()) {
        filterContractSummaryEntry.setContractStatus(event.getValue());
        configurableFilterDataProvider.refreshAll();
      }else{
        filterContractSummaryEntry.setContractStatus(null);
        configurableFilterDataProvider.refreshAll();
      }
    });
  
    clearAllButton.addClickListener(e->{
      clearCriteria();
    });
  
    contractGrid.addItemClickListener(clickEvent -> {
      if (clickEvent.getMouseEventDetails().isDoubleClick()) {
        UI.getCurrent().getNavigator().navigateTo(UIScopeContractViews.STAFF_LOAN + "/contractid=" + clickEvent.getItem().getId()
                +"&contractno="+clickEvent.getItem().getContractNumber());
      }
    });

    //generate active button
    contractGrid.addComponentColumn(createActivateColumn(contractService)).setCaption(ACTION).setId("action");
    contractGrid.getColumn("loanAmount").setRenderer(new MonetaryAmountRenderer());
    contractGrid.setColumnOrder("contractNumber","contractStatus", "loanType", "loanAmount", "staffName", "term", "dueDate", "action", "rescheduleStatus", "writeoffStatus");
  
    Grid.Column columnDueDate = contractGrid.getColumn("dueDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());
    
    contractGrid.setStyleGenerator(item -> {
      if (ContractStatus.CONTRACT_ACTIVATED.equals(item.getContractStatus())) {
        return "contract_activated";
      } else if (ContractStatus.CONTRACT_PENDING.equals(item.getContractStatus())) {
        return "contract_pending";
      } else if (ContractStatus.CLOSED.equals(item.getContractStatus())) {
        return "contract_closed";
      } else if (ContractStatus.CONTRACT_CANCELLED.equals(item.getContractStatus())) {
        return "contract_canceled";
      } else {
        return null;
      }
    });
  }
  private void clearCriteria(){
    contractNumberTextField.clear();
    staffFullNameTextField.clear();
    contractStatusComboBox.clear();
    filterContractSummaryEntry.setStaffName(null);
    filterContractSummaryEntry.setContractNumber(null);
    filterContractSummaryEntry.setContractStatus(null);
    configurableFilterDataProvider.refreshAll();
  }


  private ValueProvider<ContractStaffLoanSummaryEntry, Button> createActivateColumn(ContractService contractService) {
    return contractSummaryEntry -> {

      if(contractSummaryEntry.getContractStatus() != ContractStatus.CONTRACT_PENDING){
        return null;
      }

      Button buttonActivate = new Button("Activate");
      buttonActivate.addStyleName("btn-activate borderless");
      buttonActivate.setWidth(110,Unit.PIXELS);
      buttonActivate.setHeight(30,Unit.PIXELS);

      buttonActivate.addClickListener(event -> {
        Window popupWindow;

        ActivateStandardLoanComponent activateStandardLoanComponent = new ActivateStandardLoanComponent();
        popupWindow = activateStandardLoanComponent.displayConfiguration();

        activateStandardLoanComponent.setListener(new ActivateContractComponentListener() {
          @Override
          public void onClosed() {
            popupWindow.close();
          }

          @Override
          public void onCancelButtonClicked() {
            popupWindow.close();
          }

          @Override
          public void onConfirmButtonClicked() {
            try {
              ActivateStaffLoanContractCommand activateStandardLoanContractCommand = new ActivateStaffLoanContractCommand(contractSummaryEntry.getId(), activateStandardLoanComponent.getContractDate());
              contractService.activateStaffLoanContract(activateStandardLoanContractCommand);
              configurableFilterDataProvider.refreshAll();
              buttonActivate.setVisible(false);
              popupWindow.close();
            } catch (InvalidContractDayException | RuntimeException e) {
              Notification.show("Activating contract", e.getMessage(), Notification.Type.ERROR_MESSAGE);
            }
          }

        });

        popupWindow.setContent(activateStandardLoanComponent);
        UI.getCurrent().addWindow(popupWindow);
      });

      return buttonActivate;
    };
  }
}
