package com.gl.csf.cm.ui.util.excel;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/26/2018.
 */
public abstract class CustomAbstractXlsxStreamingView extends AbstractXlsxView {

  private int maxAccessWindowSize;

  public CustomAbstractXlsxStreamingView(int maxAccessWindowSize) {
    this.maxAccessWindowSize = maxAccessWindowSize;
  }

  protected SXSSFWorkbook createWorkbook(Map<String, Object> model, HttpServletRequest request) {
    return new SXSSFWorkbook(this.maxAccessWindowSize);
  }

  protected void renderWorkbook(Workbook workbook, HttpServletResponse response) throws IOException {
    super.renderWorkbook(workbook, response);
    ((SXSSFWorkbook)workbook).dispose();
  }
}
