package com.gl.csf.cm.service;

import com.gl.csf.cm.api.contract.command.ActivateRevolvingLoanContractCommand;
import com.gl.csf.cm.api.contract.command.ActivateStaffLoanContractCommand;
import com.gl.csf.cm.api.contract.command.ActivateStandardLoanContractCommand;
import com.gl.csf.cm.exception.InvalidContractDayException;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/11/2017.
 */
@Component
public class ContractService {
  private final CommandGateway commandGateway;
  private final Set<Integer> prohibitedDates = new HashSet<>(Arrays.asList(29, 30, 31));
  private final String PROHIBITED_DATE_ERROR_MESSAGE = "Cannot activate contract in: 29, 30, 31";
  @Inject
  public ContractService(CommandGateway commandGateway){
    this.commandGateway = commandGateway;
  }

  public void activateStandardLoanContract(ActivateStandardLoanContractCommand command) throws InvalidContractDayException {
    int dayOfMonth = command.getContractDate().getDayOfMonth();
    if(prohibitedDates.contains(dayOfMonth))
      throw new InvalidContractDayException(PROHIBITED_DATE_ERROR_MESSAGE);
    commandGateway.sendAndWait(command);
  }

  public void activateRevolvingLoanContract(ActivateRevolvingLoanContractCommand command) throws InvalidContractDayException {
    int dayOfMonth = command.getContractDate().getDayOfMonth();
    if(prohibitedDates.contains(dayOfMonth))
      throw new InvalidContractDayException(PROHIBITED_DATE_ERROR_MESSAGE);
    commandGateway.sendAndWait(command);
  }
  
  public void activateStaffLoanContract(ActivateStaffLoanContractCommand command) throws InvalidContractDayException{
    commandGateway.sendAndWait(command);
  }
}
