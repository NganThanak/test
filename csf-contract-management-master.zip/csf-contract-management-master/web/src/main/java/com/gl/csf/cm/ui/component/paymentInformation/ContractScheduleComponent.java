package com.gl.csf.cm.ui.component.paymentInformation;

import com.gl.csf.cm.common.util.LocalDateTimeFormat;
import com.gl.csf.cm.message.ContractSelectedEvent;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.util.MoneyUtils;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleEntry;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleRepository;
import com.gl.csf.cm.ui.util.MonetaryAmountRenderer;
import com.vaadin.data.provider.AbstractBackEndDataProvider;
import com.vaadin.data.provider.Query;
import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Grid;
import com.vaadin.ui.components.grid.FooterCell;
import com.vaadin.ui.components.grid.FooterRow;
import com.vaadin.ui.components.grid.HeaderRow;
import net.engio.mbassy.listener.Handler;
import org.javamoney.moneta.Money;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import javax.money.format.AmountFormatQueryBuilder;
import javax.money.format.MonetaryAmountFormat;
import javax.money.format.MonetaryFormats;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * Created by p.ly on 12/8/2017.
 */
@SpringComponent
@UIScope
public class ContractScheduleComponent extends ContractScheduleComponentDesign {
  private static final String EMPTY = "";
  private static ContractScheduleRepository repository;
  private final SessionScopeBus bus;
  private String contractNo;
  private final FooterRow footer = contractScheduleGrid.appendFooterRow();
  private FooterCell footerCellPaymentInstallment;
  private FooterCell footerCellPaymentPrinciple;
  private FooterCell footerCellPaymentInterest;
  private FooterCell footerCellPaymentMonthlyPenalty;
  private List<ContractScheduleEntry> contractScheduleEntries = new ArrayList<>();
  private Double outstandingAmount;

  @Inject
  ContractScheduleComponent(ContractScheduleRepository repository, SessionScopeBus bus) {
    this.repository = repository;
    this.bus = bus;

    // Schedule section
    contractScheduleGrid.addColumn(contractScheduleEntry -> contractScheduleEntry.getScheduleInstallmentAmount().getNumber().doubleValueExact()).setId("scheduleInstallmentAmount")
            .setCaption("Installment Amount");
    contractScheduleGrid.addColumn(contractScheduleEntry -> contractScheduleEntry.getScheduleDueDate()).setId("scheduleDueDate")
            .setCaption("Due Date");
    contractScheduleGrid.addColumn(contractScheduleEntry -> contractScheduleEntry.getSchedulePrinciple().getNumber().doubleValueExact()).setId("schedulePrinciple")
            .setCaption("Principal");
    contractScheduleGrid.addColumn(contractScheduleEntry -> contractScheduleEntry.getScheduleInterest().getNumber().doubleValueExact()).setId("scheduleInterest")
            .setCaption("Interest");

    // Payment split section
    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double paymentInstallment = null;
      // if today is due date or over due date this field will display
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        paymentInstallment = contractScheduleEntry.getPaymentInstallment().getNumber().doubleValueExact();
      }
      // if customer is paid, this field will display
      else if (contractScheduleEntry.getPaymentDate() != null) {
        paymentInstallment = contractScheduleEntry.getPaymentInstallment().getNumber().doubleValueExact();
      }
      return paymentInstallment;
    }).setId("paymentInstallment").setCaption("Installment Paid");

    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double paymentPrinciple = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        paymentPrinciple = contractScheduleEntry.getPaymentPrinciple().getNumber().doubleValueExact();
      } else if (contractScheduleEntry.getPaymentDate() != null) {
        paymentPrinciple = contractScheduleEntry.getPaymentPrinciple().getNumber().doubleValueExact();
      }
      return paymentPrinciple;
    }).setId("paymentPrinciple").setCaption("Principal");

    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double paymentInterest = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        paymentInterest = contractScheduleEntry.getPaymentInterest().getNumber().doubleValueExact();
      } else if (contractScheduleEntry.getPaymentDate() != null) {
        paymentInterest = contractScheduleEntry.getPaymentInterest().getNumber().doubleValueExact();
      }
      return paymentInterest;
    }).setId("paymentInterest").setCaption("Interest");

    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double paymentPenalty = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        paymentPenalty = contractScheduleEntry.getPaymentMonthlyPenalty().getNumber().doubleValueExact();
      } else if (contractScheduleEntry.getPaymentDate() != null) {
        paymentPenalty = contractScheduleEntry.getPaymentMonthlyPenalty().getNumber().doubleValueExact();
      }
      return paymentPenalty;
    }).setId("paymentMonthlyPenalty").setCaption("Monthly Penalty");

    // Fee
    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double fee = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        fee = contractScheduleEntry.getFee().getNumber().doubleValueExact();
      } else if (contractScheduleEntry.getPaymentDate() != null) {
        fee = contractScheduleEntry.getFee().getNumber().doubleValueExact();
      }
      return fee;
    }).setId("fee").setCaption("Fee");

    // Vat
    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double vat = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        vat = contractScheduleEntry.getVat();
      } else if (contractScheduleEntry.getPaymentDate() != null) {
        vat = contractScheduleEntry.getVat();
      }
      return vat;
    }).setId("vat").setCaption("VAT");

    // Payment status Section
    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      outstandingAmount = 0.0;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        return outstandingAmount = contractScheduleEntry.getScheduleInstallmentAmount().subtract(contractScheduleEntry.getPaymentInstallment()).getNumber().doubleValue();
      } else if (!contractScheduleEntry.getPaymentInstallment().isEqualTo(MoneyUtils.ZERO_VALUE)){
        return outstandingAmount;
      } else {
        return "";
      }
    }).setId("outstandingAmount").setCaption("Outstanding amount");

    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double outstandingRatio = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        Double paymentInstallment = contractScheduleEntry.getScheduleInstallmentAmount().getNumber().doubleValue();
        outstandingRatio = (outstandingAmount / paymentInstallment) * 30;
      }
      return outstandingRatio;
    }).setId("outstandingRatio").setCaption("Outstanding ratio");

    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      PaymentStatus paymentStatus = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        paymentStatus = contractScheduleEntry.getPaymentStatus();
      } else if (contractScheduleEntry.getPaymentDate() != null) {
        paymentStatus = contractScheduleEntry.getPaymentStatus();
      }
      return paymentStatus;
    }).setId("paymentStatus").setCaption("Payment status");

    contractScheduleGrid.addColumn(contractSchedule -> {
      if (contractSchedule.getLastPaymentDate() != null)
        labelPaymentDate.setValue("Payment updated at " + LocalDateTimeFormat.formatLocalDate(contractSchedule.getLastPaymentDate()));
      LocalDate paymentDate = contractSchedule.getPaymentDate() == null ? LocalDate.now() : contractSchedule.getPaymentDate();
      Long overdueDay = DAYS.between(contractSchedule.getScheduleDueDate(), paymentDate);
      if (overdueDay <= 0) {
        return EMPTY;
      } else if (overdueDay > DAYS.between(contractSchedule.getScheduleDueDate(), contractSchedule.getScheduleDueDate().plusMonths(1))) {
        return DAYS.between(contractSchedule.getScheduleDueDate(), contractSchedule.getScheduleDueDate().plusMonths(1));
      } else {
        return overdueDay;
      }
    }).setId("overdueDay").setCaption("Overdue Date");

    contractScheduleGrid.addColumn(contractScheduleEntry -> {
      Double penaltyAmount = null;
      if (contractScheduleEntry.getScheduleDueDate().isBefore(LocalDate.now()) || contractScheduleEntry.getScheduleDueDate().isEqual(LocalDate.now())) {
        penaltyAmount = contractScheduleEntry.getPenaltyAmount().getNumber().doubleValueExact();
      } else if (contractScheduleEntry.getPaymentDate() != null) {
        penaltyAmount = contractScheduleEntry.getPenaltyAmount().getNumber().doubleValueExact();
      }
      return penaltyAmount;
    }).setId("penaltyAmount").setCaption("Penalty Amount");

    HeaderRow groupingHeader = contractScheduleGrid.prependHeaderRow();
    groupingHeader.join("installmentNumber", "scheduleInstallmentAmount", "scheduleDueDate", "schedulePrinciple", "scheduleInterest")
            .setText("Schedule");
    groupingHeader.join("paymentInstallment", "paymentPrinciple", "paymentInterest", "paymentMonthlyPenalty")
            .setText("Payment Split");
    groupingHeader.join("fee", "vat")
            .setText(EMPTY);
    groupingHeader.join("outstandingAmount", "outstandingRatio", "paymentStatus")
            .setText("Payment Status");
    groupingHeader.join("overdueDay", "penaltyAmount")
            .setText(EMPTY);

    footer.join("installmentNumber", "scheduleInstallmentAmount", "scheduleDueDate", "schedulePrinciple", "scheduleInterest").setText("Total");
    footer.join("fee", "vat", "outstandingAmount", "outstandingRatio", "paymentStatus", "overdueDay", "penaltyAmount");

    footerCellPaymentInstallment = footer.getCell("paymentInstallment");
    footerCellPaymentPrinciple = footer.getCell("paymentPrinciple");
    footerCellPaymentInterest = footer.getCell("paymentInterest");
    footerCellPaymentMonthlyPenalty = footer.getCell("paymentMonthlyPenalty");
  
    Grid.Column columnDueDate = contractScheduleGrid.getColumn("scheduleDueDate");
    columnDueDate.setRenderer(LocalDateTimeFormat.createLocalDateRenderer());
  }

  @Override
  public void attach() {
    super.attach();
    bus.subscribe(this);
  }

  @Override
  public void detach() {
    super.detach();
    bus.unsubscribe(this);
  }

  @Handler
  public void handle(ContractSelectedEvent event) {
    this.contractNo = event.getContractNo();
    setGridContractScheduleDataProvider(contractNo);
    contractScheduleSummary(contractNo);
    fetchData();
  }

  public void fetchData() {
    contractScheduleEntries = repository.findAllByContractNumberOrderByInstallmentNumber(contractNo);
    MonetaryAmount totalPaymentInstallment = MoneyUtils.ZERO_VALUE;
    MonetaryAmount totalPaymentPrinciple = MoneyUtils.ZERO_VALUE;
    MonetaryAmount totalPaymentInterest = MoneyUtils.ZERO_VALUE;
    MonetaryAmount totalPaymentMonthlyPenalty = MoneyUtils.ZERO_VALUE;
    MonetaryAmount totalEndContractOutstandingAmount = MoneyUtils.ZERO_VALUE;
    double totalEndContractOutstandingRatioAmount = 0;
    MonetaryAmount totalEndContractPenaltyAmount = MoneyUtils.ZERO_VALUE;

    for (int i = 0; i < contractScheduleEntries.size(); i++) {
      totalPaymentInstallment = totalPaymentInstallment.add(contractScheduleEntries.get(i).getPaymentInstallment());
      totalPaymentPrinciple = totalPaymentPrinciple.add(contractScheduleEntries.get(i).getPaymentPrinciple());
      totalPaymentInterest = totalPaymentInterest.add(contractScheduleEntries.get(i).getPaymentInstallment());
      totalPaymentMonthlyPenalty = totalPaymentMonthlyPenalty.add(contractScheduleEntries.get(i).getPaymentMonthlyPenalty());
      totalEndContractOutstandingAmount = totalEndContractOutstandingAmount.add(contractScheduleEntries.get(i).getOutstandingAmount());
      totalEndContractOutstandingRatioAmount += contractScheduleEntries.get(i).getOutstandingRatio();
      totalEndContractPenaltyAmount = totalEndContractPenaltyAmount.add(contractScheduleEntries.get(i).getPenaltyAmount());
    }

    footerCellPaymentInstallment.setText(String.valueOf(totalPaymentInstallment.getNumber().doubleValueExact()));
    footerCellPaymentPrinciple.setText(String.valueOf(totalPaymentPrinciple.getNumber().doubleValueExact()));
    footerCellPaymentInterest.setText(String.valueOf(totalPaymentInterest.getNumber().doubleValueExact()));
    footerCellPaymentMonthlyPenalty.setText(String.valueOf(totalPaymentMonthlyPenalty.getNumber().doubleValueExact()));

    totalEndOutstandingAmount.setValue(formatMonetary(totalEndContractOutstandingAmount));
    totalEndOutstandingRatios.setValue(String.valueOf(totalEndContractOutstandingRatioAmount) + " days");
    totalEndPenaltyAmount.setValue(formatMonetary(totalEndContractPenaltyAmount));

    contractScheduleGrid.getDataProvider().refreshAll();
  }

  private String formatMonetary(MonetaryAmount payment) {
    MonetaryAmountFormat monetaryAmountFormatter = MonetaryFormats.getAmountFormat(
            AmountFormatQueryBuilder.of(Locale.getDefault()).set("pattern", "¤ #,##0.00").build());
    return monetaryAmountFormatter.format(payment);
  }

  private void setGridContractScheduleDataProvider(String contractNo) {
    contractScheduleGrid.setDataProvider(new AbstractBackEndDataProvider<ContractScheduleEntry, String>() {
      @Override
      protected Stream<ContractScheduleEntry> fetchFromBackEnd(Query<ContractScheduleEntry, String> query) {
        return StreamSupport.stream(repository.findAllByContractNumberOrderByInstallmentNumber(contractNo).spliterator(), true);
      }

      @Override
      protected int sizeInBackEnd(Query<ContractScheduleEntry, String> query) {
        return Math.toIntExact(repository.countAllByContractNumberOrderByInstallmentNumber(contractNo));
      }
    });
  }

  private void contractScheduleSummary(String contractNumber) {
    MonetaryAmount outStandingPrincipalAmount;
    MonetaryAmount sumPrincipal = MoneyUtils.ZERO_VALUE;
    MonetaryAmount totalPrincipalPaid = MoneyUtils.ZERO_VALUE;

    MonetaryAmount outStandingInterestAmount;
    MonetaryAmount sumInterest = MoneyUtils.ZERO_VALUE;
    MonetaryAmount totalInterestPaid = MoneyUtils.ZERO_VALUE;

    MonetaryAmount outStandingMonthlyPenaltyAmount;
    MonetaryAmount sumPenalty = MoneyUtils.ZERO_VALUE;
    MonetaryAmount totalPenaltyPaid = MoneyUtils.ZERO_VALUE;

    MonetaryAmount remainingPrincipalAmount;
    MonetaryAmount sumRemainingPrincipal = MoneyUtils.ZERO_VALUE;

    MonetaryAmount remainingInterestAmount;
    MonetaryAmount sumRemainingInterest = MoneyUtils.ZERO_VALUE;

    List<ContractScheduleEntry> entries = (List<ContractScheduleEntry>) repository.findByContractNumber(contractNumber);
    for (int i = 0; i < entries.size(); i++) {
      sumPrincipal = sumPrincipal.add(entries.get(i).getSchedulePrinciple());
      totalPrincipalPaid = totalPrincipalPaid.add(entries.get(i).getPaymentPrinciple());
      sumInterest = sumInterest.add(entries.get(i).getScheduleInterest());
      totalInterestPaid = totalInterestPaid.add(entries.get(i).getPaymentInterest());
      sumPenalty = sumPenalty.add(entries.get(i).getPenaltyAmount());
      totalPenaltyPaid = totalPenaltyPaid.add(entries.get(i).getPaymentMonthlyPenalty());
    }

    List<PaymentStatus> statuses = new ArrayList<>();
    statuses.add(PaymentStatus.FULL);
    statuses.add(PaymentStatus.OVER_PAY);
    statuses.add(PaymentStatus.PARTIAL);
    List<ContractScheduleEntry> scheduleEntry = repository.findByContractNumberAndPaymentStatusInAndPaymentDateIsLessThanEqual(contractNumber, statuses, LocalDate.now());
    for (int x = 0; x < scheduleEntry.size(); x++) {
      sumRemainingPrincipal = sumRemainingPrincipal.add(scheduleEntry.get(x).getSchedulePrinciple().subtract(scheduleEntry.get(x).getPaymentPrinciple()));
      sumRemainingInterest = sumRemainingInterest.add(scheduleEntry.get(x).getPaymentInterest().subtract(scheduleEntry.get(x).getPaymentInterest()));
    }

    outStandingPrincipalAmount = sumPrincipal.subtract(totalPrincipalPaid);
    outStandingInterestAmount = sumInterest.subtract(totalInterestPaid);
    outStandingMonthlyPenaltyAmount = sumPenalty.subtract(totalPenaltyPaid);

    //remainingPrincipalAmount = sumRemainingPrincipal.subtract(totalPrincipalPaid);
    remainingPrincipalAmount = Money.of(Math.abs(sumRemainingPrincipal.getNumber().doubleValue()), CurrencyUtil.MMK_CURRENCY);
    //remainingInterestAmount = sumRemainingInterest.subtract(totalInterestPaid);
    remainingInterestAmount = Money.of(Math.abs(sumRemainingInterest.getNumber().doubleValue()), CurrencyUtil.MMK_CURRENCY);

    outstandingPrincipal.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(outStandingPrincipalAmount).toString());
    outstandingInterest.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(outStandingInterestAmount).toString());
    outstandingMonthlyPenalty.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(outStandingMonthlyPenaltyAmount).toString());

    remainingPrincipalDate.setValue("Remaining Principal at " + LocalDateTimeFormat.formatLocalDate(LocalDate.now()));
    remainingPrincipal.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(remainingPrincipalAmount).toString());
    remainingInterestDate.setValue("Remaining Interest at " + LocalDateTimeFormat.formatLocalDate(LocalDate.now()));
    remainingInterest.setValue(CurrencyUtil.MONETARY_AMOUNT_FORMAT.format(remainingInterestAmount).toString());
  }

}
