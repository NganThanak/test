package com.gl.csf.cm.ui.util.excel;

import com.gl.csf.cm.query.contract.accounting.PortfolioPeriodInterestRealizationEntry;
import com.gl.csf.cm.query.contract.util.MoneyUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.servlet.view.document.AbstractXlsxStreamingView;

import javax.money.MonetaryAmount;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: chann bora
 */
public class InterestSummaryReportExcelBuilder extends AbstractXlsxStreamingView {
  
  private static List<PortfolioPeriodInterestRealizationEntry> installments;
  private static LocalDate startMonth;
  private static LocalDate endMonth;
  private static String loanType;
  private Map<LocalDate, PortfolioPeriodInterestRealizationEntry> allInstallments = new TreeMap<>();
  
  @Override
  protected void buildExcelDocument(Map<String, Object> map, Workbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
    String pattern = "MMM-yyyy";
    SimpleDateFormat format = new SimpleDateFormat("MM-d-yyyy");
    
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
    DateTimeFormatter excelDateFormatter = DateTimeFormatter.ofPattern("MM-d-yyyy");
    
    String filename = "Accounting Report - Interest summary report " + format.format(new Date());
    // change the file name
    response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + ".xlsx\"");
    
    // create excel sheet
    Sheet sheet = workbook.createSheet("Payment Schedule Simulation");
    
    //set header style
    CellStyle Headertyle = workbook.createCellStyle();
    Font font = workbook.createFont();
    font.setColor(HSSFColor.RED.index);
    Headertyle.setFont(font);
    
    // set table style header
    CellStyle tableStyle = workbook.createCellStyle();
    tableStyle.setFillBackgroundColor(HSSFColor.ORANGE.index);
    
    // create header
    Row header = sheet.createRow(0);
    header.createCell(0).setCellValue("Accounting Report - Interest summary report");
    header.setRowStyle(Headertyle);
    
    Row subHeader = sheet.createRow(1);
    subHeader.createCell(0).setCellValue("From Month ");
    subHeader.createCell(1).setCellValue(startMonth.format(formatter));
    subHeader.createCell(2).setCellValue("To Month ");
    subHeader.createCell(3).setCellValue(endMonth.format(formatter));
    
    Row subHeaderLoanType = sheet.createRow(2);
    subHeaderLoanType.createCell(0).setCellValue("Loan: ");
    subHeaderLoanType.createCell(1).setCellValue(loanType);
    
    // create header row
    Row headerTbl = sheet.createRow(3);
    headerTbl.createCell(0).setCellValue("Month end");
    headerTbl.createCell(1).setCellValue("Interest end of month");
    headerTbl.createCell(2).setCellValue("Principal received end of month");
    headerTbl.createCell(3).setCellValue("Remaining balance end of month");
    headerTbl.setRowStyle(tableStyle);
    
    //generate Data Row
    allInstallments.clear();
    
    Map<LocalDate, List<PortfolioPeriodInterestRealizationEntry>> maps = installments.stream().collect(Collectors.groupingBy(PortfolioPeriodInterestRealizationEntry::getEndOfMonthDate));
    maps.forEach((endOfMonthDate, entryList) -> {
    	if (entryList.size() == 1) {
    		allInstallments.put(endOfMonthDate, entryList.get(0));
		} else {
			PortfolioPeriodInterestRealizationEntry intermediate = new PortfolioPeriodInterestRealizationEntry();
			intermediate.setEndOfMonthDate(endOfMonthDate);
	    	
			MonetaryAmount interestEOM = MoneyUtils.ZERO_VALUE;
		    MonetaryAmount principalEOM = MoneyUtils.ZERO_VALUE;
		    MonetaryAmount remainingBalanceEOM = MoneyUtils.ZERO_VALUE;
		    
		    for(PortfolioPeriodInterestRealizationEntry entry: entryList) {
		    	interestEOM = interestEOM.add(entry.getInterestEndOfMonth());
		    	principalEOM = principalEOM.add(entry.getPrincipalEndOfMonth());
		    	remainingBalanceEOM = remainingBalanceEOM.add(entry.getRemainingBalanceEndOfMonth());
		    }
		    intermediate.setInterestEndOfMonth(interestEOM);
	    	intermediate.setPrincipalEndOfMonth(principalEOM);
	    	intermediate.setRemainingBalanceEndOfMonth(remainingBalanceEOM);	    	
	    	allInstallments.put(endOfMonthDate, intermediate);
	    }    	
    });
    
    generateRow(sheet, allInstallments, excelDateFormatter);
  }
  
  private void generateRow(Sheet sheet, Map<LocalDate, PortfolioPeriodInterestRealizationEntry> installments, DateTimeFormatter excelDateFormatter) {
    Row dataRow;
    
    int index = 4;
    for (PortfolioPeriodInterestRealizationEntry x : installments.values()) {
      dataRow = sheet.createRow(index);
      dataRow.createCell(0).setCellValue(x.getEndOfMonthDate().format(excelDateFormatter));
      dataRow.createCell(1).setCellValue(x.getInterestEndOfMonth().getNumber().numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(2).setCellValue(x.getPrincipalEndOfMonth().getNumber().numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(3).setCellValue(x.getRemainingBalanceEndOfMonth().getNumber().numberValue(BigDecimal.class).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      index++;
    }
  }
  
  public static void setInstallment(List<PortfolioPeriodInterestRealizationEntry> paymentSchedule, LocalDate startDateValue, LocalDate endDateValue) {
    installments = paymentSchedule;
    startMonth = startDateValue;
    endMonth = endDateValue;
  }
  
  public static void setLoanType(String loanType) {
    InterestSummaryReportExcelBuilder.loanType = loanType;
  }
}