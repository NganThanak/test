package com.gl.csf.cm.ui.component.contract.ownerinfo;

import com.gl.csf.cm.common.model.bank.Bank;
import com.gl.csf.cm.common.model.bank.BankAccount;
import com.gl.csf.cm.message.SessionScopeBus;
import com.gl.csf.cm.query.contract.lessee.LesseeBankAccountInformationEntry;
import com.gl.csf.cm.query.contract.lessee.LesseeBankAccountInformationRepository;
import com.gl.csf.cm.query.contract.staff.StaffPersonalInformationEntry;
import com.gl.csf.cm.query.contract.staff.StaffPersonalInformationRepository;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import javax.inject.Inject;
import java.time.LocalDate;

import static java.time.temporal.ChronoUnit.YEARS;

/**
 * Created by p.ly on 1/23/2018.
 */
@UIScope
@SpringComponent
public class StaffLoanPersonalInfoComponent extends StaffLoanPersonalInfoComponentDesign{
  
  private String contractId;
  private final StaffPersonalInformationRepository staffPersonalInformationRepository;
  private final Binder<StaffPersonalInformationEntry> staffPersonalInformationBinder;
  
  private final LesseeBankAccountInformationRepository lesseeBankAccountInformationRepository;
  private final Binder<LesseeBankAccountInformationEntry> lesseeBankAccountInformationBinder;
  @Inject
  public StaffLoanPersonalInfoComponent(StaffPersonalInformationRepository staffPersonalInformationRepository, LesseeBankAccountInformationRepository lesseeBankAccountInformationRepository) {
    this.staffPersonalInformationRepository = staffPersonalInformationRepository;
    this.lesseeBankAccountInformationRepository = lesseeBankAccountInformationRepository;
    this.lesseeBankAccountInformationBinder = createLesseeBankAccountInformationBinder();
    this.staffPersonalInformationBinder = createLesseePersonalInformationBinder();
  }
  
  private Binder<StaffPersonalInformationEntry> createLesseePersonalInformationBinder(){
    Binder<StaffPersonalInformationEntry> result = new BeanValidationBinder<>(StaffPersonalInformationEntry.class);
    result.forField(textFieldFullName).asRequired("Full name").bind("fullName");
    result.forField(comboBoxGender).asRequired("Gender").bind("gender");
    result.forField(dateFieldDOB).withValidator(dob -> YEARS.between(dob, LocalDate.now()) >= 18, "Age must be greater than 18.")
            .asRequired("Age must be greater than 18.").bind("dob");
    result.forField(textFieldPhoneNumber).asRequired("Phone number").bind("phoneNumber");
    result.forField(additionalPhoneNumberTextField1).bind("position");
    result.forField(additionalPhoneNumberTextField2).bind("company.company");
    result.forField(textFieldOwnerAddress).asRequired("Owner address").bind("ownerAddress.text");
    result.forField(textFieldFatherName).bind("fatherName");
    result.forField(textFieldNRCID).asRequired("National ID").bind("nrcId");
    result.forField(comboBoxState).asRequired("State").bind("ownerAddress.state");
    result.bind(textFieldEmail,"email");
    result.forField(comboBoxDistrict).asRequired("District").bind("ownerAddress.district");
    result.forField(comboBoxTownship).asRequired("Township").bind("ownerAddress.township");
    return result;
  }
  
  private Binder<LesseeBankAccountInformationEntry> createLesseeBankAccountInformationBinder(){
    Binder<LesseeBankAccountInformationEntry> result = new BeanValidationBinder<>(LesseeBankAccountInformationEntry.class);
    result.bind(textFieldBankHolderName,"bankAccount.accountName");
    result.bind(comboBoxBankName,"bankAccount.bank");
    result.bind(textFieldBankNumber,"bankAccount.accountNumber");
    result.bind(textFieldDescription,"description");
    return result;
  }
  
  public void setContractId(String contractId){
    this.contractId = contractId;
    fetchData();
  }
  private void fetchData() {
    staffPersonalInformationBinder.setBean(staffPersonalInformationRepository.findOne(contractId));
    LesseeBankAccountInformationEntry temp = lesseeBankAccountInformationRepository.findOne(contractId);
    Bank bank = new Bank();
    bank.setName("");

    if(temp.getBankAccount()== null)
      temp.setBankAccount(new BankAccount());

    if(temp.getBankAccount().getAccountName() == null)
      temp.getBankAccount().setAccountName("");

    if(temp.getBankAccount().getAccountNumber() == null)
      temp.getBankAccount().setAccountNumber("");

    if(temp.getBankAccount().getBank() == null)
      temp.getBankAccount().setBank(bank);

    lesseeBankAccountInformationBinder.setBean(temp);
  }
}
