package com.gl.csf.cm.ui.util.excel;

import com.gl.csf.cm.query.contract.accounting.ContractInterestRealizationAttributeEntry;
import com.gl.csf.cm.query.contract.accounting.ContractPeriodInterestRealizationEntry;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxStreamingView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by p.ly on 11/23/2017.
 */
public class ContractInterestRealizationAttributeExcelBuilder extends AbstractXlsxStreamingView {

  private static List<ContractPeriodInterestRealizationEntry> interestRealizationEntries;
  private static ContractInterestRealizationAttributeEntry attributeEntry;

  @Override
  protected void buildExcelDocument(Map<String, Object> map, Workbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
    String pattern = "yyyy-MMM-dd@hh-mm-ss aaa";
    SimpleDateFormat format = new SimpleDateFormat(pattern);

    DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");


    String filename = attributeEntry.getContractId() + "Contract-Interest-Realization-Attribute" + format.format(new Date());
    // change the file name
    response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + ".xlsx\"");

    // create excel sheet
    Sheet sheet = workbook.createSheet("Contract Interest Realization Attribute");

    // create header row first report
    Row header = sheet.createRow(1);
    header.createCell(0).setCellValue("Accounting report - Interest report by contract");

    Row topReportRow1 = sheet.createRow(2);
    topReportRow1.createCell(0).setCellValue("Contract No.");
    topReportRow1.createCell(1).setCellValue(attributeEntry.getContractNumber());
    topReportRow1.createCell(2).setCellValue("");
    topReportRow1.createCell(3).setCellValue("Lease amount");
    topReportRow1.createCell(4).setCellValue(attributeEntry.getLeaseAmount().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
    topReportRow1.createCell(5).setCellValue("");
    topReportRow1.createCell(6).setCellValue("Installment");
    topReportRow1.createCell(7).setCellValue(attributeEntry.getInstallment().getNumber().numberValue(BigDecimal.class)
      .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());

    Row topReportRow2 = sheet.createRow(3);
    topReportRow2.createCell(0).setCellValue("Contract date");
    topReportRow2.createCell(1).setCellValue(df.format(attributeEntry.getContractDate()));
    topReportRow2.createCell(2).setCellValue("");
    topReportRow2.createCell(3).setCellValue("Leasing term");
    topReportRow2.createCell(4).setCellValue(attributeEntry.getLeasingTerm());
    topReportRow2.createCell(5).setCellValue("");
    topReportRow2.createCell(6).setCellValue("Effective rate (month)");
    topReportRow2.createCell(7).setCellValue(attributeEntry.getMonthlyEffectiveRate().doubleValue());

    Row topReportRow3 = sheet.createRow(4);
    topReportRow3.createCell(0).setCellValue("First due date");
    topReportRow3.createCell(1).setCellValue(df.format(attributeEntry.getFirstDueDate()));
    topReportRow3.createCell(2).setCellValue("");
    topReportRow3.createCell(3).setCellValue("Flat rate");
    topReportRow3.createCell(4).setCellValue(attributeEntry.getFlatRate().doubleValue());
    topReportRow3.createCell(5).setCellValue("");
    topReportRow3.createCell(6).setCellValue("Effective rate annual)");
    topReportRow3.createCell(7).setCellValue(attributeEntry.getAnnuallyEffectiveRate().doubleValue());

    // create header row second report
    Row headerInterestRealizationAttribute = sheet.createRow(8);
    headerInterestRealizationAttribute.createCell(0).setCellValue("Period");
    headerInterestRealizationAttribute.createCell(1).setCellValue("Due date");
    headerInterestRealizationAttribute.createCell(2).setCellValue("Installment");
    headerInterestRealizationAttribute.createCell(3).setCellValue("Interest");
    headerInterestRealizationAttribute.createCell(4).setCellValue("Principal");
    headerInterestRealizationAttribute.createCell(5).setCellValue("Remaining Balance");

    headerInterestRealizationAttribute.createCell(6).setCellValue("Month end");
    headerInterestRealizationAttribute.createCell(7).setCellValue("Interest end of month");
    headerInterestRealizationAttribute.createCell(8).setCellValue("Sum of Accrued Interest");
    headerInterestRealizationAttribute.createCell(9).setCellValue("Principal received end of month");
    headerInterestRealizationAttribute.createCell(10).setCellValue("Accrued Principal received");
    headerInterestRealizationAttribute.createCell(11).setCellValue("Remaining balance end of month");

    // create data row
    Row dataRow ;
    for (int i = 9; i < (interestRealizationEntries.size()+9); i++) {
      dataRow = sheet.createRow(i);
      dataRow.createCell(0).setCellValue(interestRealizationEntries.get(i - 9).getPeriod());
      dataRow.createCell(1).setCellValue(df.format(interestRealizationEntries.get(i - 9).getDueDate()));
      dataRow.createCell(2).setCellValue(interestRealizationEntries.get(i - 9).getInstallment().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()) ;
      dataRow.createCell(3).setCellValue(interestRealizationEntries.get(i - 9).getInterest().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());

      dataRow.createCell(4).setCellValue(interestRealizationEntries.get(i - 9).getPrincipal().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(5).setCellValue(interestRealizationEntries.get(i - 9).getRemainingPrincipalBalance().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());

      dataRow.createCell(6).setCellValue(df.format(interestRealizationEntries.get(i - 9).getEndOfMonthDate()));
      dataRow.createCell(7).setCellValue(interestRealizationEntries.get(i - 9).getInterestEndOfMonth().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(8).setCellValue(interestRealizationEntries.get(i - 9).getSumOfAccruedInterestEndOfMonth().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue()) ;
      dataRow.createCell(9).setCellValue(interestRealizationEntries.get(i - 9).getPrincipalEndOfMonth().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(10).setCellValue(interestRealizationEntries.get(i - 9).getSumOfAccruedPrincipalEndOfMonth().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
      dataRow.createCell(11).setCellValue(interestRealizationEntries.get(i - 9).getRemainingBalanceEndOfMonth().getNumber().numberValue(BigDecimal.class)
        .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
    }
  }

  public static void setInterestRealizationEntries(List<ContractPeriodInterestRealizationEntry> interestRealizationEntries) {
    ContractInterestRealizationAttributeExcelBuilder.interestRealizationEntries = interestRealizationEntries;
  }

  public static void setAttributeEntry(ContractInterestRealizationAttributeEntry attributeEntry) {
    ContractInterestRealizationAttributeExcelBuilder.attributeEntry = attributeEntry;
  }
}
