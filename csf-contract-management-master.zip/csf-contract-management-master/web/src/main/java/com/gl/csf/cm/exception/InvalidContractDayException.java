package com.gl.csf.cm.exception;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 20/11/2017.
 */
public class InvalidContractDayException extends Exception {
  public InvalidContractDayException(String message){
    super(message);
  }

  public InvalidContractDayException(String message, Throwable throwable){
    super(message, throwable);
  }
  
}
