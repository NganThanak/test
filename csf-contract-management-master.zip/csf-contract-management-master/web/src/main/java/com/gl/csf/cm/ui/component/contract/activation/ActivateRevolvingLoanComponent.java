package com.gl.csf.cm.ui.component.contract.activation;

import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.ui.util.StringToMonetaryConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.ui.Window;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kimsong San (k.san@gl-f.com) on 11/16/2017.
 */
public class ActivateRevolvingLoanComponent extends ActivateRevolvingLoanComponentDesign {

	private class ActivateRevolvingLoanContext {
		private LocalDate contractDate;
		private MonetaryAmount firstWithdrawalAmount;

		public LocalDate getContractDate() {
			return contractDate;
		}

		public void setContractDate(LocalDate contractDate) {
			this.contractDate = contractDate;
		}

		public MonetaryAmount getFirstWithdrawalAmount() {
			return firstWithdrawalAmount;
		}

		public void setFirstWithdrawalAmount(MonetaryAmount firstWithdrawalAmount) {
			this.firstWithdrawalAmount = firstWithdrawalAmount;
		}
	}

	private ActivateContractComponentListener listener;
	private final Binder<ActivateRevolvingLoanContext> binder = new BeanValidationBinder<>(ActivateRevolvingLoanContext.class);

	public ActivateRevolvingLoanComponent() {
		binder.forField(contractDate).asRequired("Contract date is required")
						.bind(ActivateRevolvingLoanContext::getContractDate, ActivateRevolvingLoanContext::setContractDate);

		binder.forField(firstWithdrawalAmount).asRequired("First withdrawal amount is required")
						.withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
						.bind(ActivateRevolvingLoanContext::getFirstWithdrawalAmount, ActivateRevolvingLoanContext::setFirstWithdrawalAmount);

		binder.setBean(new ActivateRevolvingLoanContext());

		closeButton.addClickListener(e -> {
			if(listener != null)
				listener.onClosed();
		});
		buttonCancel.addClickListener(e -> {
			if(listener != null)
				listener.onCancelButtonClicked();
		});
		buttonConfirm.addClickListener(e -> {
			if(listener != null)
				listener.onConfirmButtonClicked();
		});

		buttonConfirm.setEnabled(false);
		binder.addStatusChangeListener(e-> buttonConfirm.setEnabled(e.getSource().isValid()));
	}

	public Window displayConfiguration() {
		Window window = new Window();
		window.center();
		window.removeAllCloseShortcuts();
		window.setResizable(false);
		window.setClosable(false);
		window.setModal(true);
		window.setWidth(600, Unit.PIXELS);
		return window;
	}

	public ActivateContractComponentListener getListener() {
		return listener;
	}

	public void setListener(ActivateContractComponentListener listener) {
		this.listener = listener;
	}

	public LocalDate getContractDate(){
		return binder.getBean().getContractDate();
	}

	public MonetaryAmount getFirstWithdrawalAmount(){
		return binder.getBean().getFirstWithdrawalAmount();
	}
}
