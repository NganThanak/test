package com.gl.csf.cm.ui.common;

import com.gl.csf.cm.ui.viewdeclaration.UIScopeContractViews;
import com.vaadin.server.ThemeResource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.UI;
import org.vaadin.spring.security.VaadinSecurity;

import javax.inject.Inject;

/**
 * Created by p.ly on 11/8/2017.
 */
@SpringComponent
@UIScope
public class MainMenuBar extends MainMenuBarDesign {
  private final static String SPACE = "";

  @Inject
  public MainMenuBar(VaadinSecurity vaadinSecurity) {
    //set picture logo
    ThemeResource resource = new ThemeResource("images/logo.svg");
    logo.setSource(resource);
    logo.addClickListener(e -> UI.getCurrent().getNavigator().navigateTo(SPACE));

    contractMenu.addItem("Contract", createNavigationCommand(UIScopeContractViews.CONTRACT_LIST));
    //paymentMenu.addItem("Payment", createNavigationCommand(UIScopeContractViews.PAYMENT));
    reportMenu.addItem("Report", createNavigationCommand(UIScopeContractViews.REPORT));
    MenuBar.MenuItem item = profileLoggedInMenu.addItem("Welcome, " + vaadinSecurity.getAuthentication().getName().toUpperCase(), null);
    item.addItem("Log out",  menuItem -> vaadinSecurity.logout());
  }

  private MenuBar.Command createNavigationCommand(final String viewName) {
    return menuItem -> UI.getCurrent().getNavigator().navigateTo(viewName);
  }
}
