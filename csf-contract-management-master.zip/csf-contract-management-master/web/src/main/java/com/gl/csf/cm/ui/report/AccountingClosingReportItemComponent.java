package com.gl.csf.cm.ui.report;

import com.vaadin.server.Page;
import com.vaadin.server.VaadinServlet;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import java.time.LocalDate;

/**
 * Created by p.ly on 11/21/2017.
 */
@SpringComponent
@UIScope
public class AccountingClosingReportItemComponent extends AccountingClosingReportItemComponentDesign{


  private static final String BASE_PATH = VaadinServlet.getCurrent().getServletContext().getContextPath() + "/docs/export";
  private static final String ACCOUNTING_CLOSING_REPORT_PATH = BASE_PATH + "/report/accounting-closing-report/download";

  public AccountingClosingReportItemComponent(LocalDate from, LocalDate to, String productType) {
    fromdateLabel.setValue(from.getMonth().getValue()+"/"+from.getYear());
    toDateLabel.setValue(to.getMonth().getValue()+"/"+to.getYear());
    loantypeLabel.setValue(productType);

    downloadButton.addClickListener(e -> {
      Page.getCurrent().open(ACCOUNTING_CLOSING_REPORT_PATH, "_blank");
    });
  }
}
