package com.gl.csf.cm.ui.dataprovider;

import lombok.Value;

/**
 * Created by p.ly on 11/15/2017.
 */
@Value
public class ApplicationFilter {
  String username;
  String role;
}

