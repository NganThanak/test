package com.gl.csf.cm.ui.component.contract.businessinfo;

import com.gl.csf.cm.query.contract.lessee.business.BranchEntry;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.ui.util.StringToMonetaryConverter;
import com.vaadin.data.BeanValidationBinder;
import com.vaadin.data.Binder;
import com.vaadin.data.converter.StringToIntegerConverter;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import java.util.Objects;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/21/2017.
 */
@SpringComponent
@UIScope
public class BranchDetailComponent extends BranchDetailComponentDesign {
  private Binder<BranchEntry> branchBinder = new BeanValidationBinder<>(BranchEntry.class);

  void bind(BranchEntry branchEntry) {
    branchBinder.setBean(branchEntry);
    initializeBinder(branchBinder);
  }

  private void initializeBinder(Binder<BranchEntry> branchBinder) {
    Objects.requireNonNull(branchBinder);

    openSinceDateField.setDateFormat("yyyy");

    branchBinder.bind(branchIdTextField, "contractId");
    branchBinder.bind(branchNameTextField, "branchName");
    branchBinder.bind(emailTextField, "email");
    branchBinder.forField(rentAmountTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("rentAmount");
    branchBinder.bind(phoneNumberTextField, "phoneNumber");
    branchBinder.bind(addressTextField, "address");
    branchBinder.bind(stateComboBox, "state");
    branchBinder.bind(districtComboBox, "district");
    branchBinder.bind(townshipComboBox, "township");
    branchBinder.bind(locationOwnerCombobox, "locationOwner");
    branchBinder.bind(openSinceDateField, "openSince");

    branchBinder.bind(statusComboBox, "branchStatus");
    branchBinder.forField(revenueTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("revenue");
    branchBinder.forField(expenseTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("expense");
    branchBinder.forField(marginTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("margin");
    branchBinder.forField(numberOfStaffTextField)
            .withConverter(new StringToIntegerConverter("")).bind("numberOfStaff");
    branchBinder.forField(staffExpenseTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("staffExpense");
    branchBinder.forField(otherExpenseTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("otherExpense");
    branchBinder.forField(netProfitTextField)
            .withConverter(new StringToMonetaryConverter(CurrencyUtil.MMK_CURRENCY))
            .bind("netProfit");
  }
}
