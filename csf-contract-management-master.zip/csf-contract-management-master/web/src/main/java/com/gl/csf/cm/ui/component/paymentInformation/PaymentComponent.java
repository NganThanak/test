package com.gl.csf.cm.ui.component.paymentInformation;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;

import javax.inject.Inject;

/**
 * Created by p.ly on 12/2/2017.
 */
@SpringComponent
@UIScope
public class PaymentComponent extends PaymentComponentDesign implements View{
  public void setContractNo(String contractNo) {
    penaltyComponent.setContractNo(contractNo);
    paymentInformationComponet.setContractNumber(contractNo);
  }

  public void reload(){
    paymentTab.setSelectedTab(contractComponent);
    contractComponent.fetchData();
  }
}
