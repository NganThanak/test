package com.gl.csf.cm.query.contract.lessee.business;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class BranchEventListener {
  private final BranchRepository repository;

  @Inject
  public BranchEventListener(BranchRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    if(event.getLesseeBusiness() == null || event.getLesseeBusiness().getBranches() == null)
      return;

    event.getLesseeBusiness().getBranches().forEach(branch -> {
      BranchEntry branchEntry = new BranchEntry();
      branchEntry.setId(UUID.randomUUID().toString());
      branchEntry.setContractId(event.getId());

      branchEntry.setBranchName(branch.getBranchName());
      branchEntry.setEmail(branch.getEmail());
      branchEntry.setIsBoss(branch.getIsBoss());
      branchEntry.setRentAmount(branch.getRentAmount());
      branchEntry.setPhoneNumber(branch.getPhoneNumber());
      branchEntry.setAddress(branch.getAddress());
      branchEntry.setState(branch.getState());
      branchEntry.setDistrict(branch.getDistrict());
      branchEntry.setTownship(branch.getTownship());
      branchEntry.setLocationOwner(branch.getLocationOwner());
      branchEntry.setOpenSince(branch.getOpenSince());
      branchEntry.setBranchStatus(branch.getBranchStatus());

      branchEntry.setRevenue(branch.getRevenue());
      branchEntry.setExpense(branch.getExpense());
      branchEntry.setOtherExpense(branch.getOtherExpense());
      branchEntry.setMargin(branch.getMargin());
      branchEntry.setNumberOfStaff(branch.getNumberOfStaff());
      branchEntry.setStaffExpense(branch.getStaffExpense());
      branchEntry.setNetProfit(branch.getNetProfit());

      repository.save(branchEntry);
    });

  }
}
