package com.gl.csf.cm.query.paymentinformation.paymentschedule;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDate;

@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class PaymentScheduleHistory {
    @Id
    private String id;
    private String contractNumber;
    private Integer installmentNumber;

    @Positive
    @Type(type = "Money")
    @Columns(columns = {@Column(name = "installment_currency"), @Column(name = "installment_amount")})
    private MonetaryAmount installmentAmount;

    private String paymentReference;
    private String bankTransaction;

    @Type(type = "Money")
    @Columns(columns = {@Column(name = "payment_currency"), @Column(name = "payment_amount")})
    private MonetaryAmount paymentAmount;

    @Type(type = "Money")
    @Columns(columns = {@Column(name = "allocation_currency"), @Column(name = "allocation_amount")})
    private MonetaryAmount amountAllocation;

    private LocalDate paymentDate;
    
    @Column(name = "last_payment_date")
    private LocalDate lastPaymentDate;
}
