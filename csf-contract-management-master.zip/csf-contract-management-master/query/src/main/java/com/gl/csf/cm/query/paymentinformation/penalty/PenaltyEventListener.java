package com.gl.csf.cm.query.paymentinformation.penalty;

import com.gl.csf.cm.api.contract.event.PaymentFullyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.PaymentPartiallyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.gl.csf.cm.query.contract.product.LoanProductRepository;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.query.paymentinformation.penalty.history.PenaltyHistoryEntry;
import com.gl.csf.cm.query.paymentinformation.penalty.history.PenaltyHistoryRepository;
import com.gl.csf.cm.query.paymentinformation.penalty.summary.PenaltySummary;
import com.gl.csf.cm.query.paymentinformation.penalty.summary.PenaltySummaryRepository;
import com.gl.csf.cm.query.service.PenaltyOverdueDayService;
import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;
import com.gl.csf.financeapi.utils.FinanceUtils;
import lombok.Value;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Component
public class PenaltyEventListener {

  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);

  private final PenaltyRepository penaltyRepository;
  private final LoanProductRepository loanProductRepository;
  private final PenaltyOverdueDayService penaltyOverdueDayService;
  private final PenaltyHistoryRepository penaltyHistoryRepository;
  private final PenaltySummaryRepository penaltySummaryRepository;

  @Inject
  public PenaltyEventListener(PenaltyRepository penaltyRepository, LoanProductRepository loanProductRepository,
                              PenaltyOverdueDayService penaltyOverdueDayService, PenaltyHistoryRepository penaltyHistoryRepository, PenaltySummaryRepository penaltySummaryRepository) {
    this.penaltyRepository = penaltyRepository;
    this.loanProductRepository = loanProductRepository;
    this.penaltyOverdueDayService = penaltyOverdueDayService;
    this.penaltyHistoryRepository = penaltyHistoryRepository;
    this.penaltySummaryRepository = penaltySummaryRepository;
  }

  @EventHandler
  private void on(StandardLoanContractActivatedEvent event) {
    generateContractSchedule(event);
  }

  @EventHandler
  private void on(PaymentPartiallyAllocatedEvent event) {
    if (event.getPenaltyAmount() != null) {
      if (!event.getPenaltyAmount().isZero()) {
        List<PenaltyEntry> penaltyEntries = penaltyRepository.findAllByContractNumberAndDueDateBeforeAndPaymentStatusIsNot(event.getContractNumber(), LocalDate.now(), PaymentStatus.FULL);
        allocatePenaltyAmount(new AllocatedPenaltyEvent(event.getContractNumber(), event.getBankTransaction(),
                event.getPaymentReference(), event.getPaymentDate(), event.getPenaltyAmount(), event.getAmount()), penaltyEntries);
      } else
        updatePenaltyStatus(event.getContractNumber(), event.getInstallmentNumber(), event.getPaymentDate());
    }
  }

  @EventHandler
  private void on(PaymentFullyAllocatedEvent event) {
    if (event.getPenaltyAmount() != null) {
      if (!event.getPenaltyAmount().isZero()) {
        List<PenaltyEntry> penaltyEntries = penaltyRepository.findAllByContractNumberAndDueDateBeforeAndPaymentStatusIsNot(event.getContractNumber(), LocalDate.now(), PaymentStatus.FULL);
        allocatePenaltyAmount(new AllocatedPenaltyEvent(event.getContractNumber(), event.getBankTransaction(),
                event.getPaymentReference(), event.getPaymentDate(), event.getPenaltyAmount(), event.getAmount()), penaltyEntries);
      } else {
        updatePenaltyStatus(event.getContractNumber(), event.getInstallmentNumber(), event.getPaymentDate());
      }
    }
  }

  private void updatePenaltyStatus(String contractNumber, int installmentNumber, LocalDate paymentDate) {
    Optional<PenaltyEntry> penaltyEntryOptional = penaltyRepository.findByContractNumberAndInstallmentNumber(contractNumber, installmentNumber);
    if (penaltyEntryOptional.isPresent()) {
      PenaltyEntry penaltyEntry = penaltyEntryOptional.get();
      // if customer paid before due date or in due date no penalty
      if (penaltyEntry.getDueDate().isBefore(paymentDate) || penaltyEntry.getDueDate().isEqual(paymentDate)) {
        penaltyEntry.setPaymentStatus(PaymentStatus.FULL);
        penaltyRepository.save(penaltyEntry);
      }
    }
  }

  private void allocatePenaltyAmount(AllocatedPenaltyEvent event, List<PenaltyEntry> penaltyEntries) {
    MonetaryAmount receivePenaltyAmount = event.getReceivePenaltyAmount();
    for (PenaltyEntry penaltyEntry : penaltyEntries) {
      MonetaryAmount oldAllocateAmount = penaltyEntry.getAllocatePenaltyAmount();
      penaltyEntry = penaltyOverdueDayService.calculateOverdueDays(penaltyEntry, event.getBankTransaction(), event.getPaymentReference(),
              receivePenaltyAmount, event.getTotalInstallmentAmount(), event.getPaymentDate());

      if (penaltyEntry.getReceivePenaltyAmount().isLessThanOrEqualTo(penaltyEntry.getPenaltyAmount())) {
        if (penaltyEntry.getReceivePenaltyAmount().add(oldAllocateAmount).isLessThanOrEqualTo(penaltyEntry.getPenaltyAmount())) {
          receivePenaltyAmount = receivePenaltyAmount.multiply(0);
        } else if (penaltyEntry.getReceivePenaltyAmount().add(oldAllocateAmount).isGreaterThan(penaltyEntry.getPenaltyAmount())) {
          receivePenaltyAmount = penaltyEntry.getReceivePenaltyAmount().add(oldAllocateAmount).subtract(penaltyEntry.getPenaltyAmount());
        }
      } else if (penaltyEntry.getReceivePenaltyAmount().isGreaterThan(penaltyEntry.getPenaltyAmount())) {
        receivePenaltyAmount = penaltyEntry.getReceivePenaltyAmount().subtract(penaltyEntry.getPenaltyAmount());
      }

      savePaymentPenaltyHistory(penaltyEntry, event, oldAllocateAmount);
      updatePenaltySummary(penaltyEntry.getContractNumber());

      penaltyRepository.save(penaltyEntry);
    }
  }

  private void updatePenaltySummary(String contractNumber) {

    Optional<PenaltySummary> optionalPenaltySummary = penaltySummaryRepository.findByContractNumber(contractNumber);
    PenaltySummary penaltySummary;

    MonetaryAmount monthlyPenaltyBalance = MMK_ZERO;
    MonetaryAmount totalMonthlyPenaltyAmount = MMK_ZERO;
    MonetaryAmount totalMonthlyPenaltyPaymentAmount = MMK_ZERO;

    if (optionalPenaltySummary.isPresent()) {
      penaltySummary = optionalPenaltySummary.get();
      List<PenaltyEntry> penaltyEntries = penaltyRepository.findAllByContractNumber(contractNumber);

      for (PenaltyEntry penaltyEntry : penaltyEntries) {
        totalMonthlyPenaltyAmount = totalMonthlyPenaltyAmount.add(penaltyEntry.getPenaltyAmount());
        totalMonthlyPenaltyPaymentAmount = totalMonthlyPenaltyPaymentAmount.add(penaltyEntry.getAllocatePenaltyAmount());
      }

      monthlyPenaltyBalance = totalMonthlyPenaltyAmount.subtract(totalMonthlyPenaltyPaymentAmount);
      penaltySummary.setPenaltyBalanceAmount(monthlyPenaltyBalance);

      penaltySummaryRepository.save(penaltySummary);
    }
  }

  private void savePaymentPenaltyHistory(PenaltyEntry penaltyEntry, AllocatedPenaltyEvent event, MonetaryAmount oldAllocateAmount) {
    PenaltyHistoryEntry penaltyHistoryEntry = new PenaltyHistoryEntry();

    MonetaryAmount allocateAmount = penaltyEntry.getAllocatePenaltyAmount().subtract(oldAllocateAmount);

    if (!penaltyEntry.getReceivePenaltyAmount().isEqualTo(MMK_ZERO)) {
      penaltyHistoryEntry.setId(UUID.randomUUID().toString());
      penaltyHistoryEntry.setAllocatePenaltyAmount(allocateAmount);
      penaltyHistoryEntry.setBankTransaction(event.getBankTransaction());
      penaltyHistoryEntry.setContractNumber(event.getContractNumber());
      penaltyHistoryEntry.setInstallmentNumber(penaltyEntry.getInstallmentNumber());
      penaltyHistoryEntry.setPaymentDate(event.getPaymentDate());
      penaltyHistoryEntry.setPaymentReference(event.getPaymentReference());
      penaltyHistoryEntry.setReceivePenaltyAmount(penaltyEntry.getReceivePenaltyAmount());
      penaltyHistoryEntry.setPaymentStatus(penaltyEntry.getPaymentStatus());

      penaltyHistoryRepository.save(penaltyHistoryEntry);
    }
  }

  private void generateContractSchedule(StandardLoanContractActivatedEvent event) {

    List<LoanProductEntry> loanProductEntrys = loanProductRepository.findAllByContractId(event.getId());

    final LocalDate firstDueDate = FinanceUtils.getFirstDueDate(event.getContractDate(), loanProductEntrys.get(0).getPaymentFrequency().getValue());
    final LoanParameter loanParameter = LoanParameterBuilder.createBuilder()
            .numberOfCompoundingPeriods(loanProductEntrys.get(0).getPaymentFrequency().getValue())
            .loanAmount(loanProductEntrys.get(0).getLoanAmount())
            .loanTerm(loanProductEntrys.get(0).getTerm() / 12.0)
            .nominalInterestRate(loanProductEntrys.get(0).getInterestRate().setScale(4, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(12))
                    .divide(BigDecimal.valueOf(100), BigDecimal.ROUND_HALF_UP).doubleValue())
            .contractStartDate(event.getContractDate())
            .dueDate(firstDueDate)
            .build();

    SimpleAmortization simpleAmortization = new SimpleAmortization();

    List<Installment> installments = simpleAmortization.generatePaymentSchedule(loanParameter);
    for (Installment installment : installments) {
      PenaltyEntry penaltyEntry = new PenaltyEntry();

      penaltyEntry.setId(UUID.randomUUID().toString());
      penaltyEntry.setAllocatePenaltyAmount(MMK_ZERO);
      penaltyEntry.setBankTransaction("");
      penaltyEntry.setPenaltyAmount(MMK_ZERO);
      penaltyEntry.setReceivePenaltyAmount(MMK_ZERO);
      penaltyEntry.setContractNumber(event.getContractNumber());
      penaltyEntry.setDueDate(installment.getDueDate());
      penaltyEntry.setInstallmentNumber(installment.getInstallmentNumber());
      penaltyEntry.setPaymentStatus(PaymentStatus.UNPAID);

      penaltyRepository.save(penaltyEntry);
    }
  }

  @Value
  class AllocatedPenaltyEvent {
    String contractNumber;
    String bankTransaction;
    String paymentReference;
    LocalDate paymentDate;
    MonetaryAmount ReceivePenaltyAmount;
    MonetaryAmount totalInstallmentAmount;
  }
}
