package com.gl.csf.cm.query.service;

import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleEntry;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleRepository;
import com.gl.csf.cm.query.paymentinformation.penalty.PenaltyEntry;
import com.gl.csf.cm.query.paymentinformation.penalty.PenaltyRepository;
import com.gl.csf.cm.service.DailyPenaltyRateService;
import com.gl.csf.cm.service.GracePeriodService;
import com.gl.csf.cm.service.PenaltyCalculationPeriodService;
import org.javamoney.moneta.Money;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.util.Optional;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/18/2018.
 */
@Service
public class PenaltyOverdueDayService {

  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);

  private final PenaltyRepository penaltyRepository;
  private final GracePeriodService gracePeriodService;
  private final DailyPenaltyRateService dailyPenaltyRateService;
  private final PenaltyThresholdService penaltyThresholdService;
  private final ContractScheduleRepository contractScheduleRepository;
  private final PenaltyCalculationPeriodService penaltyCalculationPeriodService;

  @Inject
  public PenaltyOverdueDayService(PenaltyRepository penaltyRepository, GracePeriodService gracePeriodService,
                                  DailyPenaltyRateService dailyPenaltyRateService, PenaltyThresholdService penaltyThresholdService,
                                  ContractScheduleRepository contractScheduleRepository, PenaltyCalculationPeriodService penaltyCalculationPeriodService) {
    this.penaltyRepository = penaltyRepository;
    this.gracePeriodService = gracePeriodService;
    this.dailyPenaltyRateService = dailyPenaltyRateService;
    this.penaltyThresholdService = penaltyThresholdService;
    this.contractScheduleRepository = contractScheduleRepository;
    this.penaltyCalculationPeriodService = penaltyCalculationPeriodService;
  }

  public PenaltyEntry calculateOverdueDays(PenaltyEntry tmpPenaltyEntry, String bankTransaction, String paymentReference,
                                           MonetaryAmount receivePenaltyAmount, MonetaryAmount totalInstallment, LocalDate paymentDate) {

    PenaltyEntry penaltyEntry = new PenaltyEntry();

    penaltyEntry.setId(tmpPenaltyEntry.getId());

    penaltyEntry.setPaymentStatus(tmpPenaltyEntry.getPaymentStatus());
    penaltyEntry.setInstallmentNumber(tmpPenaltyEntry.getInstallmentNumber());
    penaltyEntry.setDueDate(tmpPenaltyEntry.getDueDate());
    penaltyEntry.setContractNumber(tmpPenaltyEntry.getContractNumber());
    penaltyEntry.setPaymentDate(tmpPenaltyEntry.getPaymentDate());

    if (bankTransaction.equals("") && paymentReference.equals("")) {
      penaltyEntry.setBankTransaction(tmpPenaltyEntry.getBankTransaction());
      penaltyEntry.setPaymentReference(tmpPenaltyEntry.getPaymentReference());
      penaltyEntry.setReceivePenaltyAmount(tmpPenaltyEntry.getReceivePenaltyAmount());
      penaltyEntry.setAllocatePenaltyAmount(tmpPenaltyEntry.getAllocatePenaltyAmount());
      penaltyEntry.setPaymentStatus(tmpPenaltyEntry.getPaymentStatus());
      if (tmpPenaltyEntry.getPaymentDate() != null) {
        penaltyEntry = overdueDayRule(penaltyEntry, tmpPenaltyEntry.getPaymentDate());
      } else {
        penaltyEntry = overdueDayRule(penaltyEntry, LocalDate.now());
        penaltyEntry.setPaymentDate(tmpPenaltyEntry.getPaymentDate());
      }
    } else {

      penaltyEntry.setBankTransaction(tmpPenaltyEntry.getBankTransaction());
      penaltyEntry.setPaymentReference(tmpPenaltyEntry.getPaymentReference());
      penaltyEntry.setReceivePenaltyAmount(tmpPenaltyEntry.getReceivePenaltyAmount());
      penaltyEntry.setAllocatePenaltyAmount(tmpPenaltyEntry.getAllocatePenaltyAmount());
      penaltyEntry.setPaymentStatus(tmpPenaltyEntry.getPaymentStatus());

      //================ Check when customer start payment ===============================

      PenaltyEntry nextInstallmentPenaltyEntry = penaltyRepository
              .findByContractNumberAndInstallmentNumber(penaltyEntry.getContractNumber(), (penaltyEntry.getInstallmentNumber() + 1)).get();

      ContractScheduleEntry contractScheduleEntry = contractScheduleRepository.findByContractNumberAndInstallmentNumber(
              tmpPenaltyEntry.getContractNumber(), tmpPenaltyEntry.getInstallmentNumber()).get();

      // check if before penalty period
      if (paymentDate.isBefore(nextInstallmentPenaltyEntry.getDueDate().minusDays(penaltyCalculationPeriodService.getAllPenaltyCalculationPeriods().get(0).getDays()))) {

        // if total installment less than (expected installment x  Penalty threshole)
        if (totalInstallment.isLessThan(contractScheduleEntry.getScheduleInstallmentAmount()
                .multiply(penaltyThresholdService.getAllPenaltyThreshold().get(0).getThreshold()))) {
          // if total installment less than 30% of expected installment
          if (totalInstallment.isLessThan(contractScheduleEntry.getScheduleInstallmentAmount().multiply(30).divide(100))) {
            penaltyEntry = overdueDayRule(penaltyEntry, nextInstallmentPenaltyEntry.getDueDate());
            // if penalty was paid we don't calculate any more
            if (!PaymentStatus.FULL.equals(penaltyEntry.getPaymentStatus())) {
              if (!receivePenaltyAmount.isEqualTo(MMK_ZERO)) {
                penaltyEntry.setBankTransaction(bankTransaction);
                penaltyEntry.setPaymentReference(paymentReference);
                penaltyEntry.setPaymentDate(paymentDate);
              }
              penaltyEntry.setReceivePenaltyAmount(receivePenaltyAmount);
              penaltyEntry.setAllocatePenaltyAmount(tmpPenaltyEntry.getAllocatePenaltyAmount());

              // if partial paid calculate from the first payment date
              if (tmpPenaltyEntry.getPaymentDate() != null) {
                penaltyEntry = overdueDayRule(penaltyEntry, nextInstallmentPenaltyEntry.getDueDate());
                penaltyEntry = updatePaymentStatus(penaltyEntry);
              } else {
                penaltyEntry = overdueDayRule(penaltyEntry, LocalDate.now());
                penaltyEntry = updatePaymentStatus(penaltyEntry);
              }
            }
          }
          // total installment greater than 30%
          else {
            if (!PaymentStatus.FULL.equals(penaltyEntry.getPaymentStatus())) {
              if (!receivePenaltyAmount.isEqualTo(MMK_ZERO)) {
                penaltyEntry.setBankTransaction(bankTransaction);
                penaltyEntry.setPaymentReference(paymentReference);
                penaltyEntry.setPaymentDate(paymentDate);
              }
              penaltyEntry.setReceivePenaltyAmount(receivePenaltyAmount);
              penaltyEntry.setAllocatePenaltyAmount(tmpPenaltyEntry.getAllocatePenaltyAmount());

              if (tmpPenaltyEntry.getPaymentDate() != null) {
                penaltyEntry = overdueDayRule(penaltyEntry, tmpPenaltyEntry.getPaymentDate());
                penaltyEntry = updatePaymentStatus(penaltyEntry);
              } else {
                penaltyEntry = overdueDayRule(penaltyEntry, LocalDate.now());
                penaltyEntry = updatePaymentStatus(penaltyEntry);
              }
            }
          }
        }
      }
    }

    return penaltyEntry;
  }

  private PenaltyEntry overdueDayRule(PenaltyEntry penaltyEntry, LocalDate date) {

    Optional<PenaltyEntry> nextInstallmentPenaltyEntry = penaltyRepository
            .findByContractNumberAndInstallmentNumber(penaltyEntry.getContractNumber(), (penaltyEntry.getInstallmentNumber() + 1));

    int overdueDays;

    if (DAYS.between(penaltyEntry.getDueDate(), date) <= 0) {
      penaltyEntry.setOverdueDays(0);
      penaltyEntry.setAllocatePenaltyAmount(MMK_ZERO);
      penaltyEntry.setPenaltyAmount(MMK_ZERO);
    } else if (1 < DAYS.between(penaltyEntry.getDueDate(), date) && DAYS.between(penaltyEntry.getDueDate(), date) <
            DAYS.between(penaltyEntry.getDueDate(), nextInstallmentPenaltyEntry.get().getDueDate())) {
      overdueDays = (int) DAYS.between(penaltyEntry.getDueDate(), date);
      penaltyEntry.setOverdueDays(overdueDays);

      MonetaryAmount penaltyAmount = MMK_ZERO;
      if (overdueDays - gracePeriodService.getAllGracePeriod().get(0).getDays() > 0) {
        penaltyAmount = dailyPenaltyRateService.getAllDailyPenalty().get(0).getRate().multiply((overdueDays - gracePeriodService.getAllGracePeriod().get(0).getDays()));
      }

      penaltyEntry.setPenaltyAmount(penaltyAmount);

    } else if (DAYS.between(penaltyEntry.getDueDate(), date) >= DAYS.between(penaltyEntry.getDueDate(), nextInstallmentPenaltyEntry.get().getDueDate())) {
      overdueDays = (int) DAYS.between(penaltyEntry.getDueDate(), nextInstallmentPenaltyEntry.get().getDueDate());
      penaltyEntry.setOverdueDays(overdueDays);
      MonetaryAmount penaltyAmount = MMK_ZERO;
      if (overdueDays - gracePeriodService.getAllGracePeriod().get(0).getDays() > 0) {
        penaltyAmount = dailyPenaltyRateService.getAllDailyPenalty().get(0).getRate().multiply((overdueDays - gracePeriodService.getAllGracePeriod().get(0).getDays()));
      }

      penaltyEntry.setPenaltyAmount(penaltyAmount);
    }

    return penaltyEntry;
  }

  private PenaltyEntry updatePaymentStatus(PenaltyEntry penaltyEntry) {

    if (penaltyEntry.getReceivePenaltyAmount() != null) {
      if (penaltyEntry.getReceivePenaltyAmount().isZero() && PaymentStatus.UNPAID.equals(penaltyEntry.getPaymentStatus())) {
        penaltyEntry.setPaymentStatus(PaymentStatus.UNPAID);
        penaltyEntry.setAllocatePenaltyAmount(MMK_ZERO);
      } else if (penaltyEntry.getReceivePenaltyAmount().isGreaterThanOrEqualTo(penaltyEntry.getPenaltyAmount())) {
        penaltyEntry.setAllocatePenaltyAmount(penaltyEntry.getPenaltyAmount());
        penaltyEntry.setPaymentStatus(PaymentStatus.FULL);
      } else {
        MonetaryAmount totalAllocateAmount = penaltyEntry.getReceivePenaltyAmount().add(penaltyEntry.getAllocatePenaltyAmount());
        if (totalAllocateAmount.isGreaterThanOrEqualTo(penaltyEntry.getPenaltyAmount())) {
          penaltyEntry.setAllocatePenaltyAmount(penaltyEntry.getPenaltyAmount());
          penaltyEntry.setPaymentStatus(PaymentStatus.FULL);
        } else {
          penaltyEntry.setPaymentStatus(PaymentStatus.PARTIAL);
          penaltyEntry.setAllocatePenaltyAmount(penaltyEntry.getReceivePenaltyAmount());
        }
      }
    }

    return penaltyEntry;
  }
}
