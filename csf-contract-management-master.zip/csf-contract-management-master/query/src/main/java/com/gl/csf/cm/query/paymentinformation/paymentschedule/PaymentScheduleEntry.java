package com.gl.csf.cm.query.paymentinformation.paymentschedule;

import com.gl.csf.cm.common.model.PaymentStatus;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class PaymentScheduleEntry {
  @Id
  private String id;
  private String contractNumber;
  private Integer installmentNumber;

  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "installment_currency"), @Column(name = "installment_amount")})
  private MonetaryAmount installmentAmount;

  private String bankTransaction;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "payment_currency"), @Column(name = "payment_amount")})
  private MonetaryAmount paymentAmount;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "allocation_currency"), @Column(name = "allocation_amount")})
  private MonetaryAmount amountAllocation;

  private LocalDate paymentDate;
  private String paymentReference;
  
  @Column(name = "payment_status")
  @Enumerated(EnumType.STRING)
  private PaymentStatus paymentStatus;

  @Transient
  private List<PaymentScheduleEntry> subItems =new ArrayList<>();

  public void setSubItems(List<PaymentScheduleEntry> subItems){
    this.subItems = subItems;
  }

}
