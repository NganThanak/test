package com.gl.csf.cm.query.contract.product;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by p.ly on 1/25/2018.
 */
public interface StaffLoanProductRepository extends JpaRepository<StaffLoanProductEntry, String> {
  StaffLoanProductEntry findOneByContractIdAndLoanStatus(String contractId, LoanProductStatus loanProductStatus);
  List<StaffLoanProductEntry> findAllByContractId(String contractId);
  int countAllByContractId(String contractId);
}
