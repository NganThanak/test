package com.gl.csf.cm.query.contract.contractsummary;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.product.ProductType;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
@Data
@Entity
public class CustomerContractSummaryEntry {

  @Id
  private String id;
  private String customerUsername;
  private String contractNumber;
  private LocalDate dateCreated;

  @Column(name = "product_type")
  @Enumerated(EnumType.STRING)
  private ProductType productType;

  @Column(name = "contract_status")
  @Enumerated(EnumType.STRING)
  private ContractStatus contractStatus;
}
