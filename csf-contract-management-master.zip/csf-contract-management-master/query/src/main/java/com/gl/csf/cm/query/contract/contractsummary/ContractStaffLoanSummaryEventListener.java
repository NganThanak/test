package com.gl.csf.cm.query.contract.contractsummary;

import com.gl.csf.cm.api.contract.event.*;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.contract.RescheduleStatus;
import com.gl.csf.cm.common.model.contract.WriteOffStatus;
import com.gl.csf.cm.common.model.payment.DueDateCalculationPeriod;
import com.gl.csf.cm.service.DueDateCalculationPeriodService;
import com.gl.csf.financeapi.utils.FinanceUtils;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Comparator;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
@Component
public class ContractStaffLoanSummaryEventListener {
	
  private final ContractStaffLoanSummaryRepository repository;
  private final DueDateCalculationPeriodService service;

  @Inject
  public ContractStaffLoanSummaryEventListener(ContractStaffLoanSummaryRepository repository, DueDateCalculationPeriodService service) {
    this.repository = repository;
    this.service = service;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    ContractStaffLoanSummaryEntry contractSummaryEntry = new ContractStaffLoanSummaryEntry();
    
    contractSummaryEntry.setId(event.getId());
    contractSummaryEntry.setContractNumber(event.getContractNumber());
    contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    contractSummaryEntry.setRescheduleStatus(RescheduleStatus.NONE);
    contractSummaryEntry.setWriteoffStatus(WriteOffStatus.NONE);

    contractSummaryEntry.setStaffName(event.getStaff().getFullName());
    contractSummaryEntry.setLoanAmount(event.getStaffLoanProduct().getLoanAmount());
    contractSummaryEntry.setTerm(event.getStaffLoanProduct().getTerm());
    contractSummaryEntry.setLoanType(event.getStaffLoanProduct().getProductType());
    contractSummaryEntry.setPaymentFrequency(event.getStaffLoanProduct().getPaymentFrequency());

    repository.save(contractSummaryEntry);
    
  }
  
  @EventHandler
  public void on(ContractActivatedEvent event){
    ContractStaffLoanSummaryEntry contractEntry = repository.findOne(event.getId());
    if(contractEntry == null)
      return;
    contractEntry.setContractStatus(ContractStatus.CONTRACT_ACTIVATED);
    if (event.getContractNumber().contains("SL-")) {
    	int days = service.getAllDueDateCalculationPeriod().stream().filter(
    		      p -> (LocalDate.now().isAfter(p.getEffectiveDate()) || LocalDate.now().isEqual(p.getEffectiveDate()))
    		        && !LocalDate.now().isBefore(p.getEffectiveDate())) .sorted(Comparator.comparing(DueDateCalculationPeriod::getEffectiveDate).reversed())
    		      .map(DueDateCalculationPeriod::getDays).findFirst().orElse(null);
    	contractEntry.setDueDate(FinanceUtils.getFirstDueDateForStaffLoan(event.getContractDate(), days));
    } else {
    	contractEntry.setDueDate(FinanceUtils.getFirstDueDate(event.getContractDate(), contractEntry.getPaymentFrequency().getValue()));
    }
    repository.save(contractEntry);
  }
  
  @EventHandler
  public void on(StaffLoanContractCancellationRejectedEvent event){
    ContractStaffLoanSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    repository.save(contractSummaryEntry);
  }
  
  @EventHandler
  public void on(PendingStaffLoanContractCancelledEvent event){
    ContractStaffLoanSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractStatus(ContractStatus.PENDING_CANCEL);
    repository.save(contractSummaryEntry);
  }
  
  @EventHandler
  public void on(StaffLoanContractCancelledEvent event){
    ContractStaffLoanSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(contractSummaryEntry);
  }
}
