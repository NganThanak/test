package com.gl.csf.cm.query.paymentinformation.penalty.history;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/20/2018.
 */
public interface PenaltyHistoryRepository extends PagingAndSortingRepository<PenaltyHistoryEntry, String>,
        QueryByExampleExecutor<PenaltyHistoryEntry> {
  List<PenaltyHistoryEntry> findByContractNumberAndInstallmentNumber(String contractNumber, int installmentNumber);
}
