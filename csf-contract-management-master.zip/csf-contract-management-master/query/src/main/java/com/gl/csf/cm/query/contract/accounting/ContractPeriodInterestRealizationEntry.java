package com.gl.csf.cm.query.contract.accounting;

import com.gl.csf.cm.common.model.product.ProductType;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class ContractPeriodInterestRealizationEntry implements Serializable {
  @Id
  private String id;
  private String contractNumber;
  private String contractId;

  private Integer period;
  private LocalDate dueDate;

  @Column(name = "product_type")
  @Enumerated(EnumType.STRING)
  private ProductType productType;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "installment_currency"), @Column(name = "installment_amount")})
  private MonetaryAmount installment;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "interest_currency"), @Column(name = "interest_amount")})
  private MonetaryAmount interest;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "principal_currency"), @Column(name = "principal_amount")})
  private MonetaryAmount principal;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "remaining_principal_balance_currency"), @Column(name = "remaining_principal_balance_amount")})
  private MonetaryAmount remainingPrincipalBalance;

  private LocalDate endOfMonthDate;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "interest_eom_currency"), @Column(name = "interest_eom_amount")})
  private MonetaryAmount interestEndOfMonth;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "sum_of_accrued_interest_eom_currency"), @Column(name = "sum_of_accrued_interest_eom_amount")})
  private MonetaryAmount sumOfAccruedInterestEndOfMonth;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "principal_eom_currency"), @Column(name = "principal_eom_amount")})
  private MonetaryAmount principalEndOfMonth;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "sum_of_accrued_principal_eom_currency"), @Column(name = "sum_of_accrued_principal_eom_amount")})
  private MonetaryAmount sumOfAccruedPrincipalEndOfMonth;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "remaining_balance_eom_currency"), @Column(name = "remaining_balance_eom_amount")})
  private MonetaryAmount remainingBalanceEndOfMonth;
}