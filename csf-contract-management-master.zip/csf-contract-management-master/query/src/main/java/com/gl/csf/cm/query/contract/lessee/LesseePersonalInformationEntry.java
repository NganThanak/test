package com.gl.csf.cm.query.contract.lessee;

import com.gl.csf.cm.common.model.Gender;
import com.gl.csf.cm.common.model.address.Address;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Entity
@Data
public class LesseePersonalInformationEntry implements Serializable {
  @Id
  private String id;
  private String fullName;
  private String fatherName;
  @Enumerated(EnumType.STRING)
  private Gender gender;
  private LocalDate dob;
  private String phoneNumber;
  private String additionalPhoneNumber1;
  private String additionalPhoneNumber2;
  private String email;
  private String nrcId;
  private Address ownerAddress;
}
