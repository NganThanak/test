package com.gl.csf.cm.query.service;

import com.gl.csf.cm.common.model.payment.PenaltyThreshold;
import com.gl.csf.cm.config.Authenticated;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/30/2018.
 */
@Service
public class PenaltyThresholdService {
  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public PenaltyThresholdService(@Value("${endpoints.rest.parameter.penaltythreshold}") String baseUrl,
                                          @Authenticated(Authenticated.With.CLIENT_CREDENTIALS) RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  public List<PenaltyThreshold> getAllPenaltyThreshold(){
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
            new ParameterizedTypeReference<List<PenaltyThreshold>>(){}).getBody();
  }

  public Optional<PenaltyThreshold> getPenaltyThresholdById(UUID stateId){
    Objects.requireNonNull(stateId);

    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/" + stateId, HttpMethod.GET, null,
              new ParameterizedTypeReference<PenaltyThreshold>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
