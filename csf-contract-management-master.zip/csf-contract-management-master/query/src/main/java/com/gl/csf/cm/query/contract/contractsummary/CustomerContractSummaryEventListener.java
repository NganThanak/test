package com.gl.csf.cm.query.contract.contractsummary;

import com.gl.csf.cm.api.contract.event.*;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
@Component
public class CustomerContractSummaryEventListener {
  private final CustomerContractSummaryRepository repository;

  @Inject
  public CustomerContractSummaryEventListener(CustomerContractSummaryRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event) {
    CustomerContractSummaryEntry entry = new CustomerContractSummaryEntry();

    entry.setId(event.getId());
    entry.setContractNumber(event.getContractNumber());
    entry.setProductType(event.getLoanProduct().getProductType());
    entry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    entry.setDateCreated(event.getCreatedDate());
    
    repository.save(entry);
  }
  
  @EventHandler
  public void on(ContractCancelledEvent event){
    CustomerContractSummaryEntry entry =repository.findOne(event.getId());
    entry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(entry);
  }
  
  @EventHandler
  public void on(ContractActivatedCancelledEvent event){
    CustomerContractSummaryEntry entry =repository.findOne(event.getId());
    entry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(entry);
  }
  
  @EventHandler
  public void on(ContractNumberUpdatedEvent event){
    CustomerContractSummaryEntry entry = repository.findOne(event.getId());
    entry.setContractNumber(event.getContractNumber());
    repository.save(entry);
  }
}
