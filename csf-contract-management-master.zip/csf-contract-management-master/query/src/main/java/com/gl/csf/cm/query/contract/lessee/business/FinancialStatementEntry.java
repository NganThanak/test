package com.gl.csf.cm.query.contract.lessee.business;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class FinancialStatementEntry implements Serializable {
  @Id
  private String id;
  private Integer totalBranch;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "revenue_currency"), @Column(name = "revenue_amount")})
  private MonetaryAmount revenue;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "expense_currency"), @Column(name = "expense_amount")})
  private MonetaryAmount expense;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "margin_currency"), @Column(name = "margin_amount")})
  private MonetaryAmount margin;
  private Integer numberOfStaff;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "staff_expense_currency"), @Column(name = "staff_expense_amount")})
  private MonetaryAmount staffExpense;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "net_profit_currency"), @Column(name = "net_profit_amount")})
  private MonetaryAmount netProfit;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "total_rent_currency"), @Column(name = "total_rent")})
  private MonetaryAmount totalRent;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "other_expense_currency"), @Column(name = "other_expense")})
  private MonetaryAmount otherExpense;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "financial_ratio_currency"), @Column(name = "financial_ratio")})
  private MonetaryAmount financialRatio;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "installment_currency"), @Column(name = "installment")})
  private MonetaryAmount installment;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "financial_ratio_low_currency"), @Column(name = "financial_ratio_low")})
  private MonetaryAmount financialRatioLow;

}
