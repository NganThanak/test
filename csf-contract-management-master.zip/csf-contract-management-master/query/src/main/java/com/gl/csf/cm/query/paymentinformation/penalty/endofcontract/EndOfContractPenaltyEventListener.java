package com.gl.csf.cm.query.paymentinformation.penalty.endofcontract;

import com.gl.csf.cm.api.contract.event.PaymentFullyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.PaymentPartiallyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleEntry;
import com.gl.csf.cm.query.paymentinformation.contractschedule.ContractScheduleRepository;
import com.gl.csf.cm.query.paymentinformation.penalty.PenaltyRepository;
import com.gl.csf.cm.query.paymentinformation.penalty.summary.PenaltySummary;
import com.gl.csf.cm.query.paymentinformation.penalty.summary.PenaltySummaryRepository;
import com.gl.csf.cm.service.DailyPenaltyRateService;
import com.gl.csf.cm.query.service.PenaltyOverdueDayService;
import lombok.Value;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/18/2018.
 */
@Component
public class EndOfContractPenaltyEventListener {

  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);

  private final EndOfContractPenaltyRepository endOfContractPenaltyRepository;
  private final PenaltyRepository penaltyRepository;
  private final PenaltyOverdueDayService penaltyOverdueDayService;
  private final ContractScheduleRepository contractScheduleRepository;
  private final DailyPenaltyRateService dailyPenaltyRateService;
  private final PenaltySummaryRepository penaltySummaryRepository;

  @Inject
  public EndOfContractPenaltyEventListener(EndOfContractPenaltyRepository endOfContractPenaltyRepository, PenaltyRepository penaltyRepository,
                                           PenaltyOverdueDayService penaltyOverdueDayService, ContractScheduleRepository contractScheduleRepository,
                                           DailyPenaltyRateService dailyPenaltyRateService, PenaltySummaryRepository penaltySummaryRepository) {
    this.endOfContractPenaltyRepository = endOfContractPenaltyRepository;
    this.penaltyRepository = penaltyRepository;
    this.penaltyOverdueDayService = penaltyOverdueDayService;
    this.contractScheduleRepository = contractScheduleRepository;
    this.dailyPenaltyRateService = dailyPenaltyRateService;
    this.penaltySummaryRepository = penaltySummaryRepository;
  }

  @EventHandler
  private void on(StandardLoanContractActivatedEvent event) {
    EndOfContractPenaltyEntry endOfContractPenaltyEntry = new EndOfContractPenaltyEntry();

    endOfContractPenaltyEntry.setId(UUID.randomUUID().toString());
    endOfContractPenaltyEntry.setBankTransaction("");
    endOfContractPenaltyEntry.setContractNumber(event.getContractNumber());
    endOfContractPenaltyEntry.setPaymentAllocation(MMK_ZERO);
    endOfContractPenaltyEntry.setPaymentAmount(MMK_ZERO);
    endOfContractPenaltyEntry.setPaymentStatus(null);
    endOfContractPenaltyEntry.setPenaltyAmount(MMK_ZERO);

    endOfContractPenaltyRepository.save(endOfContractPenaltyEntry);
  }

  @EventHandler
  private void on(PaymentPartiallyAllocatedEvent event) {
    updateEndOfContractPenalty(new EndOfContractPenaltyAllocatedEvent(event.getContractNumber(), event.getInstallmentNumber(), event.getPaymentDate(),
            event.getBankTransaction(), event.getPenaltyAmount()));
  }

  @EventHandler
  private void on(PaymentFullyAllocatedEvent event) {
    updateEndOfContractPenalty(new EndOfContractPenaltyAllocatedEvent(event.getContractNumber(), event.getInstallmentNumber(), event.getPaymentDate(),
            event.getBankTransaction(), event.getPenaltyAmount()));
  }

  private Boolean isEndOfContract(String contractNumber, int installmentNumber){

    Boolean isEndOfContract = true;

    Optional<ContractScheduleEntry> contractScheduleEntries = contractScheduleRepository.findByContractNumberAndInstallmentNumber(contractNumber, (installmentNumber+1));
    if(contractScheduleEntries.isPresent()){
      isEndOfContract = false;
    }

    return isEndOfContract;
  }

  private void updateEndOfContractPenalty(EndOfContractPenaltyAllocatedEvent event) {
    List<ContractScheduleEntry> contractScheduleEntries = contractScheduleRepository.findByContractNumber(event.getContractNumber());
    EndOfContractPenaltyEntry endOfContractPenaltyEntry;
    Double totalOutstandingRatio = 0D;
    MonetaryAmount penaltyAmount;
    PaymentStatus paymentStatus;
    MonetaryAmount penaltyAmountAllocation;

    if(isEndOfContract(event.getContractNumber(), event.getInstallmentNumber())){
      for (ContractScheduleEntry contractScheduleEntry : contractScheduleEntries) {
        totalOutstandingRatio = totalOutstandingRatio + contractScheduleEntry.getOutstandingRatio();
      }

      List<EndOfContractPenaltyEntry> endOfContractPenaltyEntries = endOfContractPenaltyRepository.findByContractNumber(event.getContractNumber());
      penaltyAmount = dailyPenaltyRateService.getAllDailyPenalty().get(0).getRate().multiply(totalOutstandingRatio);

      if(event.getPaymentAmount().isEqualTo(MMK_ZERO)){
        paymentStatus = PaymentStatus.UNPAID;
        penaltyAmountAllocation = MMK_ZERO;
      }
      else if(penaltyAmount.isGreaterThanOrEqualTo(event.getPaymentAmount())){
        penaltyAmountAllocation = event.getPaymentAmount();
        paymentStatus = PaymentStatus.PARTIAL;
      }
      else{
        penaltyAmountAllocation = penaltyAmount;
        paymentStatus = PaymentStatus.FULL;
      }

      if(!endOfContractPenaltyEntries.isEmpty()){
        endOfContractPenaltyEntry = endOfContractPenaltyEntries.get(0);
        endOfContractPenaltyEntry.setBankTransaction(event.getBankTransaction());
        endOfContractPenaltyEntry.setPaymentAllocation(penaltyAmountAllocation);
        endOfContractPenaltyEntry.setPaymentAmount(event.getPaymentAmount());
        endOfContractPenaltyEntry.setPaymentDate(event.getPaymentDate());
        endOfContractPenaltyEntry.setPaymentStatus(paymentStatus);
        endOfContractPenaltyEntry.setPenaltyAmount(penaltyAmount);
        endOfContractPenaltyEntry.setContractNumber(event.getContractNumber());
      }
      else{
        endOfContractPenaltyEntry = new EndOfContractPenaltyEntry();
        endOfContractPenaltyEntry.setId(UUID.randomUUID().toString());
        endOfContractPenaltyEntry.setBankTransaction(event.getBankTransaction());
        endOfContractPenaltyEntry.setPaymentAllocation(penaltyAmountAllocation);
        endOfContractPenaltyEntry.setPaymentAmount(event.getPaymentAmount());
        endOfContractPenaltyEntry.setPaymentDate(event.getPaymentDate());
        endOfContractPenaltyEntry.setPaymentStatus(paymentStatus);
        endOfContractPenaltyEntry.setPenaltyAmount(penaltyAmount);
        endOfContractPenaltyEntry.setContractNumber(event.getContractNumber());
      }

      endOfContractPenaltyRepository.save(endOfContractPenaltyEntry);

      updatePenaltySummary(event.getContractNumber(), endOfContractPenaltyEntry);

    }
  }

  private void updatePenaltySummary(String contractNumber, EndOfContractPenaltyEntry endOfContractPenaltyEntry){
    Optional<PenaltySummary> optionalPenaltySummary = penaltySummaryRepository.findByContractNumber(contractNumber);
    if(optionalPenaltySummary.isPresent()){
      PenaltySummary penaltySummary = optionalPenaltySummary.get();
      penaltySummary.setEndOfContractPenaltyBalanceAmount(endOfContractPenaltyEntry.getPenaltyAmount().subtract(endOfContractPenaltyEntry.getPaymentAmount()));
      penaltySummaryRepository.save(penaltySummary);
    }
  }


  @Value
  class EndOfContractPenaltyAllocatedEvent {
    String contractNumber;
    int installmentNumber;
    LocalDate paymentDate;
    String bankTransaction;
    MonetaryAmount paymentAmount;
  }
}
