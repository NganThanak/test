package com.gl.csf.cm.query.contract.lessee.business;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.lessee.LesseeBusiness;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class LesseeBusinessEventListener {
  private final LesseeBusinessRepository repository;

  @Inject
  public LesseeBusinessEventListener(LesseeBusinessRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    LesseeBusiness lesseeBusiness = event.getLesseeBusiness();

    LesseeBusinessEntry lesseeBusinessEntry = new LesseeBusinessEntry();
    lesseeBusinessEntry.setId(event.getId());
    lesseeBusinessEntry.setBusinessName(lesseeBusiness.getBusinessName());
    lesseeBusinessEntry.setMainBranch(new MainBranch(lesseeBusiness.getMainBranchId(), lesseeBusiness.getMainBranchName()));
    lesseeBusinessEntry.setIsBoss(lesseeBusiness.getIsBoss());
    lesseeBusinessEntry.setBusinessId(lesseeBusiness.getBusinessId());

    repository.save(lesseeBusinessEntry);
  }
}
