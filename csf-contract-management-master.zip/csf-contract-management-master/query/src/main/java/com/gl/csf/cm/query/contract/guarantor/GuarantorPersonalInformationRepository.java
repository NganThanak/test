package com.gl.csf.cm.query.contract.guarantor;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
public interface GuarantorPersonalInformationRepository extends JpaRepository<GuarantorPersonalInformationEntry, String> {
}
