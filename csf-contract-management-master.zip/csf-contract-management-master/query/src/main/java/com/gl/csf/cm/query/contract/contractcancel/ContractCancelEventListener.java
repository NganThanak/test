package com.gl.csf.cm.query.contract.contractcancel;

import com.gl.csf.cm.api.contract.event.*;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/14/2017.
 */
@Component
public class ContractCancelEventListener {
  private final ContractCancelRepository contractCancelRepository;
  
  @Inject
  public ContractCancelEventListener(ContractCancelRepository contractCancelRepository) {
    this.contractCancelRepository = contractCancelRepository;
  }
  
  @EventHandler
  public void on(PendingContractCancelledEvent event){
    Optional<ContractCancelEntry> contractSummaryEntry = contractCancelRepository.findByContractID(event.getId());
    if(contractSummaryEntry.isPresent()){
      contractSummaryEntry.get().setContractStatus(event.getContractStatus());
      contractSummaryEntry.get().setCancelledReasonStaff(event.getCancelReason());
      contractSummaryEntry.get().setUpdatedBy(event.getUpdatedBy());
      contractSummaryEntry.get().setCancelledDate(LocalDate.now());
      contractCancelRepository.save(contractSummaryEntry.get());
    }else {
      ContractCancelEntry contractCancelEntry = new ContractCancelEntry();
      contractCancelEntry.setId(UUID.randomUUID().toString());
      contractCancelEntry.setContractID(event.getId());
      contractCancelEntry.setContractStatus(event.getContractStatus());
      contractCancelEntry.setCancelledReasonStaff(event.getCancelReason());
      contractCancelEntry.setUpdatedBy(event.getUpdatedBy());
      contractCancelEntry.setCancelledDate(LocalDate.now());
      contractCancelRepository.save(contractCancelEntry);
    }
  }
  
  @EventHandler
  public void on(ContractCancelledEvent event){
    Optional<ContractCancelEntry> contractSummaryEntry = contractCancelRepository.findByContractID(event.getId());
    if(!contractSummaryEntry.isPresent()){
      ContractCancelEntry newContractEntry = new ContractCancelEntry();
      newContractEntry.setId(UUID.randomUUID().toString());
      newContractEntry.setContractID(event.getId());
      newContractEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
      newContractEntry.setCancelledReasonManager(event.getCancelReason());
      newContractEntry.setUpdatedBy(event.getUpdatedBy());
      newContractEntry.setCancelledDate(LocalDate.now());
      contractCancelRepository.save(newContractEntry);
    }else {
      contractSummaryEntry.get().setUpdatedBy(event.getUpdatedBy());
      contractSummaryEntry.get().setCancelledDate(LocalDate.now());
      contractSummaryEntry.get().setCancelledReasonManager(event.getCancelReason());
      contractSummaryEntry.get().setContractStatus(ContractStatus.CONTRACT_CANCELLED);
      contractCancelRepository.save(contractSummaryEntry.get());
    }
  }
  
  @EventHandler
  public void on(ContractCancellationRejectedEvent event){
    Optional<ContractCancelEntry> contractSummaryEntry = contractCancelRepository.findByContractID(event.getId());
    contractSummaryEntry.get().setUpdatedBy(event.getUpdatedBy());
    contractSummaryEntry.get().setCancelledDate(LocalDate.now());
    contractSummaryEntry.get().setContractStatus(ContractStatus.CONTRACT_PENDING);
    contractCancelRepository.save(contractSummaryEntry.get());
  }
  
  @EventHandler
  public void on(ContractActivatedCancelledEvent event){
    ContractCancelEntry newContractEntry = new ContractCancelEntry();
    newContractEntry.setId(UUID.randomUUID().toString());
    newContractEntry.setContractID(event.getId());
    newContractEntry.setContractStatus(event.getContractStatus());
    newContractEntry.setCancelledReasonManager(event.getCancelReason());
    newContractEntry.setUpdatedBy(event.getUpdatedBy());
    newContractEntry.setCancelledDate(LocalDate.now());
    contractCancelRepository.save(newContractEntry);
  }
  
  @EventHandler
  public void on(PendingStaffLoanContractCancelledEvent event){
    Optional<ContractCancelEntry> contractSummaryEntry = contractCancelRepository.findByContractID(event.getId());
    if(contractSummaryEntry.isPresent()){
      contractSummaryEntry.get().setContractStatus(event.getContractStatus());
      contractSummaryEntry.get().setCancelledReasonStaff(event.getCancelReason());
      contractSummaryEntry.get().setUpdatedBy(event.getUpdatedBy());
      contractSummaryEntry.get().setCancelledDate(LocalDate.now());
      contractCancelRepository.save(contractSummaryEntry.get());
    }else {
      ContractCancelEntry contractCancelEntry = new ContractCancelEntry();
      contractCancelEntry.setId(UUID.randomUUID().toString());
      contractCancelEntry.setContractID(event.getId());
      contractCancelEntry.setContractStatus(event.getContractStatus());
      contractCancelEntry.setCancelledReasonStaff(event.getCancelReason());
      contractCancelEntry.setUpdatedBy(event.getUpdatedBy());
      contractCancelEntry.setCancelledDate(LocalDate.now());
      contractCancelRepository.save(contractCancelEntry);
    }
  }
  
  @EventHandler
  public void on(StaffLoanContractCancelledEvent event){
    Optional<ContractCancelEntry> contractSummaryEntry = contractCancelRepository.findByContractID(event.getId());
    if(!contractSummaryEntry.isPresent()){
      ContractCancelEntry newContractEntry = new ContractCancelEntry();
      newContractEntry.setId(UUID.randomUUID().toString());
      newContractEntry.setContractID(event.getId());
      newContractEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
      newContractEntry.setCancelledReasonManager(event.getCancelReason());
      newContractEntry.setUpdatedBy(event.getUpdatedBy());
      newContractEntry.setCancelledDate(LocalDate.now());
      contractCancelRepository.save(newContractEntry);
    }else {
      contractSummaryEntry.get().setUpdatedBy(event.getUpdatedBy());
      contractSummaryEntry.get().setCancelledDate(LocalDate.now());
      contractSummaryEntry.get().setCancelledReasonManager(event.getCancelReason());
      contractSummaryEntry.get().setContractStatus(ContractStatus.CONTRACT_CANCELLED);
      contractCancelRepository.save(contractSummaryEntry.get());
    }
  }
  
  @EventHandler
  public void on(StaffLoanContractCancellationRejectedEvent event){
    Optional<ContractCancelEntry> contractSummaryEntry = contractCancelRepository.findByContractID(event.getId());
    contractSummaryEntry.get().setUpdatedBy(event.getUpdatedBy());
    contractSummaryEntry.get().setCancelledDate(LocalDate.now());
    contractSummaryEntry.get().setContractStatus(ContractStatus.CONTRACT_PENDING);
    contractCancelRepository.save(contractSummaryEntry.get());
  }
}
