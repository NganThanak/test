package com.gl.csf.cm.query.paymentinformation.paymentschedule;

import com.gl.csf.cm.common.model.PaymentStatus;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
public interface PaymentScheduleRepository extends PagingAndSortingRepository<PaymentScheduleEntry, String>,
        QueryByExampleExecutor<PaymentScheduleEntry> {
    PaymentScheduleEntry findAllByContractNumberAndInstallmentNumber(String contractNumber, int installmentNo);
    List<PaymentScheduleEntry> findAllByContractNumberOrderByInstallmentNumber(String contractNumber);
    /*findAllByContractNumberAndOrderByInstallmentNumber*/
    List<PaymentScheduleEntry> findByContractNumberAndPaymentStatusInOrderByInstallmentNumberAsc(String contractNumber, List<PaymentStatus> statuses);
}

