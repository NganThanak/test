package com.gl.csf.cm.query.paymentinformation.contractschedule;

import com.gl.csf.cm.common.model.payment.PaymentStatus;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class ContractScheduleEntry {
  @Id
  private String id;

  private String contractNumber;

  private int installmentNumber;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "schedule_installment_amount_currency"), @Column(name = "schedule_installment_amount")})
  private MonetaryAmount scheduleInstallmentAmount;

  private LocalDate scheduleDueDate;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "schedule_principle_currency"), @Column(name = "schedule_principle")})
  private MonetaryAmount schedulePrinciple;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "schedule_interest_currency"), @Column(name = "schedule_interest_amount")})
  private MonetaryAmount scheduleInterest;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "payment_installment_currency"), @Column(name = "payment_installment")})
  private MonetaryAmount paymentInstallment;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "payment_principle_currency"), @Column(name = "payment_principle")})
  private MonetaryAmount paymentPrinciple;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "payment_interest_currency"), @Column(name = "payment_interest")})
  private MonetaryAmount paymentInterest;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "payment_monthly_penalty_currency"), @Column(name = "payment_monthly_penalty")})
  private MonetaryAmount paymentMonthlyPenalty;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "fee_currency"), @Column(name = "fee")})
  private MonetaryAmount fee;

  private Double vat;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "outstanding_amount_currency"), @Column(name = "outstanding_amount")})
  private MonetaryAmount outstandingAmount;

  private Double outstandingRatio;

  @Column(name = "payment_status")
  @Enumerated(EnumType.STRING)
  private PaymentStatus paymentStatus;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "penalty_amount_currency"), @Column(name = "penalty_amount")})
  private MonetaryAmount penaltyAmount;
  
  @Column(name = "payment_date")
  private LocalDate paymentDate;

  @Column(name = "last_payment_date")
  private LocalDate lastPaymentDate;
  
}
