package com.gl.csf.cm.query.contract.contractsummary;

import com.gl.csf.cm.api.contract.event.*;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.contract.RescheduleStatus;
import com.gl.csf.cm.common.model.contract.WriteOffStatus;
import com.gl.csf.cm.common.model.payment.DueDateCalculationPeriod;
import com.gl.csf.cm.common.model.product.PaymentFrequency;
import com.gl.csf.cm.service.DueDateCalculationPeriodService;
import com.gl.csf.financeapi.utils.FinanceUtils;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.time.LocalDate;
import java.time.Month;
import java.util.Comparator;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
@Component
public class ContractSummaryEventListener {
  private final ContractSummaryRepository repository;
  private final DueDateCalculationPeriodService service;

  @Inject
  public ContractSummaryEventListener(ContractSummaryRepository repository, DueDateCalculationPeriodService service) {
    this.repository = repository;
    this.service = service;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
      ContractSummaryEntry contractSummaryEntry = new ContractSummaryEntry();
      contractSummaryEntry.setId(event.getId());
  
      contractSummaryEntry.setContractNumber(event.getContractNumber());
      contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
      contractSummaryEntry.setRescheduleStatus(RescheduleStatus.NONE);
      contractSummaryEntry.setWriteoffStatus(WriteOffStatus.NONE);
  
      contractSummaryEntry.setBusinessName(event.getLesseeBusiness().getBusinessName());
      contractSummaryEntry.setLoanAmount(event.getLoanProduct().getLoanAmount());
      contractSummaryEntry.setTerm(event.getLoanProduct().getTerm());
      contractSummaryEntry.setLoanType(event.getLoanProduct().getProductType());
      contractSummaryEntry.setPaymentFrequency(event.getLoanProduct().getPaymentFrequency());
  
      repository.save(contractSummaryEntry);
  }

  @EventHandler
  public void on(ContractActivatedEvent event){
    ContractSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    if(contractSummaryEntry == null)
      return;
    contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_ACTIVATED);
    if (event.getContractNumber().contains("SL-")) {
      int days = service.getAllDueDateCalculationPeriod().stream().filter(
    		      p -> (LocalDate.now().isAfter(p.getEffectiveDate()) || LocalDate.now().isEqual(p.getEffectiveDate()))
    		        && !LocalDate.now().isBefore(p.getEffectiveDate())) .sorted(Comparator.comparing(DueDateCalculationPeriod::getEffectiveDate).reversed())
    		      .map(DueDateCalculationPeriod::getDays).findFirst().orElse(null);
      contractSummaryEntry.setDueDate(FinanceUtils.getFirstDueDateForStaffLoan(event.getContractDate(), days));
    } else {
      contractSummaryEntry.setDueDate(getFirstDueDate(event.getContractDate(), contractSummaryEntry.getPaymentFrequency()));
    }
    repository.save(contractSummaryEntry);
  }
  
  @EventHandler
  public void on(PendingContractCancelledEvent event){
    ContractSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractStatus(ContractStatus.PENDING_CANCEL);
    repository.save(contractSummaryEntry);
  }
  
  @EventHandler
  public void on(ContractCancelledEvent event){
    ContractSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(contractSummaryEntry);
  }
  
  @EventHandler
  public void on(ContractActivatedCancelledEvent event){
    ContractSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(contractSummaryEntry);
  }
  
  @EventHandler
  public void on(ContractCancellationRejectedEvent event){
    ContractSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    repository.save(contractSummaryEntry);
  }
  
  @EventHandler
  public void on(ContractNumberUpdatedEvent event){
    ContractSummaryEntry contractSummaryEntry = repository.findOne(event.getId());
    contractSummaryEntry.setContractNumber(event.getContractNumber());
    repository.save(contractSummaryEntry);
  }
  
  private LocalDate getFirstDueDate(LocalDate contractDate, PaymentFrequency paymentFrequency){		
    int dayOfMonth = contractDate.getDayOfMonth();		
	int monthsPerPayment = 12/paymentFrequency.getValue();		
	Month nextMonth = contractDate.getMonth().plus(monthsPerPayment);		
	int year = contractDate.plusMonths(monthsPerPayment).getYear();		
	return LocalDate.of(year, nextMonth, dayOfMonth);		
  }
}
