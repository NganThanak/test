package com.gl.csf.cm.query.paymentinformation.penalty.summary;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/19/2018.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class PenaltySummary {

  @Id
  private String id;

  private String contractNumber;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "monthly_penalty_balance_amount_currency"), @Column(name = "monthly_penalty_balance_amount")})
  private MonetaryAmount penaltyBalanceAmount;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "end_of_contract_penalty_amount_currency"), @Column(name = "end_of_contract_penalty_amount")})
  private MonetaryAmount endOfContractPenaltyBalanceAmount;

}
