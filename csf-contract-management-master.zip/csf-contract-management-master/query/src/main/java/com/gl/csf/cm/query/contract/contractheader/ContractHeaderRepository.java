package com.gl.csf.cm.query.contract.contractheader;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/16/2017.
 */
public interface ContractHeaderRepository extends JpaRepository<ContractHeaderEntry, String> {
}
