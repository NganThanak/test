package com.gl.csf.cm.query.contract.lessee.business;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.gl.csf.cm.common.model.address.District;
import com.gl.csf.cm.common.model.address.State;
import com.gl.csf.cm.common.model.address.Township;
import com.gl.csf.cm.common.model.lessee.BranchStatus;
import com.gl.csf.cm.common.model.lessee.LocationOwner;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Entity
@Getter
@Setter
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class BranchEntry implements Serializable {
  @Id
  private String id;
  private String contractId;

  private String branchName;
  private String email;
  private Boolean isBoss;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "rent_currency"), @Column(name = "rent_amount")})
  private MonetaryAmount rentAmount;

  private String phoneNumber;
  @JsonProperty("ADDRESS")
  private String address;

  private State state;
  private District district;
  private Township township;

  @Enumerated(EnumType.STRING)
  @JsonProperty("LOCATION_OWNER")
  private LocationOwner locationOwner;

  @JsonProperty("OPEN_SINCE")
  private LocalDate openSince;

  @Enumerated(EnumType.STRING)
  private BranchStatus branchStatus;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "revenue_currency"), @Column(name = "revenue_amount")})
  private MonetaryAmount revenue;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "expense_currency"), @Column(name = "expense_amount")})
  private MonetaryAmount expense;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "other_expense_currency"), @Column(name = "other_expense_amount")})
  private MonetaryAmount otherExpense;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "margin_currency"), @Column(name = "margin_amount")})
  private MonetaryAmount margin;
  private Integer numberOfStaff;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "staff_expense_currency"), @Column(name = "staff_expense_amount")})
  private MonetaryAmount staffExpense;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "net_profit_currency"), @Column(name = "net_profit_amount")})
  private MonetaryAmount netProfit;

  @Override
  public String toString() {
    return branchName;
  }
}
