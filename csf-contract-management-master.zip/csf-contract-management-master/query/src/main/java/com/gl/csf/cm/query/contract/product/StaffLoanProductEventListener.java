package com.gl.csf.cm.query.contract.product;

import com.gl.csf.cm.api.contract.event.ApplicationSubmittedEvent;
import com.gl.csf.cm.common.model.lessee.Staff;
import com.gl.csf.cm.common.model.product.StaffLoanProduct;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Created by p.ly on 1/25/2018.
 */
@Component
public class StaffLoanProductEventListener{
  private final StaffLoanProductRepository repository;
  public final static String ORIGINAL_TERM = "Original Term";
  public final static String CREATED_BY = "System";

  @Inject
  public StaffLoanProductEventListener(StaffLoanProductRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    StaffLoanProduct staffLoanProduct = event.getStaffLoanProduct();
    Staff staff = event.getStaff();
    StaffLoanProductEntry loanProductEntry = new StaffLoanProductEntry();
    loanProductEntry.setId(UUID.randomUUID().toString());
    loanProductEntry.setContractId(event.getId());
    loanProductEntry.setTerm(staffLoanProduct.getTerm());
    loanProductEntry.setContractTerm(ORIGINAL_TERM);
    loanProductEntry.setCreatedBy(CREATED_BY);
    loanProductEntry.setInitiatedDate(LocalDate.now());
    loanProductEntry.setLoanStatus(LoanProductStatus.PENDING);
    loanProductEntry.setLoanType(staffLoanProduct.getProductType());
    loanProductEntry.setLoanAmount(staffLoanProduct.getLoanAmount());
    loanProductEntry.setPaymentFrequency(staffLoanProduct.getPaymentFrequency());
    loanProductEntry.setStaffLoanPurposes(staff.getStaffLoanPurposes());
    loanProductEntry.setInterestRate(staffLoanProduct.getInterestRate());

    repository.save(loanProductEntry);
  }

}
