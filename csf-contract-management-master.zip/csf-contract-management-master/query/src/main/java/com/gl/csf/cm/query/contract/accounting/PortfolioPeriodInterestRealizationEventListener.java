package com.gl.csf.cm.query.contract.accounting;

import com.gl.csf.cm.api.contract.event.ContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.RevolvingLoanContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.StaffLoanContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.financeapi.monthend.AccumulatedAmortizedEntry;
import com.gl.csf.financeapi.monthend.InstallmentMonthEndAmortizationEntry;
import com.gl.csf.financeapi.monthend.MonthEndAmortization;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
@Component
public class PortfolioPeriodInterestRealizationEventListener {
  private final PortfolioPeriodInterestRealizationRepository repository;

  @Inject
  public PortfolioPeriodInterestRealizationEventListener(PortfolioPeriodInterestRealizationRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(StandardLoanContractActivatedEvent event){
    createPortfolioPeriodInterestRealizationEntry(event, ProductType.STANDARD_LOAN, event.getLoanAmount(), LoanParameter.DueDateMode.FIXED);
  }

  @EventHandler
  public void on(RevolvingLoanContractActivatedEvent event){
    createPortfolioPeriodInterestRealizationEntry(event, ProductType.REVOLVING_LOAN, event.getFirstWithdrawalAmount(), LoanParameter.DueDateMode.FIXED);
  }
  
  @EventHandler
  public void on(StaffLoanContractActivatedEvent event){
    createPortfolioPeriodInterestRealizationEntry(event, ProductType.STAFF_LOAN, event.getLoanAmount(), LoanParameter.DueDateMode.END_OF_MONTH);
  }

  private void createPortfolioPeriodInterestRealizationEntry(ContractActivatedEvent event, ProductType productType, MonetaryAmount loanAmount, LoanParameter.DueDateMode dueDateMode){
	List<InstallmentMonthEndAmortizationEntry> installmentMonthEndAmortizationEntries = MonthEndAmortization.amortizeInstallments(event.getContractDate(), loanAmount,
            event.getPaymentFrequency(), event.getTerm(), event.getInterestRate(), 4, BigDecimal.ROUND_HALF_UP, event.getFirstDueDate(), dueDateMode);

    installmentMonthEndAmortizationEntries.forEach(installmentAmortizedEntry ->{
      AccumulatedAmortizedEntry amortizedEntry = installmentAmortizedEntry.getMonthEndAccumulatedAmortizedEntry();
      updateOrCreateEntry(amortizedEntry.getAmortizedEntry().getDate(),
              productType,
              amortizedEntry.getAmortizedEntry().getInterest(),
              amortizedEntry.getAmortizedEntry().getPrincipal(),
              amortizedEntry.getRemainingBalance());
    });
  }

  private void updateOrCreateEntry(LocalDate endOfMonthDate, ProductType loanType,
                                   MonetaryAmount interestEndOfMonth,
                                   MonetaryAmount principalEndOfMonth,
                                   MonetaryAmount remainingBalanceEndOfMonth){
    // Entry for specific loan type
	if (loanType != null) {
      updateOrCreateEntryForLoanType(endOfMonthDate, loanType, interestEndOfMonth, principalEndOfMonth, remainingBalanceEndOfMonth);
	} else {
    // Entry for all loan type
      updateOrCreateEntryForLoanType(endOfMonthDate, null, interestEndOfMonth, principalEndOfMonth, remainingBalanceEndOfMonth);
	}
  }

  private void updateOrCreateEntryForLoanType(LocalDate endOfMonthDate, ProductType loanType,
                                   MonetaryAmount interestEndOfMonth,
                                   MonetaryAmount principalEndOfMonth,
                                   MonetaryAmount remainingBalanceEndOfMonth){
    Optional<PortfolioPeriodInterestRealizationEntry> optionalEntry = repository.findByEndOfMonthDateAndLoanType(endOfMonthDate, loanType);
    if(optionalEntry.isPresent()){
      PortfolioPeriodInterestRealizationEntry entry = optionalEntry.get();
      entry.setInterestEndOfMonth(entry.getInterestEndOfMonth().add(interestEndOfMonth));
      entry.setPrincipalEndOfMonth(entry.getPrincipalEndOfMonth().add(principalEndOfMonth));
      entry.setRemainingBalanceEndOfMonth(entry.getRemainingBalanceEndOfMonth().add(remainingBalanceEndOfMonth));
      repository.save(entry);
    } else {
      PortfolioPeriodInterestRealizationEntry entryForLoanType = new PortfolioPeriodInterestRealizationEntry();
      entryForLoanType.setId(UUID.randomUUID().toString());
      entryForLoanType.setLoanType(loanType);
      entryForLoanType.setEndOfMonthDate(endOfMonthDate);
      entryForLoanType.setInterestEndOfMonth(interestEndOfMonth);
      entryForLoanType.setPrincipalEndOfMonth(principalEndOfMonth);
      entryForLoanType.setRemainingBalanceEndOfMonth(remainingBalanceEndOfMonth);
      repository.save(entryForLoanType);
    }
  }
}
