package com.gl.csf.cm.query.paymentinformation.paymentschedule;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.util.List;

public interface PaymentScheduleHistoryRepository extends PagingAndSortingRepository<PaymentScheduleHistory, String>,
        QueryByExampleExecutor<PaymentScheduleHistory> {
    List<PaymentScheduleHistory> findAllByContractNumberAndInstallmentNumber(String contractNumber, int installmentNo);
    PaymentScheduleHistory findFirstByContractNumberOrderByLastPaymentDateDesc(String contractNumber);
    List<PaymentScheduleHistory> findAllByContractNumber(String contractNumber);
}
