package com.gl.csf.cm.query.services;

import com.gl.csf.cm.common.model.payment.DailyPenaltyRate;
import com.gl.csf.cm.config.Authenticated;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;
import javax.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by p.ly on 1/16/2018.
 */
@Service
public class DailyPenaltyRateServices {

  private final String baseUrl;
  private final RestTemplate restTemplate;

  @Inject
  public DailyPenaltyRateServices(@Value("${endpoints.rest.parameter.dailypenaltyrate}") String baseUrl,
                                  @Authenticated(Authenticated.With.CLIENT_CREDENTIALS) RestTemplate restTemplate) {
    this.baseUrl = baseUrl;
    this.restTemplate = restTemplate;
  }

  public List<DailyPenaltyRate> getAllDailyPenaltyRates(){
    return restTemplate.exchange(baseUrl, HttpMethod.GET, null,
      new ParameterizedTypeReference<List<DailyPenaltyRate>>(){}).getBody();
  }

  public Optional<DailyPenaltyRate> getDailyPenaltyRateById(UUID stateId){
    Objects.requireNonNull(stateId);

    try {
      return Optional.of(restTemplate.exchange(baseUrl + "/" + stateId, HttpMethod.GET, null,
        new ParameterizedTypeReference<DailyPenaltyRate>(){}).getBody());
    } catch (NotFoundException e){
      return Optional.empty();
    }
  }
}
