package com.gl.csf.cm.query.contract.lessee.business;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.lessee.LesseeBusiness;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class FinancialStatementEventListener {
  private final FinancialStatementRepository repository;

  @Inject
  public FinancialStatementEventListener(FinancialStatementRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    LesseeBusiness lesseeBusiness = event.getLesseeBusiness();

    FinancialStatementEntry financialStatementEntry = new FinancialStatementEntry();
    financialStatementEntry.setId(event.getId());
    financialStatementEntry.setTotalBranch(lesseeBusiness.getTotalBranch());
    financialStatementEntry.setRevenue(lesseeBusiness.getRevenue());
    financialStatementEntry.setExpense(lesseeBusiness.getExpense());
    financialStatementEntry.setMargin(lesseeBusiness.getMargin());
    financialStatementEntry.setNumberOfStaff(lesseeBusiness.getNumberOfStaff());
    financialStatementEntry.setStaffExpense(lesseeBusiness.getStaffExpense());
    financialStatementEntry.setNetProfit(lesseeBusiness.getNetProfit());
    financialStatementEntry.setTotalRent(lesseeBusiness.getTotalRent());
    financialStatementEntry.setOtherExpense(lesseeBusiness.getOtherExpense());
    financialStatementEntry.setFinancialRatio(lesseeBusiness.getFinancialRatio());
    financialStatementEntry.setFinancialRatioLow(lesseeBusiness.getFinancialRatioLow());
    financialStatementEntry.setInstallment(lesseeBusiness.getInstallment());

    repository.save(financialStatementEntry);
  }
}
