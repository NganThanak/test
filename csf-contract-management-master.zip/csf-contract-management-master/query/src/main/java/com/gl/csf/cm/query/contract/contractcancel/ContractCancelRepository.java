package com.gl.csf.cm.query.contract.contractcancel;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.csf.cm.common.model.contract.ContractStatus;

import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/14/2017.
 */
public interface ContractCancelRepository extends JpaRepository<ContractCancelEntry, String> {
  Optional<ContractCancelEntry> findByContractID(String applicationId);
  Optional<ContractCancelEntry> findByContractIDAndContractStatus(String contractID, ContractStatus contractStatus);
}
