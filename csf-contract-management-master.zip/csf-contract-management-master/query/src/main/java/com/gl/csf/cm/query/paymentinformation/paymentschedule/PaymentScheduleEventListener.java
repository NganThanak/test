package com.gl.csf.cm.query.paymentinformation.paymentschedule;

import com.gl.csf.cm.api.contract.event.PaymentFullyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.PaymentPartiallyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.common.model.PaymentStatus;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.gl.csf.cm.query.contract.product.LoanProductRepository;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;
import com.gl.csf.financeapi.utils.FinanceUtils;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Component
public class PaymentScheduleEventListener {
  private final PaymentScheduleRepository paymentScheduleRepository;
  private final LoanProductRepository loanProductRepository;
  private final PaymentScheduleHistoryRepository paymentScheduleHistoryRepository;
  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);
  MonetaryAmount remainingAmount = MMK_ZERO;

  @Inject
  public PaymentScheduleEventListener(PaymentScheduleRepository paymentScheduleRepository, LoanProductRepository loanProductRepository,
                                      PaymentScheduleHistoryRepository paymentScheduleHistoryRepository) {
    this.paymentScheduleRepository = paymentScheduleRepository;
    this.loanProductRepository = loanProductRepository;
    this.paymentScheduleHistoryRepository = paymentScheduleHistoryRepository;
  }

  @EventHandler
  private void on(PaymentPartiallyAllocatedEvent event) {
    MonetaryAmount totalReceivedAmount = MMK_ZERO;
    int installmentNumber = event.getInstallmentNumber();
    
    List<PaymentScheduleHistory> paymentScheduleHistories = paymentScheduleHistoryRepository.findAllByContractNumberAndInstallmentNumber(event.getContractNumber(),
      event.getInstallmentNumber());
    if (!paymentScheduleHistories.isEmpty()) {
      for (PaymentScheduleHistory paymentScheduleHistory : paymentScheduleHistories) {
        totalReceivedAmount = totalReceivedAmount.add(paymentScheduleHistory.getPaymentAmount());
      }
      remainingAmount = totalReceivedAmount;
    }
    totalReceivedAmount = totalReceivedAmount.add(event.getAmount());
    
    PaymentScheduleEntry paymentScheduleEntry = paymentScheduleRepository.findAllByContractNumberAndInstallmentNumber(event.getContractNumber(), event.getInstallmentNumber());
    if(paymentScheduleEntry != null) {
  
      addPaymentScheduleHistory(event, paymentScheduleEntry, installmentNumber, event.getAmount());
      
      if (totalReceivedAmount.isEqualTo(paymentScheduleEntry.getInstallmentAmount())) {
        paymentScheduleEntry.setPaymentStatus(PaymentStatus.FULL);
        paymentScheduleEntry.setAmountAllocation(totalReceivedAmount);
        paymentScheduleRepository.save(paymentScheduleEntry);
      } else if (totalReceivedAmount.isLessThan(paymentScheduleEntry.getInstallmentAmount())) {
        paymentScheduleEntry.setPaymentStatus(PaymentStatus.PARTIAL);
        paymentScheduleEntry.setAmountAllocation(totalReceivedAmount);
        paymentScheduleRepository.save(paymentScheduleEntry);
      } else if (totalReceivedAmount.isGreaterThan(paymentScheduleEntry.getInstallmentAmount())) {

        List<PaymentStatus> statuses = new ArrayList<>();
        statuses.add(PaymentStatus.UNPAID);
        statuses.add(PaymentStatus.PARTIAL);
        List<PaymentScheduleEntry> scheduleEntryList = paymentScheduleRepository.findByContractNumberAndPaymentStatusInOrderByInstallmentNumberAsc(event.getContractNumber(), statuses);
        MonetaryAmount getReceivedAmount = MMK_ZERO;
        MonetaryAmount paidAmount = event.getAmount();
        for (int i = 0; i < scheduleEntryList.size(); i++) {
  
          paidAmount = paidAmount.add(scheduleEntryList.get(i).getAmountAllocation()!= null ? scheduleEntryList.get(i).getAmountAllocation() : MMK_ZERO);
          getReceivedAmount =  paidAmount.subtract(scheduleEntryList.get(i).getInstallmentAmount());
          
          if (getReceivedAmount.isGreaterThan(MMK_ZERO)) {
            scheduleEntryList.get(i).setPaymentStatus(PaymentStatus.FULL); // OVER_PAY
            scheduleEntryList.get(i).setAmountAllocation(scheduleEntryList.get(i).getInstallmentAmount());
            paymentScheduleRepository.save(scheduleEntryList.get(i));
            paidAmount = getReceivedAmount;
          } else if (getReceivedAmount.isEqualTo(MMK_ZERO)) {
            scheduleEntryList.get(i).setPaymentStatus(PaymentStatus.FULL);
            scheduleEntryList.get(i).setAmountAllocation(paidAmount);
            paymentScheduleRepository.save(scheduleEntryList.get(i));
            break;
          } else if (getReceivedAmount.isLessThan(MMK_ZERO)) {
            scheduleEntryList.get(i).setPaymentStatus(PaymentStatus.PARTIAL);
            scheduleEntryList.get(i).setAmountAllocation(paidAmount);
            paymentScheduleRepository.save(scheduleEntryList.get(i));
            break;
          }
        }
      }
    }
  }

  private void addPaymentScheduleHistory(PaymentPartiallyAllocatedEvent event, PaymentScheduleEntry paymentScheduleEntry,
                                         int installmentNumber, MonetaryAmount installmentAmount) {
    
    PaymentScheduleHistory history = new PaymentScheduleHistory();
    history.setId(UUID.randomUUID().toString());
    history.setBankTransaction(event.getBankTransaction());
    history.setContractNumber(event.getContractNumber());
    history.setInstallmentNumber(installmentNumber);
    history.setPaymentAmount(installmentAmount);
    history.setInstallmentAmount(paymentScheduleEntry.getInstallmentAmount());
    history.setAmountAllocation(event.getAmount());
    history.setPaymentDate(event.getPaymentDate());
    history.setPaymentReference(event.getPaymentReference());
    history.setLastPaymentDate(event.getPaymentDate());
    paymentScheduleHistoryRepository.save(history);
  }

  @EventHandler
  private void on(PaymentFullyAllocatedEvent event) {
    PaymentScheduleEntry paymentScheduleEntry = paymentScheduleRepository.findAllByContractNumberAndInstallmentNumber(event.getContractNumber(),
      event.getInstallmentNumber());
    int installmentNumber = paymentScheduleEntry.getInstallmentNumber();

    if (paymentScheduleEntry.getPaymentStatus().equals(PaymentStatus.FULL)) {
      while (paymentScheduleEntry.getPaymentStatus().equals(PaymentStatus.FULL)) {
        paymentScheduleEntry = paymentScheduleRepository.findAllByContractNumberAndInstallmentNumber(event.getContractNumber(),
          installmentNumber);
        installmentNumber = installmentNumber + 1;
      }
      paymentScheduleEntry.setPaymentStatus(PaymentStatus.FULL);
      paymentScheduleRepository.save(paymentScheduleEntry);
      addFullPaymentScheduleHistory(event, paymentScheduleEntry, paymentScheduleEntry.getInstallmentNumber(), paymentScheduleEntry.getInstallmentAmount());

    } else {
      paymentScheduleEntry.setPaymentStatus(PaymentStatus.FULL);
      paymentScheduleRepository.save(paymentScheduleEntry);
      addFullPaymentScheduleHistory(event, paymentScheduleEntry, paymentScheduleEntry.getInstallmentNumber(), paymentScheduleEntry.getInstallmentAmount());
    }

  }

  private void addFullPaymentScheduleHistory(PaymentFullyAllocatedEvent event, PaymentScheduleEntry paymentScheduleEntry,
                                             int installmentNumber, MonetaryAmount amount) {
    PaymentScheduleHistory history = new PaymentScheduleHistory();
    history.setId(UUID.randomUUID().toString());
    history.setBankTransaction(event.getBankTransaction());
    history.setContractNumber(event.getContractNumber());
    history.setInstallmentNumber(installmentNumber);
    history.setInstallmentAmount(paymentScheduleEntry.getInstallmentAmount());
    history.setAmountAllocation(event.getAmount());
    history.setPaymentDate(event.getPaymentDate());
    history.setPaymentAmount(amount);
    history.setPaymentReference(event.getPaymentReference());
    history.setLastPaymentDate(event.getPaymentDate());

    paymentScheduleHistoryRepository.save(history);
  }

  @EventHandler
  public void on(StandardLoanContractActivatedEvent event) {

    List<LoanProductEntry> loanProductEntrys = loanProductRepository.findAllByContractId(event.getId());

    final LocalDate firstDueDate = FinanceUtils.getFirstDueDate(event.getContractDate(), loanProductEntrys.get(0).getPaymentFrequency().getValue());
    final LoanParameter loanParameter = LoanParameterBuilder.createBuilder()
      .numberOfCompoundingPeriods(loanProductEntrys.get(0).getPaymentFrequency().getValue())
      .loanAmount(loanProductEntrys.get(0).getLoanAmount())
      .loanTerm(loanProductEntrys.get(0).getTerm() / 12.0)
      .nominalInterestRate(loanProductEntrys.get(0).getInterestRate().setScale(4, BigDecimal.ROUND_HALF_UP)
        .multiply(BigDecimal.valueOf(12))
        .divide(BigDecimal.valueOf(100), BigDecimal.ROUND_HALF_UP).doubleValue())
      .contractStartDate(event.getContractDate())
      .dueDate(firstDueDate)
      .build();

    SimpleAmortization simpleAmortization = new SimpleAmortization();

    List<Installment> installments = simpleAmortization.generatePaymentSchedule(loanParameter);
    for (Installment installment : installments) {
      PaymentScheduleEntry entry = new PaymentScheduleEntry();
      entry.setId(UUID.randomUUID().toString());
      entry.setAmountAllocation(MMK_ZERO);
      entry.setInstallmentNumber(installment.getInstallmentNumber());
      entry.setInstallmentAmount(installment.getAmount());
      entry.setContractNumber(event.getContractNumber());
      entry.setPaymentStatus(PaymentStatus.UNPAID);

      paymentScheduleRepository.save(entry);
    }
  }

}
