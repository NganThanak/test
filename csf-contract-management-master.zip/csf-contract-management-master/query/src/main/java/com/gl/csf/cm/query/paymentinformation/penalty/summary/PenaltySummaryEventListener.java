package com.gl.csf.cm.query.paymentinformation.penalty.summary;

import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/19/2018.
 */
@Component
public class PenaltySummaryEventListener {
  private final PenaltySummaryRepository penaltySummaryRepository;

  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);

  @Inject
  public PenaltySummaryEventListener(PenaltySummaryRepository penaltySummaryRepository) {
    this.penaltySummaryRepository = penaltySummaryRepository;
  }

  @EventHandler
  private void on(StandardLoanContractActivatedEvent event) {
    PenaltySummary penaltySummary = new PenaltySummary();
    penaltySummary.setId(UUID.randomUUID().toString());
    penaltySummary.setContractNumber(event.getContractNumber());
    penaltySummary.setEndOfContractPenaltyBalanceAmount(MMK_ZERO);
    penaltySummary.setPenaltyBalanceAmount(MMK_ZERO);

    penaltySummaryRepository.save(penaltySummary);
  }
}
