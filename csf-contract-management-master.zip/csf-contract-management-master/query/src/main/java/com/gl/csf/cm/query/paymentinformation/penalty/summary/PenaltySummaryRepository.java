package com.gl.csf.cm.query.paymentinformation.penalty.summary;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/19/2018.
 */
public interface PenaltySummaryRepository extends PagingAndSortingRepository<PenaltySummary, String>,
        QueryByExampleExecutor<PenaltySummary> {
  Optional<PenaltySummary> findByContractNumber(String contractNumber);
}
