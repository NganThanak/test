package com.gl.csf.cm.query.contract.lessee;

import com.gl.csf.cm.api.contract.event.ApplicationSubmittedEvent;
import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.lessee.LesseeBankAccountInformation;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class LesseeBankAccountInformationEventListener {
  private final LesseeBankAccountInformationRepository repository;

  @Inject
  public LesseeBankAccountInformationEventListener(LesseeBankAccountInformationRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    LesseeBankAccountInformation lesseeBankAccountInformation = event.getLesseeBankAccountInformation();
    LesseeBankAccountInformationEntry lesseeBankAccountInformationEntry = new LesseeBankAccountInformationEntry();
    lesseeBankAccountInformationEntry.setId(event.getId());
    lesseeBankAccountInformationEntry.setBankAccount(lesseeBankAccountInformation.getBankAccount());
    lesseeBankAccountInformationEntry.setBankAccountType(lesseeBankAccountInformation.getBankAccountType());
    lesseeBankAccountInformationEntry.setDescription(lesseeBankAccountInformation.getDescription());

    repository.save(lesseeBankAccountInformationEntry);
  }
  
  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    LesseeBankAccountInformationEntry lesseeBankAccountInformationEntry = new LesseeBankAccountInformationEntry();
    lesseeBankAccountInformationEntry.setId(event.getId());
    lesseeBankAccountInformationEntry.setBankAccount(event.getStaff().getBankAccount());
    
    repository.save(lesseeBankAccountInformationEntry);
  }
}
