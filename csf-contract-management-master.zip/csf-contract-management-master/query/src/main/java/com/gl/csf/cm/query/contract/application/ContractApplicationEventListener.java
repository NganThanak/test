package com.gl.csf.cm.query.contract.application;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.api.contract.event.ContractNumberUpdatedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Component
public class ContractApplicationEventListener {
  private final ContractApplicationRepository repository;

  @Inject
  public ContractApplicationEventListener(ContractApplicationRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event) {
    ContractApplicationEntry entry = new ContractApplicationEntry();
    entry.setId(event.getId());
    entry.setApplicationId(event.getApplicationId());
    entry.setContractNumber(event.getContractNumber());
    entry.setCreatedDate(event.getCreatedDate());
    repository.save(entry);
  }
  
  @EventHandler
  public void on(ContractNumberUpdatedEvent event){
    ContractApplicationEntry contractApplicationEntry = repository.findOne(event.getId());
    contractApplicationEntry.setContractNumber(event.getContractNumber());
    repository.save(contractApplicationEntry);
  }
}
