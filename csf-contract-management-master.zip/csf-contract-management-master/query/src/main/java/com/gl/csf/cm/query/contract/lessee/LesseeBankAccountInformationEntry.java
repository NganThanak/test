package com.gl.csf.cm.query.contract.lessee;

import com.gl.csf.cm.common.model.bank.BankAccount;
import com.gl.csf.cm.common.model.bank.BankAccountType;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Entity
@Data
public class LesseeBankAccountInformationEntry implements Serializable {
  @Id
  private String id;
  private BankAccount bankAccount;
  @Enumerated(EnumType.STRING)
  private BankAccountType bankAccountType;
  private String description;
}
