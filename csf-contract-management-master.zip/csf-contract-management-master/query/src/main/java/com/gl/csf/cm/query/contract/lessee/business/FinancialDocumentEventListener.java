package com.gl.csf.cm.query.contract.lessee.business;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.document.DocumentDescriptor;
import com.gl.csf.cm.common.model.lessee.LesseeBusiness;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class FinancialDocumentEventListener {
  private FinancialDocumentRepository repository;

  @Inject
  public FinancialDocumentEventListener(FinancialDocumentRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    LesseeBusiness lesseeBusiness = event.getLesseeBusiness();
    if(lesseeBusiness == null || lesseeBusiness.getFinancialDocuments() == null)
      return;

    lesseeBusiness.getFinancialDocuments().forEach(financialDocument -> {
      FinancialDocumentEntry financialDocumentEntry = new FinancialDocumentEntry();
      financialDocumentEntry.setDocumentDescriptor(new DocumentDescriptor(financialDocument.getBucketId(), financialDocument.getDocumentId()));
      financialDocumentEntry.setContractId(event.getId());
      financialDocumentEntry.setAttachment(financialDocument.getAttachment());
      financialDocumentEntry.setUploadBy(financialDocument.getUploadBy());
      financialDocumentEntry.setDateTime(financialDocument.getDateTime());
      financialDocumentEntry.setComment(financialDocument.getComment());

      repository.save(financialDocumentEntry);
    });
  }
}
