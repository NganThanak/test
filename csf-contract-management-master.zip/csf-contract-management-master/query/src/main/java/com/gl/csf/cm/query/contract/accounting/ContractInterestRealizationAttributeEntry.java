package com.gl.csf.cm.query.contract.accounting;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Digits;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class ContractInterestRealizationAttributeEntry implements Serializable {
  @Id
  private String contractId;
  private String contractNumber;
  private LocalDate contractDate;
  private LocalDate firstDueDate;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "lease_amount_currency"), @Column(name = "lease_amount")})
  private MonetaryAmount leaseAmount;
  private Integer leasingTerm;
  @Digits(integer = 2, fraction = 2)
  private BigDecimal flatRate;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "installment_currency"), @Column(name = "installment_amount")})
  private MonetaryAmount installment;
  @Digits(integer = 2, fraction = 4)
  private BigDecimal monthlyEffectiveRate;
  @Digits(integer = 3, fraction = 4)
  private BigDecimal annuallyEffectiveRate;
}
