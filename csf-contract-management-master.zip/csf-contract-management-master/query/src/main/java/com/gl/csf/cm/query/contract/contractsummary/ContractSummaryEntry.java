package com.gl.csf.cm.query.contract.contractsummary;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import com.gl.csf.cm.common.model.contract.RescheduleStatus;
import com.gl.csf.cm.common.model.contract.WriteOffStatus;
import com.gl.csf.cm.common.model.product.PaymentFrequency;
import com.gl.csf.cm.common.model.product.ProductType;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;
import org.zalando.money.validation.Positive;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class ContractSummaryEntry {
  @Id
  private String id;

  private String contractNumber;

  @Column(name = "contract_status")
  @Enumerated(EnumType.STRING)
  private ContractStatus contractStatus;

  @Column(name = "reschedule_status")
  @Enumerated(EnumType.STRING)
  private RescheduleStatus rescheduleStatus;

  @Column(name = "writeoff_status")
  @Enumerated(EnumType.STRING)
  private WriteOffStatus writeoffStatus;

  @Column(name = "loan_type")
  @Enumerated(EnumType.STRING)
  private ProductType loanType;

  @Positive
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "loan_currency"), @Column(name = "loan_amount")})
  private MonetaryAmount loanAmount;

  private PaymentFrequency paymentFrequency;

  private String businessName;
  private Integer term;
  private LocalDate dueDate;
}
