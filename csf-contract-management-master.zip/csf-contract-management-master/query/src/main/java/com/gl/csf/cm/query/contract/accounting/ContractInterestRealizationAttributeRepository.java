package com.gl.csf.cm.query.contract.accounting;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
public interface ContractInterestRealizationAttributeRepository extends JpaRepository<ContractInterestRealizationAttributeEntry, String> {
  Optional<ContractInterestRealizationAttributeEntry> findByContractNumber(String contractNumber);
}
