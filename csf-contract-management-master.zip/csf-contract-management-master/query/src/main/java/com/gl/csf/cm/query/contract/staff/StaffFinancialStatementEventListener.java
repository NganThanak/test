package com.gl.csf.cm.query.contract.staff;

import com.gl.csf.cm.api.contract.event.ApplicationSubmittedEvent;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/26/2018.
 */
@Component
public class StaffFinancialStatementEventListener {
  private final StaffFinancialStatementRepository repository;
  
  public StaffFinancialStatementEventListener(StaffFinancialStatementRepository repository) {
    this.repository = repository;
  }
  
  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    
    StaffFinancialStatementEntry financialStatementEntry = new StaffFinancialStatementEntry();
    financialStatementEntry.setId(event.getId());
    financialStatementEntry.setAnnualSalary(event.getStaff().getAnnualSalary());
    financialStatementEntry.setMonthlySalary(event.getStaff().getMonthlySalary());
    financialStatementEntry.setFinancialRatio((event.getStaffLoanProduct().getLoanAmount().multiply(100).divide(event.getStaff().getAnnualSalary().getNumber()))
            .getNumber().numberValue(BigDecimal.class).setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue());
    repository.save(financialStatementEntry);
  }
}
