package com.gl.csf.cm.query.contract.accounting;

import com.gl.csf.cm.api.contract.event.ContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.RevolvingLoanContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.StaffLoanContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.common.model.product.ProductType;
import com.gl.csf.financeapi.monthend.AccumulatedAmortizedEntry;
import com.gl.csf.financeapi.monthend.InstallmentMonthEndAmortizationEntry;
import com.gl.csf.financeapi.monthend.MonthEndAmortization;
import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
@Component
public class ContractPeriodInterestRealizationEventListener {
  private final ContractPeriodInterestRealizationRepository repository;

  @Inject
  public ContractPeriodInterestRealizationEventListener(ContractPeriodInterestRealizationRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(StandardLoanContractActivatedEvent event){
    createContractPeriodInterestRealizationEntries(event, ProductType.STANDARD_LOAN, event.getLoanAmount(), LoanParameter.DueDateMode.FIXED);
  }

  @EventHandler
  public void on(RevolvingLoanContractActivatedEvent event){
    createContractPeriodInterestRealizationEntries(event, ProductType.REVOLVING_LOAN, event.getFirstWithdrawalAmount(), LoanParameter.DueDateMode.FIXED);
  }
  
  @EventHandler
  public void on(StaffLoanContractActivatedEvent event){
    createContractPeriodInterestRealizationEntries(event, ProductType.STAFF_LOAN, event.getLoanAmount(), LoanParameter.DueDateMode.END_OF_MONTH);
  }
  
  private void createContractPeriodInterestRealizationEntries(ContractActivatedEvent event, ProductType productType, MonetaryAmount loanAmount, LoanParameter.DueDateMode dueDateMode){
	List<InstallmentMonthEndAmortizationEntry> installmentMonthEndAmortizationEntries = MonthEndAmortization.amortizeInstallments(event.getContractDate(), loanAmount,
            event.getPaymentFrequency(), event.getTerm(), event.getInterestRate(), 4, BigDecimal.ROUND_HALF_UP, 
            event.getFirstDueDate(), dueDateMode);

    final List<ContractPeriodInterestRealizationEntry> result = new ArrayList<>();
    installmentMonthEndAmortizationEntries.forEach(installmentAmortization -> {
      ContractPeriodInterestRealizationEntry entry = new ContractPeriodInterestRealizationEntry();
      entry.setId(UUID.randomUUID().toString());
      entry.setContractId(event.getId());
      entry.setContractNumber(event.getContractNumber());
      entry.setProductType(productType);

      Installment installment = installmentAmortization.getInstallment();
      entry.setPeriod(installment.getInstallmentNumber());
      entry.setDueDate(installment.getDueDate());
      entry.setInstallment(installment.getAmount());
      entry.setInterest(installment.getInterest());
      entry.setPrincipal(installment.getPrincipal());
      entry.setRemainingPrincipalBalance(installment.getEndBalance());

      AccumulatedAmortizedEntry accumulatedAmortizedEntry = installmentAmortization.getMonthEndAccumulatedAmortizedEntry();
      entry.setEndOfMonthDate(accumulatedAmortizedEntry.getAmortizedEntry().getDate());
      entry.setInterestEndOfMonth(accumulatedAmortizedEntry.getAmortizedEntry().getInterest());
      entry.setSumOfAccruedInterestEndOfMonth(accumulatedAmortizedEntry.getAccumulatedInterest());
      entry.setPrincipalEndOfMonth(accumulatedAmortizedEntry.getAmortizedEntry().getPrincipal());
      entry.setSumOfAccruedPrincipalEndOfMonth(accumulatedAmortizedEntry.getAccumulatedPrincipal());
      entry.setRemainingBalanceEndOfMonth(accumulatedAmortizedEntry.getRemainingBalance());
      result.add(entry);
    });

    repository.save(result);
  }
}
