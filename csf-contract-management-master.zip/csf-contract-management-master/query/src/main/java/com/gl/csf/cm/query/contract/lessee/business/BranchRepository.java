package com.gl.csf.cm.query.contract.lessee.business;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
public interface BranchRepository extends JpaRepository<BranchEntry, String> {
  List<BranchEntry> findAllByContractId(String contractId);
}
