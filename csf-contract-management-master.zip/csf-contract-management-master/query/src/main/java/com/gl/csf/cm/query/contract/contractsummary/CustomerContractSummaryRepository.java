package com.gl.csf.cm.query.contract.contractsummary;

import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 11/6/2017.
 */
public interface CustomerContractSummaryRepository extends PagingAndSortingRepository<CustomerContractSummaryEntry, String> {
}
