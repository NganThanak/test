package com.gl.csf.cm.query.contract.application;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 17/11/2017.
 */
@Data
@Entity
public class ContractApplicationEntry {
  @Id
  private String id;
  private String contractNumber;
  private String applicationId;
  private LocalDate createdDate;
}
