package com.gl.csf.cm.query.contract.accounting;

import com.gl.csf.cm.common.model.product.ProductType;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
@Data
@Entity
public class PortfolioPeriodInterestRealizationEntry implements Serializable {
  @Id
  private String id;
  private LocalDate endOfMonthDate;
  @Enumerated(EnumType.STRING)
  private ProductType loanType;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "interest_eom_currency"), @Column(name = "interest_eom_amount")})
  private MonetaryAmount interestEndOfMonth;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "principal_eom_currency"), @Column(name = "principal_eom_amount")})
  private MonetaryAmount principalEndOfMonth;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "remaining_balance_eom_currency"), @Column(name = "remaining_balance_eom_amount")})
  private MonetaryAmount remainingBalanceEndOfMonth;
}
