package com.gl.csf.cm.query.contract.accounting;

import com.gl.csf.cm.common.model.product.ProductType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
public interface ContractPeriodInterestRealizationRepository extends JpaRepository<ContractPeriodInterestRealizationEntry, String> {
  List<ContractPeriodInterestRealizationEntry> findAllByContractNumber(String contractNumber);
  int countByContractNumber(String contractNumber);

  List<ContractPeriodInterestRealizationEntry> findAllByEndOfMonthDateBetween(LocalDate from, LocalDate to);
  Page<ContractPeriodInterestRealizationEntry> findAllByEndOfMonthDateBetween(LocalDate from, LocalDate to, Pageable pageable);
  int countByEndOfMonthDateBetween(LocalDate from, LocalDate to);

  List<ContractPeriodInterestRealizationEntry> findAllByEndOfMonthDateBetweenAndProductType(LocalDate from, LocalDate to, ProductType productType);
}
