package com.gl.csf.cm.query.contract.contractheader;

import com.gl.csf.cm.api.contract.event.*;
import com.gl.csf.cm.common.model.contract.ContractStatus;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/16/2017.
 */
@Component
public class ContractHeaderEventListener {
  private final ContractHeaderRepository repository;

  @Inject
  public ContractHeaderEventListener(ContractHeaderRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    ContractHeaderEntry contractHeaderEntry = new ContractHeaderEntry();
    contractHeaderEntry.setId(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    contractHeaderEntry.setContractNumber(event.getContractNumber());
    contractHeaderEntry.setTerm(event.getLoanProduct().getTerm());
    contractHeaderEntry.setBusinessName(event.getLesseeBusiness().getBusinessName());
    contractHeaderEntry.setLoanAmount(event.getLoanProduct().getLoanAmount());
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    ContractHeaderEntry contractHeaderEntry = new ContractHeaderEntry();
    contractHeaderEntry.setId(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    contractHeaderEntry.setContractNumber(event.getContractNumber());
    contractHeaderEntry.setTerm(event.getStaffLoanProduct().getTerm());
    contractHeaderEntry.setBusinessName(event.getStaff().getFullName());
    contractHeaderEntry.setLoanAmount(event.getStaffLoanProduct().getLoanAmount());
    repository.save(contractHeaderEntry);
  }

  @EventHandler
  public void on(ContractActivatedEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    if(contractHeaderEntry == null)
      return;
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_ACTIVATED);
    contractHeaderEntry.setContractDate(event.getContractDate());
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(PendingContractCancelledEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.PENDING_CANCEL);
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(ContractCancelledEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(ContractActivatedCancelledEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(ContractCancellationRejectedEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(ContractNumberUpdatedEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractNumber(event.getContractNumber());
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(PendingStaffLoanContractCancelledEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.PENDING_CANCEL);
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(StaffLoanContractCancelledEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_CANCELLED);
    repository.save(contractHeaderEntry);
  }
  
  @EventHandler
  public void on(StaffLoanContractCancellationRejectedEvent event){
    ContractHeaderEntry contractHeaderEntry = repository.findOne(event.getId());
    contractHeaderEntry.setContractStatus(ContractStatus.CONTRACT_PENDING);
    repository.save(contractHeaderEntry);
  }
}
