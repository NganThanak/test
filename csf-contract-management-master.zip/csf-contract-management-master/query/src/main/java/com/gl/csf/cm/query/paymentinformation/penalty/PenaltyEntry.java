package com.gl.csf.cm.query.paymentinformation.penalty;

import com.gl.csf.cm.common.model.payment.PaymentStatus;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class PenaltyEntry {
  @Id
  private String id;

  private String contractNumber;
  private int installmentNumber;
  private  int overdueDays;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "penalty_amount_currency"), @Column(name = "penalty_amount")})
  private MonetaryAmount penaltyAmount;

  @Column(name = "payment_status")
  @Enumerated(EnumType.STRING)
  private PaymentStatus paymentStatus;
  private LocalDate dueDate;
  private LocalDate paymentDate;
  private String bankTransaction;
  private String paymentReference;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "receive_penalty_amount_currency"), @Column(name = "receive_penalty_amount")})
  private MonetaryAmount receivePenaltyAmount;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "allocation_penalty_amount_currency"), @Column(name = "allocation_penalty_amount")})
  private MonetaryAmount allocatePenaltyAmount;

  @Transient
  private List<PenaltyEntry> subItems =new ArrayList<>();

  public void setSubItems(List<PenaltyEntry> subItems){
    this.subItems = subItems;
  }
}
