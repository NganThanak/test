package com.gl.csf.cm.query.contract.product;

import com.gl.csf.cm.common.model.lessee.StaffLoanPurpose;
import com.gl.csf.cm.common.model.product.PaymentFrequency;
import com.gl.csf.cm.common.model.product.ProductType;
import lombok.Data;
import org.hibernate.annotations.*;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

/**
 * Created by p.ly on 1/25/2018.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class StaffLoanProductEntry implements Serializable {
  @Id
  private String id;
  private String contractId;

  private Integer term;
  private String contractTerm;
  private LocalDate initiatedDate;
  private String createdBy;
  private LocalDate activatedDate;
  private String activatedBy;

  @Enumerated(EnumType.STRING)
  private LoanProductStatus loanStatus;

  @Enumerated(EnumType.STRING)
  private ProductType loanType;

  @Type(type = "Money")
  @Columns(columns = {@Column(name = "loan_currency"), @Column(name = "loan_amount")})
  private MonetaryAmount loanAmount;

  private PaymentFrequency paymentFrequency;
  @Digits(integer = 2, fraction = 1)
  private BigDecimal interestRate;


  @NotNull
  @ElementCollection
  @LazyCollection(LazyCollectionOption.FALSE)
  private Collection<StaffLoanPurpose> staffLoanPurposes;
}
