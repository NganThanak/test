package com.gl.csf.cm.query.contract.lessee.business;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
public interface FinancialStatementRepository extends JpaRepository<FinancialStatementEntry, String> {
}
