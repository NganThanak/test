package com.gl.csf.cm.query.contract.staff;

import com.gl.csf.cm.common.model.Gender;
import com.gl.csf.cm.common.model.address.Address;
import com.gl.csf.cm.common.model.lessee.Company;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/24/2018.
 */
@Data
@Entity
public class StaffPersonalInformationEntry {
  @Id
  private String id;
  private String fullName;
  private String fatherName;
  @Enumerated(EnumType.STRING)
  private Gender gender;
  private LocalDate dob;
  private String phoneNumber;
  private String position;
  private String email;
  private String nrcId;
  private Address ownerAddress;
  private Company company;
}
