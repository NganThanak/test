package com.gl.csf.cm.query.paymentinformation.penalty;

import com.gl.csf.cm.common.model.payment.PaymentStatus;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
public interface PenaltyRepository extends PagingAndSortingRepository<PenaltyEntry, String>,
        QueryByExampleExecutor<PenaltyEntry> {
  List<PenaltyEntry> findAllByContractNumberAndDueDateBeforeAndPaymentStatusIsNot(String contractNumber, LocalDate today, PaymentStatus paymentStatus);
  List<PenaltyEntry> findAllByContractNumber(String contractNumber);
  Optional<PenaltyEntry> findByContractNumberAndInstallmentNumber(String contractNumber, int installmentNumber);
}
