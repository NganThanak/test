package com.gl.csf.cm.query.messaging;

import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryEntry;
import com.gl.csf.cm.query.contract.contractsummary.ContractSummaryRepository;
import com.gl.csf.cm.query.contract.lessee.LesseeBankAccountInformationEntry;
import com.gl.csf.cm.query.contract.lessee.LesseeBankAccountInformationRepository;
import com.gl.csf.cm.query.contract.lessee.LesseePersonalInformationEntry;
import com.gl.csf.cm.query.contract.lessee.LesseePersonalInformationRepository;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.gl.csf.cm.query.contract.product.LoanProductRepository;
import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;
import com.gl.csf.financeapi.utils.FinanceUtils;
import lombok.Value;
import org.axonframework.eventhandling.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/3/2018.
 */
@Service
public class ContractPaymentEventForwarder {

  private final static Logger logger = LoggerFactory.getLogger(ContractPaymentEventForwarder.class);

  @Inject
  private Source messagingChannel;
  @Inject
  private LoanProductRepository loanProductRepository;
  @Inject
  private ContractSummaryRepository contractSummaryRepository;
  @Inject
  private LesseeBankAccountInformationRepository lesseeBankAccountInformationRepository;
  @Inject
  private LesseePersonalInformationRepository lesseePersonalInformationRepository;

  @EventHandler
  public void on(StandardLoanContractActivatedEvent event) {

    messagingChannel.output().send(MessageBuilder
            .withPayload(new ExpectedPaymentList(generateExpectedPayments(event))).build());
  }

  private List<ExpectedPayment> generateExpectedPayments(StandardLoanContractActivatedEvent event) {
    List<ExpectedPayment> expectedPayments = new ArrayList<>();

    List<LoanProductEntry> loanProductEntrys = loanProductRepository.findAllByContractId(event.getId());

    ContractSummaryEntry contractSummaryEntry = contractSummaryRepository.findOne(event.getId());

    LesseeBankAccountInformationEntry lesseeBankAccountInformationEntry = lesseeBankAccountInformationRepository.findOne(event.getId());

    LesseePersonalInformationEntry lesseePersonalInformation = lesseePersonalInformationRepository.findOne(event.getId());

    final LocalDate firstDueDate = FinanceUtils.getFirstDueDate(event.getContractDate(), loanProductEntrys.get(0).getPaymentFrequency().getValue());
    final LoanParameter loanParameter = LoanParameterBuilder.createBuilder()
            .numberOfCompoundingPeriods(loanProductEntrys.get(0).getPaymentFrequency().getValue())
            .loanAmount(loanProductEntrys.get(0).getLoanAmount())
            .loanTerm(loanProductEntrys.get(0).getTerm() / 12.0)
            .nominalInterestRate(loanProductEntrys.get(0).getInterestRate().setScale(4, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(12))
                    .divide(BigDecimal.valueOf(100), BigDecimal.ROUND_HALF_UP).doubleValue())
            .contractStartDate(event.getContractDate())
            .dueDate(firstDueDate)
            .build();

    SimpleAmortization simpleAmortization = new SimpleAmortization();

    List<Installment> installments = simpleAmortization.generatePaymentSchedule(loanParameter);
    for (Installment installment : installments) {
      expectedPayments.add(new ExpectedPayment(UUID.randomUUID().toString(), contractSummaryEntry.getContractNumber(),
              installment.getInstallmentNumber(), contractSummaryEntry.getBusinessName(), installment.getDueDate(), installment.getAmount(),
              lesseeBankAccountInformationEntry.getBankAccount().getBank().getName(),
              lesseeBankAccountInformationEntry.getBankAccount().getAccountNumber(), lesseePersonalInformation.getFullName()));
    }

    return expectedPayments;
  }

  @Value
  public static class ExpectedPayment {
    String id;
    String contractNumber;
    int installmentNumber;
    String businessName;
    LocalDate dueDate;
    MonetaryAmount dueAmount;
    String bankName;
    String bankAccount;
    String customerName;
  }

  @Value
  public static class ExpectedPaymentList {
    List<ExpectedPayment> expectedPayments;
  }
}
