package com.gl.csf.cm.query.contract.lessee;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.lessee.LesseePersonalInformation;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class LesseePersonalInformationEventListener {
  private final LesseePersonalInformationRepository repository;

  @Inject
  public LesseePersonalInformationEventListener(LesseePersonalInformationRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    LesseePersonalInformation lesseePersonalInformation = event.getLesseePersonalInformation();

    LesseePersonalInformationEntry lesseePersonalInformationEntry = new LesseePersonalInformationEntry();
    lesseePersonalInformationEntry.setId(event.getId());
    lesseePersonalInformationEntry.setFullName(lesseePersonalInformation.getFullName());
    lesseePersonalInformationEntry.setFatherName(lesseePersonalInformation.getFatherName());
    lesseePersonalInformationEntry.setGender(lesseePersonalInformation.getGender());
    lesseePersonalInformationEntry.setDob(lesseePersonalInformation.getDob());
    lesseePersonalInformationEntry.setPhoneNumber(lesseePersonalInformation.getPhoneNumber());
    lesseePersonalInformationEntry.setAdditionalPhoneNumber1(lesseePersonalInformation.getAdditionalPhoneNumber1());
    lesseePersonalInformationEntry.setAdditionalPhoneNumber2(lesseePersonalInformation.getAdditionalPhoneNumber2());
    lesseePersonalInformationEntry.setEmail(lesseePersonalInformation.getEmail());
    lesseePersonalInformationEntry.setNrcId(lesseePersonalInformation.getNrcId());
    lesseePersonalInformationEntry.setOwnerAddress(lesseePersonalInformation.getOwnerAddress());

    repository.save(lesseePersonalInformationEntry);
  }
}
