package com.gl.csf.cm.query.contract.lessee.business;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 27/11/2017.
 */
@Embeddable
@Getter
@Setter
public class MainBranch implements Serializable{
  private String branchId;
  private String branchName;

  public MainBranch(){
  }

  public MainBranch(String branchId, String branchName){
    this.branchId = branchId;
    this.branchName = branchName;
  }

  @Override
  public String toString() {
    return branchName;
  }
}
