package com.gl.csf.cm.query.contract.accounting;

import com.gl.csf.cm.api.contract.event.ContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.RevolvingLoanContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.StaffLoanContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.common.model.payment.DueDateCalculationPeriod;
import com.gl.csf.cm.service.DueDateCalculationPeriodService;
import com.gl.csf.financeapi.utils.FinanceUtils;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
@Component
public class ContractInterestRealizationAttributeEventListener {

  private final ContractInterestRealizationAttributeRepository repository;
  private final DueDateCalculationPeriodService service;

  @Inject
  public ContractInterestRealizationAttributeEventListener(ContractInterestRealizationAttributeRepository repository, DueDateCalculationPeriodService service){
    this.repository = repository;
    this.service = service;
  }

  @EventHandler
  public void on(StandardLoanContractActivatedEvent event){
    createContractInterestRealizationAttributeEntry(event, event.getLoanAmount());
  }

  @EventHandler
  public void on(RevolvingLoanContractActivatedEvent event){
    createContractInterestRealizationAttributeEntry(event, event.getFirstWithdrawalAmount());
  }
  
  @EventHandler
  public void on(StaffLoanContractActivatedEvent event){
    createContractInterestRealizationAttributeEntry(event, event.getLoanAmount());
  }
  
  private void createContractInterestRealizationAttributeEntry(ContractActivatedEvent event, MonetaryAmount loanAmount){
    MonetaryAmount installment = FinanceUtils.getInstallmentAmount(loanAmount,
      event.getInterestRate().setScale(4, BigDecimal.ROUND_HALF_UP)
        .multiply(BigDecimal.valueOf(12))
        .divide(BigDecimal.valueOf(100), BigDecimal.ROUND_HALF_UP),
      event.getPaymentFrequency(), event.getTerm() / 12.0);

    MonetaryAmount scaledInstallment = Money.of(installment.getNumber().numberValue(BigDecimal.class)
      .setScale(4, BigDecimal.ROUND_HALF_UP), installment.getCurrency());

    BigDecimal irr = FinanceUtils.getIrr(loanAmount, scaledInstallment, event.getTerm()).multiply(BigDecimal.valueOf(100)).setScale(4, BigDecimal.ROUND_HALF_DOWN);

    int days = service.getAllDueDateCalculationPeriod().stream().filter(
      p -> (LocalDate.now().isAfter(p.getEffectiveDate()) || LocalDate.now().isEqual(p.getEffectiveDate()))
        && !LocalDate.now().isBefore(p.getEffectiveDate())) .sorted(Comparator.comparing(DueDateCalculationPeriod::getEffectiveDate).reversed())
      .map(DueDateCalculationPeriod::getDays).findFirst().orElse(null);

    ContractInterestRealizationAttributeEntry entry = new ContractInterestRealizationAttributeEntry();
    entry.setContractId(event.getId());
    entry.setContractNumber(event.getContractNumber());
    entry.setContractDate(event.getContractDate());
    entry.setLeaseAmount(loanAmount);
    entry.setLeasingTerm(event.getTerm());
    entry.setFlatRate(event.getInterestRate());
    entry.setInstallment(scaledInstallment);
    entry.setMonthlyEffectiveRate(irr);
    entry.setAnnuallyEffectiveRate(irr.multiply(BigDecimal.valueOf(12)));

    //check permission to set difference first duedate
    if(isContractForStaffLoan(event.getContractNumber()))
      entry.setFirstDueDate(FinanceUtils.getFirstDueDateForStaffLoan(event.getContractDate(), days));
    else
      entry.setFirstDueDate(FinanceUtils.getFirstDueDate(event.getContractDate(), event.getPaymentFrequency()));

    repository.save(entry);
  }

  private boolean isContractForStaffLoan(String contractNo){
    return contractNo.startsWith("SL-");
  }
}
