package com.gl.csf.cm.query.contract.contractheader;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Thanak Ngan (t.ngan@gl-f.com) on 11/16/2017.
 */
@Data
@Entity
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class ContractHeaderEntry implements Serializable {
  @Id
  private String id;
  private String contractNumber;
  private LocalDate contractDate;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "loan_amount_currency"), @Column(name = "loan_amount")})
  private MonetaryAmount loanAmount;
  private Integer term;
  private String businessName;
  @Enumerated(EnumType.STRING)
  private ContractStatus contractStatus;
}
