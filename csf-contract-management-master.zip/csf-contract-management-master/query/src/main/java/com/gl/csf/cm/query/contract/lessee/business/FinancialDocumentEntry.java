package com.gl.csf.cm.query.contract.lessee.business;

import com.gl.csf.cm.common.model.document.DocumentDescriptor;
import lombok.Data;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Entity
@Data
public class FinancialDocumentEntry implements Serializable {
  @EmbeddedId
  private DocumentDescriptor documentDescriptor;
  private String contractId;
  private String attachment;
  private String uploadBy;
  private LocalDateTime dateTime;
  private String comment;
}
