package com.gl.csf.cm.query.contract.guarantor;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.guarantor.GuarantorPersonalInformation;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class GuarantorPersonalInformationEventListener {
  private final GuarantorPersonalInformationRepository repository;

  @Inject
  public GuarantorPersonalInformationEventListener(GuarantorPersonalInformationRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    GuarantorPersonalInformation guarantorPersonalInformation = event.getGuarantorPersonalInformation();

    if(guarantorPersonalInformation == null)
      return;

    GuarantorPersonalInformationEntry guarantorPersonalInformationEntry = new GuarantorPersonalInformationEntry();
    guarantorPersonalInformationEntry.setId(event.getId());
    guarantorPersonalInformationEntry.setFullName(guarantorPersonalInformation.getFullName());
    guarantorPersonalInformationEntry.setGender(guarantorPersonalInformation.getGender());
    guarantorPersonalInformationEntry.setDob(guarantorPersonalInformation.getDob());
    guarantorPersonalInformationEntry.setPhoneNumber(guarantorPersonalInformation.getPhoneNumber());
    guarantorPersonalInformationEntry.setEmail(guarantorPersonalInformation.getEmail());
    guarantorPersonalInformationEntry.setNrcId(guarantorPersonalInformation.getNrcId());
    guarantorPersonalInformationEntry.setRelationship(guarantorPersonalInformation.getRelationship());
    guarantorPersonalInformationEntry.setAddress(guarantorPersonalInformation.getAddress());

    repository.save(guarantorPersonalInformationEntry);
  }
}
