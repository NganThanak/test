package com.gl.csf.cm.query.contract.staff;

import lombok.Data;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jadira.usertype.moneyandcurrency.moneta.PersistentMoneyAmountAndCurrency;

import javax.money.MonetaryAmount;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/26/2018.
 */
@Entity
@Data
@TypeDef(name = "Money", typeClass = PersistentMoneyAmountAndCurrency.class)
public class StaffFinancialStatementEntry {
  @Id
  private String id;
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "monthly_currency"), @Column(name = "monthly_salary")})
  private MonetaryAmount monthlySalary;
  
  @Type(type = "Money")
  @Columns(columns = {@Column(name = "annual_currency"), @Column(name = "annual_salary")})
  private MonetaryAmount annualSalary;
  
  private Double financialRatio;
}
