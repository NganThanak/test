package com.gl.csf.cm.query.contract.staff;

import com.gl.csf.cm.query.contract.lessee.business.FinancialStatementEntry;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 1/26/2018.
 */
public interface StaffFinancialStatementRepository extends JpaRepository<StaffFinancialStatementEntry, String> {
}

