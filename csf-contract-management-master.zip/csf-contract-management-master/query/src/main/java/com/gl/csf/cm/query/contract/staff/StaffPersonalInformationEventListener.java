package com.gl.csf.cm.query.contract.staff;

import com.gl.csf.cm.api.contract.event.ApplicationSubmittedEvent;
import com.gl.csf.cm.common.model.lessee.Staff;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class StaffPersonalInformationEventListener {
  private final StaffPersonalInformationRepository repository;

  @Inject
  public StaffPersonalInformationEventListener(StaffPersonalInformationRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ApplicationSubmittedEvent event){
    Staff staff = event.getStaff();
    StaffPersonalInformationEntry staffPersonalInformationEntry = new StaffPersonalInformationEntry();
    staffPersonalInformationEntry.setId(event.getId());
    staffPersonalInformationEntry.setFullName(staff.getFullName());
    staffPersonalInformationEntry.setFatherName(staff.getFatherName());
    staffPersonalInformationEntry.setGender(staff.getGender());
    staffPersonalInformationEntry.setDob(staff.getDateOfBirth());
    staffPersonalInformationEntry.setPhoneNumber(staff.getPhoneNumber());
    staffPersonalInformationEntry.setPosition(staff.getPosition());
    staffPersonalInformationEntry.setCompany(staff.getCompany());
    staffPersonalInformationEntry.setEmail(staff.getEmail());
    staffPersonalInformationEntry.setNrcId(staff.getNrcID());
    staffPersonalInformationEntry.setOwnerAddress(staff.getAddress());

    repository.save(staffPersonalInformationEntry);
  }
}
