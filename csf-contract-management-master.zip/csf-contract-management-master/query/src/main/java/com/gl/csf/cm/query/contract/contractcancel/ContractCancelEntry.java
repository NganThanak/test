package com.gl.csf.cm.query.contract.contractcancel;

import com.gl.csf.cm.common.model.contract.ContractStatus;
import lombok.Data;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.time.LocalDate;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Chann Bora (b.chann@gl-f.com) on 12/14/2017.
 */
@Data
@Entity
public class ContractCancelEntry {
  @Id
  private String id;
  
  @Column(name = "contract_status")
  @Enumerated(EnumType.STRING)
  private ContractStatus contractStatus;
  
  private String contractID;
  private LocalDate cancelledDate;
  private String updatedBy;
  @Type(type = "text")
  private String cancelledReasonStaff;
  @Type(type = "text")
  private String cancelledReasonManager;
  
}
