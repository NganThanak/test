package com.gl.csf.cm.query.contract.product;

import com.gl.csf.cm.api.contract.event.ContractActivatedEvent;
import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.product.LoanProduct;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;
import javax.inject.Inject;
import java.util.UUID;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class LoanProductEventListener {
  private final LoanProductRepository repository;
  public final static String ORIGINAL_TERM = "Original Term";
  public final static String CREATED_BY = "System";

  @Inject
  public LoanProductEventListener(LoanProductRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    LoanProduct loanProduct = event.getLoanProduct();

    LoanProductEntry loanProductEntry = new LoanProductEntry();
    loanProductEntry.setId(UUID.randomUUID().toString());
    loanProductEntry.setContractId(event.getId());
    loanProductEntry.setCreatedBy(CREATED_BY);
    loanProductEntry.setInitiatedDate(event.getCreatedDate());
    loanProductEntry.setLoanStatus(LoanProductStatus.PENDING);
    loanProductEntry.setLoanType(loanProduct.getProductType());
    loanProductEntry.setLoanAmount(loanProduct.getLoanAmount());
    loanProductEntry.setPaymentFrequency(loanProduct.getPaymentFrequency());
    loanProductEntry.setInterestRate(event.getLoanProduct().getInterestRate());
    loanProductEntry.setTerm(loanProduct.getTerm());
    loanProductEntry.setContractTerm(ORIGINAL_TERM);
    loanProductEntry.setReasonForRequest(loanProduct.getReasonForRequest());

    repository.save(loanProductEntry);
  }

  @EventHandler
  public void on(ContractActivatedEvent event){
    LoanProductEntry loanProductEntry = repository.findOneByContractIdAndLoanStatus(event.getId(), LoanProductStatus.PENDING);
    if(loanProductEntry == null)
      return;
    loanProductEntry.setLoanStatus(LoanProductStatus.ACTIVE);
    loanProductEntry.setActivatedDate(event.getActivatedDate());
    loanProductEntry.setActivatedBy(event.getActivatedBy());
    repository.save(loanProductEntry);
  }
}
