package com.gl.csf.cm.query.paymentinformation.contractschedule;

import com.gl.csf.cm.api.contract.event.PaymentFullyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.PaymentPartiallyAllocatedEvent;
import com.gl.csf.cm.api.contract.event.StandardLoanContractActivatedEvent;
import com.gl.csf.cm.common.model.payment.DailyPenaltyRate;
import com.gl.csf.cm.common.model.payment.GracePeriod;
import com.gl.csf.cm.common.model.payment.PaymentStatus;
import com.gl.csf.cm.common.model.payment.PenaltyCalculationPeriod;
import com.gl.csf.cm.config.MultiOutputSource;
import com.gl.csf.cm.query.contract.product.LoanProductEntry;
import com.gl.csf.cm.query.contract.product.LoanProductRepository;
import com.gl.csf.cm.query.contract.util.CurrencyUtil;
import com.gl.csf.cm.query.contract.util.MoneyUtils;
import com.gl.csf.cm.query.services.DailyPenaltyRateServices;
import com.gl.csf.cm.query.services.GracePeriodServices;
import com.gl.csf.cm.query.services.PenaltyCalculationPeriodServices;
import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;
import com.gl.csf.financeapi.utils.FinanceUtils;
import lombok.Value;
import org.axonframework.eventhandling.EventHandler;
import org.javamoney.moneta.Money;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * Copyright (c) GL Finance Plc. All rights reserved. (http://www.gl-f.com/)
 * Author: Kuylim Tith (k.tith@gl-f.com) on 1/13/2018.
 */
@Component
@EnableBinding(MultiOutputSource.class)
public class ContractScheduleEventListener {

  private static final MonetaryAmount MMK_ZERO = Money.of(0, CurrencyUtil.MMK_CURRENCY);
  private final MultiOutputSource messagingChannel;
  private final LoanProductRepository loanProductRepository;
  private final ContractScheduleRepository contractScheduleRepository;
  private final GracePeriodServices gracePeriodServices;
  private final PenaltyCalculationPeriodServices penaltyCalculationPeriodServices;
  private final DailyPenaltyRateServices dailyPenaltyRateServices;
  @Inject
  public ContractScheduleEventListener(MultiOutputSource messagingChannel,
                                       LoanProductRepository loanProductRepository, ContractScheduleRepository contractScheduleRepository, GracePeriodServices gracePeriodServices, PenaltyCalculationPeriodServices penaltyCalculationPeriodServices, DailyPenaltyRateServices dailyPenaltyRateServices) {
    this.messagingChannel = messagingChannel;
    this.loanProductRepository = loanProductRepository;
    this.contractScheduleRepository = contractScheduleRepository;
    this.gracePeriodServices = gracePeriodServices;
    this.penaltyCalculationPeriodServices = penaltyCalculationPeriodServices;
    this.dailyPenaltyRateServices = dailyPenaltyRateServices;
  }

  @EventHandler
  private void on (StandardLoanContractActivatedEvent event){
    generateContractSchedule(event);
  }

  @EventHandler
  private void on (PaymentFullyAllocatedEvent event){
    
    List<PaymentStatus> statuses = new ArrayList<>();
    statuses.add(PaymentStatus.UNPAID);
    statuses.add(PaymentStatus.PARTIAL);
    MonetaryAmount monthlyPenalty = (event.getPenaltyAmount() == null ? MoneyUtils.ZERO_VALUE : event.getPenaltyAmount() );
    MonetaryAmount receiveAmount = event.getAmount().subtract(monthlyPenalty);
    MonetaryAmount lastInstallmentPaidNoPenalty = MoneyUtils.ZERO_VALUE;
    ContractScheduleEntry contractSchedule = new ContractScheduleEntry();
    List<GracePeriod> gracePeriods = gracePeriodServices.getAllGracePeriods();
    List<PenaltyCalculationPeriod> penaltyCalculationPeriods = penaltyCalculationPeriodServices.getAllPenaltyCalculationPeriods();
    List<DailyPenaltyRate> dailyPenaltyRates = dailyPenaltyRateServices.getAllDailyPenaltyRates();
    MonetaryAmount penaltyRate = dailyPenaltyRates.get(0).getRate();
    List<ContractScheduleEntry> contractSchedules = contractScheduleRepository.findByContractNumberAndPaymentStatusInOrderByScheduleDueDate(event.getContractNumber(), statuses);
    
    for (int i = 0; i < contractSchedules.size(); i++) {
      contractSchedule = contractSchedules.get(i);
      lastInstallmentPaidNoPenalty = contractSchedule.getPaymentInstallment().subtract(contractSchedule.getPaymentMonthlyPenalty());
      receiveAmount = receiveAmount.add(lastInstallmentPaidNoPenalty);
      
      // if the received amount less than interest
      if(receiveAmount.subtract(contractSchedule.getScheduleInterest()).isLessThanOrEqualTo(MoneyUtils.ZERO_VALUE)){
        contractSchedule.setPaymentInstallment(receiveAmount);
        contractSchedule.setPaymentInterest(receiveAmount);
        contractSchedule.setPaymentPrinciple(MoneyUtils.ZERO_VALUE);
        contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
        if(contractSchedule.getScheduleDueDate().isBefore(event.getPaymentDate())) {
          contractSchedule.setOutstandingAmount(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount));
          contractSchedule.setOutstandingRatio(getTwoDigitPlace(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount)
                  .divide(contractSchedule.getScheduleInstallmentAmount().getNumber().doubleValue()).multiply(30).getNumber().doubleValue()));
        }
        contractSchedule.setPaymentStatus(PaymentStatus.PARTIAL);
        if (contractSchedule.getPaymentDate() == null)
          contractSchedule.setPaymentDate(event.getPaymentDate());
        if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
          Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
          contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
        }
        contractSchedule.setLastPaymentDate(event.getPaymentDate());
        contractScheduleRepository.save(contractSchedule);
        break;
      } else {
        // if the received amount == schedule installment amount
        if(receiveAmount.subtract(contractSchedule.getScheduleInstallmentAmount()).isEqualTo(MoneyUtils.ZERO_VALUE)){
          contractSchedule.setPaymentInstallment(receiveAmount);
          contractSchedule.setPaymentPrinciple(contractSchedule.getSchedulePrinciple());
          contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
          contractSchedule.setPaymentInterest(contractSchedule.getScheduleInterest());
          contractSchedule.setOutstandingAmount(MoneyUtils.ZERO_VALUE);
          contractSchedule.setOutstandingRatio(0.00);
          contractSchedule.setPaymentStatus(PaymentStatus.FULL);
          if (contractSchedule.getPaymentDate() == null)
            contractSchedule.setPaymentDate(event.getPaymentDate());
          if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
            Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
            contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
          }
          contractSchedule.setLastPaymentDate(event.getPaymentDate());
          contractScheduleRepository.save(contractSchedule);
          break;
        }else if(receiveAmount.subtract(contractSchedule.getScheduleInstallmentAmount()).isLessThan(MoneyUtils.ZERO_VALUE)){
          // if the received payment less than schedule installment
          contractSchedule.setPaymentInstallment(receiveAmount);
          contractSchedule.setPaymentInterest(contractSchedule.getScheduleInterest());
          contractSchedule.setPaymentPrinciple(receiveAmount.subtract(contractSchedule.getScheduleInterest()));
          contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
          if(contractSchedule.getScheduleDueDate().isBefore(event.getPaymentDate())) {
            contractSchedule.setOutstandingAmount(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount));
            contractSchedule.setOutstandingRatio(getTwoDigitPlace(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount)
                    .divide(contractSchedule.getScheduleInstallmentAmount().getNumber().doubleValue()).multiply(30).getNumber().doubleValue()));
          }
          contractSchedule.setPaymentStatus(PaymentStatus.PARTIAL);
          if (contractSchedule.getPaymentDate() == null)
            contractSchedule.setPaymentDate(event.getPaymentDate());
          if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
            Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
            contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
          }
          contractSchedule.setLastPaymentDate(event.getPaymentDate());
          contractScheduleRepository.save(contractSchedule);
          break;
        }else {
          // if the received payment greater than schedule installment
          contractSchedule.setPaymentInstallment(contractSchedule.getScheduleInstallmentAmount());
          contractSchedule.setPaymentPrinciple(contractSchedule.getSchedulePrinciple());
          contractSchedule.setPaymentInterest(contractSchedule.getScheduleInterest());
          contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
          contractSchedule.setOutstandingRatio(0.00);
          contractSchedule.setOutstandingAmount(MoneyUtils.ZERO_VALUE);
          contractSchedule.setPaymentStatus(PaymentStatus.FULL);
          if (contractSchedule.getPaymentDate() == null)
            contractSchedule.setPaymentDate(event.getPaymentDate());
          if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
            Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
            contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
          }
          contractSchedule.setLastPaymentDate(event.getPaymentDate());
          contractScheduleRepository.save(contractSchedule);
          receiveAmount = receiveAmount.subtract(contractSchedule.getScheduleInstallmentAmount());
        }
      }
    }

    messagingChannel.outputAllocationPayment().send(MessageBuilder
            .withPayload(new PaymentAllocatedEventAsMessage(event.getPaymentId(), event.getAllocateOn(), event.getExpectedPaymentId(),
                    event.getContractNumber(), event.getInstallmentNumber(), event.getAmount(), event.getPaymentDate(),
                    event.getBankTransaction(), monthlyPenalty)).build());
  }

  @EventHandler
  private void on (PaymentPartiallyAllocatedEvent event){
    List<PaymentStatus> statuses = new ArrayList<>();
    statuses.add(PaymentStatus.UNPAID);
    statuses.add(PaymentStatus.PARTIAL);
    MonetaryAmount monthlyPenalty = (event.getPenaltyAmount() == null ? MoneyUtils.ZERO_VALUE : event.getPenaltyAmount() );
    MonetaryAmount receiveAmount = event.getAmount().subtract(monthlyPenalty);
    MonetaryAmount lastInstallmentPaidNoPenalty = MoneyUtils.ZERO_VALUE;
    ContractScheduleEntry contractSchedule = new ContractScheduleEntry();
    List<GracePeriod> gracePeriods = gracePeriodServices.getAllGracePeriods();
    List<PenaltyCalculationPeriod> penaltyCalculationPeriods = penaltyCalculationPeriodServices.getAllPenaltyCalculationPeriods();
    List<DailyPenaltyRate> dailyPenaltyRates = dailyPenaltyRateServices.getAllDailyPenaltyRates();
    MonetaryAmount penaltyRate = dailyPenaltyRates.get(0).getRate();
    List<ContractScheduleEntry> contractSchedules = contractScheduleRepository.findByContractNumberAndPaymentStatusInOrderByScheduleDueDate(event.getContractNumber(), statuses);
  
    for (int i = 0; i < contractSchedules.size(); i++) {
      contractSchedule = contractSchedules.get(i);
      lastInstallmentPaidNoPenalty = contractSchedule.getPaymentInstallment().subtract(contractSchedule.getPaymentMonthlyPenalty());
      receiveAmount = receiveAmount.add(lastInstallmentPaidNoPenalty);
    
      // if the received amount less than interest
      if(receiveAmount.subtract(contractSchedule.getScheduleInterest()).isLessThanOrEqualTo(MoneyUtils.ZERO_VALUE)){
        contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
        contractSchedule.setPaymentInstallment(receiveAmount);
        contractSchedule.setPaymentInterest(receiveAmount);
        contractSchedule.setPaymentPrinciple(MoneyUtils.ZERO_VALUE);
        if(contractSchedule.getScheduleDueDate().isBefore(event.getPaymentDate())) {
          contractSchedule.setOutstandingAmount(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount));
          contractSchedule.setOutstandingRatio(getTwoDigitPlace(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount)
                  .divide(contractSchedule.getScheduleInstallmentAmount().getNumber().doubleValue()).multiply(30).getNumber().doubleValue()));
        }
        contractSchedule.setPaymentStatus(PaymentStatus.PARTIAL);
        if (contractSchedule.getPaymentDate() == null)
          contractSchedule.setPaymentDate(event.getPaymentDate());
        if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
          Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
          contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
        }
        contractSchedule.setLastPaymentDate(event.getPaymentDate());
        contractScheduleRepository.save(contractSchedule);
        break;
      } else {
        // if the received amount == schedule installment amount
        if(receiveAmount.subtract(contractSchedule.getScheduleInstallmentAmount()).isEqualTo(MoneyUtils.ZERO_VALUE)){
          contractSchedule.setPaymentInstallment(receiveAmount);
          contractSchedule.setPaymentPrinciple(contractSchedule.getSchedulePrinciple());
          contractSchedule.setPaymentInterest(contractSchedule.getScheduleInterest());
          contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
          contractSchedule.setOutstandingAmount(MoneyUtils.ZERO_VALUE);
          contractSchedule.setOutstandingRatio(0.00);
          contractSchedule.setPaymentStatus(PaymentStatus.FULL);
          if (contractSchedule.getPaymentDate() == null)
            contractSchedule.setPaymentDate(event.getPaymentDate());
          if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
            Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
            contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
          }
          contractSchedule.setLastPaymentDate(event.getPaymentDate());
          contractScheduleRepository.save(contractSchedule);
          break;
        }else if(receiveAmount.subtract(contractSchedule.getScheduleInstallmentAmount()).isLessThan(MoneyUtils.ZERO_VALUE)){
          // if the received payment less than schedule installment
          contractSchedule.setPaymentInstallment(receiveAmount);
          contractSchedule.setPaymentPrinciple(receiveAmount.subtract(contractSchedule.getScheduleInterest()));
          contractSchedule.setPaymentInterest(contractSchedule.getScheduleInterest());
          contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
          if(contractSchedule.getScheduleDueDate().isBefore(event.getPaymentDate())) {
            contractSchedule.setOutstandingAmount(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount));
            contractSchedule.setOutstandingRatio(getTwoDigitPlace(contractSchedule.getScheduleInstallmentAmount().subtract(receiveAmount)
                    .divide(contractSchedule.getScheduleInstallmentAmount().getNumber().doubleValue()).multiply(30).getNumber().doubleValue()));
          }
          contractSchedule.setPaymentStatus(PaymentStatus.PARTIAL);
          if (contractSchedule.getPaymentDate() == null)
            contractSchedule.setPaymentDate(event.getPaymentDate());
          if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
            Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
            contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
          }
          contractSchedule.setLastPaymentDate(event.getPaymentDate());
          contractScheduleRepository.save(contractSchedule);
          break;
        }else {
          // if the received payment greater than schedule installment
          contractSchedule.setPaymentInstallment(contractSchedule.getScheduleInstallmentAmount());
          contractSchedule.setPaymentPrinciple(contractSchedule.getSchedulePrinciple());
          contractSchedule.setPaymentInterest(contractSchedule.getScheduleInterest());
          contractSchedule.setPaymentMonthlyPenalty(monthlyPenalty);
          contractSchedule.setOutstandingAmount(MoneyUtils.ZERO_VALUE);
          contractSchedule.setOutstandingRatio(0.00);
          contractSchedule.setPaymentStatus(PaymentStatus.FULL);
          if (contractSchedule.getPaymentDate() == null)
            contractSchedule.setPaymentDate(event.getPaymentDate());
          if(contractSchedule.getScheduleDueDate().plusMonths(i + 1).minusDays(penaltyCalculationPeriods.get(0).getDays()).isBefore(event.getPaymentDate())){
            Long penaltyDays = DAYS.between(contractSchedule.getScheduleDueDate().plusDays(gracePeriods.get(0).getDays()), event.getPaymentDate());
            contractSchedule.setPenaltyAmount(penaltyRate.multiply(penaltyDays));
          }
          contractSchedule.setLastPaymentDate(event.getPaymentDate());
          contractScheduleRepository.save(contractSchedule);
          receiveAmount = receiveAmount.subtract(contractSchedule.getScheduleInstallmentAmount());
        }
      }
    }

    messagingChannel.outputAllocationPayment().send(MessageBuilder
            .withPayload(new PaymentAllocatedEventAsMessage(event.getPaymentId(), event.getAllocateOn(), event.getExpectedPaymentId(),
                    event.getContractNumber(), event.getInstallmentNumber(), event.getAmount(), event.getPaymentDate(),
                    event.getBankTransaction(), event.getPenaltyAmount())).build());
  }

  private void generateContractSchedule(StandardLoanContractActivatedEvent event){

    List<LoanProductEntry> loanProductEntrys = loanProductRepository.findAllByContractId(event.getId());

    final LocalDate firstDueDate = FinanceUtils.getFirstDueDate(event.getContractDate(), loanProductEntrys.get(0).getPaymentFrequency().getValue());
    final LoanParameter loanParameter = LoanParameterBuilder.createBuilder()
            .numberOfCompoundingPeriods(loanProductEntrys.get(0).getPaymentFrequency().getValue())
            .loanAmount(loanProductEntrys.get(0).getLoanAmount())
            .loanTerm(loanProductEntrys.get(0).getTerm() / 12.0)
            .nominalInterestRate(loanProductEntrys.get(0).getInterestRate().setScale(4, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(12))
                    .divide(BigDecimal.valueOf(100), BigDecimal.ROUND_HALF_UP).doubleValue())
            .contractStartDate(event.getContractDate())
            .dueDate(firstDueDate)
            .build();

    SimpleAmortization simpleAmortization = new SimpleAmortization();

    List<Installment> installments = simpleAmortization.generatePaymentSchedule(loanParameter);
    for (Installment installment : installments) {
      ContractScheduleEntry contractScheduleEntry = new ContractScheduleEntry();
      contractScheduleEntry.setId(UUID.randomUUID().toString());
      contractScheduleEntry.setContractNumber(event.getContractNumber());
      contractScheduleEntry.setInstallmentNumber(installment.getInstallmentNumber());
      contractScheduleEntry.setFee(MMK_ZERO);
      contractScheduleEntry.setOutstandingAmount(MMK_ZERO);
      contractScheduleEntry.setOutstandingRatio(0.00);
      contractScheduleEntry.setPaymentInstallment(MMK_ZERO);
      contractScheduleEntry.setPaymentInterest(MMK_ZERO);
      contractScheduleEntry.setPaymentMonthlyPenalty(MMK_ZERO);
      contractScheduleEntry.setPaymentPrinciple(MMK_ZERO);
      contractScheduleEntry.setPaymentStatus(PaymentStatus.UNPAID);
      contractScheduleEntry.setPenaltyAmount(MMK_ZERO);
      contractScheduleEntry.setScheduleDueDate(installment.getDueDate());
      contractScheduleEntry.setScheduleInstallmentAmount(installment.getAmount());
      contractScheduleEntry.setScheduleInterest(installment.getInterest());
      contractScheduleEntry.setSchedulePrinciple(installment.getPrincipal());
      contractScheduleEntry.setVat(0.0);

      contractScheduleRepository.save(contractScheduleEntry);
    }
  }
  
  private double getTwoDigitPlace(double ratioNumber){
    DecimalFormat df2 = new DecimalFormat("###.##");
    return Double.valueOf(df2.format(ratioNumber));
  }

  @Value
  class PaymentAllocatedEventAsMessage{
    String paymentId;
    LocalDate allocateOn;
    String expectedPaymentId;
    String contractNumber;
    int installmentNumber;
    MonetaryAmount amount;
    LocalDate paymentDate;
    String bankTransaction;
    MonetaryAmount penaltyAmount;
  }

}
