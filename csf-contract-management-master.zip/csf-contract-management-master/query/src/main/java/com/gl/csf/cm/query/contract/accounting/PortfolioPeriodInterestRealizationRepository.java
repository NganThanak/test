package com.gl.csf.cm.query.contract.accounting;

import com.gl.csf.cm.common.model.product.ProductType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 22/11/2017.
 */
public interface PortfolioPeriodInterestRealizationRepository extends JpaRepository<PortfolioPeriodInterestRealizationEntry, String> {
  List<PortfolioPeriodInterestRealizationEntry> findAllByLoanTypeAndEndOfMonthDateBetween(ProductType loanType, LocalDate from, LocalDate to);
  List<PortfolioPeriodInterestRealizationEntry> findAllByEndOfMonthDateBetween(LocalDate from, LocalDate to);
  Page<PortfolioPeriodInterestRealizationEntry> findAllByLoanTypeAndEndOfMonthDateBetween(ProductType loanType, LocalDate from, LocalDate to, Pageable pageable);
  int countByLoanTypeAndEndOfMonthDateBetween(ProductType loanType, LocalDate from, LocalDate to);
  Optional<PortfolioPeriodInterestRealizationEntry> findByEndOfMonthDateAndLoanType(LocalDate endOfMonthDate, ProductType loanType);
}
