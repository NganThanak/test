package com.gl.csf.cm.query.contract.guarantor;

import com.gl.csf.cm.api.contract.event.ContractCreatedEvent;
import com.gl.csf.cm.common.model.guarantor.GuarantorBusiness;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Component
public class GuarantorBusinessEventListener {
  private final GuarantorBusinessRepository repository;

  @Inject
  public GuarantorBusinessEventListener(GuarantorBusinessRepository repository){
    this.repository = repository;
  }

  @EventHandler
  public void on(ContractCreatedEvent event){
    GuarantorBusiness guarantorBusiness = event.getGuarantorBusiness();
    if(guarantorBusiness == null)
      return;

    GuarantorBusinessEntry guarantorBusinessEntry = new GuarantorBusinessEntry();
    guarantorBusinessEntry.setId(event.getId());
    guarantorBusinessEntry.setAddress(guarantorBusiness.getAddress());
    guarantorBusinessEntry.setPhoneNumber(guarantorBusiness.getPhoneNumber());
    repository.save(guarantorBusinessEntry);
  }
}
