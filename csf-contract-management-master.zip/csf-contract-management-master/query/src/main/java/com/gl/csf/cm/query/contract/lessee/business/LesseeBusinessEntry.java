package com.gl.csf.cm.query.contract.lessee.business;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 21/11/2017.
 */
@Entity
@Data
public class LesseeBusinessEntry implements Serializable {
  @Id
  private String id;
  private String businessName;
  private MainBranch mainBranch;
  private Boolean isBoss;
  private String businessId;
}
