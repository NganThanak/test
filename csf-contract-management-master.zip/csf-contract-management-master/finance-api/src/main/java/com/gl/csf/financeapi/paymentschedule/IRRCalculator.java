package com.gl.csf.financeapi.paymentschedule;

import com.gl.csf.financeapi.utils.BigFunctions;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;

/**
 * Created by Calvin Phibol on 8/16/2017.
 */
public class IRRCalculator {
  /**
   * Calculate the interest rate that makes NPV = 0, using Newton Rapshon method for 20 iterations
   *
   * @values is the cash in/outflows,
   * @guess is the guessed initial interest rate percentage in decimal, its value should be between 0 and 1
   */

  public static double irr(double[] values, double guess) {
    int iterationCount = 20;
    double accuracy = 0.0000001d;

    double x0 = guess;
    double x1;

    int i = 0;

    while (i < iterationCount) {

      // the value of the function (NPV) and its derivative can be calculated in the same loop
      double fx = 0;
      double dfx = 0;

      for (int k = 0; k < values.length; k++) {
        fx += values[k] / Math.pow(1.0 + x0, k);
        dfx += -k * values[k] / Math.pow(1.0 + x0, k + 1);
      }

      // calculate the new root from the guessed root using the Newton-Raphson Method
      x1 = x0 - fx / dfx;

      if (Math.abs(x1 - x0) <= accuracy) {
        return x1;
      }

      x0 = x1;
      ++i;
    }

    // maximum number of iterations is exceeded
    return Double.NaN;
  }

  public static BigDecimal irr(BigDecimal[] values, double guess, int scale, int roundingMode) {
    return irr(values, BigDecimal.valueOf(guess), scale, roundingMode);
  }

  public static BigDecimal irr(BigDecimal[] values, BigDecimal guess, int scale, int roundingMode) {
    int iterationCount = 20;
    BigDecimal accuracy = BigDecimal.valueOf(0.0000001d);
    accuracy.setScale(scale, roundingMode);

    BigDecimal x0 = guess;
    BigDecimal x1 = x0;

    int i = 0;

    while (i < iterationCount) {

      // the value of the function (NPV) and its derivative can be calculated in the same loop

      BigDecimal fx = BigDecimal.valueOf(0d);
      BigDecimal dfx = BigDecimal.valueOf(0d);

      for (int k = 0; k < values.length; k++) {
        fx = fx.add(values[k].divide(BigFunctions.pow(BigDecimal.valueOf(1).add(x0), BigDecimal.valueOf(k), scale), scale, roundingMode));
        dfx = dfx.add(BigDecimal.valueOf(-k).multiply(values[k].divide(BigFunctions.pow(BigDecimal.valueOf(1.0).add(x0), BigDecimal.valueOf(k + 1), scale), scale, roundingMode)));
      }

      // calculate the new root from the guessed root using the Newton-Raphson Method
      // x1 = x0 - fx/dfx
      x1 = x0.subtract(fx.divide(dfx, scale, roundingMode));

      if (x1.subtract(x0).abs().compareTo(accuracy) <= 0) {
        return x1;
      }

      x0 = x1;
      ++i;
    }

    // maximum number of iterations is exceeded
    return BigDecimal.valueOf(0);
  }

  public static BigDecimal irr(MonetaryAmount[] values, BigDecimal guess, int scale, int roundingMode) {
    BigDecimal[] bigValues = new BigDecimal[values.length];

    for (int i = 0; i < values.length; i++) {
      bigValues[i] = values[i].getNumber().numberValue(BigDecimal.class);
    }

    return irr(bigValues, guess, scale, roundingMode);
  }
}
