package com.gl.csf.financeapi.paymentschedule;

import javax.money.MonetaryAmount;

public class SimpleAmortization extends Amortization {

  /**
   * paymentinformation amount = interest + periodic principal
   * @param param given loan parameters
   * @return a periodic paymentinformation amount based on Simple interest calculation
   */
  public MonetaryAmount calculateInstallmentAmount(LoanParameter param) {
    return param.getLoanAmount()
            .multiply(param.getNominalInterestRate())
            .divide(param.getNumberOfCompoundingPeriods())
            .add(param.getLoanAmount().divide(param.getNumberOfPeriods()));
  }
}