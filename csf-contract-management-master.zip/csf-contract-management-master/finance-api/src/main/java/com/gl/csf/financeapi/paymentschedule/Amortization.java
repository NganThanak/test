package com.gl.csf.financeapi.paymentschedule;

import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Calvin Phibol on 8/28/2017.
 *
 * This class is used to generate the paymentinformation schedule either for Simple or Compound Interest,
 * approximate internal rate of return(irr) using Newton Rapson's method and calculate installment amount.
 *
 * Usage:
 * <code>
 *     LoanParameter param = LoanParameter.createBuilder().compounding(Compounding.MONTHLY).loanAmount(10000).loanTerm(2).nominalInterestRate(0.276).build();
 *
 *     SimpleAmortization amortization = new SimpleAmortization();
 *
 *     List<Installment> amortizationTable = amortization.generatePaymentSchedule(param);
 * </code>
 *
 */

public abstract class Amortization {

  /**
   * Generate amortization table based on the given loan parameters.
   */
  public List<Installment> generatePaymentSchedule(LoanParameter param){
    MonetaryAmount paymentAmount = calculateInstallmentAmount(param);
    double irr = irr(param);

    List<Installment> amortizedTable = new ArrayList<>();

    MonetaryAmount balance = param.getLoanAmount();

    for(int i=0; i< param.getNumberOfPeriods(); i++){

      MonetaryAmount interest = balance.multiply( irr );
      MonetaryAmount principal = paymentAmount.subtract(interest);
      LocalDate paymentDate;

      Installment prevInstallment;

      if(i == 0){
        paymentDate = param.getDueDate();
      }else{
        prevInstallment = amortizedTable.get(i-1);
        paymentDate = getNextDueDate(prevInstallment.getDueDate(), param.getDueDateMode());
      }

      Installment p = new Installment();
      p.setPrincipal(principal);
      p.setInterest(interest);
      p.setAmount(paymentAmount);
      p.setBeginBalance(balance);
      p.setEndBalance(balance.subtract(principal));
      p.setInstallmentNumber(i+1);
      p.setDueDate(paymentDate);

      amortizedTable.add(p);

      balance = balance.subtract(principal);
    }

    return amortizedTable;
  }

  /**
   * Generate revolving amortization table based on the given loan parameters.
   */

  public List<Installment> generateRevolvingPaymentSchedule(LoanParameter param){
    List<Installment> amortizedTable = new ArrayList<>();

    if(param.getWithdrawals().size() == 0)
      return amortizedTable;

    LoanParameter loanParameter = LoanParameterBuilder.createBuilder()
            .loanAmount(param.getLoanAmount())
            .loanTerm(param.getLoanTerm())
            .numberOfCompoundingPeriods(param.getNumberOfCompoundingPeriods())
            .nominalInterestRate(param.getNominalInterestRate())
            .build();

    double irr = irr(loanParameter);

    int curWithdrawalIndx = 0;
    int prevWithdrawalIndx = curWithdrawalIndx;

    MonetaryAmount withdrawalSubtotal = param.getWithdrawal(curWithdrawalIndx).getAmount();
    MonetaryAmount balance = withdrawalSubtotal;

    for(int i=0; i< param.getNumberOfPeriods(); i++){

      if(i == 0 ){
        withdrawalSubtotal = param.getWithdrawal(curWithdrawalIndx).getAmount();
        balance = withdrawalSubtotal;
      }else{

        Installment prevInstallment = amortizedTable.get(i - 1);

        if(curWithdrawalIndx + 1 < param.getWithdrawals().size()) {
          Withdrawal nextW = param.getWithdrawal(curWithdrawalIndx + 1);

          if (isNewWithdrawal(prevInstallment.getDueDate(), nextW.getWithdrawalDate())) {
            prevWithdrawalIndx = curWithdrawalIndx;
            curWithdrawalIndx++;

            MonetaryAmount newSubtotal = Money.of(0, withdrawalSubtotal.getCurrency());

            for (int j = 0; j <= curWithdrawalIndx; j++) {
              newSubtotal = newSubtotal.add(param.getWithdrawal(j).getAmount());
            }

            withdrawalSubtotal = newSubtotal;

          }

        }
      }

      LoanParameter withdrawalParam = LoanParameterBuilder.createBuilder()
              .loanAmount(withdrawalSubtotal)
              .loanTerm(param.getLoanTerm())
              .numberOfCompoundingPeriods(param.getNumberOfCompoundingPeriods())
              .nominalInterestRate(param.getNominalInterestRate())
              .build();

      MonetaryAmount paymentAmount = calculateInstallmentAmount(withdrawalParam);

      MonetaryAmount interest     = balance.multiply(irr);
      MonetaryAmount principal    = paymentAmount.subtract(interest);
      MonetaryAmount beginBalance = balance;
      MonetaryAmount endBalance;
      LocalDate paymentDate;

      if(i == 0){
        paymentDate = getNextDueDate(param.getWithdrawal(0).getWithdrawalDate(), loanParameter.getDueDateMode());
      } else {
        Installment prevInstallment = amortizedTable.get(i - 1);
        paymentDate = getNextDueDate(prevInstallment.getDueDate(), loanParameter.getDueDateMode());
      }

      // if new withdrawal, new begin bal = prev balance + withdrawal amount, but interest is calculated based on the prev balance
      if(curWithdrawalIndx > prevWithdrawalIndx){
        balance = balance.add(param.getWithdrawal(curWithdrawalIndx).getAmount());
        beginBalance = balance;
        prevWithdrawalIndx = curWithdrawalIndx;
      }

      // the final installment amount = prev balance + interest
      if(i + 1 == param.getNumberOfPeriods()){
        paymentAmount = beginBalance.add(interest);
        principal     = paymentAmount.subtract(interest);
      }

      endBalance = balance.subtract(principal);

      Installment p = new Installment();

      p.setDueDate( paymentDate);
      p.setAmount(paymentAmount);
      p.setPrincipal(principal);
      p.setInterest(interest);
      p.setInstallmentNumber(i + 1);
      p.setBeginBalance(beginBalance);
      p.setEndBalance(endBalance);

      amortizedTable.add(p);

      balance = balance.subtract(principal);
    }

    return amortizedTable;
  }

  private boolean isNewWithdrawal(LocalDate curDate, LocalDate withdrawalDate){
    return curDate.getYear() == withdrawalDate.getYear() && curDate.getMonth().compareTo(withdrawalDate.getMonth()) >= 0;
  }

  public abstract MonetaryAmount calculateInstallmentAmount(LoanParameter param);

  private double irr(LoanParameter param) {
    MonetaryAmount pmt = calculateInstallmentAmount(param);
    MonetaryAmount[] values = new MonetaryAmount[param.getNumberOfPeriods() + 1];
    values[0] = param.getLoanAmount().multiply(-1);
    int npr = param.getNumberOfPeriods();

    for (int i = 1; i <= npr; i++) {
      values[i] = pmt;
    }

    BigDecimal rateOfReturn = IRRCalculator.irr(values, BigDecimal.valueOf(0.1), param.getScale(), param.getRoundingMode());

    return rateOfReturn.doubleValue();
  }

  private static LocalDate getNextDueDate(LocalDate currentDueDate, LoanParameter.DueDateMode dueDateMode){
    switch (dueDateMode){
      case FIXED:
        return currentDueDate.plusMonths(1);
      case END_OF_MONTH:
        return currentDueDate.plusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
      default:
        throw new IllegalArgumentException("Unsupported due date mode");
    }
  }
}

