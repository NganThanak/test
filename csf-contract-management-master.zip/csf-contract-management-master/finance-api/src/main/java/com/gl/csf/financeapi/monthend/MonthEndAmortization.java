package com.gl.csf.financeapi.monthend;

import com.gl.csf.financeapi.paymentschedule.Installment;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;
import org.javamoney.moneta.Money;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.time.temporal.ChronoUnit.DAYS;
import static java.time.temporal.ChronoUnit.MONTHS;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 25/11/2017.
 */
public class MonthEndAmortization {
  public static List<InstallmentMonthEndAmortizationEntry> amortizeInstallments(LocalDate startDate, MonetaryAmount financeAmount,
                                                                                int paymentFrequency, int term, BigDecimal monthlyFlatRate,
                                                                                int amountScale, int bigDecimalRoundingMode, LocalDate firstDueDate, LoanParameter.DueDateMode dueDateMode){
    final MonetaryAmount zero = Money.of(0, financeAmount.getCurrency());
    final List<InstallmentMonthEndAmortizationEntry> result = new ArrayList<>();
    final List<Installment> installments = generatePaymentSchedule(startDate, financeAmount, paymentFrequency, term, monthlyFlatRate, firstDueDate, dueDateMode);

    final Installment firstInstallment = installments.stream().findFirst()
            .orElseThrow(() -> new IllegalStateException("Couldn't find first installment"));

    // Prior to first installment
    AmortizedEntry amortizedEntry = interpolateSingleEntry(startDate, startDate, startDate.withDayOfMonth(startDate.lengthOfMonth()), firstDueDate,
            zero, firstInstallment.getInterest(), zero, firstInstallment.getPrincipal(), amountScale, bigDecimalRoundingMode);

    // Keep track of the last result for accumulation of interest, principal and remaining interest
    AccumulatedAmortizedEntry lastResult = new AccumulatedAmortizedEntry(amortizedEntry,
            amortizedEntry.getInterest(), amortizedEntry.getPrincipal(), financeAmount.subtract(amortizedEntry.getPrincipal()));
    // Add to result collection
    result.add(new InstallmentMonthEndAmortizationEntry(
            new Installment(startDate, 0, zero, zero, zero, zero, zero), lastResult));

    // From first due date to the last due date
    for(int i = 0 ; i + 1 < installments.size() ; i++){
      Installment currentInstallment = installments.get(i);
      Installment nextInstallment = installments.get(i + 1);
      LocalDate currentInstallmentDate = currentInstallment.getDueDate();
      LocalDate nextInstallmentDate = nextInstallment.getDueDate();

      LocalDate previousDueDate = (i == 0) ? startDate : installments.get(i - 1).getDueDate();

      amortizedEntry = interpolateSingleEntry(previousDueDate, currentInstallmentDate, currentInstallmentDate.withDayOfMonth(currentInstallmentDate.lengthOfMonth()),
              nextInstallmentDate, currentInstallment.getInterest(), nextInstallment.getInterest(), currentInstallment.getPrincipal(), nextInstallment.getPrincipal(),
              amountScale, bigDecimalRoundingMode);

      // Add to result collection
      lastResult = new AccumulatedAmortizedEntry(amortizedEntry,
              lastResult.getAccumulatedInterest().add(amortizedEntry.getInterest()),
              lastResult.getAccumulatedPrincipal().add(amortizedEntry.getPrincipal()),
              lastResult.getRemainingBalance().subtract(amortizedEntry.getPrincipal()));

      result.add(new InstallmentMonthEndAmortizationEntry(currentInstallment, lastResult));
    }

    // From last due date to the end of the month
    int lastIndexOfInstallment = installments.size() - 1;
    Installment lastInstallment = installments.get(lastIndexOfInstallment);

    LocalDate dueDateBeforeLastDueDate = (lastIndexOfInstallment - 1) < 0
            ? startDate : installments.get(lastIndexOfInstallment - 1).getDueDate();
    LocalDate lastInstallmentDueDate = lastInstallment.getDueDate();
    LocalDate endOfMonthOfLastDueDate = lastInstallmentDueDate.withDayOfMonth(lastInstallmentDueDate.lengthOfMonth());

    amortizedEntry = interpolateSingleEntry(dueDateBeforeLastDueDate, lastInstallmentDueDate,
            endOfMonthOfLastDueDate, endOfMonthOfLastDueDate,
            lastInstallment.getInterest(), zero, lastInstallment.getPrincipal(), zero,
            amountScale, bigDecimalRoundingMode);

    lastResult = new AccumulatedAmortizedEntry(amortizedEntry,
            lastResult.getAccumulatedInterest().add(amortizedEntry.getInterest()),
            lastResult.getAccumulatedPrincipal().add(amortizedEntry.getPrincipal()),
            lastResult.getRemainingBalance().subtract(amortizedEntry.getPrincipal()));
    // Add to result collection
    result.add(new InstallmentMonthEndAmortizationEntry(lastInstallment, lastResult));

    return result;
  }

  public static List<AccumulatedAmortizedEntry> amortize(LocalDate startDate, MonetaryAmount financeAmount,
                                                         int paymentFrequency, int term, BigDecimal monthlyFlatRate,
                                                         int amountScale, int bigDecimalRoundingMode, LocalDate firstDueDate, LoanParameter.DueDateMode dueDateMode){
    final MonetaryAmount zero = Money.of(0, financeAmount.getCurrency());
    final List<AccumulatedAmortizedEntry> result = new ArrayList<>();
    final List<Installment> installments = generatePaymentSchedule(startDate, financeAmount, paymentFrequency, term, monthlyFlatRate, firstDueDate, dueDateMode);
    final Installment firstInstallment = installments.stream().findFirst()
            .orElseThrow(() -> new IllegalStateException("Couldn't find first installment"));

    // From contract date to first due date
    List<AmortizedEntry> contractDateToFirstDueDateRealization = interpolateMonthEndAmortization(
            startDate, startDate, firstDueDate,
            zero, firstInstallment.getInterest(),
            zero, firstInstallment.getPrincipal(),
            amountScale, bigDecimalRoundingMode);

    result.addAll(createAccumulatedAmortizedEntries(contractDateToFirstDueDateRealization, zero, zero, financeAmount));

    // From first due date to the last due date
    for(int i = 0 ; i + 1 < installments.size() ; i++){
      Installment currentInstallment = installments.get(i);
      Installment nextInstallment = installments.get(i + 1);
      LocalDate currentInstallmentDate = currentInstallment.getDueDate();
      LocalDate nextInstallmentDate = nextInstallment.getDueDate();

      LocalDate previousDueDate = (i == 0) ? startDate : installments.get(i - 1).getDueDate();

      List<AmortizedEntry> inBetweenAmortizations = interpolateMonthEndAmortization(
              previousDueDate, currentInstallmentDate, nextInstallmentDate,
              currentInstallment.getInterest(), nextInstallment.getInterest(),
              currentInstallment.getPrincipal(), nextInstallment.getPrincipal(), amountScale, bigDecimalRoundingMode);

      AccumulatedAmortizedEntry lastResult = result.get(result.size() - 1);
      result.addAll(createAccumulatedAmortizedEntries(inBetweenAmortizations,
              lastResult.getAccumulatedInterest(), lastResult.getAccumulatedPrincipal(), lastResult.getRemainingBalance()));
    }

    // From last due date to the end of the month
    int lastIndexOfInstallment = installments.size() - 1;
    Installment lastInstallment = installments.get(lastIndexOfInstallment);

    LocalDate dueDateBeforeLastDueDate = (lastIndexOfInstallment - 1) < 0
            ? startDate : installments.get(lastIndexOfInstallment - 1).getDueDate();
    LocalDate lastInstallmentDueDate = lastInstallment.getDueDate();
    LocalDate endOfMonthOfLastDueDate = lastInstallmentDueDate.withDayOfMonth(lastInstallmentDueDate.lengthOfMonth());

    AmortizedEntry lastDueDateToMonthEndAmortizedEntry = interpolateSingleEntry(dueDateBeforeLastDueDate, lastInstallmentDueDate,
            endOfMonthOfLastDueDate, endOfMonthOfLastDueDate,
            lastInstallment.getInterest(), zero, lastInstallment.getPrincipal(), zero,
            amountScale, bigDecimalRoundingMode);

    AccumulatedAmortizedEntry lastResult = result.get(result.size() - 1);
    result.addAll(createAccumulatedAmortizedEntries(Collections.singletonList(lastDueDateToMonthEndAmortizedEntry),
            lastResult.getAccumulatedInterest(), lastResult.getAccumulatedPrincipal(), lastResult.getRemainingBalance()));
    return result;
  }

  private static List<Installment> generatePaymentSchedule(LocalDate startDate, MonetaryAmount financeAmount,
                                                           int paymentFrequency, int term, BigDecimal monthlyFlatRate, LocalDate firstDueDate, LoanParameter.DueDateMode dueDateMode){
    final LoanParameter loanParameter = LoanParameterBuilder.createBuilder()
            .numberOfCompoundingPeriods(paymentFrequency)
            .loanAmount(financeAmount)
            .loanTerm(term / 12.0)
            .nominalInterestRate(monthlyFlatRate.setScale(4, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(12))
                    .divide(BigDecimal.valueOf(100), BigDecimal.ROUND_HALF_UP).doubleValue())
            .contractStartDate(startDate)
            .dueDate(firstDueDate)
            .dueDateMode(dueDateMode)
            .build();
    return new SimpleAmortization().generatePaymentSchedule(loanParameter);
  }

  private static List<AmortizedEntry> interpolateMonthEndAmortization(LocalDate previousDue, LocalDate from, LocalDate to,
                                                                      MonetaryAmount interestAtFrom, MonetaryAmount interestAtTo,
                                                                      MonetaryAmount principalAtFrom, MonetaryAmount principalAtTo,
                                                                      int amountScale, int bigDecimalRoundingMode){
    List<AmortizedEntry> result = new ArrayList<>();
    long monthBetweenFromTo = MONTHS.between(from, to);
    if(monthBetweenFromTo <= 0)
      return result;

    // Populate result
    LocalDate currentMonthEndDate = from.withDayOfMonth(from.lengthOfMonth());
    while(to.isAfter(currentMonthEndDate)){
      AmortizedEntry amortizedEntry = interpolateSingleEntry(previousDue, from, currentMonthEndDate, to, interestAtFrom, interestAtTo,
              principalAtFrom, principalAtTo, amountScale, bigDecimalRoundingMode);

      result.add(amortizedEntry);

      // Change current month end date
      currentMonthEndDate = currentMonthEndDate.plusMonths(1);
      // Make sure that we are at the end of the month after adding 1 month above
      currentMonthEndDate = currentMonthEndDate.withDayOfMonth(currentMonthEndDate.lengthOfMonth());
    }

    return result;
  }

  private static AmortizedEntry interpolateSingleEntry(LocalDate previousDate, LocalDate currentDate,
                                                       LocalDate interpolatedDate, LocalDate nextDate,
                                                       MonetaryAmount currentInterest, MonetaryAmount nextInterest,
                                                       MonetaryAmount currentPrincipal, MonetaryAmount nextPrincipal,
                                                       int amountScale, int bigDecimalRoundingMode){
    // TODO: Invariance
    LocalDate previousEndOfMonth = previousDate.withDayOfMonth(previousDate.lengthOfMonth());
    BigDecimal l1 = BigDecimal.valueOf(DAYS.between(previousEndOfMonth, currentDate) - 1);
    BigDecimal l2 = BigDecimal.valueOf(DAYS.between(previousDate, currentDate));
    // Prevent divide by zero
    BigDecimal normalizedCurrentFactor = l2.compareTo(BigDecimal.ZERO) <= 0
            ? BigDecimal.ZERO : l1.divide(l2, 9, BigDecimal.ROUND_HALF_UP);

    BigDecimal l3 = BigDecimal.valueOf(DAYS.between(currentDate, interpolatedDate) + 1);
    BigDecimal l4 = BigDecimal.valueOf(DAYS.between(currentDate, nextDate));
    // Prevent divide by zero
    BigDecimal normalizedNextFactor = l4.compareTo(BigDecimal.ZERO) <= 0
            ? BigDecimal.ZERO : l3.divide(l4, 9, BigDecimal.ROUND_HALF_UP);

    MonetaryAmount interest = currentInterest.multiply(normalizedCurrentFactor)
            .add(nextInterest.multiply(normalizedNextFactor));

    MonetaryAmount principal = currentPrincipal.multiply(normalizedCurrentFactor)
            .add(nextPrincipal.multiply(normalizedNextFactor));

    MonetaryAmount scaledInterest = Money.of(interest.getNumber().numberValue(BigDecimal.class)
            .setScale(amountScale, bigDecimalRoundingMode), interest.getCurrency());

    MonetaryAmount scaledPrincipal = Money.of(principal.getNumber().numberValue(BigDecimal.class)
            .setScale(amountScale, bigDecimalRoundingMode), principal.getCurrency());

    return new AmortizedEntry(interpolatedDate, scaledInterest, scaledPrincipal);
  }

  private static List<AccumulatedAmortizedEntry> createAccumulatedAmortizedEntries(List<AmortizedEntry> amortizedEntries,
                                                                                   MonetaryAmount accumulatedInterest, MonetaryAmount accumulatedPrincipal, MonetaryAmount remainingBalance){
    List<AccumulatedAmortizedEntry> result = new ArrayList<>();

    for(AmortizedEntry amortizedEntry : amortizedEntries){
      accumulatedInterest = accumulatedInterest.add(amortizedEntry.getInterest());
      accumulatedPrincipal = accumulatedPrincipal.add(amortizedEntry.getPrincipal());
      remainingBalance = remainingBalance.subtract(amortizedEntry.getPrincipal());

      AccumulatedAmortizedEntry accumulatedAmortizedEntry = new AccumulatedAmortizedEntry(amortizedEntry,
              accumulatedInterest, accumulatedPrincipal, remainingBalance);

      result.add(accumulatedAmortizedEntry);
    }

    return result;
  }
}
