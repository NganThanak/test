package com.gl.csf.financeapi.monthend;

import javax.money.MonetaryAmount;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 26/11/2017.
 */
public class AccumulatedAmortizedEntry {
  private AmortizedEntry amortizedEntry;
  private MonetaryAmount accumulatedInterest;
  private MonetaryAmount accumulatedPrincipal;
  private MonetaryAmount remainingBalance;

  AccumulatedAmortizedEntry(AmortizedEntry amortizedEntry, MonetaryAmount accumulatedInterest,
                            MonetaryAmount accumulatedPrincipal, MonetaryAmount remainingBalance) {
    this.amortizedEntry = amortizedEntry;
    this.accumulatedInterest = accumulatedInterest;
    this.accumulatedPrincipal = accumulatedPrincipal;
    this.remainingBalance = remainingBalance;
  }

  public AmortizedEntry getAmortizedEntry() {
    return amortizedEntry;
  }

  public MonetaryAmount getAccumulatedInterest() {
    return accumulatedInterest;
  }

  public MonetaryAmount getAccumulatedPrincipal() {
    return accumulatedPrincipal;
  }

  public MonetaryAmount getRemainingBalance() {
    return remainingBalance;
  }
}
