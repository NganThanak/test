package com.gl.csf.financeapi.paymentschedule;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LoanParameter {

  public enum DueDateMode {
    FIXED, END_OF_MONTH
  }

  // Financed amount
  private MonetaryAmount loanAmount;

  // For revolving loan withdrawal
  private List<Withdrawal> withdrawals = new ArrayList<>();

  // Quoted interest rate per year
  private double nominalInterestRate;

  /**
   * Term of a loan in years
   */
  private double loanTerm;

  /**
   * Number of periods for the given compounding method.
   * e.g. for monthly compounding, 1 year = 12 months,
   * for quarterly compounding, 1year = 4 quarters,
   * for daily compounding, 1year = 365 days
   * for weekly compounding 1year = 52 weeks
   */
  private int numberOfCompoundingPeriods;

  // First due Date
  private LocalDate dueDate;
  private LocalDate contractStartDate;

  // precision
  private int scale = 10;
  // default rounding mode
  private int roundingMode = BigDecimal.ROUND_HALF_UP;
  private DueDateMode dueDateMode;

  LoanParameter(LoanParameterBuilder builder) {
    loanAmount = builder.getLoanAmount();
    withdrawals = builder.getWithdrawals();
    loanTerm = builder.getLoanTerm();
    nominalInterestRate = builder.getNominalInterestRate();
    numberOfCompoundingPeriods = builder.getNumberOfCompoundingPeriods();
    scale = builder.getScale();
    roundingMode = builder.getRoundingMode();
    dueDate = builder.getDueDate();
    contractStartDate = builder.getContractStartDate();
    dueDateMode = builder.getDueDateMode();
  }

  double getLoanTerm() {
    return loanTerm;
  }

  MonetaryAmount getLoanAmount() {
    return loanAmount;
  }

  List<Withdrawal> getWithdrawals() {
    return withdrawals;
  }

  Withdrawal getWithdrawal(int index) {
    return index >= 0 && index < withdrawals.size() ? withdrawals.get(index) : null;
  }

  double getNominalInterestRate() {
    return nominalInterestRate;
  }

  int getNumberOfPeriods() {
    return (int) Math.round(loanTerm * getNumberOfCompoundingPeriods());
  }

  LocalDate getDueDate() {
    return dueDate;
  }

  int getScale() {
    return scale;
  }

  int getRoundingMode() {
    return roundingMode;
  }

  int getNumberOfCompoundingPeriods() {
    return numberOfCompoundingPeriods;
  }

  LocalDate getContractStartDate() {
    return contractStartDate;
  }

  DueDateMode getDueDateMode() {
    return dueDateMode;
  }

  /**
   * @return number of compounding periods per year according to the compounding method.
   */
  static int getNumberOfCompoundingPeriods(Compounding compounding) {
    int numberOfCompoundingPeriods; // i.e. yearly

    switch (compounding) {
      case DAILY:
        // compounding daily, supposed 1 year = 365 days, some consider 1 year = 360 days and 30days in a month.
        numberOfCompoundingPeriods = 365;
        break;

      case WEEKLY:
        // compounding weekly.
        numberOfCompoundingPeriods = 52;
        break;

      case MONTHLY:
        // compounding monthly.
        numberOfCompoundingPeriods = 12;
        break;

      case QUARTERLY:
        // compounding quarterly
        numberOfCompoundingPeriods = 4;
        break;

      case SEMIANNUALY:
        // compounding yearly.
        numberOfCompoundingPeriods = 2;
        break;
      case YEARLY:
        numberOfCompoundingPeriods = 1;
        break;

      default:
        numberOfCompoundingPeriods = 1;
        break;
    }

    return numberOfCompoundingPeriods;
  }
}
