package com.gl.csf.financeapi.paymentschedule;

/**
 * Created by Calvin Phibol on 8/28/2017.
 */
public enum Compounding {
    DAILY, WEEKLY, MONTHLY, QUARTERLY, SEMIANNUALY, YEARLY
}


