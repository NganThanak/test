package com.gl.csf.financeapi.paymentschedule;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

public class Installment {
    private LocalDate dueDate;
    private int installmentNumber;
    private MonetaryAmount beginBalance; // amount before paymentinformation
    private MonetaryAmount endBalance; // endBalance = beginBalance - principal, i.e. amount after paymentinformation
    private MonetaryAmount interest;  // interest = beginBalance x ratePerPeriod
    private MonetaryAmount principal;  // principal = amount - interest
    private MonetaryAmount amount; // amount = interest + principal; // given value

    public Installment(LocalDate dueDate, int installmentNumber, MonetaryAmount beginBalance, MonetaryAmount endBalance, MonetaryAmount interest, MonetaryAmount principal, MonetaryAmount amount) {
        this.dueDate = dueDate;
        this.installmentNumber = installmentNumber;
        this.beginBalance = beginBalance;
        this.endBalance = endBalance;
        this.interest = interest;
        this.principal = principal;
        this.amount = amount;
    }

    public Installment(){
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public int getInstallmentNumber() {
        return installmentNumber;
    }

    void setInstallmentNumber(int installmentNumber) {
        this.installmentNumber = installmentNumber;
    }

    MonetaryAmount getBeginBalance() {
        return beginBalance;
    }

    void setBeginBalance(MonetaryAmount beginBalance) {
        this.beginBalance = beginBalance;
    }

    public MonetaryAmount getEndBalance() {
        return endBalance;
    }

    void setEndBalance(MonetaryAmount endBalance) {
        this.endBalance = endBalance;
    }

    public MonetaryAmount getInterest() {
        return interest;
    }

    public void setInterest(MonetaryAmount interest) {
        this.interest = interest;
    }

    public MonetaryAmount getPrincipal() {
        return principal;
    }

    void setPrincipal(MonetaryAmount principal) {
        this.principal = principal;
    }

    public MonetaryAmount getAmount() {
        return amount;
    }

    public void setAmount(MonetaryAmount amount) {
        this.amount = amount;
    }
}
