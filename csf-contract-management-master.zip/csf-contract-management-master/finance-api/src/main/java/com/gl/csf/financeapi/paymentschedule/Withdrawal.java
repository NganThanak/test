package com.gl.csf.financeapi.paymentschedule;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Created by Calvin Phibol on 8/31/2017.
 */
public class Withdrawal {
  private MonetaryAmount amount;
  private LocalDate withdrawalDate;

  public Withdrawal(MonetaryAmount amt, LocalDate withdrawalDate) {
    this.amount = amt;
    this.withdrawalDate = withdrawalDate;
  }

  public MonetaryAmount getAmount() {
    return amount;
  }

  public LocalDate getWithdrawalDate() {
    return withdrawalDate;
  }
}
