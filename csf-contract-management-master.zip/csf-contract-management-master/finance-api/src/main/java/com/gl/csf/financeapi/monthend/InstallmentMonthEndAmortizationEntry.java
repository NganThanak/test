package com.gl.csf.financeapi.monthend;

import com.gl.csf.financeapi.paymentschedule.Installment;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 26/11/2017.
 */
public class InstallmentMonthEndAmortizationEntry {
  private Installment installment;
  private AccumulatedAmortizedEntry monthEndAccumulatedAmortizedEntry;

  InstallmentMonthEndAmortizationEntry(Installment installment, AccumulatedAmortizedEntry monthEndAccumulatedAmortizedEntry) {
    this.installment = installment;
    this.monthEndAccumulatedAmortizedEntry = monthEndAccumulatedAmortizedEntry;
  }

  public Installment getInstallment() {
    return installment;
  }

  public AccumulatedAmortizedEntry getMonthEndAccumulatedAmortizedEntry() {
    return monthEndAccumulatedAmortizedEntry;
  }
}
