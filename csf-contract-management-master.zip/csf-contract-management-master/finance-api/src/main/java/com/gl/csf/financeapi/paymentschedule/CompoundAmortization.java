package com.gl.csf.financeapi.paymentschedule;

import javax.money.MonetaryAmount;


public class CompoundAmortization extends Amortization {

  public MonetaryAmount calculateInstallmentAmount(LoanParameter param) {
    double effectiveInterestRate = calculateEffectiveInterestRate(param);
    MonetaryAmount fv = param.getLoanAmount().multiply(Math.pow(1 + effectiveInterestRate, param.getLoanTerm()));
    // calculate like a simple interest.
    MonetaryAmount compoundInterestPerPeriod = fv.subtract(param.getLoanAmount()).divide(param.getNumberOfPeriods());

    return compoundInterestPerPeriod.add(param.getLoanAmount().divide(param.getNumberOfPeriods()));
  }

    /*
     * Adjust interest rate according to the compounding method.
	 *
 	 * r = (1 + i/n)^n - 1
	 * where r: effective interest rate
	 *       i: nominal interest rate or stated interest rate per year
	 *       n: number of compounding periods per year,
	 *          i.e. if compounding monthly: n=12, if compounding quarterly: n=4,
	 *               if compounding daily: n=365, if compounding weekly: n=52.
	 * @compoundingMethod: 1: daily, 2: weekly, 3: monthly, 4: quarterly, 5: yearly
	 */
  private static double calculateEffectiveInterestRate(LoanParameter param) {
    return Math.pow(1 + param.getNominalInterestRate() / param.getNumberOfCompoundingPeriods(), param.getNumberOfCompoundingPeriods()) - 1;
  }
}