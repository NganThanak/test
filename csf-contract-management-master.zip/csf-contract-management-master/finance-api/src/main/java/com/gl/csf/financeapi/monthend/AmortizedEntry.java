package com.gl.csf.financeapi.monthend;

import javax.money.MonetaryAmount;
import java.time.LocalDate;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 25/11/2017.
 */
public class AmortizedEntry {
  private LocalDate date;
  private MonetaryAmount interest;
  private MonetaryAmount principal;

  AmortizedEntry(LocalDate date, MonetaryAmount interest, MonetaryAmount principal) {
    this.date = date;
    this.interest = interest;
    this.principal = principal;
  }

  public LocalDate getDate() {
    return date;
  }

  public MonetaryAmount getInterest() {
    return interest;
  }

  public MonetaryAmount getPrincipal() {
    return principal;
  }
}
