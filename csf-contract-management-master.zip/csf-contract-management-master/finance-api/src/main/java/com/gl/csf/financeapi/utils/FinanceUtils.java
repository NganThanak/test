package com.gl.csf.financeapi.utils;

import com.gl.csf.financeapi.paymentschedule.IRRCalculator;
import com.gl.csf.financeapi.paymentschedule.LoanParameter;
import com.gl.csf.financeapi.paymentschedule.LoanParameterBuilder;
import com.gl.csf.financeapi.paymentschedule.SimpleAmortization;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

/**
 * Copyright (c) Group Lease Public Company Limited. All rights reserved. (http://www.grouplease.co.th/)
 * Author: Peeranut Ngaorungsri (peeranut.ng@grouplease.co.th) on 24/11/2017.
 */
public class FinanceUtils {
  public static MonetaryAmount getInstallmentAmount(MonetaryAmount loanAmount, BigDecimal interestRate, int numberOfCompoundingPeriods, double term){
    SimpleAmortization simpleAmortization = new SimpleAmortization();

    LoanParameter loanParameter = LoanParameterBuilder.createBuilder().loanAmount(loanAmount)
            .nominalInterestRate(interestRate.doubleValue())
            .numberOfCompoundingPeriods(numberOfCompoundingPeriods)
            .loanTerm(term)
            .build();

    return simpleAmortization.calculateInstallmentAmount(loanParameter);
  }

  public static BigDecimal getIrr(MonetaryAmount loanAmount, MonetaryAmount installment, int term){
    MonetaryAmount[] cashFlows = new MonetaryAmount[term + 1];
    cashFlows[0] = loanAmount.negate();

    for(int i = 1 ; i < term + 1 ; i++){
      cashFlows[i] = installment;
    }

    return IRRCalculator.irr(cashFlows, BigDecimal.valueOf(0.1), 6, BigDecimal.ROUND_HALF_UP);
  }

  public static LocalDate getFirstDueDate(LocalDate contractDate, int paymentFrequency){
    int dayOfMonth = contractDate.getDayOfMonth();
    // First due date depends on the payment information frequency
    int monthsPerPayment = 12/paymentFrequency;
    Month nextMonth = contractDate.getMonth().plus(monthsPerPayment);
    int year = contractDate.plusMonths(monthsPerPayment).getYear();
    return LocalDate.of(year, nextMonth, dayOfMonth);
  }

  public static LocalDate getFirstDueDateForStaffLoan(LocalDate contractDate, int dueDateCalcPeriod) {
    return contractDate.lengthOfMonth() - contractDate.getDayOfMonth() > dueDateCalcPeriod
      ? contractDate.with(TemporalAdjusters.lastDayOfMonth())
      : contractDate.plusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
  }
}
